# Data Plan

## Firebase Firestore

- **Source:** The user-provided Firebase project `rabta-24267` in region `asia-south1`.
- **Purpose:** Store and synchronize conversation metadata and messages between devices.
- **Collections:** `profiles`, `conversations`, each conversation's `messages` subcollection, and `statuses` (WhatsApp-style 24-hour text/photo statuses shared across devices; large status photos are split into ordered `mediaChunks` subcollection documents). Username discovery is a prefix query over the `profiles` collection's `username` field; the existing exact lookups by email, username, and mobile digits remain in place.
- **Identity and deduplication:** A conversation document ID is built from the two normalized user IDs sorted lexicographically, so both message directions address the same thread.
- **Refresh:** Active conversation and message views use Firestore `onSnapshot` listeners. Every listener returns and runs its unsubscribe function when its React view is left or replaced.
- **Writes:** User-created text, compressed image data, voice data, delivery state, read state, and conversation summaries are written only in response to the user's messaging actions. Failed client writes remain visible locally with a retry control.
- **Media:** Image messages are compressed client-side and stored in Firestore. Voice messages remain available across devices and are chunked when needed.
- **Excluded services:** No Firebase Analytics, billing-only service, advertising service, or paid feature is initialized.

Profile preferences, statuses, and call-history interface state use the artifact's typed actions and artifact database when the private server is reachable. When it is not — the Android APK serves the same client files locally with no server — the client falls back to an on-device localStorage store (`bolo-local-state-v1`) mirroring the same state shapes (see below); the hosted deployment is unaffected.

## Local (no-server) mode — APK fallback (2026-10-17)

- **Trigger:** The client's `backend` facade (`client/src/localBackend.ts`) tries the typed server actions first; the first failure (e.g. the APK's missing `./actions` endpoint) switches the session to local mode. Previously this failure surfaced as the fatal "ایپ نہیں کھل سکی" screen at boot.
- **Stored on-device only:** Profile (photo kept as a data URL), preferences, app-lock secret hash/salt, chat organisation (archive/lock/mute/delete lists, per-chat wallpapers), blocked contacts, chat lists, own statuses (24-hour expiry, photo statuses as data URLs), call log, conversation summaries, and feedback — all in the single `bolo-local-state-v1` localStorage record. Nothing is uploaded anywhere in this mode.
- **Firebase identity:** The local profile's email/username/mobile/photo feed `ensureFirebaseProfile` and all Firestore listeners exactly as the server profile did, so messaging, username search, statuses, and groups keep working over the internet in the APK.

## WhatsApp-style Settings (2026-10-17)

- **Artifact database:** The profile gains a security-notifications toggle, a separate call tone, and auto-download toggles for photos and voice. New tables hold blocked contacts (`blocked_contacts`), user lists and their members (`chat_lists`, `chat_list_members`), and submitted feedback (`feedback`). Change-number writes the existing profile `mobile_number` field through `saveProfile`.
- **Firestore conversation document:** `disappearingBy` maps each participant's safe doc key to their per-chat disappearing-message timer in seconds (0 = off). Messages sent while a timer is on carry an `expiresAt` timestamp; the message listener filters out expired messages so they disappear from the thread.
- **Blocking:** Enforced client-side from the stored blocked list — a blocked contact's incoming messages are hidden and the composer is disabled in that chat.
- **Backup:** Chat backup reads one thread's messages once from Firestore and downloads them as a plain-text file on the device; nothing is uploaded anywhere new.
- **Network usage:** Counted on demand from the user's own Firestore conversations and messages (sent, received, photos, voice totals); no Analytics or paid service is involved.
