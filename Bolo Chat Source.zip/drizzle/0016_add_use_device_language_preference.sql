ALTER TABLE `profiles` ADD COLUMN `use_device_language` integer DEFAULT 0 NOT NULL;
