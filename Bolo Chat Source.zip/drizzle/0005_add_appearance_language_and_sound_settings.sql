ALTER TABLE `profiles` ADD `language` text DEFAULT 'ur' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD `wallpaper` text DEFAULT 'doodle' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD `message_tone` text DEFAULT 'chime' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD `conversation_tones_enabled` integer DEFAULT true NOT NULL;
