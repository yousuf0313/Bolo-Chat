ALTER TABLE `profiles` ADD `about` text NOT NULL DEFAULT 'دستیاب ہوں';
--> statement-breakpoint
ALTER TABLE `profiles` ADD `notifications_enabled` integer NOT NULL DEFAULT 1;
--> statement-breakpoint
ALTER TABLE `profiles` ADD `read_receipts_enabled` integer NOT NULL DEFAULT 1;
--> statement-breakpoint
ALTER TABLE `messages` ADD `message_type` text NOT NULL DEFAULT 'text';
--> statement-breakpoint
ALTER TABLE `messages` ADD `audio_blob_key` text;
--> statement-breakpoint
ALTER TABLE `messages` ADD `audio_duration` integer;
--> statement-breakpoint
CREATE TABLE `statuses` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `body` text NOT NULL,
  `accent` text NOT NULL,
  `created_at` integer NOT NULL,
  `expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `calls` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `contact_name` text NOT NULL,
  `contact_email` text,
  `call_type` text NOT NULL,
  `started_at` integer NOT NULL
);
