ALTER TABLE `profiles` ADD COLUMN `mobile_number` text;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `avatar_blob_key` text;
--> statement-breakpoint
ALTER TABLE `conversations` ADD COLUMN `contact_photo_url` text;
