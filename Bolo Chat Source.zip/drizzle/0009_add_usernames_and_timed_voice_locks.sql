ALTER TABLE `profiles` ADD `username` text NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE `conversations` ADD `contact_username` text;
--> statement-breakpoint
ALTER TABLE `messages` ADD `voice_effect` text NOT NULL DEFAULT 'original';
--> statement-breakpoint
ALTER TABLE `messages` ADD `unlock_at` integer;
--> statement-breakpoint
ALTER TABLE `messages` ADD `password_hash` text;
--> statement-breakpoint
ALTER TABLE `messages` ADD `password_salt` text;
--> statement-breakpoint
ALTER TABLE `messages` ADD `unlocked_at` integer;
