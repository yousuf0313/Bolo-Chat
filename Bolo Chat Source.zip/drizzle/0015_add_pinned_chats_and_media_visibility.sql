ALTER TABLE `profiles` ADD COLUMN `pinned_thread_ids` text DEFAULT '[]' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `media_visibility_enabled` integer DEFAULT 1 NOT NULL;
