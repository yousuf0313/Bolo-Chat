ALTER TABLE `statuses` ADD `status_type` text NOT NULL DEFAULT 'text';
--> statement-breakpoint
ALTER TABLE `statuses` ADD `image_blob_key` text;
