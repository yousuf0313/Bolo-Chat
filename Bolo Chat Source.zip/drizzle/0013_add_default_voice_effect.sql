ALTER TABLE `profiles` ADD COLUMN `default_voice_effect` text DEFAULT 'original' NOT NULL;
