ALTER TABLE `profiles` ADD COLUMN `app_lock_enabled` integer DEFAULT false NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `app_lock_method` text DEFAULT 'none' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `app_lock_hash` text;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `app_lock_salt` text;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `archived_thread_ids` text DEFAULT '[]' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `locked_thread_ids` text DEFAULT '[]' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `muted_thread_ids` text DEFAULT '[]' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `deleted_thread_ids` text DEFAULT '[]' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `thread_wallpapers` text DEFAULT '{}' NOT NULL;
