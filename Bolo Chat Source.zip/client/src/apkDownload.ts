import { Directory, Filesystem } from "@capacitor/filesystem";
import { Browser } from "@capacitor/browser";
import { FileOpener } from "@capawesome-team/capacitor-file-opener";
import { isNativeApp } from "./nativeBiometric";

/* In-app APK download for the update dialog.
 *
 * The old flow handed the GitHub asset URL to the system browser and
 * hoped Android's download manager would save the file and offer to
 * install it. In practice the download finished inside the browser
 * without the file ever landing anywhere the user could open — the app
 * just kept saying "downloading".
 *
 * This module downloads the APK *inside* the app instead, through the
 * Capacitor Filesystem plugin:
 *  - real progress events drive the dialog's progress bar, and the
 *    download promise resolving is what flips the dialog to its
 *    "download complete" state — progress can no longer spin forever;
 *  - on native, the file is written to the app's own storage on the
 *    phone (Directory.Data), so it is saved in one known place;
 *  - on web, the plugin returns the file as a Blob and we hand it to the
 *    browser as a normal file download.
 *
 * `openDownloadedApk` then opens the saved file so Android shows its
 * install prompt; if the saved file cannot be opened directly it falls
 * back to the original download URL in the system browser. */

export type DownloadedApk = {
  /** Native file URI of the saved APK (native only). */
  uri: string | null;
  /** Object URL of the downloaded Blob (web only). */
  blobUrl: string | null;
  fileName: string;
};

/**
 * Download `url` as `fileName`, reporting progress (0–100, or null when
 * the total size is unknown) through `onProgress`. Resolves once the
 * file is fully saved; rejects on any network or write failure so the
 * dialog can show a retry state instead of spinning forever.
 */
export async function downloadApk(url: string, fileName: string, onProgress: (percent: number | null) => void): Promise<DownloadedApk> {
  const listener = await Filesystem.addListener("progress", (status) => {
    if (status.url !== url) return;
    if (status.contentLength > 0) onProgress(Math.min(100, Math.floor((status.bytes / status.contentLength) * 100)));
    else onProgress(null);
  });
  try {
    const result = await Filesystem.downloadFile({
      url,
      path: fileName,
      directory: Directory.Data,
      progress: true,
    });
    onProgress(100);
    if (isNativeApp()) {
      let uri: string | null = result.path ?? null;
      try {
        const resolved = await Filesystem.getUri({ path: fileName, directory: Directory.Data });
        if (resolved.uri) uri = resolved.uri;
      } catch {
        /* keep the path returned by the download itself */
      }
      return { uri, blobUrl: null, fileName };
    }
    if (result.blob) {
      const blobUrl = URL.createObjectURL(result.blob);
      triggerBrowserSave(blobUrl, fileName);
      return { uri: null, blobUrl, fileName };
    }
    throw new Error("download produced no file");
  } finally {
    await listener.remove().catch(() => undefined);
  }
}

/** Save a blob URL through the browser's own download mechanism (web). */
function triggerBrowserSave(blobUrl: string, fileName: string): void {
  const anchor = document.createElement("a");
  anchor.href = blobUrl;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
}

/** Outcome of an Install tap: either the system installer was opened, or
 * a specific failure the dialog can explain to the user. */
export type OpenApkResult =
  | { opened: true }
  | { opened: false; error: "not-found" | "cannot-open" };

/**
 * Open the saved APK so the Android package installer starts.
 *
 * The previous flow handed the saved file's `file://` URI to the Browser
 * plugin (a Chrome Custom Tab). A Custom Tab cannot read the app's
 * private storage and cannot install packages, so the Install tap
 * silently died — the download completed but nothing ever installed.
 *
 * Now, on native, the FileOpener plugin opens the file the way Android
 * requires: it builds a `content://` URI for the file through
 * FileProvider, then starts an ACTION_VIEW intent with MIME type
 * `application/vnd.android.package-archive` and
 * FLAG_GRANT_READ_URI_PERMISSION, so the system installer can read and
 * install the downloaded APK. The saved file is verified with `stat`
 * first: a missing or empty file returns `not-found` so the dialog can
 * show a clear error and offer a fresh download instead of a dead tap.
 * If the native opener is unavailable (an older APK build), the release
 * page opens in the system browser as a fallback; if that also fails,
 * `cannot-open` is returned so the dialog can say so.
 *
 * Web: the downloaded blob is saved again through the browser.
 */
export async function openDownloadedApk(downloaded: DownloadedApk, fallbackUrl: string | null): Promise<OpenApkResult> {
  if (downloaded.blobUrl) {
    triggerBrowserSave(downloaded.blobUrl, downloaded.fileName);
    return { opened: true };
  }
  if (isNativeApp() && downloaded.uri) {
    try {
      const stat = await Filesystem.stat({ path: downloaded.fileName, directory: Directory.Data });
      if (!stat || stat.size <= 0) return { opened: false, error: "not-found" };
    } catch {
      return { opened: false, error: "not-found" };
    }
    try {
      await FileOpener.openFile({ path: downloaded.uri, mimeType: "application/vnd.android.package-archive" });
      return { opened: true };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (/does not exist/i.test(message)) return { opened: false, error: "not-found" };
      /* opener unavailable in this build — fall through to the browser fallback */
    }
  }
  if (fallbackUrl) {
    try {
      await Browser.open({ url: fallbackUrl });
      return { opened: true };
    } catch {
      try {
        window.open(fallbackUrl, "_blank", "noopener,noreferrer");
        return { opened: true };
      } catch {
        return { opened: false, error: "cannot-open" };
      }
    }
  }
  return { opened: false, error: downloaded.uri ? "cannot-open" : "not-found" };
}
