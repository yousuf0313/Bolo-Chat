import { Directory, Filesystem } from "@capacitor/filesystem";
import { Browser } from "@capacitor/browser";
import { isNativeApp } from "./nativeBiometric";

/* In-app APK download for the update dialog.
 *
 * The old flow handed the GitHub asset URL to the system browser and
 * hoped Android's download manager would save the file and offer to
 * install it. In practice the download finished inside the browser
 * without the file ever landing anywhere the user could open — the app
 * just kept saying "downloading".
 *
 * This module downloads the APK *inside* the app instead, through the
 * Capacitor Filesystem plugin:
 *  - real progress events drive the dialog's progress bar, and the
 *    download promise resolving is what flips the dialog to its
 *    "download complete" state — progress can no longer spin forever;
 *  - on native, the file is written to the app's own storage on the
 *    phone (Directory.Data), so it is saved in one known place;
 *  - on web, the plugin returns the file as a Blob and we hand it to the
 *    browser as a normal file download.
 *
 * `openDownloadedApk` then opens the saved file so Android shows its
 * install prompt; if the saved file cannot be opened directly it falls
 * back to the original download URL in the system browser. */

export type DownloadedApk = {
  /** Native file URI of the saved APK (native only). */
  uri: string | null;
  /** Object URL of the downloaded Blob (web only). */
  blobUrl: string | null;
  fileName: string;
};

/**
 * Download `url` as `fileName`, reporting progress (0–100, or null when
 * the total size is unknown) through `onProgress`. Resolves once the
 * file is fully saved; rejects on any network or write failure so the
 * dialog can show a retry state instead of spinning forever.
 */
export async function downloadApk(url: string, fileName: string, onProgress: (percent: number | null) => void): Promise<DownloadedApk> {
  const listener = await Filesystem.addListener("progress", (status) => {
    if (status.url !== url) return;
    if (status.contentLength > 0) onProgress(Math.min(100, Math.floor((status.bytes / status.contentLength) * 100)));
    else onProgress(null);
  });
  try {
    const result = await Filesystem.downloadFile({
      url,
      path: fileName,
      directory: Directory.Data,
      progress: true,
    });
    onProgress(100);
    if (isNativeApp()) {
      let uri: string | null = result.path ?? null;
      try {
        const resolved = await Filesystem.getUri({ path: fileName, directory: Directory.Data });
        if (resolved.uri) uri = resolved.uri;
      } catch {
        /* keep the path returned by the download itself */
      }
      return { uri, blobUrl: null, fileName };
    }
    if (result.blob) {
      const blobUrl = URL.createObjectURL(result.blob);
      triggerBrowserSave(blobUrl, fileName);
      return { uri: null, blobUrl, fileName };
    }
    throw new Error("download produced no file");
  } finally {
    await listener.remove().catch(() => undefined);
  }
}

/** Save a blob URL through the browser's own download mechanism (web). */
function triggerBrowserSave(blobUrl: string, fileName: string): void {
  const anchor = document.createElement("a");
  anchor.href = blobUrl;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
}

/**
 * Open the saved APK so the system installer starts. Native: open the
 * file URI through the Browser plugin (hands it to Android, which routes
 * .apk files to the package installer). Web: save/open the blob again.
 * Falls back to `fallbackUrl` in the system browser when the saved file
 * cannot be opened, so the tap never silently dies.
 */
export async function openDownloadedApk(downloaded: DownloadedApk, fallbackUrl: string | null): Promise<void> {
  if (downloaded.blobUrl) {
    triggerBrowserSave(downloaded.blobUrl, downloaded.fileName);
    return;
  }
  if (downloaded.uri) {
    try {
      await Browser.open({ url: downloaded.uri });
      return;
    } catch {
      /* fall through to the browser download fallback */
    }
  }
  if (fallbackUrl) {
    try {
      await Browser.open({ url: fallbackUrl });
      return;
    } catch {
      window.open(fallbackUrl, "_blank", "noopener,noreferrer");
    }
  }
}
