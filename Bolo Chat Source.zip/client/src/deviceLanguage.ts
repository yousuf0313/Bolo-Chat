/* Device-language detection, shared by the app UI and the on-device
 * backend so a brand-new profile follows the phone's language from the
 * very first moment it is created — not only after onboarding saves
 * preferences. */

export const SUPPORTED_LANGUAGE_CODES = [
  "ur", "en", "hi", "ar", "fa", "ps", "tr", "es", "fr", "de", "pt", "ru",
  "bn", "id", "ms", "zh", "ja", "ko", "it", "nl", "th", "vi", "sw", "uk", "pl",
] as const;

const SUPPORTED = new Set<string>(SUPPORTED_LANGUAGE_CODES);

/** Map one BCP-47 locale tag ("en-US", "ur_PK", "in-ID"…) to a supported
 *  language code, or null when the app has no translation for it. */
export function languageForLocaleTag(tag: string): string | null {
  const primary = tag.trim().toLowerCase().replace(/_/g, "-").split("-")[0] ?? "";
  // "in" is the legacy Java/Android code for Indonesian ("id").
  const normalized = primary === "in" ? "id" : primary;
  return SUPPORTED.has(normalized) ? normalized : null;
}

/** The app language matching the device's own language settings: the
 *  first of the device's preferred languages the app supports, else
 *  English. Read live from navigator.languages / navigator.language,
 *  which reflect the device locale in both the browser and the APK. */
export function detectDeviceLanguage(): string {
  try {
    const tags = [...(navigator.languages ?? []), navigator.language ?? ""];
    for (const tag of tags) {
      if (!tag) continue;
      const match = languageForLocaleTag(tag);
      if (match) return match;
    }
  } catch { /* no locale information available — use the fallback */ }
  return "en";
}
