/* The version of this build of Easy Chat.
 *
 * The APK build pipeline overwrites this value for every release build
 * (matching the GitHub release tag, e.g. tag "v1.0.123" -> "1.0.123"), so
 * an installed copy always knows which version it is. The in-app update
 * check in ./updateCheck compares this against the latest GitHub release;
 * Settings shows it so the user can see which version they are running. */
export const APP_VERSION = "1.0.0";
