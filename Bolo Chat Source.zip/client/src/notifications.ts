import { isNativeApp } from "./nativeBiometric";

/* New-message notifications.
 *
 * Inside the Android APK the app shows real phone notifications through
 * @capacitor/local-notifications; on the web it uses the Web Notifications
 * API. Both paths behave the same way for the user:
 *
 * - One notification per chat. When more messages arrive in the same chat
 *   the existing notification is updated in place, and its text carries
 *   the unread count ("3 نئے پیغامات · <latest preview>") — the way
 *   WhatsApp groups bursts from one sender into a single notification.
 * - The title is the sender's name, the body a preview of the message.
 * - Tapping the notification opens exactly that chat.
 *
 * Notifications are raised by the Firestore conversation listener in
 * App.tsx while the app is open or in the background (the WebView and its
 * listeners keep running). A completely killed app cannot be woken by a
 * local notification plugin — that needs a push server (FCM), which is
 * developer/backend work outside this web artifact. */

type OpenChatHandler = (conversationId: string) => void;

let openHandler: OpenChatHandler | null = null;
let nativeListenerReady = false;
const webNotifications = new Map<string, Notification>();

function notificationIdFor(conversationId: string): number {
  let hash = 0;
  for (let i = 0; i < conversationId.length; i += 1) {
    hash = (Math.imul(31, hash) + conversationId.charCodeAt(i)) | 0;
  }
  return (Math.abs(hash) % 900_000) + 1000;
}

/** Register the tap handler and ask for notification permission once. */
export async function initMessageNotifications(onOpenChat: OpenChatHandler): Promise<void> {
  openHandler = onOpenChat;
  if (isNativeApp()) {
    try {
      const { LocalNotifications } = await import("@capacitor/local-notifications");
      const permission = await LocalNotifications.requestPermissions();
      if (permission.display !== "granted") return;
      try {
        await LocalNotifications.createChannel({
          id: "bolo-messages",
          name: "Bolo Chat — نئے پیغامات",
          description: "Bolo Chat کے نئے پیغامات کی اطلاعات",
          importance: 5,
          visibility: 1,
          vibration: true,
        });
      } catch { /* channel creation is best-effort (Android 8+) */ }
      if (!nativeListenerReady) {
        nativeListenerReady = true;
        await LocalNotifications.addListener("localNotificationActionPerformed", (action) => {
          const extra = action.notification.extra as { conversationId?: unknown } | undefined;
          const conversationId = typeof extra?.conversationId === "string" ? extra.conversationId : null;
          if (conversationId && openHandler) openHandler(conversationId);
        });
      }
    } catch { /* plugin unavailable in this build — notifications stay off */ }
    return;
  }
  try {
    if ("Notification" in window && Notification.permission === "default") {
      await Notification.requestPermission();
    }
  } catch { /* permission prompt unavailable */ }
}

export async function showMessageNotification(input: {
  conversationId: string;
  title: string;
  body: string;
  unreadCount: number;
  newMessagesLabel: string;
}): Promise<void> {
  const body = input.unreadCount > 1 ? `${input.unreadCount} ${input.newMessagesLabel} · ${input.body}` : input.body;
  if (isNativeApp()) {
    try {
      const { LocalNotifications } = await import("@capacitor/local-notifications");
      const permission = await LocalNotifications.checkPermissions();
      if (permission.display !== "granted") return;
      await LocalNotifications.schedule({
        notifications: [{
          id: notificationIdFor(input.conversationId),
          title: input.title,
          body,
          channelId: "bolo-messages",
          extra: { conversationId: input.conversationId },
        }],
      });
      return;
    } catch { /* fall through to the web API below */ }
  }
  try {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    webNotifications.get(input.conversationId)?.close();
    const notification = new Notification(input.title, { body, tag: input.conversationId });
    notification.onclick = () => {
      window.focus();
      if (openHandler) openHandler(input.conversationId);
      notification.close();
    };
    webNotifications.set(input.conversationId, notification);
  } catch { /* notifications unavailable */ }
}

/** Remove a chat's notification once the user has opened that chat. */
export async function clearMessageNotification(conversationId: string): Promise<void> {
  webNotifications.get(conversationId)?.close();
  webNotifications.delete(conversationId);
  if (isNativeApp()) {
    try {
      const { LocalNotifications } = await import("@capacitor/local-notifications");
      await LocalNotifications.cancel({ notifications: [{ id: notificationIdFor(conversationId) }] });
    } catch { /* plugin unavailable */ }
  }
}

/** Save an image (data URL) to the device: the phone gallery in the APK, a file download on the web. */
export async function saveImageToDevice(dataUrl: string, filename: string): Promise<boolean> {
  if (isNativeApp()) {
    try {
      const { Filesystem, Directory } = await import("@capacitor/filesystem");
      const base64 = dataUrl.includes(",") ? dataUrl.slice(dataUrl.indexOf(",") + 1) : dataUrl;
      try {
        await Filesystem.writeFile({ path: `Pictures/Bolo Chat/${filename}`, data: base64, directory: Directory.ExternalStorage, recursive: true });
        return true;
      } catch {
        await Filesystem.writeFile({ path: filename, data: base64, directory: Directory.Documents, recursive: true });
        return true;
      }
    } catch { /* plugin unavailable — fall through to download */ }
  }
  try {
    const anchor = document.createElement("a");
    anchor.href = dataUrl;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    return true;
  } catch {
    return false;
  }
}
