import { createContext, useContext, useEffect, useMemo, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { fileToBase64 } from "@hatch/space-sdk/client";
import { backend, type AppState } from "./localBackend";
import { isNativeApp, nativeEnrollBiometric, nativeVerifyBiometric } from "./nativeBiometric";
import { APP_VERSION } from "./appVersion";
import { checkForUpdate, type UpdateInfo } from "./updateCheck";
import { openExternalUrl } from "./externalBrowser";
import boloLogoFull from "./assets/bolo-logo.jpg";
import boloLogoIcon from "./assets/bolo-logo.jpg";
import {
createFirebaseGroup,
deleteFirebaseMessage,
ensureFirebaseConversation,
ensureFirebaseProfile,
fetchFirebaseGroupMessagesOnce,
fetchFirebaseMessagesOnce,
fetchFirebaseProfileByEmail,
fetchFirebaseUsage,
firebaseThreadId,
groupConversationId,
hashFirebaseVoicePassword,
imageFileToDataUrl,
listenToFirebaseConversations,
listenToFirebaseDisappearing,
listenToFirebaseGroupMessages,
listenToFirebaseGroups,
listenToFirebaseMessages,
listenToFirebasePresence,
listenToFirebaseStatuses,
lookupFirebaseProfile,
markFirebaseGroupMessagesRead,
markFirebaseMessagesRead,
markFirebaseOffline,
profileImageFileToDataUrl,
publishFirebaseStatus,
searchFirebaseProfilesByUsername,
sendFirebaseGroupMessage,
sendFirebaseMessage,
setFirebaseDisappearing,
setFirebaseGroupMembers,
statusImageFileToDataUrl,
touchFirebasePresence,
updateFirebaseGroup,
type FirebaseContact,
type FirebaseConversation,
type FirebaseMessage,
type FirebaseMessageInput,
type FirebaseStatus,
} from "./firebase";

/* AppState (the getAppState response shape) is defined in ./localBackend,
   which re-exports it from the typed action client. */

/* Instant-open caches: chat threads, profile and contact screens render
   synchronously from the last data seen (this session, or the persisted
   snapshot below) and refresh fresh data in the background — no spinner
   ever blocks a screen that has been opened before. */
const threadMessageCache = new Map<string, FirebaseMessage[]>();
const ensuredConversationKeys = new Set<string>();
const APP_STATE_CACHE_KEY = "chitchat-app-state-v1";
function readCachedAppState(): AppState | null {
  try {
    const raw = window.localStorage.getItem(APP_STATE_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AppState;
    return parsed && typeof parsed === "object" && "profile" in parsed ? parsed : null;
  } catch { return null; }
}
function writeCachedAppState(state: AppState) {
  try { window.localStorage.setItem(APP_STATE_CACHE_KEY, JSON.stringify(state)); } catch { /* storage unavailable/full */ }
}
type Conversation = FirebaseConversation;
type Status = AppState["statuses"][number];
type StatusAccent = Status["accent"];
const STATUS_ACCENTS: StatusAccent[] = ["teal", "emerald", "blue", "violet", "rose", "crimson", "amber", "orange"];
type ViewerSlide = { key: string; status_type: "text" | "photo"; body: string; accent: StatusAccent; image_url: string | null; author_name: string; author_photo: string | null; created_at: string; own: boolean; status_id?: number };
function ownStatusSlide(status: Status, profile: NonNullable<AppState["profile"]>, ownPhoto: string | null): ViewerSlide {
  return { key: `own-${status.id}`, status_type: status.status_type, body: status.body, accent: status.accent, image_url: status.image_url, author_name: profile.display_name, author_photo: ownPhoto, created_at: status.created_at, own: true, status_id: status.id };
}
function contactStatusSlide(status: FirebaseStatus): ViewerSlide {
  return { key: `fb-${status.id}`, status_type: status.status_type, body: status.body, accent: status.accent, image_url: status.image_url, author_name: status.author_name, author_photo: status.author_photo, created_at: status.created_at, own: false };
}
type Tab = "chats" | "status" | "calls" | "settings";
type CallType = "audio" | "video";
type CallTarget = { name: string; email: string | null; photo: string | null; type: CallType };
type Language = "ur" | "en" | "hi" | "ar" | "fa" | "ps" | "tr" | "es" | "fr" | "de" | "pt" | "ru" | "bn" | "id" | "ms" | "zh" | "ja" | "ko" | "it" | "nl" | "th" | "vi" | "sw" | "uk" | "pl";
type ThemeMode = "system" | "light" | "dark";
type Wallpaper = "doodle" | "grid" | "plain" | "garden" | "midnight" | "sunset" | "ocean" | "linen" | "terrazzo" | "constellation" | "waves" | "blossom" | "forest" | "jungle" | "meadow" | "pinewood" | "bamboo" | "autumn" | "leaves" | "waterfall" | "lake" | "desert" | "canyon" | "savanna" | "skyline" | "towers" | "citynight" | "oldtown" | "suburb" | "village" | "harbor" | "bridge" | "street" | "rooftops" | "aurora" | "ember" | "lagoon" | "orchid" | "honey" | "mist" | "coral" | "mint" | "herringbone" | "chevron" | "dots" | "diamonds" | "arcs" | "mosaic" | "prism" | "tiles";
type MessageTone = "saba" | "noor" | "raqs" | "aabshar" | "sukoon" | "none";
type VoiceEffect = "original" | "soft" | "deep" | "bright" | "quick" | "slow" | "chipmunk" | "helium" | "robot" | "monster" | "echo" | "cave";
const LANGUAGE_OPTIONS: { value: Language; label: string; sample: string }[] = [
  { value: "ur", label: "اردو", sample: "Urdu" }, { value: "en", label: "English", sample: "English" }, { value: "hi", label: "हिन्दी", sample: "Hindi" },
  { value: "ar", label: "العربية", sample: "Arabic" }, { value: "fa", label: "فارسی", sample: "Persian" }, { value: "ps", label: "پښتو", sample: "Pashto" },
  { value: "tr", label: "Türkçe", sample: "Turkish" }, { value: "es", label: "Español", sample: "Spanish" }, { value: "fr", label: "Français", sample: "French" },
  { value: "de", label: "Deutsch", sample: "German" }, { value: "pt", label: "Português", sample: "Portuguese" }, { value: "ru", label: "Русский", sample: "Russian" },
  { value: "bn", label: "বাংলা", sample: "Bengali" }, { value: "id", label: "Bahasa Indonesia", sample: "Indonesian" }, { value: "ms", label: "Bahasa Melayu", sample: "Malay" },
  { value: "zh", label: "中文（简体）", sample: "Chinese (Simplified)" }, { value: "ja", label: "日本語", sample: "Japanese" }, { value: "ko", label: "한국어", sample: "Korean" },
  { value: "it", label: "Italiano", sample: "Italian" }, { value: "nl", label: "Nederlands", sample: "Dutch" }, { value: "th", label: "ไทย", sample: "Thai" },
  { value: "vi", label: "Tiếng Việt", sample: "Vietnamese" }, { value: "sw", label: "Kiswahili", sample: "Swahili" }, { value: "uk", label: "Українська", sample: "Ukrainian" },
  { value: "pl", label: "Polski", sample: "Polish" },
];
const RTL_LANGUAGES: Language[] = ["ur", "ar", "fa", "ps"];
const LANGUAGE_LOCALES: Record<Language, string> = { ur: "ur-PK", en: "en-US", hi: "hi-IN", ar: "ar-EG", fa: "fa-IR", ps: "ps-AF", tr: "tr-TR", es: "es-ES", fr: "fr-FR", de: "de-DE", pt: "pt-BR", ru: "ru-RU", bn: "bn-BD", id: "id-ID", ms: "ms-MY", zh: "zh-CN", ja: "ja-JP", ko: "ko-KR", it: "it-IT", nl: "nl-NL", th: "th-TH", vi: "vi-VN", sw: "sw-KE", uk: "uk-UA", pl: "pl-PL" };
const WALLPAPER_VALUES: Wallpaper[] = ["doodle", "grid", "plain", "garden", "midnight", "sunset", "ocean", "linen", "terrazzo", "constellation", "waves", "blossom", "forest", "jungle", "meadow", "pinewood", "bamboo", "autumn", "leaves", "waterfall", "lake", "desert", "canyon", "savanna", "skyline", "towers", "citynight", "oldtown", "suburb", "village", "harbor", "bridge", "street", "rooftops", "aurora", "ember", "lagoon", "orchid", "honey", "mist", "coral", "mint", "herringbone", "chevron", "dots", "diamonds", "arcs", "mosaic", "prism", "tiles"];
const VOICE_EFFECT_OPTIONS: { value: VoiceEffect; label: TextKey }[] = [{ value: "original", label: "originalVoice" }, { value: "soft", label: "softVoice" }, { value: "deep", label: "deepVoice" }, { value: "bright", label: "brightVoice" }, { value: "quick", label: "quickVoice" }, { value: "slow", label: "slowVoice" }, { value: "chipmunk", label: "chipmunkVoice" }, { value: "helium", label: "heliumVoice" }, { value: "robot", label: "robotVoice" }, { value: "monster", label: "monsterVoice" }, { value: "echo", label: "echoVoice" }, { value: "cave", label: "caveVoice" }];

type IconName = "search" | "plus" | "back" | "send" | "edit" | "close" | "chat" | "status" | "phone" | "video" | "settings" | "mic" | "bell" | "checks" | "trash" | "more" | "speaker" | "mute" | "user" | "language" | "wallpaper" | "music" | "play" | "pause" | "image" | "lock" | "clock" | "camera" | "archive" | "users" | "fingerprint" | "bellOff";

function Icon({ name, size = 22 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    search: <><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    back: <path d="m15 18-6-6 6-6"/>,
    send: <><path d="m4 4 17 8-17 8 3-8-3-8Z"/><path d="M7 12h14"/></>,
    edit: <><path d="M4 20h4L19 9l-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/></>,
    close: <path d="m6 6 12 12M18 6 6 18"/>,
    chat: <><path d="M21 12a8 8 0 0 1-8 8H5l-2 2 1.3-5A8.5 8.5 0 1 1 21 12Z"/><path d="M8 12h.01M12 12h.01M16 12h.01"/></>,
    status: <><path d="M7.2 4.2A9 9 0 0 1 12 3c5 0 9 4 9 9s-4 9-9 9a9 9 0 0 1-5.6-2"/><path d="M3.5 15.5A9 9 0 0 1 3 12c0-1.5.4-3 1.1-4.2"/></>,
    phone: <path d="M7 3H4.5C3.7 3 3 3.7 3 4.5 3 13.6 10.4 21 19.5 21c.8 0 1.5-.7 1.5-1.5V17l-4.2-1-1.2 2c-3.7-1.5-6.6-4.4-8.1-8.1l2-1.2L7 3Z"/>,
    video: <><rect x="3" y="6" width="13" height="12" rx="3"/><path d="m16 10 5-3v10l-5-3"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.8 1.8 0 0 0 .36 2l.06.06-2.12 2.12-.06-.06a1.8 1.8 0 0 0-2-.36 1.8 1.8 0 0 0-1.1 1.64V21h-3v-.6A1.8 1.8 0 0 0 10.4 18.8a1.8 1.8 0 0 0-2 .36l-.06.06-2.12-2.12.06-.06a1.8 1.8 0 0 0 .36-2A1.8 1.8 0 0 0 5 14H4v-3h1a1.8 1.8 0 0 0 1.64-1.1 1.8 1.8 0 0 0-.36-2l-.06-.06 2.12-2.12.06.06a1.8 1.8 0 0 0 2 .36A1.8 1.8 0 0 0 11.5 4.5V3h3v1.5a1.8 1.8 0 0 0 1.1 1.64 1.8 1.8 0 0 0 2-.36l.06-.06 2.12 2.12-.06.06a1.8 1.8 0 0 0-.36 2A1.8 1.8 0 0 0 21 11v3h-1a1.8 1.8 0 0 0-1.6 1Z"/></>,
    mic: <><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
    checks: <><path d="m3 12 4 4L17 6"/><path d="m11 15 2 2 8-9"/></>,
    trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14"/></>,
    more: <><circle cx="5" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="19" cy="12" r="1" fill="currentColor"/></>,
    speaker: <><path d="M5 10v4h3l4 4V6L8 10H5Z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/></>,
    mute: <><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 12 4.9M12 18v3M9 21h6M4 4l16 16"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    language: <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.4 2.5 3.7 5.5 3.7 9S14.4 18.5 12 21M12 3c-2.4 2.5-3.7 5.5-3.7 9s1.3 6.5 3.7 9"/></>,
    wallpaper: <><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.5"/><path d="m5 18 4.5-5 3 3 2-2 4.5 4"/></>,
    music: <><path d="M9 18V5l10-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="16" cy="16" r="3"/></>,
    play: <path d="m8 5 11 7-11 7V5Z" fill="currentColor" stroke="none"/>,
    pause: <><path d="M9 5v14M15 5v14" strokeWidth="3"/></>,
    image: <><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m5 18 4.5-4.5 3 3 2.5-2.5 4 4"/></>,
    lock: <><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    camera: <><path d="M4 8h3l2-2.5h6L17 8h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13.5" r="3.5"/></>,
    archive: <><path d="M3 4h18v4H3z"/><path d="M5 8v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8"/><path d="M10 12h4"/></>,
    users: <><circle cx="9" cy="8" r="3.5"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M16 5.2a3.5 3.5 0 0 1 0 6.3M17.6 14.4A6 6 0 0 1 21 20"/></>,
    fingerprint: <><path d="M12 10.5a3.5 3.5 0 0 1 3.5 3.5c0 1.9.4 3.4 1.1 4.9"/><path d="M8.7 11.7A3.5 3.5 0 0 1 12 10.5"/><path d="M5.8 9.6a7 7 0 0 1 12.4 0c.6 1.2.8 2.6.8 4.4 0 2.2.3 4 1 5.8"/><path d="M8.8 14.6c.1 1.9.6 3.5 1.4 5"/><path d="M4.2 7.6A10 10 0 0 1 21 12c0 1.7.1 3.2.5 4.8"/></>,
    bellOff: <><path d="M9 5.2A6 6 0 0 1 18 8c0 2 .6 3.3 1.2 4.4M6.3 6.6C6.1 7 6 7.5 6 8c0 7-3 7-3 9h13"/><path d="M10 21h4M4 4l16 16"/></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

const UR_TEXT = {
    chats:"چیٹس", status:"اسٹیٹس", calls:"کالز", settings:"سیٹنگز", conversations:"چیٹس", search:"نام یا پیغام تلاش کریں", searchLabel:"چیٹ تلاش کریں", newChat:"نئی چیٹ", message:"پیغام لکھیں", send:"پیغام بھیجیں", voice:"صوتی پیغام ریکارڈ کریں", preferences:"آپ کی ترجیحات", chatPrefs:"چیٹ کی ترجیحات", notifications:"اطلاعات", notificationHint:"نئے پیغامات اور کالز کی اطلاع", receipts:"ریڈ رسیدیں", receiptsHint:"پیغام پڑھنے کی نشان دہی", appearanceSound:"ظاہری شکل اور آواز", language:"زبان", wallpaper:"چیٹ وال پیپر", wallpaperHint:"گفتگو کا پس منظر", tone:"پیغام کی ٹون", toneHint:"پیغام بھیجنے کی آواز", conversationTones:"گفتگو کی آوازیں", conversationTonesHint:"پیغام بھیجنے پر آواز", preview:"سنیں", activeUpdates:"میری تازہ اپ ڈیٹس", recentActivity:"حالیہ سرگرمی", welcome:"خوش آمدید", createProfile:"اپنی پروفائل بنائیں", profileIntro:"نام اور Gmail درج کریں تاکہ آپ چیٹس، اسٹیٹس اور کال انٹرفیس آزما سکیں۔", login:"لاگ ان", createAccount:"نیا اکاؤنٹ بنائیں", loginIntro:"اپنا Gmail پتہ درج کریں — اگر آپ کا اکاؤنٹ پہلے بنا ہوا ہے تو آپ کی پروفائل واپس مل جائے گی۔", loginFailed:"لاگ ان نہیں ہو سکا۔ انٹرنیٹ دیکھ کر دوبارہ کوشش کریں۔", loggingIn:"لاگ ان ہو رہا ہے…", yourName:"آپ کا نام", nameExample:"مثلاً احمد", gmail:"Gmail پتہ", emailNote:"یہ پتہ رابطہ شناخت کے لیے محفوظ ہوگا؛ کوئی تصدیقی ای میل نہیں بھیجی جائے گی۔", profileSaveError:"پروفائل محفوظ نہیں ہو سکی۔ معلومات دوبارہ دیکھیں۔", saving:"محفوظ ہو رہا ہے…", start:"شروع کریں", close:"بند کریں", addContact:"رابطہ شامل کریں", contactName:"رابطے کا نام", enterName:"نام لکھیں", emailOptional:"Gmail یا ای میل", optional:"اختیاری", createChat:"چیٹ بنائیں", creating:"بن رہی ہے…", chatCreateError:"چیٹ نہیں بن سکی۔ دوبارہ کوشش کریں۔", profile:"پروفائل", about:"تعارف", changeSaveError:"تبدیلی محفوظ نہیں ہو سکی۔", save:"محفوظ کریں", newStatus:"نیا اسٹیٹس", for24Hours:"24 گھنٹے کے لیے", sharePrompt:"کیا شیئر کرنا چاہتے ہیں؟", statusPlaceholder:"اپنا اسٹیٹس لکھیں…", statusColor:"اسٹیٹس کا رنگ", statusError:"اسٹیٹس محفوظ نہیں ہو سکا۔", postStatus:"اسٹیٹس لگائیں", audioMessage:"صوتی پیغام", imageMessage:"تصویر", chooseImage:"تصویر بھیجیں", imageSaveError:"تصویر محفوظ نہیں ہو سکی۔", deliverySent:"بھیجا گیا", deliveryDelivered:"پہنچ گیا", deliveryRead:"پڑھ لیا", noMessages:"ابھی کوئی پیغام نہیں", openChat:"کی چیٹ کھولیں", playVoice:"صوتی پیغام چلائیں", pauseVoice:"صوتی پیغام روکیں", voiceSaveError:"صوتی پیغام محفوظ نہیں ہو سکا۔", micPermission:"مائیک کی اجازت درکار ہے۔", stopSend:"ریکارڈنگ روک کر بھیجیں", pressToSend:"بھیجنے کے لیے دبائیں", voiceSaving:"صوتی پیغام محفوظ ہو رہا ہے…", loadingChat:"چیٹ کھل رہی ہے…", chatMissing:"یہ چیٹ نہیں مل سکی۔", retryChat:"دوبارہ کوشش کریں", goBack:"واپس جائیں", backChats:"چیٹس پر واپس جائیں", offline:"آف لائن رابطہ", videoCall:"ویڈیو کال", audioCall:"آڈیو کال", localBanner:"پیغامات Bolo Chat کے محفوظ بیک اینڈ میں فوراً محفوظ ہوتے ہیں۔", startChat:"چیٹ شروع کریں", startChatHint:"متن یا صوتی پیغام بھیج کر انٹرفیس آزمائیں۔", receiveMode:"موصولہ پیغام درج کریں", receivedFrom:"کی طرف سے درج ہو رہا ہے", messageError:"پیغام محفوظ نہیں ہو سکا۔", you:"آپ", myStatus:"میرا اسٹیٹس", delete:"حذف کریں", firstChat:"پہلی چیٹ شروع کریں", firstChatHint:"رابطہ شامل کریں، پھر متن اور صوتی پیغام آزمائیں۔", noSearch:"کوئی چیٹ نہیں ملی۔", clearSearch:"تلاش صاف کریں", update24:"24 گھنٹے کی اپ ڈیٹ", addStatus:"اپنا اسٹیٹس شامل کریں", activeUpdate:"فعال اپ ڈیٹ", tapAddUpdate:"اپ ڈیٹ شامل کرنے کے لیے دبائیں", contactStatuses:"رابطوں کے اسٹیٹس", statusServerHint:"رابطوں کے اسٹیٹس یہاں نظر آئیں گے — جو بھی صارف اسٹیٹس لگائے گا، 24 گھنٹے تک یہاں دکھے گا۔", newCall:"نئی کال", callNote:"اپنی حالیہ آڈیو اور ویڈیو کالز یہاں دیکھیں۔", noCalls:"ابھی کوئی کال نہیں", noCallsHint:"رابطہ منتخب کر کے آڈیو یا ویڈیو کال کا انٹرفیس آزمائیں۔", test:"آزمائشی", callAgain:"کو دوبارہ کال", addContactFirst:"پہلے چیٹس میں کوئی رابطہ شامل کریں۔", call:"کال", editProfile:"پروفائل میں ترمیم", doodle:"ڈوڈل", grid:"گرڈ", plain:"سادہ", preferenceError:"ترجیح محفوظ نہیں ہو سکی۔ دوبارہ کوشش کریں۔", serverConnection:"سرور کنکشن", serverInfo:"پیغامات، تصاویر، صوتی نوٹس، پروفائل اور ترجیحات Bolo Chat کے محفوظ بیک اینڈ میں محفوظ ہوتی ہیں۔", localMode:"بیک اینڈ فعال", serverRequired:"کال جاری ہے", videoPlaceholder:"دوسرے شخص کی ویڈیو یہاں نظر آئے گی", mute:"مائیک بند کریں", unmute:"مائیک کھولیں", microphone:"مائیک", endCall:"کال ختم کریں", end:"ختم", speaker:"اسپیکر", loadingApp:"آپ کی گفتگوئیں تیار ہو رہی ہیں…", appError:"ایپ نہیں کھل سکی", tryAgain:"دوبارہ کوشش کریں۔", reopen:"دوبارہ کھولیں", navigation:"مرکزی نیویگیشن", openAChat:"کوئی چیٹ کھولیں", openAChatHint:"متن، صوتی پیغام اور کال کنٹرولز آزمائیں۔", justNow:"ابھی", hoursAgo:"گھنٹے پہلے", color:"رنگ", theme:"تھیم", themeHint:"ایپ کی روشنی اپنی پسند سے چنیں", systemTheme:"فون کے مطابق", lightTheme:"لائٹ", darkTheme:"ڈارک", originalTones:"Bolo Chat کی خاص دھنیں", username:"یوزرنیم", usernameHint:"3 سے 30 انگریزی حروف — بڑے (A-Z) اور چھوٹے (a-z) دونوں چلیں گے — ساتھ اعداد، نقطہ یا انڈر اسکور؛ تلاش میں حروف کے بڑے یا چھوٹے ہونے سے فرق نہیں پڑتا", contactUsername:"رابطے کا یوزرنیم", voiceStudio:"وائس تیار کریں", chooseVoice:"آواز کا انداز", originalVoice:"اصل", softVoice:"نرم", deepVoice:"گہری", brightVoice:"روشن", quickVoice:"تیز", sendNow:"ابھی بھیجیں", afterMinute:"1 منٹ بعد", afterHour:"1 گھنٹے بعد", customDelay:"اپنا وقت", minutes:"منٹ", password:"پاس ورڈ", passwordHint:"وقت پورا ہونے سے پہلے پاس ورڈ بھی کام نہیں کرے گا۔ کوششوں کی کوئی حد نہیں۔", timedVoice:"وقت اور پاس ورڈ سے بند وائس", sendFailed:"پیغام نہیں بھیجا گیا", retry:"دوبارہ بھیجیں", unlocksIn:"کھلنے میں", readyToUnlock:"اب پاس ورڈ درج کر کے کھولیں", unlockVoice:"وائس کھولیں", tooEarly:"مقررہ وقت ابھی پورا نہیں ہوا۔", wrongPassword:"پاس ورڈ درست نہیں۔ دوبارہ کوشش کریں۔", unlocked:"وائس کھل گئی", prepareVoice:"ریکارڈنگ تیار ہے", cancelRecording:"ریکارڈنگ منسوخ کریں", scheduleAndSend:"محفوظ کر کے بھیجیں", voiceEffect:"وائس انداز", mobileNumber:"موبائل نمبر", contactMobile:"رابطے کا موبائل نمبر", mobileHint:"اختیاری — نمبر آپ خود لکھتے ہیں، کوئی SMS کوڈ نہیں بھیجا جائے گا۔", profilePhoto:"پروفائل تصویر", changePhoto:"تصویر بدلیں", addPhoto:"تصویر لگائیں", removePhoto:"تصویر ہٹائیں", photoError:"تصویر محفوظ نہیں ہو سکی۔ چھوٹی تصویر آزمائیں۔", contactInfo:"رابطے کی معلومات", viewContact:"رابطے کی معلومات دیکھیں", noPhoto:"تصویر نہیں", photoStatus:"تصویری اسٹیٹس", textStatus:"لکھا ہوا اسٹیٹس", chooseStatusPhoto:"تصویر چنیں", statusCaption:"تصویر کے ساتھ کچھ لکھیں (اختیاری)", statusPhotoError:"تصویر والا اسٹیٹس نہیں لگ سکا۔", postPhotoStatus:"تصویری اسٹیٹس لگائیں", findUser:"صارف تلاش کریں", findUserHint:"یوزرنیم لکھیں — صارف ملتے ہی اس کی پروفائل نظر آئے گی، اس پر دبائیں تو چیٹ کھل جائے گی۔", usernameSearchPlaceholder:"یوزرنیم لکھیں…", searchingUsers:"تلاش ہو رہی ہے…", noUserFound:"اس یوزرنیم سے کوئی صارف نہیں ملا۔", orAddManually:"یا رابطہ خود شامل کریں", recentUpdates:"حالیہ اپ ڈیٹس", nextStatus:"اگلا اسٹیٹس", prevStatus:"پچھلا اسٹیٹس", appLanguage:"ایپ کی زبان", account:"اکاؤنٹ", accountHint:"حفاظتی اطلاعات، نمبر تبدیل کریں", privacy:"پرائیویسی", privacyHint:"بلاک کیے گئے رابطے، غائب ہونے والے پیغامات", lists:"لسٹیں", listsHint:"لوگوں کو لسٹوں میں رکھیں", chatsSection:"چیٹس", chatsHint:"چیٹ ہسٹری اور بیک اپ", appearance:"شکل و صورت", appearanceHint:"چیٹ تھیم، ایپ تھیم", storageData:"اسٹوریج اور ڈیٹا", storageHint:"نیٹ ورک کا استعمال، خودکار ڈاؤن لوڈ", helpFeedback:"مدد اور رائے", helpHint:"مدد مرکز، ہم سے رابطہ کریں", inviteFriend:"دوست کو دعوت دیں", inviteHint:"Bolo Chat استعمال کرنے کی دعوت بھیجیں", securityNotifications:"حفاظتی اطلاعات", securityHint:"اکاؤنٹ کی حفاظت سے متعلق اطلاعات", changeNumber:"نمبر تبدیل کریں", changeNumberHint:"آپ کا موبائل نمبر پروفائل میں محفوظ ہوگا — کوئی SMS کوڈ نہیں بھیجا جائے گا۔", blockedAccounts:"بلاک کیے گئے اکاؤنٹ", blockedHint:"بلاک رابطے آپ کو پیغام نہیں بھیج سکیں گے", disappearing:"غائب ہونے والے پیغامات", disappearingHint:"آن کرنے پر اس چیٹ کے نئے پیغام مقررہ وقت بعد خود غائب ہو جائیں گے", timerOff:"بند", timer24h:"24 گھنٹے", timer7d:"7 دن", timer90d:"90 دن", block:"بلاک کریں", unblock:"بلاک ختم کریں", noBlocked:"ابھی کوئی بلاک نہیں", forChat:"کے لیے", createList:"نئی لسٹ", listName:"لسٹ کا نام", addPeople:"شامل کریں", inList:"لسٹ میں ہے", noLists:"ابھی کوئی لسٹ نہیں — نام لکھ کر پہلی لسٹ بنائیں۔", chatHistory:"چیٹ ہسٹری", totalChats:"کل چیٹس", backup:"بیک اپ", exportChat:"بیک اپ ڈاؤن لوڈ کریں", exporting:"تیار ہو رہا ہے…", exportError:"بیک اپ نہیں بن سکا۔", networkUsage:"نیٹ ورک کا استعمال", sentMessages:"بھیجے گئے پیغامات", receivedMessages:"موصول پیغامات", photosExchanged:"تصاویر (کل)", voiceExchanged:"وائس پیغامات (کل)", usageError:"استعمال کی تفصیل نہیں مل سکی۔", autoDownload:"خودکار ڈاؤن لوڈ", autoPhotos:"تصاویر خود ڈاؤن لوڈ ہوں", autoVoice:"وائس خود ڈاؤن لوڈ ہو", autoDownloadHint:"بند کرنے پر تصویر یا وائس خود نہیں کھلے گا — دبانے پر ڈاؤن لوڈ ہوگا۔", downloadMedia:"ڈاؤن لوڈ کریں", tapToDownloadPhoto:"تصویر دیکھنے کے لیے ڈاؤن لوڈ کریں", tapToDownloadVoice:"وائس سننے کے لیے ڈاؤن لوڈ کریں", blockedBanner:"آپ نے اس رابطے کو بلاک کیا ہوا ہے — پیغام نہیں بھیجا جا سکتا۔", timerActive:"غائب ہونے والے پیغامات آن ہیں", callTone:"کال ٹون", helpCentre:"مدد مرکز", helpBody:"Bolo Chat میں آپ نام، یوزرنیم (@) یا موبائل نمبر سے صارف تلاش کر سکتے ہیں۔ اسٹیٹس 24 گھنٹے بعد خود ختم ہو جاتا ہے۔ پیغامات آپ کے Firebase اکاؤنٹ میں محفوظ ہوتے ہیں۔ بلاک کرنے سے وہ رابطہ آپ کو پیغام نہیں بھیج سکتا، اور غائب ہونے والے پیغامات مقررہ وقت بعد خود مٹ جاتے ہیں۔", contactUs:"ہم سے رابطہ کریں", feedback:"اپنی رائے بھیجیں", feedbackPlaceholder:"اپنی رائے یا مسئلہ لکھیں…", sendFeedback:"رائے بھیجیں", feedbackSent:"شکریہ! آپ کی رائے محفوظ ہو گئی۔", feedbackError:"رائے نہیں بھیجی جا سکی۔", inviteText:"السلام علیکم! میں Bolo Chat استعمال کر رہا ہوں — پیغامات، اسٹیٹس اور کالز کے لیے۔ آپ بھی Bolo Chat کھول کر اپنے یوزرنیم سے مجھے تلاش کریں اور پیغام بھیجیں۔", copyInvite:"دعوت کاپی کریں", copied:"کاپی ہو گیا!", shareInvite:"دعوت بھیجیں", settingsSaved:"محفوظ ہو گیا", openSection:"کھولیں", slowVoice:"سست", chipmunkVoice:"چپمنک", heliumVoice:"ہیلیم", robotVoice:"روبوٹ", monsterVoice:"بھاری دیو", echoVoice:"گونج", caveVoice:"غار", voiceStyle:"وائس کا انداز", voiceStyleHint:"یہ انداز آپ کے بھیجے گئے ہر وائس پیغام پر لگے گا۔ اصل چننے پر آپ کی اصل آواز جائے گی، بالکل واٹس ایپ کی طرح۔ یہیں سے انداز بدلا جائے گا — ریکارڈنگ کے وقت کوئی پوپ اپ نہیں آئے گا۔", recordingNow:"ریکارڈنگ ہو رہی ہے…", moreOptions:"مزید اختیارات", appLock:"ایپ لاک", appLockHint:"پوری ایپ کو پن، پاس ورڈ یا فنگر پرنٹ سے بند کریں", pinMethod:"پن کوڈ", passwordMethod:"پاس ورڈ", biometricMethod:"فنگر پرنٹ / چہرہ", setSecret:"نیا کوڈ مقرر کریں", enterSecret:"اپنا کوڈ درج کریں", confirmSecret:"کوڈ دوبارہ لکھیں", secretMismatch:"دونوں کوڈ ایک جیسے نہیں ہیں۔", wrongSecret:"کوڈ درست نہیں ہے۔ دوبارہ کوشش کریں۔", lockNow:"ابھی ایپ لاک کریں", unlockApp:"ایپ کھولیں", useFingerprint:"فنگر پرنٹ استعمال کریں", fingerprintFailed:"فنگر پرنٹ کی تصدیق نہیں ہو سکی — کوڈ درج کریں۔", biometricUnavailable:"اس ڈیوائس پر فنگر پرنٹ دستیاب نہیں ہے۔", disableLock:"لاک بند کریں", lockSaved:"لاک محفوظ ہو گیا", lockOff:"لاک بند ہے", lockOn:"لاک آن ہے", archived:"آرکائیو شدہ", archiveChat:"چیٹ آرکائیو کریں", unarchiveChat:"آرکائیو ختم کریں", lockedChats:"بند چیٹس", lockChat:"چیٹ لاک کریں", unlockChat:"چیٹ کا لاک کھولیں", lockedPreview:"یہ چیٹ لاک ہے", muteChat:"اطلاعات خاموش کریں", unmuteChat:"خاموشی ختم کریں", deleteChat:"چیٹ حذف کریں", deleteChatConfirm:"یہ چیٹ اور اس رابطے کی پروفائل آپ کی فہرست سے حذف ہو جائے گی اور اس کے پیغامات بھی مٹ جائیں گے۔", deleteMessageConfirm:"یہ پیغام حذف ہو جائے گا۔", cancel:"منسوخ کریں", onlineNow:"آن لائن", lastSeen:"آخری بار", newGroup:"نیا گروپ", groupName:"گروپ کا نام", groupDescription:"گروپ کی تفصیل", createGroup:"گروپ بنائیں", selectMembers:"اراکین منتخب کریں", groupInfo:"گروپ کی معلومات", groupMembers:"اراکین", admin:"ایڈمن", makeAdmin:"ایڈمن بنائیں", removeAdmin:"ایڈمن ختم کریں", removeMember:"گروپ سے نکالیں", leaveGroup:"گروپ چھوڑیں", addMembers:"اراکین شامل کریں", sharedMedia:"مشترکہ میڈیا", noSharedMedia:"ابھی اس چیٹ میں کوئی تصویر شیئر نہیں ہوئی۔", chatWallpaper:"اس چیٹ کا وال پیپر", groupPhoto:"گروپ کی تصویر", createdBy:"گروپ بنایا", chatActions:"چیٹ کے اختیارات", groupNameRequired:"گروپ کا نام اور کم از کم ایک رکن منتخب کریں۔", memberActions:"رکن کے اختیارات", groupSettings:"گروپ سیٹنگز", unlockToView:"یہ چیٹ لاک ہے — کھولنے کے لیے تصدیق کریں", tapFingerprint:"تصدیق کے لیے فنگر پرنٹ کا بٹن دبائیں", deleteForEveryone:"حذف کریں"
};
type TextKey = keyof typeof UR_TEXT;
const UI_TEXT: Record<Language, Partial<Record<TextKey, string>>> = {
  ur: UR_TEXT,
  en: {
    chats:"Chats", status:"Updates", calls:"Calls", settings:"Settings", conversations:"Chats", search:"Search name or message", searchLabel:"Search chats", newChat:"New chat", message:"Message", send:"Send message", voice:"Record voice message", preferences:"Your preferences", chatPrefs:"Chat preferences", notifications:"Notifications", notificationHint:"Alerts for new messages and calls", receipts:"Read receipts", receiptsHint:"Show when messages are read", appearanceSound:"Appearance & sound", language:"Language", wallpaper:"Chat wallpaper", wallpaperHint:"Conversation background", tone:"Message tone", toneHint:"Sound when sending a message", conversationTones:"Conversation tones", conversationTonesHint:"Play sounds when sending messages", preview:"Preview", activeUpdates:"My recent updates", recentActivity:"Recent activity", welcome:"Welcome", createProfile:"Create your profile", profileIntro:"Enter your name and Gmail to try chats, updates, and call controls.", login:"Log in", createAccount:"Create account", loginIntro:"Enter your Gmail address — if you already have an account, your profile will be restored.", loginFailed:"Could not log in. Check your internet connection and try again.", loggingIn:"Logging in…", yourName:"Your name", nameExample:"e.g. Ahmed", gmail:"Gmail address", emailNote:"This address is saved to identify your profile; no verification email will be sent.", profileSaveError:"Could not save your profile. Check the details and try again.", saving:"Saving…", start:"Get started", close:"Close", addContact:"Add a contact", contactName:"Contact name", enterName:"Enter a name", emailOptional:"Gmail or email", optional:"optional", createChat:"Create chat", creating:"Creating…", chatCreateError:"Could not create the chat. Try again.", profile:"Profile", about:"About", changeSaveError:"Could not save changes.", save:"Save", newStatus:"New update", for24Hours:"Visible for 24 hours", sharePrompt:"What would you like to share?", statusPlaceholder:"Write an update…", statusColor:"Update color", statusError:"Could not save the update.", postStatus:"Post update", audioMessage:"Voice message", imageMessage:"Photo", chooseImage:"Send a photo", imageSaveError:"Could not save the photo.", deliverySent:"Sent", deliveryDelivered:"Delivered", deliveryRead:"Read", noMessages:"No messages yet", openChat:"— open chat", playVoice:"Play voice message", pauseVoice:"Pause voice message", voiceSaveError:"Could not save the voice message.", micPermission:"Microphone permission is required.", stopSend:"Stop and send recording", pressToSend:"Tap to send", voiceSaving:"Saving voice message…", loadingChat:"Opening chat…", chatMissing:"This chat could not be found.", retryChat:"Try again", goBack:"Go back", backChats:"Back to chats", offline:"Offline contact", videoCall:"Video call", audioCall:"Audio call", localBanner:"Messages are saved immediately in Bolo Chat’s secure backend.", startChat:"Start the conversation", startChatHint:"Send a text or voice message to try the interface.", receiveMode:"Enter an incoming message", receivedFrom:"Entering as", messageError:"Could not save the message.", you:"You", myStatus:"My update", delete:"Delete", firstChat:"Start your first chat", firstChatHint:"Add a contact, then try text and voice messages.", noSearch:"No chats found.", clearSearch:"Clear search", update24:"24-hour update", addStatus:"Add your update", activeUpdate:"active update", tapAddUpdate:"Tap to add an update", contactStatuses:"Contact updates", statusServerHint:"Statuses from other users will appear here — every status stays visible for 24 hours.", newCall:"New call", callNote:"View your recent audio and video calls here.", noCalls:"No calls yet", noCallsHint:"Choose a contact to try the audio or video call interface.", test:"Test", callAgain:"— call again", addContactFirst:"Add a contact in Chats first.", call:"call", editProfile:"Edit profile", doodle:"Doodle", grid:"Grid", plain:"Plain", preferenceError:"Could not save this preference. Try again.", serverConnection:"Server connection", serverInfo:"Messages, photos, voice notes, profile details, and preferences are stored in Bolo Chat’s secure backend.", localMode:"Backend active", serverRequired:"Call in progress", videoPlaceholder:"The other person’s video will appear here", mute:"Mute microphone", unmute:"Unmute microphone", microphone:"Microphone", endCall:"End call", end:"End", speaker:"Speaker", loadingApp:"Preparing your chats…", appError:"Could not open the app", tryAgain:"Try again.", reopen:"Open again", navigation:"Main navigation", openAChat:"Open a chat", openAChatHint:"Try text, voice messages, and call controls.", justNow:"Just now", hoursAgo:"hours ago", color:"color", theme:"Theme", themeHint:"Choose how the app looks", systemTheme:"Use device", lightTheme:"Light", darkTheme:"Dark", originalTones:"Original Bolo Chat tones", username:"Username", usernameHint:"3–30 English letters — uppercase (A-Z) and lowercase (a-z) both work — plus numbers, dots, or underscores; search ignores letter case", contactUsername:"Contact username", voiceStudio:"Prepare voice", chooseVoice:"Voice style", originalVoice:"Original", softVoice:"Soft", deepVoice:"Deep", brightVoice:"Bright", quickVoice:"Quick", sendNow:"Send now", afterMinute:"After 1 minute", afterHour:"After 1 hour", customDelay:"Custom time", minutes:"minutes", password:"Password", passwordHint:"The password will not work before the time is reached. Attempts are unlimited.", timedVoice:"Timed, password-locked voice", sendFailed:"Message not sent", retry:"Retry", unlocksIn:"Unlocks in", readyToUnlock:"Enter the password to unlock now", unlockVoice:"Unlock voice", tooEarly:"The scheduled time has not arrived yet.", wrongPassword:"That password is not correct. Try again.", unlocked:"Voice unlocked", prepareVoice:"Recording is ready", cancelRecording:"Discard recording", scheduleAndSend:"Save and send", voiceEffect:"Voice style", mobileNumber:"Mobile number", contactMobile:"Contact mobile number", mobileHint:"Optional — you type the number yourself; no SMS code is sent.", profilePhoto:"Profile photo", changePhoto:"Change photo", addPhoto:"Add photo", removePhoto:"Remove photo", photoError:"Could not save the photo. Try a smaller image.", contactInfo:"Contact info", viewContact:"View contact info", noPhoto:"No photo", photoStatus:"Photo status", textStatus:"Text status", chooseStatusPhoto:"Choose a photo", statusCaption:"Add a caption (optional)", statusPhotoError:"Could not post the photo status.", postPhotoStatus:"Post photo status", findUser:"Find a user", findUserHint:"Type a username — the matching profile appears below; tap it to open a chat.", usernameSearchPlaceholder:"Type a username…", searchingUsers:"Searching…", noUserFound:"No user found with that username.", orAddManually:"Or add a contact manually", recentUpdates:"Recent updates", nextStatus:"Next status", prevStatus:"Previous status", appLanguage:"App language", account:"Account", accountHint:"Security notifications, change number", privacy:"Privacy", privacyHint:"Blocked accounts, disappearing messages", lists:"Lists", listsHint:"Organise people into lists", chatsSection:"Chats", chatsHint:"Chat history and backup", appearance:"Appearance", appearanceHint:"Chat theme, app theme", storageData:"Storage and data", storageHint:"Network usage, auto-download", helpFeedback:"Help and feedback", helpHint:"Help Centre, contact us", inviteFriend:"Invite a friend", inviteHint:"Send an invitation to use Bolo Chat", securityNotifications:"Security notifications", securityHint:"Alerts about your account security", changeNumber:"Change number", changeNumberHint:"Your mobile number is saved on your profile — no SMS code is sent.", blockedAccounts:"Blocked accounts", blockedHint:"Blocked contacts cannot message you", disappearing:"Disappearing messages", disappearingHint:"When on, new messages in this chat disappear after the chosen time", timerOff:"Off", timer24h:"24 hours", timer7d:"7 days", timer90d:"90 days", block:"Block", unblock:"Unblock", noBlocked:"No one is blocked yet", forChat:"for", createList:"New list", listName:"List name", addPeople:"Add", inList:"In list", noLists:"No lists yet — type a name to create your first list.", chatHistory:"Chat history", totalChats:"Total chats", backup:"Backup", exportChat:"Download backup", exporting:"Preparing…", exportError:"Could not create the backup.", networkUsage:"Network usage", sentMessages:"Messages sent", receivedMessages:"Messages received", photosExchanged:"Photos (total)", voiceExchanged:"Voice messages (total)", usageError:"Could not load usage.", autoDownload:"Auto-download", autoPhotos:"Auto-download photos", autoVoice:"Auto-download voice", autoDownloadHint:"When off, a photo or voice message will not open automatically — tap to download it.", downloadMedia:"Download", tapToDownloadPhoto:"Tap to download this photo", tapToDownloadVoice:"Tap to download this voice message", blockedBanner:"You blocked this contact — messages cannot be sent.", timerActive:"Disappearing messages are on", callTone:"Call tone", helpCentre:"Help Centre", helpBody:"In Bolo Chat you can find people by name, username (@) or mobile number. Statuses disappear automatically after 24 hours. Messages are stored in your Firebase account. Blocked contacts cannot message you, and disappearing messages delete themselves after the chosen time.", contactUs:"Contact us", feedback:"Send your feedback", feedbackPlaceholder:"Write your feedback or problem…", sendFeedback:"Send feedback", feedbackSent:"Thank you! Your feedback was saved.", feedbackError:"Could not send feedback.", inviteText:"Assalamualaikum! I am using Bolo Chat for messages, statuses and calls. Open Bolo Chat, search my username and send me a message.", copyInvite:"Copy invitation", copied:"Copied!", shareInvite:"Share invitation", settingsSaved:"Saved", openSection:"Open", slowVoice:"Slow", chipmunkVoice:"Chipmunk", heliumVoice:"Helium", robotVoice:"Robot", monsterVoice:"Monster", echoVoice:"Echo", caveVoice:"Cave", voiceStyle:"Voice style", voiceStyleHint:"This style is applied to every voice message you send. Choose Original and your real voice is sent, just like WhatsApp. The style is changed here in Settings — no popup appears while recording.", recordingNow:"Recording…", moreOptions:"More options", appLock:"App lock", appLockHint:"Lock the whole app with a PIN, password or fingerprint", pinMethod:"PIN code", passwordMethod:"Password", biometricMethod:"Fingerprint / face", setSecret:"Set a new code", enterSecret:"Enter your code", confirmSecret:"Repeat the code", secretMismatch:"The two codes do not match.", wrongSecret:"That code is not correct. Try again.", lockNow:"Lock the app now", unlockApp:"Unlock app", useFingerprint:"Use fingerprint", fingerprintFailed:"Fingerprint check failed — enter your code instead.", biometricUnavailable:"Fingerprint is not available on this device.", disableLock:"Turn off lock", lockSaved:"Lock saved", lockOff:"Lock is off", lockOn:"Lock is on", archived:"Archived", archiveChat:"Archive chat", unarchiveChat:"Unarchive chat", lockedChats:"Locked chats", lockChat:"Lock chat", unlockChat:"Unlock chat", lockedPreview:"This chat is locked", muteChat:"Mute notifications", unmuteChat:"Unmute notifications", deleteChat:"Delete chat", deleteChatConfirm:"This chat and the contact's profile will be removed from your list, and its messages will be deleted.", deleteMessageConfirm:"This message will be deleted.", cancel:"Cancel", onlineNow:"online", lastSeen:"last seen", newGroup:"New group", groupName:"Group name", groupDescription:"Group description", createGroup:"Create group", selectMembers:"Select members", groupInfo:"Group info", groupMembers:"members", admin:"Admin", makeAdmin:"Make admin", removeAdmin:"Remove admin", removeMember:"Remove from group", leaveGroup:"Leave group", addMembers:"Add members", sharedMedia:"Shared media", noSharedMedia:"No photos have been shared in this chat yet.", chatWallpaper:"Wallpaper for this chat", groupPhoto:"Group photo", createdBy:"Group created by", chatActions:"Chat options", groupNameRequired:"Enter a group name and choose at least one member.", memberActions:"Member options", groupSettings:"Group settings", unlockToView:"This chat is locked — verify to open it", tapFingerprint:"Tap the fingerprint button to verify", deleteForEveryone:"Delete"
  },
  hi: {
    chats:"चैट", status:"स्टेटस", calls:"कॉल", settings:"सेटिंग्स", conversations:"चैट", search:"नाम या संदेश खोजें", searchLabel:"चैट खोजें", newChat:"नई चैट", message:"संदेश लिखें", send:"संदेश भेजें", voice:"वॉइस संदेश रिकॉर्ड करें", preferences:"आपकी पसंद", chatPrefs:"चैट की पसंद", notifications:"सूचनाएँ", notificationHint:"नए संदेश और कॉल की सूचना", receipts:"रीड रिसीट", receiptsHint:"संदेश पढ़ने का निशान दिखाएँ", appearanceSound:"दिखावट और आवाज़", language:"भाषा", wallpaper:"चैट वॉलपेपर", wallpaperHint:"बातचीत की पृष्ठभूमि", tone:"संदेश टोन", toneHint:"संदेश भेजने की आवाज़", conversationTones:"बातचीत की आवाज़ें", conversationTonesHint:"संदेश भेजते समय आवाज़ चलाएँ", preview:"सुनें", activeUpdates:"मेरे नए अपडेट", recentActivity:"हाल की गतिविधि", welcome:"स्वागत है", createProfile:"अपनी प्रोफ़ाइल बनाएँ", profileIntro:"चैट, स्टेटस और कॉल कंट्रोल आज़माने के लिए नाम और Gmail डालें।", login:"लॉग इन", createAccount:"नया खाता बनाएँ", loginIntro:"अपना Gmail पता डालें — अगर आपका खाता पहले बना है तो आपकी प्रोफ़ाइल वापस मिल जाएगी।", loginFailed:"लॉग इन नहीं हुआ। इंटरनेट जाँचकर फिर कोशिश करें।", loggingIn:"लॉग इन हो रहा है…", yourName:"आपका नाम", nameExample:"जैसे अहमद", gmail:"Gmail पता", emailNote:"यह पता आपकी पहचान के लिए सेव होगा; कोई सत्यापन ईमेल नहीं भेजा जाएगा।", profileSaveError:"प्रोफ़ाइल सेव नहीं हुई। जानकारी जाँचकर फिर कोशिश करें।", saving:"सेव हो रहा है…", start:"शुरू करें", close:"बंद करें", addContact:"संपर्क जोड़ें", contactName:"संपर्क का नाम", enterName:"नाम लिखें", emailOptional:"Gmail या ईमेल", optional:"वैकल्पिक", createChat:"चैट बनाएँ", creating:"बन रही है…", chatCreateError:"चैट नहीं बनी। फिर कोशिश करें।", profile:"प्रोफ़ाइल", about:"परिचय", changeSaveError:"बदलाव सेव नहीं हुए।", save:"सेव करें", newStatus:"नया स्टेटस", for24Hours:"24 घंटे के लिए", sharePrompt:"आप क्या साझा करना चाहते हैं?", statusPlaceholder:"अपना स्टेटस लिखें…", statusColor:"स्टेटस का रंग", statusError:"स्टेटस सेव नहीं हुआ।", postStatus:"स्टेटस लगाएँ", audioMessage:"वॉइस संदेश", imageMessage:"तस्वीर", chooseImage:"तस्वीर भेजें", imageSaveError:"तस्वीर सेव नहीं हुई।", deliverySent:"भेजा गया", deliveryDelivered:"पहुँच गया", deliveryRead:"पढ़ा गया", noMessages:"अभी कोई संदेश नहीं", openChat:"की चैट खोलें", playVoice:"वॉइस संदेश चलाएँ", pauseVoice:"वॉइस संदेश रोकें", voiceSaveError:"वॉइस संदेश सेव नहीं हुआ।", micPermission:"माइक्रोफ़ोन की अनुमति चाहिए।", stopSend:"रिकॉर्डिंग रोककर भेजें", pressToSend:"भेजने के लिए दबाएँ", voiceSaving:"वॉइस संदेश सेव हो रहा है…", loadingChat:"चैट खुल रही है…", chatMissing:"यह चैट नहीं मिली।", retryChat:"फिर कोशिश करें", goBack:"वापस जाएँ", backChats:"चैट पर वापस जाएँ", offline:"ऑफ़लाइन संपर्क", videoCall:"वीडियो कॉल", audioCall:"ऑडियो कॉल", localBanner:"संदेश Bolo Chat के सुरक्षित बैकएंड में तुरंत सेव होते हैं।", startChat:"बातचीत शुरू करें", startChatHint:"इंटरफ़ेस आज़माने के लिए टेक्स्ट या वॉइस संदेश भेजें।", receiveMode:"आया हुआ संदेश दर्ज करें", receivedFrom:"की ओर से दर्ज हो रहा है", messageError:"संदेश सेव नहीं हुआ।", you:"आप", myStatus:"मेरा स्टेटस", delete:"हटाएँ", firstChat:"पहली चैट शुरू करें", firstChatHint:"संपर्क जोड़ें, फिर टेक्स्ट और वॉइस संदेश आज़माएँ।", noSearch:"कोई चैट नहीं मिली।", clearSearch:"खोज साफ़ करें", update24:"24 घंटे का अपडेट", addStatus:"अपना स्टेटस जोड़ें", activeUpdate:"सक्रिय अपडेट", tapAddUpdate:"स्टेटस जोड़ने के लिए दबाएँ", contactStatuses:"संपर्कों के स्टेटस", statusServerHint:"दूसरे उपयोगकर्ताओं के स्टेटस यहाँ दिखेंगे — हर स्टेटस 24 घंटे तक रहता है।", newCall:"नई कॉल", callNote:"अपनी हाल की ऑडियो और वीडियो कॉल यहाँ देखें।", noCalls:"अभी कोई कॉल नहीं", noCallsHint:"ऑडियो या वीडियो कॉल इंटरफ़ेस आज़माने के लिए संपर्क चुनें।", test:"टेस्ट", callAgain:"को फिर कॉल करें", addContactFirst:"पहले चैट में कोई संपर्क जोड़ें।", call:"कॉल", editProfile:"प्रोफ़ाइल बदलें", doodle:"डूडल", grid:"ग्रिड", plain:"सादा", preferenceError:"पसंद सेव नहीं हुई। फिर कोशिश करें।", serverConnection:"सर्वर कनेक्शन", serverInfo:"संदेश, तस्वीरें, वॉइस नोट, प्रोफ़ाइल और पसंद Bolo Chat के सुरक्षित बैकएंड में सेव होते हैं।", localMode:"बैकएंड सक्रिय", serverRequired:"कॉल जारी है", videoPlaceholder:"दूसरे व्यक्ति का वीडियो यहाँ दिखेगा", mute:"माइक्रोफ़ोन बंद करें", unmute:"माइक्रोफ़ोन खोलें", microphone:"माइक्रोफ़ोन", endCall:"कॉल खत्म करें", end:"खत्म", speaker:"स्पीकर", loadingApp:"आपकी चैट तैयार हो रही हैं…", appError:"ऐप नहीं खुल सका", tryAgain:"फिर कोशिश करें।", reopen:"दोबारा खोलें", navigation:"मुख्य नेविगेशन", openAChat:"कोई चैट खोलें", openAChatHint:"टेक्स्ट, वॉइस संदेश और कॉल कंट्रोल आज़माएँ।", justNow:"अभी", hoursAgo:"घंटे पहले", color:"रंग", theme:"थीम", themeHint:"ऐप का रूप चुनें", systemTheme:"फ़ोन के अनुसार", lightTheme:"लाइट", darkTheme:"डार्क", originalTones:"Bolo Chat की खास धुनें", username:"यूज़रनेम", usernameHint:"3–30 अंग्रेज़ी अक्षर — बड़े (A-Z) और छोटे (a-z) दोनों चलेंगे — अंक, डॉट या अंडरस्कोर; खोज में अक्षरों के बड़े या छोटे होने से फ़र्क नहीं पड़ता", contactUsername:"संपर्क का यूज़रनेम", voiceStudio:"वॉइस तैयार करें", chooseVoice:"आवाज़ का अंदाज़", originalVoice:"असल", softVoice:"नर्म", deepVoice:"गहरी", brightVoice:"चमकीली", quickVoice:"तेज़", sendNow:"अभी भेजें", afterMinute:"1 मिनट बाद", afterHour:"1 घंटे बाद", customDelay:"अपना समय", minutes:"मिनट", password:"पासवर्ड", passwordHint:"समय पूरा होने से पहले पासवर्ड काम नहीं करेगा। कोशिशों की कोई सीमा नहीं है।", timedVoice:"समय और पासवर्ड से लॉक वॉइस", sendFailed:"संदेश नहीं भेजा गया", retry:"फिर भेजें", unlocksIn:"खुलने में", readyToUnlock:"अब पासवर्ड डालकर खोलें", unlockVoice:"वॉइस खोलें", tooEarly:"तय समय अभी पूरा नहीं हुआ।", wrongPassword:"पासवर्ड सही नहीं है। फिर कोशिश करें।", unlocked:"वॉइस खुल गई", prepareVoice:"रिकॉर्डिंग तैयार है", cancelRecording:"रिकॉर्डिंग हटाएँ", scheduleAndSend:"सेव करके भेजें", voiceEffect:"वॉइस अंदाज़", mobileNumber:"मोबाइल नंबर", contactMobile:"संपर्क का मोबाइल नंबर", mobileHint:"वैकल्पिक — नंबर आप खुद लिखते हैं; कोई SMS कोड नहीं भेजा जाएगा।", profilePhoto:"प्रोफ़ाइल तस्वीर", changePhoto:"तस्वीर बदलें", addPhoto:"तस्वीर लगाएँ", removePhoto:"तस्वीर हटाएँ", photoError:"तस्वीर सेव नहीं हुई। छोटी तस्वीर आज़माएँ।", contactInfo:"संपर्क जानकारी", viewContact:"संपर्क जानकारी देखें", noPhoto:"कोई तस्वीर नहीं", photoStatus:"तस्वीर स्टेटस", textStatus:"लिखा स्टेटस", chooseStatusPhoto:"तस्वीर चुनें", statusCaption:"तस्वीर के साथ कुछ लिखें (वैकल्पिक)", statusPhotoError:"तस्वीर स्टेटस नहीं लगा।", postPhotoStatus:"तस्वीर स्टेटस लगाएँ", findUser:"उपयोगकर्ता खोजें", findUserHint:"यूज़रनेम लिखें — मिलते ही प्रोफ़ाइल नीचे दिखेगी; उस पर दबाएँ तो चैट खुल जाएगी।", usernameSearchPlaceholder:"यूज़रनेम लिखें…", searchingUsers:"खोज हो रही है…", noUserFound:"इस यूज़रनेम से कोई उपयोगकर्ता नहीं मिला।", orAddManually:"या संपर्क खुद जोड़ें", recentUpdates:"हाल के अपडेट", nextStatus:"अगला स्टेटस", prevStatus:"पिछला स्टेटस", appLanguage:"ऐप की भाषा", account:"अकाउंट", accountHint:"सुरक्षा सूचनाएँ, नंबर बदलें", privacy:"प्राइवेसी", privacyHint:"ब्लॉक किए संपर्क, गायब होने वाले संदेश", lists:"लिस्ट", listsHint:"लोगों को लिस्ट में रखें", chatsSection:"चैट", chatsHint:"चैट हिस्ट्री और बैकअप", appearance:"दिखावट", appearanceHint:"चैट थीम, ऐप थीम", storageData:"स्टोरेज और डेटा", storageHint:"नेटवर्क उपयोग, ऑटो-डाउनलोड", helpFeedback:"मदद और सुझाव", helpHint:"मदद केंद्र, हमसे संपर्क करें", inviteFriend:"दोस्त को बुलाएँ", inviteHint:"Bolo Chat इस्तेमाल करने का निमंत्रण भेजें", securityNotifications:"सुरक्षा सूचनाएँ", securityHint:"अकाउंट सुरक्षा की सूचनाएँ", changeNumber:"नंबर बदलें", changeNumberHint:"आपका मोबाइल नंबर प्रोफ़ाइल में सेव होगा — कोई SMS कोड नहीं भेजा जाएगा।", blockedAccounts:"ब्लॉक किए अकाउंट", blockedHint:"ब्लॉक किए संपर्क आपको संदेश नहीं भेज सकेंगे", disappearing:"गायब होने वाले संदेश", disappearingHint:"चालू करने पर इस चैट के नए संदेश तय समय बाद खुद गायब हो जाएँगे", timerOff:"बंद", timer24h:"24 घंटे", timer7d:"7 दिन", timer90d:"90 दिन", block:"ब्लॉक करें", unblock:"ब्लॉक हटाएँ", noBlocked:"अभी कोई ब्लॉक नहीं", forChat:"के लिए", createList:"नई लिस्ट", listName:"लिस्ट का नाम", addPeople:"जोड़ें", inList:"लिस्ट में है", noLists:"अभी कोई लिस्ट नहीं — नाम लिखकर पहली लिस्ट बनाएँ।", chatHistory:"चैट हिस्ट्री", totalChats:"कुल चैट", backup:"बैकअप", exportChat:"बैकअप डाउनलोड करें", exporting:"तैयार हो रहा है…", exportError:"बैकअप नहीं बन सका।", networkUsage:"नेटवर्क उपयोग", sentMessages:"भेजे गए संदेश", receivedMessages:"मिले संदेश", photosExchanged:"तस्वीरें (कुल)", voiceExchanged:"वॉइस संदेश (कुल)", usageError:"उपयोग की जानकारी नहीं मिली।", autoDownload:"ऑटो-डाउनलोड", autoPhotos:"तस्वीरें खुद डाउनलोड हों", autoVoice:"वॉइस खुद डाउनलोड हो", autoDownloadHint:"बंद करने पर तस्वीर या वॉइस खुद नहीं खुलेगा — दबाने पर डाउनलोड होगा।", downloadMedia:"डाउनलोड करें", tapToDownloadPhoto:"तस्वीर देखने के लिए डाउनलोड करें", tapToDownloadVoice:"वॉइस सुनने के लिए डाउनलोड करें", blockedBanner:"आपने इस संपर्क को ब्लॉक किया है — संदेश नहीं भेजा जा सकता।", timerActive:"गायब होने वाले संदेश चालू हैं", callTone:"कॉल टोन", helpCentre:"मदद केंद्र", helpBody:"Bolo Chat में आप नाम, यूज़रनेम (@) या मोबाइल नंबर से उपयोगकर्ता खोज सकते हैं। स्टेटस 24 घंटे बाद खुद खत्म हो जाता है। संदेश आपके Firebase अकाउंट में सेव होते हैं। ब्लॉक किए संपर्क आपको संदेश नहीं भेज सकते, और गायब होने वाले संदेश तय समय बाद खुद मिट जाते हैं।", contactUs:"हमसे संपर्क करें", feedback:"अपना सुझाव भेजें", feedbackPlaceholder:"अपना सुझाव या समस्या लिखें…", sendFeedback:"सुझाव भेजें", feedbackSent:"धन्यवाद! आपका सुझाव सेव हो गया।", feedbackError:"सुझाव नहीं भेजा जा सका।", inviteText:"अस्सलामुअलैकुम! मैं Bolo Chat इस्तेमाल कर रहा हूँ — संदेश, स्टेटस और कॉल के लिए। आप भी Bolo Chat खोलकर मेरे यूज़रनेम से मुझे खोजें और संदेश भेजें।", copyInvite:"निमंत्रण कॉपी करें", copied:"कॉपी हो गया!", shareInvite:"निमंत्रण भेजें", settingsSaved:"सेव हो गया", openSection:"खोलें", slowVoice:"धीमी", chipmunkVoice:"चिपमंक", heliumVoice:"हीलियम", robotVoice:"रोबोट", monsterVoice:"दानव", echoVoice:"गूँज", caveVoice:"गुफा", voiceStyle:"आवाज़ का अंदाज़", voiceStyleHint:"यह अंदाज़ आपके हर वॉइस संदेश पर लगेगा। असल चुनने पर आपकी असली आवाज़ जाएगी, बिल्कुल WhatsApp की तरह। अंदाज़ यहीं सेटिंग्स से बदला जाएगा — रिकॉर्डिंग के समय कोई पॉपअप नहीं आएगा।", recordingNow:"रिकॉर्ड हो रहा है…", moreOptions:"और विकल्प"
  },
  ar: {"chats": "المحادثات", "status": "الحالة", "calls": "المكالمات", "settings": "الإعدادات", "conversations": "المحادثات", "search": "ابحث عن اسم أو رسالة", "newChat": "محادثة جديدة", "message": "اكتب رسالة", "send": "إرسال الرسالة", "voice": "تسجيل رسالة صوتية", "notifications": "الإشعارات", "language": "اللغة", "wallpaper": "خلفية المحادثة", "tone": "نغمة الرسالة", "preview": "استمع", "welcome": "مرحباً", "createProfile": "أنشئ ملفك الشخصي", "yourName": "اسمك", "gmail": "بريد Gmail", "saving": "جارٍ الحفظ…", "start": "ابدأ", "close": "إغلاق", "addContact": "إضافة جهة اتصال", "contactName": "اسم جهة الاتصال", "enterName": "أدخل الاسم", "createChat": "إنشاء محادثة", "creating": "جارٍ الإنشاء…", "profile": "الملف الشخصي", "about": "نبذة", "save": "حفظ", "newStatus": "حالة جديدة", "postStatus": "نشر الحالة", "audioMessage": "رسالة صوتية", "imageMessage": "صورة", "chooseImage": "إرسال صورة", "noMessages": "لا رسائل بعد", "playVoice": "تشغيل الرسالة الصوتية", "pauseVoice": "إيقاف الرسالة الصوتية", "micPermission": "يلزم إذن الميكروفون.", "stopSend": "إيقاف التسجيل والإرسال", "voiceSaving": "جارٍ حفظ الرسالة الصوتية…", "loadingChat": "جارٍ فتح المحادثة…", "backChats": "العودة إلى المحادثات", "videoCall": "مكالمة فيديو", "audioCall": "مكالمة صوتية", "startChat": "ابدأ المحادثة", "you": "أنت", "myStatus": "حالتي", "delete": "حذف", "firstChat": "ابدأ أول محادثة", "noSearch": "لم يتم العثور على محادثات.", "addStatus": "أضف حالتك", "contactStatuses": "حالات جهات الاتصال", "newCall": "مكالمة جديدة", "noCalls": "لا مكالمات بعد", "call": "مكالمة", "editProfile": "تعديل الملف الشخصي", "mute": "كتم الميكروفون", "unmute": "إلغاء كتم الميكروفون", "endCall": "إنهاء المكالمة", "speaker": "مكبر الصوت", "loadingApp": "جارٍ تجهيز محادثاتك…", "appError": "تعذر فتح التطبيق", "tryAgain": "حاول مرة أخرى.", "reopen": "افتح مجدداً", "navigation": "التنقل الرئيسي", "justNow": "الآن", "hoursAgo": "قبل ساعات", "color": "اللون", "theme": "المظهر", "systemTheme": "حسب الجهاز", "lightTheme": "فاتح", "darkTheme": "داكن", "username": "اسم المستخدم", "chooseVoice": "أسلوب الصوت", "originalVoice": "الأصلي", "softVoice": "ناعم", "deepVoice": "عميق", "brightVoice": "مشرق", "quickVoice": "سريع", "slowVoice": "بطيء", "chipmunkVoice": "سنجاب", "heliumVoice": "هيليوم", "robotVoice": "روبوت", "monsterVoice": "وحش", "echoVoice": "صدى", "caveVoice": "كهف", "voiceStyle": "أسلوب الصوت", "voiceStyleHint": "يُطبَّق هذا الأسلوب على كل رسالة صوتية ترسلها. اختر الأصلي فتُرسَل بصوتك الحقيقي، تماماً مثل واتساب. يُغيَّر الأسلوب من هنا في الإعدادات — لا تظهر نافذة أثناء التسجيل.", "recordingNow": "جارٍ التسجيل…", "moreOptions": "خيارات إضافية", "timedVoice": "رسالة صوتية مؤقتة مقفلة بكلمة مرور", "password": "كلمة المرور", "unlockVoice": "فتح الصوت", "cancelRecording": "إلغاء التسجيل", "scheduleAndSend": "حفظ وإرسال", "prepareVoice": "التسجيل جاهز", "sendNow": "إرسال الآن", "afterMinute": "بعد دقيقة", "afterHour": "بعد ساعة", "customDelay": "وقت مخصص", "minutes": "دقائق", "mobileNumber": "رقم الجوال", "profilePhoto": "صورة الملف الشخصي", "changePhoto": "تغيير الصورة", "addPhoto": "إضافة صورة", "removePhoto": "إزالة الصورة", "photoStatus": "حالة بصورة", "textStatus": "حالة نصية", "findUser": "البحث عن مستخدم", "appLanguage": "لغة التطبيق", "account": "الحساب", "privacy": "الخصوصية", "lists": "القوائم", "chatsSection": "المحادثات", "appearance": "المظهر", "storageData": "التخزين والبيانات", "helpFeedback": "المساعدة والملاحظات", "inviteFriend": "دعوة صديق", "block": "حظر", "unblock": "إلغاء الحظر", "backup": "نسخة احتياطية", "downloadMedia": "تنزيل", "settingsSaved": "تم الحفظ", "openSection": "فتح", "retry": "إعادة المحاولة", "microphone": "الميكروفون", "end": "إنهاء"},
  fa: {"chats": "گفتگوها", "status": "وضعیت", "calls": "تماس‌ها", "settings": "تنظیمات", "conversations": "گفتگوها", "search": "نام یا پیام را جستجو کنید", "newChat": "گفتگوی جدید", "message": "پیام بنویسید", "send": "ارسال پیام", "voice": "ضبط پیام صوتی", "notifications": "اعلان‌ها", "language": "زبان", "wallpaper": "پس‌زمینه گفتگو", "tone": "آهنگ پیام", "preview": "گوش دادن", "welcome": "خوش آمدید", "createProfile": "پروفایل خود را بسازید", "yourName": "نام شما", "gmail": "نشانی Gmail", "saving": "در حال ذخیره…", "start": "شروع", "close": "بستن", "addContact": "افزودن مخاطب", "contactName": "نام مخاطب", "enterName": "نام را وارد کنید", "createChat": "ایجاد گفتگو", "creating": "در حال ایجاد…", "profile": "پروفایل", "about": "درباره", "save": "ذخیره", "newStatus": "وضعیت جدید", "postStatus": "ثبت وضعیت", "audioMessage": "پیام صوتی", "imageMessage": "عکس", "chooseImage": "ارسال عکس", "noMessages": "هنوز پیامی نیست", "playVoice": "پخش پیام صوتی", "pauseVoice": "توقف پیام صوتی", "micPermission": "اجازه میکروفون لازم است.", "stopSend": "توقف ضبط و ارسال", "voiceSaving": "در حال ذخیره پیام صوتی…", "loadingChat": "در حال باز کردن گفتگو…", "backChats": "بازگشت به گفتگوها", "videoCall": "تماس تصویری", "audioCall": "تماس صوتی", "startChat": "گفتگو را شروع کنید", "you": "شما", "myStatus": "وضعیت من", "delete": "حذف", "firstChat": "اولین گفتگو را شروع کنید", "noSearch": "گفتگویی یافت نشد.", "addStatus": "وضعیت خود را اضافه کنید", "contactStatuses": "وضعیت مخاطبان", "newCall": "تماس جدید", "noCalls": "هنوز تماسی نیست", "call": "تماس", "editProfile": "ویرایش پروفایل", "mute": "بی‌صدا کردن میکروفون", "unmute": "با صدا کردن میکروفون", "endCall": "پایان تماس", "speaker": "بلندگو", "loadingApp": "گفتگوهای شما آماده می‌شود…", "appError": "برنامه باز نشد", "tryAgain": "دوباره تلاش کنید.", "reopen": "باز کردن دوباره", "navigation": "پیمایش اصلی", "justNow": "هم‌اکنون", "hoursAgo": "ساعت پیش", "color": "رنگ", "theme": "پوسته", "systemTheme": "طبق دستگاه", "lightTheme": "روشن", "darkTheme": "تیره", "username": "نام کاربری", "chooseVoice": "سبک صدا", "originalVoice": "اصلی", "softVoice": "نرم", "deepVoice": "بم", "brightVoice": "روشن", "quickVoice": "سریع", "slowVoice": "آهسته", "chipmunkVoice": "سنجابک", "heliumVoice": "هلیوم", "robotVoice": "ربات", "monsterVoice": "هیولا", "echoVoice": "پژواک", "caveVoice": "غار", "voiceStyle": "سبک صدا", "voiceStyleHint": "این سبک روی هر پیام صوتی که می‌فرستید اعمال می‌شود. «اصلی» را انتخاب کنید تا صدای واقعی شما ارسال شود، دقیقاً مانند واتس‌اپ. سبک از همین‌جا در تنظیمات تغییر می‌کند — هنگام ضبط هیچ پنجره‌ای باز نمی‌شود.", "recordingNow": "در حال ضبط…", "moreOptions": "گزینه‌های بیشتر", "timedVoice": "پیام صوتی زمان‌دار با رمز", "password": "رمز عبور", "unlockVoice": "باز کردن صدا", "cancelRecording": "لغو ضبط", "scheduleAndSend": "ذخیره و ارسال", "prepareVoice": "ضبط آماده است", "sendNow": "اکنون بفرست", "afterMinute": "پس از ۱ دقیقه", "afterHour": "پس از ۱ ساعت", "customDelay": "زمان دلخواه", "minutes": "دقیقه", "mobileNumber": "شماره موبایل", "profilePhoto": "عکس پروفایل", "changePhoto": "تغییر عکس", "addPhoto": "افزودن عکس", "removePhoto": "حذف عکس", "photoStatus": "وضعیت عکسی", "textStatus": "وضعیت متنی", "findUser": "یافتن کاربر", "appLanguage": "زبان برنامه", "account": "حساب", "privacy": "حریم خصوصی", "lists": "فهرست‌ها", "chatsSection": "گفتگوها", "appearance": "ظاهر", "storageData": "فضای ذخیره و داده", "helpFeedback": "راهنما و بازخورد", "inviteFriend": "دعوت از دوست", "block": "مسدود کردن", "unblock": "رفع مسدودی", "backup": "پشتیبان", "downloadMedia": "دانلود", "settingsSaved": "ذخیره شد", "openSection": "باز کردن", "retry": "تلاش دوباره", "microphone": "میکروفون", "end": "پایان"},
  ps: {"chats": "چټونه", "status": "حالت", "calls": "زنګونه", "settings": "ترتیبات", "conversations": "چټونه", "search": "نوم یا پیغام ولټوئ", "newChat": "نوی چټ", "message": "پیغام ولیکئ", "send": "پیغام واستوئ", "voice": "غږیز پیغام ثبت کړئ", "notifications": "خبرتیاوې", "language": "ژبه", "wallpaper": "د چټ شالید", "tone": "د پیغام ټون", "preview": "واورئ", "welcome": "ښه راغلاست", "createProfile": "خپل پروفایل جوړ کړئ", "yourName": "ستاسو نوم", "gmail": "د Gmail پته", "saving": "خوښېږي…", "start": "پیل کړئ", "close": "بند کړئ", "addContact": "اړیکه ورزیاته کړئ", "contactName": "د اړیکې نوم", "enterName": "نوم ولیکئ", "createChat": "چټ جوړ کړئ", "creating": "جوړېږي…", "profile": "پروفایل", "about": "پېژندنه", "save": "خوندي کړئ", "newStatus": "نوی حالت", "postStatus": "حالت ولګوئ", "audioMessage": "غږیز پیغام", "imageMessage": "انځور", "chooseImage": "انځور واستوئ", "noMessages": "تر اوسه پیغام نشته", "playVoice": "غږیز پیغام وچلوئ", "pauseVoice": "غږیز پیغام ودروئ", "micPermission": "د مایک اجازې ته اړتیا ده.", "stopSend": "ثبت ودروئ او واستوئ", "voiceSaving": "غږیز پیغام خوندېږي…", "loadingChat": "چټ پرانستل کېږي…", "backChats": "چټونو ته ستون شئ", "videoCall": "ویډیو زنګ", "audioCall": "غږیز زنګ", "startChat": "خبرې پیل کړئ", "you": "تاسو", "myStatus": "زما حالت", "delete": "ړنګ کړئ", "firstChat": "لومړی چټ پیل کړئ", "noSearch": "کوم چټ ونه موندل شو.", "addStatus": "خپل حالت ورزیات کړئ", "contactStatuses": "د اړیکو حالتونه", "newCall": "نوی زنګ", "noCalls": "تر اوسه زنګ نشته", "call": "زنګ", "editProfile": "پروفایل سم کړئ", "mute": "مایک بند کړئ", "unmute": "مایک پرانیزئ", "endCall": "زنګ ختم کړئ", "speaker": "سپیکر", "loadingApp": "ستاسو چټونه تیارېږي…", "appError": "اپلیکیشن پرانستل نشو", "tryAgain": "بیا هڅه وکړئ.", "reopen": "بیا پرانیزئ", "navigation": "اصلي نیویګیشن", "justNow": "همدا اوس", "hoursAgo": "ساعتونه وړاندې", "color": "رنګ", "theme": "بڼه", "systemTheme": "د تلیفون له مخې", "lightTheme": "روښانه", "darkTheme": "تیاره", "username": "کارن نوم", "chooseVoice": "د غږ انداز", "originalVoice": "اصلي", "softVoice": "نرم", "deepVoice": "دروند", "brightVoice": "روښانه", "quickVoice": "چټک", "slowVoice": "ورو", "chipmunkVoice": "چپمنک", "heliumVoice": "هیلیوم", "robotVoice": "روباټ", "monsterVoice": "دیو", "echoVoice": "ازانګه", "caveVoice": "سمڅه", "voiceStyle": "د غږ انداز", "voiceStyleHint": "دا انداز به ستاسو پر هر غږیز پیغام لګېږي. اصلي وټاکئ نو ستاسو اصلي غږ به ځي، بالکل د واټساپ په څېر. انداز همدلته له ترتیباتو بدلېږي — د ثبت پر وخت کوم پاپ اپ نه راځي.", "recordingNow": "ثبت روان دی…", "moreOptions": "نور انتخابونه", "timedVoice": "وخت او پټنوم سره تړلی غږ", "password": "پټنوم", "unlockVoice": "غږ پرانیزئ", "cancelRecording": "ثبت لغوه کړئ", "scheduleAndSend": "خوندي کړئ او واستوئ", "prepareVoice": "ثبت تیار دی", "sendNow": "اوس واستوئ", "afterMinute": "۱ دقیقې وروسته", "afterHour": "۱ ساعت وروسته", "customDelay": "خپل وخت", "minutes": "دقیقې", "mobileNumber": "د موبایل شمېره", "profilePhoto": "د پروفایل انځور", "changePhoto": "انځور بدل کړئ", "addPhoto": "انځور ولګوئ", "removePhoto": "انځور لرې کړئ", "photoStatus": "انځوریز حالت", "textStatus": "لیکلی حالت", "findUser": "کاروونکی ولټوئ", "appLanguage": "د اپ ژبه", "account": "حساب", "privacy": "محرمیت", "lists": "لستونه", "chatsSection": "چټونه", "appearance": "بڼه", "storageData": "زیرمه او ډېټا", "helpFeedback": "مرسته او نظر", "inviteFriend": "ملګری راوبلئ", "block": "بند کړئ", "unblock": "بند خلاص کړئ", "backup": "بیک اپ", "downloadMedia": "ډاونلوډ", "settingsSaved": "خوندي شو", "openSection": "پرانیزئ", "retry": "بیا واستوئ", "microphone": "مایک", "end": "ختم"},
  tr: {"chats": "Sohbetler", "status": "Durum", "calls": "Aramalar", "settings": "Ayarlar", "conversations": "Sohbetler", "search": "Ad veya mesaj ara", "newChat": "Yeni sohbet", "message": "Mesaj yazın", "send": "Mesajı gönder", "voice": "Sesli mesaj kaydet", "notifications": "Bildirimler", "language": "Dil", "wallpaper": "Sohbet duvar kağıdı", "tone": "Mesaj sesi", "preview": "Dinle", "welcome": "Hoş geldiniz", "createProfile": "Profilinizi oluşturun", "yourName": "Adınız", "gmail": "Gmail adresi", "saving": "Kaydediliyor…", "start": "Başla", "close": "Kapat", "addContact": "Kişi ekle", "contactName": "Kişi adı", "enterName": "Ad yazın", "createChat": "Sohbet oluştur", "creating": "Oluşturuluyor…", "profile": "Profil", "about": "Hakkında", "save": "Kaydet", "newStatus": "Yeni durum", "postStatus": "Durumu paylaş", "audioMessage": "Sesli mesaj", "imageMessage": "Fotoğraf", "chooseImage": "Fotoğraf gönder", "noMessages": "Henüz mesaj yok", "playVoice": "Sesli mesajı oynat", "pauseVoice": "Sesli mesajı durdur", "micPermission": "Mikrofon izni gerekli.", "stopSend": "Kaydı durdur ve gönder", "voiceSaving": "Sesli mesaj kaydediliyor…", "loadingChat": "Sohbet açılıyor…", "backChats": "Sohbetlere dön", "videoCall": "Görüntülü arama", "audioCall": "Sesli arama", "startChat": "Sohbeti başlatın", "you": "Siz", "myStatus": "Durumum", "delete": "Sil", "firstChat": "İlk sohbeti başlatın", "noSearch": "Sohbet bulunamadı.", "addStatus": "Durumunuzu ekleyin", "contactStatuses": "Kişilerin durumları", "newCall": "Yeni arama", "noCalls": "Henüz arama yok", "call": "Arama", "editProfile": "Profili düzenle", "mute": "Mikrofonu kapat", "unmute": "Mikrofonu aç", "endCall": "Aramayı bitir", "speaker": "Hoparlör", "loadingApp": "Sohbetleriniz hazırlanıyor…", "appError": "Uygulama açılamadı", "tryAgain": "Tekrar deneyin.", "reopen": "Yeniden aç", "navigation": "Ana gezinme", "justNow": "Şimdi", "hoursAgo": "saat önce", "color": "Renk", "theme": "Tema", "systemTheme": "Cihaza göre", "lightTheme": "Açık", "darkTheme": "Koyu", "username": "Kullanıcı adı", "chooseVoice": "Ses tarzı", "originalVoice": "Orijinal", "softVoice": "Yumuşak", "deepVoice": "Kalın", "brightVoice": "Parlak", "quickVoice": "Hızlı", "slowVoice": "Yavaş", "chipmunkVoice": "Sincap", "heliumVoice": "Helyum", "robotVoice": "Robot", "monsterVoice": "Canavar", "echoVoice": "Yankı", "caveVoice": "Mağara", "voiceStyle": "Ses tarzı", "voiceStyleHint": "Bu tarz, gönderdiğiniz her sesli mesaja uygulanır. Orijinali seçerseniz gerçek sesiniz gider, tıpkı WhatsApp gibi. Tarz buradan, Ayarlardan değiştirilir — kayıt sırasında pencere açılmaz.", "recordingNow": "Kaydediliyor…", "moreOptions": "Diğer seçenekler", "timedVoice": "Zamanlı, şifreli sesli mesaj", "password": "Şifre", "unlockVoice": "Sesin kilidini aç", "cancelRecording": "Kaydı iptal et", "scheduleAndSend": "Kaydet ve gönder", "prepareVoice": "Kayıt hazır", "sendNow": "Şimdi gönder", "afterMinute": "1 dakika sonra", "afterHour": "1 saat sonra", "customDelay": "Özel süre", "minutes": "dakika", "mobileNumber": "Cep telefonu numarası", "profilePhoto": "Profil fotoğrafı", "changePhoto": "Fotoğrafı değiştir", "addPhoto": "Fotoğraf ekle", "removePhoto": "Fotoğrafı kaldır", "photoStatus": "Fotoğraflı durum", "textStatus": "Yazılı durum", "findUser": "Kullanıcı bul", "appLanguage": "Uygulama dili", "account": "Hesap", "privacy": "Gizlilik", "lists": "Listeler", "chatsSection": "Sohbetler", "appearance": "Görünüm", "storageData": "Depolama ve veriler", "helpFeedback": "Yardım ve geri bildirim", "inviteFriend": "Arkadaşını davet et", "block": "Engelle", "unblock": "Engeli kaldır", "backup": "Yedek", "downloadMedia": "İndir", "settingsSaved": "Kaydedildi", "openSection": "Aç", "retry": "Tekrar gönder", "microphone": "Mikrofon", "end": "Bitir"},
  es: {"chats": "Chats", "status": "Estados", "calls": "Llamadas", "settings": "Ajustes", "conversations": "Chats", "search": "Buscar nombre o mensaje", "newChat": "Nuevo chat", "message": "Escribe un mensaje", "send": "Enviar mensaje", "voice": "Grabar mensaje de voz", "notifications": "Notificaciones", "language": "Idioma", "wallpaper": "Fondo del chat", "tone": "Tono de mensaje", "preview": "Escuchar", "welcome": "Bienvenido", "createProfile": "Crea tu perfil", "yourName": "Tu nombre", "gmail": "Correo de Gmail", "saving": "Guardando…", "start": "Empezar", "close": "Cerrar", "addContact": "Añadir contacto", "contactName": "Nombre del contacto", "enterName": "Escribe un nombre", "createChat": "Crear chat", "creating": "Creando…", "profile": "Perfil", "about": "Info", "save": "Guardar", "newStatus": "Nuevo estado", "postStatus": "Publicar estado", "audioMessage": "Mensaje de voz", "imageMessage": "Foto", "chooseImage": "Enviar una foto", "noMessages": "Aún no hay mensajes", "playVoice": "Reproducir mensaje de voz", "pauseVoice": "Pausar mensaje de voz", "micPermission": "Se necesita permiso del micrófono.", "stopSend": "Detener grabación y enviar", "voiceSaving": "Guardando mensaje de voz…", "loadingChat": "Abriendo chat…", "backChats": "Volver a chats", "videoCall": "Videollamada", "audioCall": "Llamada de voz", "startChat": "Inicia la conversación", "you": "Tú", "myStatus": "Mi estado", "delete": "Eliminar", "firstChat": "Inicia tu primer chat", "noSearch": "No se encontraron chats.", "addStatus": "Añade tu estado", "contactStatuses": "Estados de contactos", "newCall": "Nueva llamada", "noCalls": "Aún no hay llamadas", "call": "Llamada", "editProfile": "Editar perfil", "mute": "Silenciar micrófono", "unmute": "Activar micrófono", "endCall": "Terminar llamada", "speaker": "Altavoz", "loadingApp": "Preparando tus chats…", "appError": "No se pudo abrir la app", "tryAgain": "Inténtalo de nuevo.", "reopen": "Abrir de nuevo", "navigation": "Navegación principal", "justNow": "Ahora", "hoursAgo": "hace horas", "color": "Color", "theme": "Tema", "systemTheme": "Según el dispositivo", "lightTheme": "Claro", "darkTheme": "Oscuro", "username": "Nombre de usuario", "chooseVoice": "Estilo de voz", "originalVoice": "Original", "softVoice": "Suave", "deepVoice": "Grave", "brightVoice": "Brillante", "quickVoice": "Rápida", "slowVoice": "Lenta", "chipmunkVoice": "Ardilla", "heliumVoice": "Helio", "robotVoice": "Robot", "monsterVoice": "Monstruo", "echoVoice": "Eco", "caveVoice": "Cueva", "voiceStyle": "Estilo de voz", "voiceStyleHint": "Este estilo se aplica a cada mensaje de voz que envíes. Elige Original y se enviará tu voz real, igual que en WhatsApp. El estilo se cambia aquí, en Ajustes; no aparece ninguna ventana al grabar.", "recordingNow": "Grabando…", "moreOptions": "Más opciones", "timedVoice": "Voz programada con contraseña", "password": "Contraseña", "unlockVoice": "Desbloquear voz", "cancelRecording": "Cancelar grabación", "scheduleAndSend": "Guardar y enviar", "prepareVoice": "Grabación lista", "sendNow": "Enviar ahora", "afterMinute": "Tras 1 minuto", "afterHour": "Tras 1 hora", "customDelay": "Tiempo personalizado", "minutes": "minutos", "mobileNumber": "Número de móvil", "profilePhoto": "Foto de perfil", "changePhoto": "Cambiar foto", "addPhoto": "Añadir foto", "removePhoto": "Quitar foto", "photoStatus": "Estado con foto", "textStatus": "Estado de texto", "findUser": "Buscar usuario", "appLanguage": "Idioma de la app", "account": "Cuenta", "privacy": "Privacidad", "lists": "Listas", "chatsSection": "Chats", "appearance": "Apariencia", "storageData": "Almacenamiento y datos", "helpFeedback": "Ayuda y comentarios", "inviteFriend": "Invitar a un amigo", "block": "Bloquear", "unblock": "Desbloquear", "backup": "Copia de seguridad", "downloadMedia": "Descargar", "settingsSaved": "Guardado", "openSection": "Abrir", "retry": "Reenviar", "microphone": "Micrófono", "end": "Terminar"},
  fr: {"chats": "Discussions", "status": "Statut", "calls": "Appels", "settings": "Paramètres", "conversations": "Discussions", "search": "Rechercher un nom ou un message", "newChat": "Nouvelle discussion", "message": "Écrivez un message", "send": "Envoyer le message", "voice": "Enregistrer un message vocal", "notifications": "Notifications", "language": "Langue", "wallpaper": "Fond de discussion", "tone": "Son du message", "preview": "Écouter", "welcome": "Bienvenue", "createProfile": "Créez votre profil", "yourName": "Votre nom", "gmail": "Adresse Gmail", "saving": "Enregistrement…", "start": "Commencer", "close": "Fermer", "addContact": "Ajouter un contact", "contactName": "Nom du contact", "enterName": "Saisissez un nom", "createChat": "Créer la discussion", "creating": "Création…", "profile": "Profil", "about": "À propos", "save": "Enregistrer", "newStatus": "Nouveau statut", "postStatus": "Publier le statut", "audioMessage": "Message vocal", "imageMessage": "Photo", "chooseImage": "Envoyer une photo", "noMessages": "Aucun message pour le moment", "playVoice": "Lire le message vocal", "pauseVoice": "Mettre en pause", "micPermission": "L'autorisation du micro est requise.", "stopSend": "Arrêter et envoyer", "voiceSaving": "Enregistrement du message vocal…", "loadingChat": "Ouverture de la discussion…", "backChats": "Retour aux discussions", "videoCall": "Appel vidéo", "audioCall": "Appel audio", "startChat": "Commencez la conversation", "you": "Vous", "myStatus": "Mon statut", "delete": "Supprimer", "firstChat": "Commencez votre première discussion", "noSearch": "Aucune discussion trouvée.", "addStatus": "Ajoutez votre statut", "contactStatuses": "Statuts des contacts", "newCall": "Nouvel appel", "noCalls": "Aucun appel pour le moment", "call": "Appel", "editProfile": "Modifier le profil", "mute": "Couper le micro", "unmute": "Réactiver le micro", "endCall": "Terminer l'appel", "speaker": "Haut-parleur", "loadingApp": "Préparation de vos discussions…", "appError": "Impossible d'ouvrir l'application", "tryAgain": "Réessayez.", "reopen": "Rouvrir", "navigation": "Navigation principale", "justNow": "À l'instant", "hoursAgo": "heures", "color": "Couleur", "theme": "Thème", "systemTheme": "Selon l'appareil", "lightTheme": "Clair", "darkTheme": "Sombre", "username": "Nom d'utilisateur", "chooseVoice": "Style de voix", "originalVoice": "Originale", "softVoice": "Douce", "deepVoice": "Grave", "brightVoice": "Claire", "quickVoice": "Rapide", "slowVoice": "Lente", "chipmunkVoice": "Écureuil", "heliumVoice": "Hélium", "robotVoice": "Robot", "monsterVoice": "Monstre", "echoVoice": "Écho", "caveVoice": "Grotte", "voiceStyle": "Style de voix", "voiceStyleHint": "Ce style s'applique à chaque message vocal que vous envoyez. Choisissez Originale et votre vraie voix est envoyée, comme sur WhatsApp. Le style se change ici, dans les Paramètres — aucune fenêtre ne s'affiche pendant l'enregistrement.", "recordingNow": "Enregistrement…", "moreOptions": "Plus d'options", "timedVoice": "Message vocal programmé avec mot de passe", "password": "Mot de passe", "unlockVoice": "Déverrouiller", "cancelRecording": "Annuler l'enregistrement", "scheduleAndSend": "Enregistrer et envoyer", "prepareVoice": "Enregistrement prêt", "sendNow": "Envoyer maintenant", "afterMinute": "Après 1 minute", "afterHour": "Après 1 heure", "customDelay": "Délai personnalisé", "minutes": "minutes", "mobileNumber": "Numéro de mobile", "profilePhoto": "Photo de profil", "changePhoto": "Changer la photo", "addPhoto": "Ajouter une photo", "removePhoto": "Retirer la photo", "photoStatus": "Statut photo", "textStatus": "Statut texte", "findUser": "Trouver un utilisateur", "appLanguage": "Langue de l'application", "account": "Compte", "privacy": "Confidentialité", "lists": "Listes", "chatsSection": "Discussions", "appearance": "Apparence", "storageData": "Stockage et données", "helpFeedback": "Aide et avis", "inviteFriend": "Inviter un ami", "block": "Bloquer", "unblock": "Débloquer", "backup": "Sauvegarde", "downloadMedia": "Télécharger", "settingsSaved": "Enregistré", "openSection": "Ouvrir", "retry": "Renvoyer", "microphone": "Micro", "end": "Terminer"},
  de: {"chats": "Chats", "status": "Status", "calls": "Anrufe", "settings": "Einstellungen", "conversations": "Chats", "search": "Name oder Nachricht suchen", "newChat": "Neuer Chat", "message": "Nachricht schreiben", "send": "Nachricht senden", "voice": "Sprachnachricht aufnehmen", "notifications": "Benachrichtigungen", "language": "Sprache", "wallpaper": "Chat-Hintergrund", "tone": "Nachrichtenton", "preview": "Anhören", "welcome": "Willkommen", "createProfile": "Erstellen Sie Ihr Profil", "yourName": "Ihr Name", "gmail": "Gmail-Adresse", "saving": "Wird gespeichert…", "start": "Starten", "close": "Schließen", "addContact": "Kontakt hinzufügen", "contactName": "Name des Kontakts", "enterName": "Name eingeben", "createChat": "Chat erstellen", "creating": "Wird erstellt…", "profile": "Profil", "about": "Info", "save": "Speichern", "newStatus": "Neuer Status", "postStatus": "Status posten", "audioMessage": "Sprachnachricht", "imageMessage": "Foto", "chooseImage": "Foto senden", "noMessages": "Noch keine Nachrichten", "playVoice": "Sprachnachricht abspielen", "pauseVoice": "Sprachnachricht pausieren", "micPermission": "Mikrofonzugriff ist erforderlich.", "stopSend": "Aufnahme stoppen und senden", "voiceSaving": "Sprachnachricht wird gespeichert…", "loadingChat": "Chat wird geöffnet…", "backChats": "Zurück zu den Chats", "videoCall": "Videoanruf", "audioCall": "Audioanruf", "startChat": "Beginnen Sie das Gespräch", "you": "Sie", "myStatus": "Mein Status", "delete": "Löschen", "firstChat": "Starten Sie Ihren ersten Chat", "noSearch": "Keine Chats gefunden.", "addStatus": "Status hinzufügen", "contactStatuses": "Status Ihrer Kontakte", "newCall": "Neuer Anruf", "noCalls": "Noch keine Anrufe", "call": "Anruf", "editProfile": "Profil bearbeiten", "mute": "Mikrofon stummschalten", "unmute": "Mikrofon aktivieren", "endCall": "Anruf beenden", "speaker": "Lautsprecher", "loadingApp": "Ihre Chats werden vorbereitet…", "appError": "Die App konnte nicht geöffnet werden", "tryAgain": "Versuchen Sie es erneut.", "reopen": "Erneut öffnen", "navigation": "Hauptnavigation", "justNow": "Gerade eben", "hoursAgo": "Stunden zuvor", "color": "Farbe", "theme": "Design", "systemTheme": "Geräteeinstellung", "lightTheme": "Hell", "darkTheme": "Dunkel", "username": "Benutzername", "chooseVoice": "Stimmstil", "originalVoice": "Original", "softVoice": "Sanft", "deepVoice": "Tief", "brightVoice": "Hell", "quickVoice": "Schnell", "slowVoice": "Langsam", "chipmunkVoice": "Chipmunk", "heliumVoice": "Helium", "robotVoice": "Roboter", "monsterVoice": "Monster", "echoVoice": "Echo", "caveVoice": "Höhle", "voiceStyle": "Stimmstil", "voiceStyleHint": "Dieser Stil wird auf jede gesendete Sprachnachricht angewendet. Wählen Sie Original, wird Ihre echte Stimme gesendet — genau wie bei WhatsApp. Der Stil wird hier in den Einstellungen geändert; bei der Aufnahme erscheint kein Fenster.", "recordingNow": "Aufnahme läuft…", "moreOptions": "Weitere Optionen", "timedVoice": "Zeitgesteuerte Sprachnachricht mit Passwort", "password": "Passwort", "unlockVoice": "Sprache freischalten", "cancelRecording": "Aufnahme verwerfen", "scheduleAndSend": "Speichern und senden", "prepareVoice": "Aufnahme bereit", "sendNow": "Jetzt senden", "afterMinute": "Nach 1 Minute", "afterHour": "Nach 1 Stunde", "customDelay": "Eigene Zeit", "minutes": "Minuten", "mobileNumber": "Handynummer", "profilePhoto": "Profilfoto", "changePhoto": "Foto ändern", "addPhoto": "Foto hinzufügen", "removePhoto": "Foto entfernen", "photoStatus": "Foto-Status", "textStatus": "Text-Status", "findUser": "Benutzer finden", "appLanguage": "App-Sprache", "account": "Konto", "privacy": "Datenschutz", "lists": "Listen", "chatsSection": "Chats", "appearance": "Aussehen", "storageData": "Speicher und Daten", "helpFeedback": "Hilfe und Feedback", "inviteFriend": "Freund einladen", "block": "Blockieren", "unblock": "Blockierung aufheben", "backup": "Backup", "downloadMedia": "Herunterladen", "settingsSaved": "Gespeichert", "openSection": "Öffnen", "retry": "Erneut senden", "microphone": "Mikrofon", "end": "Beenden"},
  pt: {"chats": "Conversas", "status": "Status", "calls": "Chamadas", "settings": "Configurações", "conversations": "Conversas", "search": "Buscar nome ou mensagem", "newChat": "Nova conversa", "message": "Escreva uma mensagem", "send": "Enviar mensagem", "voice": "Gravar mensagem de voz", "notifications": "Notificações", "language": "Idioma", "wallpaper": "Papel de parede da conversa", "tone": "Som da mensagem", "preview": "Ouvir", "welcome": "Bem-vindo", "createProfile": "Crie seu perfil", "yourName": "Seu nome", "gmail": "E-mail do Gmail", "saving": "Salvando…", "start": "Começar", "close": "Fechar", "addContact": "Adicionar contato", "contactName": "Nome do contato", "enterName": "Digite um nome", "createChat": "Criar conversa", "creating": "Criando…", "profile": "Perfil", "about": "Sobre", "save": "Salvar", "newStatus": "Novo status", "postStatus": "Publicar status", "audioMessage": "Mensagem de voz", "imageMessage": "Foto", "chooseImage": "Enviar uma foto", "noMessages": "Ainda não há mensagens", "playVoice": "Ouvir mensagem de voz", "pauseVoice": "Pausar mensagem de voz", "micPermission": "É necessária permissão do microfone.", "stopSend": "Parar gravação e enviar", "voiceSaving": "Salvando mensagem de voz…", "loadingChat": "Abrindo conversa…", "backChats": "Voltar às conversas", "videoCall": "Videochamada", "audioCall": "Chamada de voz", "startChat": "Inicie a conversa", "you": "Você", "myStatus": "Meu status", "delete": "Excluir", "firstChat": "Inicie sua primeira conversa", "noSearch": "Nenhuma conversa encontrada.", "addStatus": "Adicione seu status", "contactStatuses": "Status dos contatos", "newCall": "Nova chamada", "noCalls": "Ainda não há chamadas", "call": "Chamada", "editProfile": "Editar perfil", "mute": "Silenciar microfone", "unmute": "Ativar microfone", "endCall": "Encerrar chamada", "speaker": "Alto-falante", "loadingApp": "Preparando suas conversas…", "appError": "Não foi possível abrir o app", "tryAgain": "Tente novamente.", "reopen": "Abrir de novo", "navigation": "Navegação principal", "justNow": "Agora", "hoursAgo": "horas atrás", "color": "Cor", "theme": "Tema", "systemTheme": "Do aparelho", "lightTheme": "Claro", "darkTheme": "Escuro", "username": "Nome de usuário", "chooseVoice": "Estilo de voz", "originalVoice": "Original", "softVoice": "Suave", "deepVoice": "Grave", "brightVoice": "Brilhante", "quickVoice": "Rápida", "slowVoice": "Lenta", "chipmunkVoice": "Esquilo", "heliumVoice": "Hélio", "robotVoice": "Robô", "monsterVoice": "Monstro", "echoVoice": "Eco", "caveVoice": "Caverna", "voiceStyle": "Estilo de voz", "voiceStyleHint": "Este estilo é aplicado a cada mensagem de voz que você envia. Escolha Original e sua voz verdadeira é enviada, igual ao WhatsApp. O estilo é alterado aqui, nas Configurações — nenhuma janela aparece ao gravar.", "recordingNow": "Gravando…", "moreOptions": "Mais opções", "timedVoice": "Voz programada com senha", "password": "Senha", "unlockVoice": "Desbloquear voz", "cancelRecording": "Cancelar gravação", "scheduleAndSend": "Salvar e enviar", "prepareVoice": "Gravação pronta", "sendNow": "Enviar agora", "afterMinute": "Após 1 minuto", "afterHour": "Após 1 hora", "customDelay": "Tempo personalizado", "minutes": "minutos", "mobileNumber": "Número de celular", "profilePhoto": "Foto de perfil", "changePhoto": "Mudar foto", "addPhoto": "Adicionar foto", "removePhoto": "Remover foto", "photoStatus": "Status com foto", "textStatus": "Status de texto", "findUser": "Encontrar usuário", "appLanguage": "Idioma do app", "account": "Conta", "privacy": "Privacidade", "lists": "Listas", "chatsSection": "Conversas", "appearance": "Aparência", "storageData": "Armazenamento e dados", "helpFeedback": "Ajuda e feedback", "inviteFriend": "Convidar um amigo", "block": "Bloquear", "unblock": "Desbloquear", "backup": "Backup", "downloadMedia": "Baixar", "settingsSaved": "Salvo", "openSection": "Abrir", "retry": "Reenviar", "microphone": "Microfone", "end": "Encerrar"},
  ru: {"chats": "Чаты", "status": "Статус", "calls": "Звонки", "settings": "Настройки", "conversations": "Чаты", "search": "Поиск по имени или сообщению", "newChat": "Новый чат", "message": "Напишите сообщение", "send": "Отправить сообщение", "voice": "Записать голосовое сообщение", "notifications": "Уведомления", "language": "Язык", "wallpaper": "Фон чата", "tone": "Звук сообщения", "preview": "Слушать", "welcome": "Добро пожаловать", "createProfile": "Создайте профиль", "yourName": "Ваше имя", "gmail": "Адрес Gmail", "saving": "Сохранение…", "start": "Начать", "close": "Закрыть", "addContact": "Добавить контакт", "contactName": "Имя контакта", "enterName": "Введите имя", "createChat": "Создать чат", "creating": "Создание…", "profile": "Профиль", "about": "О себе", "save": "Сохранить", "newStatus": "Новый статус", "postStatus": "Опубликовать статус", "audioMessage": "Голосовое сообщение", "imageMessage": "Фото", "chooseImage": "Отправить фото", "noMessages": "Сообщений пока нет", "playVoice": "Слушать голосовое сообщение", "pauseVoice": "Пауза", "micPermission": "Нужен доступ к микрофону.", "stopSend": "Остановить запись и отправить", "voiceSaving": "Сохранение голосового сообщения…", "loadingChat": "Открытие чата…", "backChats": "Назад к чатам", "videoCall": "Видеозвонок", "audioCall": "Аудиозвонок", "startChat": "Начните разговор", "you": "Вы", "myStatus": "Мой статус", "delete": "Удалить", "firstChat": "Начните первый чат", "noSearch": "Чаты не найдены.", "addStatus": "Добавьте статус", "contactStatuses": "Статусы контактов", "newCall": "Новый звонок", "noCalls": "Звонков пока нет", "call": "Звонок", "editProfile": "Изменить профиль", "mute": "Выключить микрофон", "unmute": "Включить микрофон", "endCall": "Завершить звонок", "speaker": "Динамик", "loadingApp": "Подготовка чатов…", "appError": "Не удалось открыть приложение", "tryAgain": "Попробуйте ещё раз.", "reopen": "Открыть снова", "navigation": "Главная навигация", "justNow": "Только что", "hoursAgo": "ч. назад", "color": "Цвет", "theme": "Тема", "systemTheme": "Как на устройстве", "lightTheme": "Светлая", "darkTheme": "Тёмная", "username": "Имя пользователя", "chooseVoice": "Стиль голоса", "originalVoice": "Оригинал", "softVoice": "Мягкий", "deepVoice": "Глубокий", "brightVoice": "Яркий", "quickVoice": "Быстрый", "slowVoice": "Медленный", "chipmunkVoice": "Бурундук", "heliumVoice": "Гелий", "robotVoice": "Робот", "monsterVoice": "Монстр", "echoVoice": "Эхо", "caveVoice": "Пещера", "voiceStyle": "Стиль голоса", "voiceStyleHint": "Этот стиль применяется к каждому отправляемому голосовому сообщению. Выберите «Оригинал» — и отправится ваш настоящий голос, как в WhatsApp. Стиль меняется здесь, в Настройках, — при записи окно не появляется.", "recordingNow": "Идёт запись…", "moreOptions": "Ещё варианты", "timedVoice": "Голос по расписанию с паролем", "password": "Пароль", "unlockVoice": "Открыть голос", "cancelRecording": "Отменить запись", "scheduleAndSend": "Сохранить и отправить", "prepareVoice": "Запись готова", "sendNow": "Отправить сейчас", "afterMinute": "Через 1 минуту", "afterHour": "Через 1 час", "customDelay": "Своё время", "minutes": "минут", "mobileNumber": "Номер телефона", "profilePhoto": "Фото профиля", "changePhoto": "Сменить фото", "addPhoto": "Добавить фото", "removePhoto": "Убрать фото", "photoStatus": "Статус с фото", "textStatus": "Текстовый статус", "findUser": "Найти пользователя", "appLanguage": "Язык приложения", "account": "Аккаунт", "privacy": "Конфиденциальность", "lists": "Списки", "chatsSection": "Чаты", "appearance": "Оформление", "storageData": "Хранилище и данные", "helpFeedback": "Помощь и отзывы", "inviteFriend": "Пригласить друга", "block": "Заблокировать", "unblock": "Разблокировать", "backup": "Резервная копия", "downloadMedia": "Скачать", "settingsSaved": "Сохранено", "openSection": "Открыть", "retry": "Отправить снова", "microphone": "Микрофон", "end": "Завершить"},
  bn: {"chats": "চ্যাট", "status": "স্ট্যাটাস", "calls": "কল", "settings": "সেটিংস", "conversations": "চ্যাট", "search": "নাম বা বার্তা খুঁজুন", "newChat": "নতুন চ্যাট", "message": "বার্তা লিখুন", "send": "বার্তা পাঠান", "voice": "ভয়েস বার্তা রেকর্ড করুন", "notifications": "বিজ্ঞপ্তি", "language": "ভাষা", "wallpaper": "চ্যাটের ওয়ালপেপার", "tone": "বার্তার টোন", "preview": "শুনুন", "welcome": "স্বাগতম", "createProfile": "আপনার প্রোফাইল তৈরি করুন", "yourName": "আপনার নাম", "gmail": "Gmail ঠিকানা", "saving": "সংরক্ষণ হচ্ছে…", "start": "শুরু করুন", "close": "বন্ধ করুন", "addContact": "যোগাযোগ যোগ করুন", "contactName": "যোগাযোগের নাম", "enterName": "নাম লিখুন", "createChat": "চ্যাট তৈরি করুন", "creating": "তৈরি হচ্ছে…", "profile": "প্রোফাইল", "about": "পরিচিতি", "save": "সংরক্ষণ করুন", "newStatus": "নতুন স্ট্যাটাস", "postStatus": "স্ট্যাটাস দিন", "audioMessage": "ভয়েস বার্তা", "imageMessage": "ছবি", "chooseImage": "ছবি পাঠান", "noMessages": "এখনো কোনো বার্তা নেই", "playVoice": "ভয়েস বার্তা চালান", "pauseVoice": "ভয়েস বার্তা থামান", "micPermission": "মাইক্রোফোনের অনুমতি দরকার।", "stopSend": "রেকর্ডিং থামিয়ে পাঠান", "voiceSaving": "ভয়েস বার্তা সংরক্ষণ হচ্ছে…", "loadingChat": "চ্যাট খুলছে…", "backChats": "চ্যাটে ফিরে যান", "videoCall": "ভিডিও কল", "audioCall": "অডিও কল", "startChat": "কথোপকথন শুরু করুন", "you": "আপনি", "myStatus": "আমার স্ট্যাটাস", "delete": "মুছুন", "firstChat": "প্রথম চ্যাট শুরু করুন", "noSearch": "কোনো চ্যাট পাওয়া যায়নি।", "addStatus": "আপনার স্ট্যাটাস যোগ করুন", "contactStatuses": "যোগাযোগের স্ট্যাটাস", "newCall": "নতুন কল", "noCalls": "এখনো কোনো কল নেই", "call": "কল", "editProfile": "প্রোফাইল সম্পাদনা", "mute": "মাইক বন্ধ করুন", "unmute": "মাইক খুলুন", "endCall": "কল শেষ করুন", "speaker": "স্পিকার", "loadingApp": "আপনার চ্যাট তৈরি হচ্ছে…", "appError": "অ্যাপ খুলতে পারেনি", "tryAgain": "আবার চেষ্টা করুন।", "reopen": "আবার খুলুন", "navigation": "মূল নেভিগেশন", "justNow": "এখনই", "hoursAgo": "ঘণ্টা আগে", "color": "রং", "theme": "থিম", "systemTheme": "ডিভাইস অনুযায়ী", "lightTheme": "হালকা", "darkTheme": "গাঢ়", "username": "ব্যবহারকারীর নাম", "chooseVoice": "কণ্ঠের ধরন", "originalVoice": "আসল", "softVoice": "নরম", "deepVoice": "গভীর", "brightVoice": "উজ্জ্বল", "quickVoice": "দ্রুত", "slowVoice": "ধীর", "chipmunkVoice": "কাঠবিড়ালি", "heliumVoice": "হিলিয়াম", "robotVoice": "রোবট", "monsterVoice": "দানব", "echoVoice": "প্রতিধ্বনি", "caveVoice": "গুহা", "voiceStyle": "কণ্ঠের ধরন", "voiceStyleHint": "এই ধরনটি আপনার পাঠানো প্রতিটি ভয়েস বার্তায় প্রযোজ্য হবে। আসল বেছে নিলে আপনার আসল কণ্ঠই যাবে, ঠিক WhatsApp-এর মতো। ধরন এখানে সেটিংস থেকেই বদলাবে — রেকর্ডিংয়ের সময় কোনো পপআপ আসবে না।", "recordingNow": "রেকর্ড হচ্ছে…", "moreOptions": "আরও বিকল্প", "timedVoice": "সময় ও পাসওয়ার্ডে লক করা ভয়েস", "password": "পাসওয়ার্ড", "unlockVoice": "ভয়েস খুলুন", "cancelRecording": "রেকর্ডিং বাতিল করুন", "scheduleAndSend": "সংরক্ষণ করে পাঠান", "prepareVoice": "রেকর্ডিং তৈরি", "sendNow": "এখনই পাঠান", "afterMinute": "১ মিনিট পরে", "afterHour": "১ ঘণ্টা পরে", "customDelay": "নিজের সময়", "minutes": "মিনিট", "mobileNumber": "মোবাইল নম্বর", "profilePhoto": "প্রোফাইল ছবি", "changePhoto": "ছবি বদলান", "addPhoto": "ছবি যোগ করুন", "removePhoto": "ছবি সরান", "photoStatus": "ছবির স্ট্যাটাস", "textStatus": "লেখা স্ট্যাটাস", "findUser": "ব্যবহারকারী খুঁজুন", "appLanguage": "অ্যাপের ভাষা", "account": "অ্যাকাউন্ট", "privacy": "গোপনীয়তা", "lists": "তালিকা", "chatsSection": "চ্যাট", "appearance": "চেহারা", "storageData": "স্টোরেজ ও ডেটা", "helpFeedback": "সাহায্য ও মতামত", "inviteFriend": "বন্ধুকে আমন্ত্রণ জানান", "block": "ব্লক করুন", "unblock": "ব্লক খুলুন", "backup": "ব্যাকআপ", "downloadMedia": "ডাউনলোড", "settingsSaved": "সংরক্ষিত হয়েছে", "openSection": "খুলুন", "retry": "আবার পাঠান", "microphone": "মাইক", "end": "শেষ"},
  id: {"chats": "Chat", "status": "Status", "calls": "Panggilan", "settings": "Pengaturan", "conversations": "Chat", "search": "Cari nama atau pesan", "newChat": "Chat baru", "message": "Tulis pesan", "send": "Kirim pesan", "voice": "Rekam pesan suara", "notifications": "Notifikasi", "language": "Bahasa", "wallpaper": "Wallpaper chat", "tone": "Nada pesan", "preview": "Dengarkan", "welcome": "Selamat datang", "createProfile": "Buat profil Anda", "yourName": "Nama Anda", "gmail": "Alamat Gmail", "saving": "Menyimpan…", "start": "Mulai", "close": "Tutup", "addContact": "Tambah kontak", "contactName": "Nama kontak", "enterName": "Masukkan nama", "createChat": "Buat chat", "creating": "Membuat…", "profile": "Profil", "about": "Tentang", "save": "Simpan", "newStatus": "Status baru", "postStatus": "Pasang status", "audioMessage": "Pesan suara", "imageMessage": "Foto", "chooseImage": "Kirim foto", "noMessages": "Belum ada pesan", "playVoice": "Putar pesan suara", "pauseVoice": "Jeda pesan suara", "micPermission": "Izin mikrofon diperlukan.", "stopSend": "Berhenti merekam dan kirim", "voiceSaving": "Menyimpan pesan suara…", "loadingChat": "Membuka chat…", "backChats": "Kembali ke chat", "videoCall": "Panggilan video", "audioCall": "Panggilan suara", "startChat": "Mulai percakapan", "you": "Anda", "myStatus": "Status saya", "delete": "Hapus", "firstChat": "Mulai chat pertama Anda", "noSearch": "Tidak ada chat ditemukan.", "addStatus": "Tambahkan status Anda", "contactStatuses": "Status kontak", "newCall": "Panggilan baru", "noCalls": "Belum ada panggilan", "call": "Panggilan", "editProfile": "Edit profil", "mute": "Bisukan mikrofon", "unmute": "Nyalakan mikrofon", "endCall": "Akhiri panggilan", "speaker": "Speaker", "loadingApp": "Menyiapkan chat Anda…", "appError": "Aplikasi tidak dapat dibuka", "tryAgain": "Coba lagi.", "reopen": "Buka lagi", "navigation": "Navigasi utama", "justNow": "Baru saja", "hoursAgo": "jam lalu", "color": "Warna", "theme": "Tema", "systemTheme": "Ikuti perangkat", "lightTheme": "Terang", "darkTheme": "Gelap", "username": "Nama pengguna", "chooseVoice": "Gaya suara", "originalVoice": "Asli", "softVoice": "Lembut", "deepVoice": "Dalam", "brightVoice": "Cerah", "quickVoice": "Cepat", "slowVoice": "Lambat", "chipmunkVoice": "Tupai", "heliumVoice": "Helium", "robotVoice": "Robot", "monsterVoice": "Monster", "echoVoice": "Gema", "caveVoice": "Gua", "voiceStyle": "Gaya suara", "voiceStyleHint": "Gaya ini berlaku untuk setiap pesan suara yang Anda kirim. Pilih Asli, maka suara asli Anda yang terkirim, sama seperti WhatsApp. Gaya diubah di sini, di Pengaturan — tidak ada jendela yang muncul saat merekam.", "recordingNow": "Merekam…", "moreOptions": "Opsi lain", "timedVoice": "Pesan suara terjadwal dengan kata sandi", "password": "Kata sandi", "unlockVoice": "Buka suara", "cancelRecording": "Batalkan rekaman", "scheduleAndSend": "Simpan dan kirim", "prepareVoice": "Rekaman siap", "sendNow": "Kirim sekarang", "afterMinute": "Setelah 1 menit", "afterHour": "Setelah 1 jam", "customDelay": "Waktu sendiri", "minutes": "menit", "mobileNumber": "Nomor ponsel", "profilePhoto": "Foto profil", "changePhoto": "Ganti foto", "addPhoto": "Tambah foto", "removePhoto": "Hapus foto", "photoStatus": "Status foto", "textStatus": "Status teks", "findUser": "Cari pengguna", "appLanguage": "Bahasa aplikasi", "account": "Akun", "privacy": "Privasi", "lists": "Daftar", "chatsSection": "Chat", "appearance": "Tampilan", "storageData": "Penyimpanan dan data", "helpFeedback": "Bantuan dan masukan", "inviteFriend": "Undang teman", "block": "Blokir", "unblock": "Buka blokir", "backup": "Cadangan", "downloadMedia": "Unduh", "settingsSaved": "Tersimpan", "openSection": "Buka", "retry": "Kirim ulang", "microphone": "Mikrofon", "end": "Akhiri"},
  ms: {"chats": "Sembang", "status": "Status", "calls": "Panggilan", "settings": "Tetapan", "conversations": "Sembang", "search": "Cari nama atau mesej", "newChat": "Sembang baharu", "message": "Tulis mesej", "send": "Hantar mesej", "voice": "Rakam mesej suara", "notifications": "Pemberitahuan", "language": "Bahasa", "wallpaper": "Kertas dinding sembang", "tone": "Nada mesej", "preview": "Dengar", "welcome": "Selamat datang", "createProfile": "Buat profil anda", "yourName": "Nama anda", "gmail": "Alamat Gmail", "saving": "Menyimpan…", "start": "Mula", "close": "Tutup", "addContact": "Tambah kenalan", "contactName": "Nama kenalan", "enterName": "Masukkan nama", "createChat": "Buat sembang", "creating": "Membuat…", "profile": "Profil", "about": "Perihal", "save": "Simpan", "newStatus": "Status baharu", "postStatus": "Siarkan status", "audioMessage": "Mesej suara", "imageMessage": "Foto", "chooseImage": "Hantar foto", "noMessages": "Tiada mesej lagi", "playVoice": "Main mesej suara", "pauseVoice": "Jeda mesej suara", "micPermission": "Kebenaran mikrofon diperlukan.", "stopSend": "Berhenti rakam dan hantar", "voiceSaving": "Menyimpan mesej suara…", "loadingChat": "Membuka sembang…", "backChats": "Kembali ke sembang", "videoCall": "Panggilan video", "audioCall": "Panggilan suara", "startChat": "Mulakan perbualan", "you": "Anda", "myStatus": "Status saya", "delete": "Padam", "firstChat": "Mulakan sembang pertama anda", "noSearch": "Tiada sembang dijumpai.", "addStatus": "Tambah status anda", "contactStatuses": "Status kenalan", "newCall": "Panggilan baharu", "noCalls": "Tiada panggilan lagi", "call": "Panggilan", "editProfile": "Edit profil", "mute": "Senyapkan mikrofon", "unmute": "Nyahsenyap mikrofon", "endCall": "Tamatkan panggilan", "speaker": "Pembesar suara", "loadingApp": "Menyiapkan sembang anda…", "appError": "Aplikasi tidak dapat dibuka", "tryAgain": "Cuba lagi.", "reopen": "Buka semula", "navigation": "Navigasi utama", "justNow": "Baru sahaja", "hoursAgo": "jam lalu", "color": "Warna", "theme": "Tema", "systemTheme": "Ikut peranti", "lightTheme": "Cerah", "darkTheme": "Gelap", "username": "Nama pengguna", "chooseVoice": "Gaya suara", "originalVoice": "Asal", "softVoice": "Lembut", "deepVoice": "Dalam", "brightVoice": "Cerah", "quickVoice": "Pantas", "slowVoice": "Perlahan", "chipmunkVoice": "Tupai", "heliumVoice": "Helium", "robotVoice": "Robot", "monsterVoice": "Raksasa", "echoVoice": "Gema", "caveVoice": "Gua", "voiceStyle": "Gaya suara", "voiceStyleHint": "Gaya ini digunakan pada setiap mesej suara yang anda hantar. Pilih Asal, suara sebenar anda akan dihantar, sama seperti WhatsApp. Gaya ditukar di sini, dalam Tetapan — tiada tetingkap muncul semasa merakam.", "recordingNow": "Merakam…", "moreOptions": "Pilihan lain", "timedVoice": "Mesej suara berjadual dengan kata laluan", "password": "Kata laluan", "unlockVoice": "Buka suara", "cancelRecording": "Batalkan rakaman", "scheduleAndSend": "Simpan dan hantar", "prepareVoice": "Rakaman sedia", "sendNow": "Hantar sekarang", "afterMinute": "Selepas 1 minit", "afterHour": "Selepas 1 jam", "customDelay": "Masa sendiri", "minutes": "minit", "mobileNumber": "Nombor telefon bimbit", "profilePhoto": "Foto profil", "changePhoto": "Tukar foto", "addPhoto": "Tambah foto", "removePhoto": "Buang foto", "photoStatus": "Status foto", "textStatus": "Status teks", "findUser": "Cari pengguna", "appLanguage": "Bahasa aplikasi", "account": "Akaun", "privacy": "Privasi", "lists": "Senarai", "chatsSection": "Sembang", "appearance": "Penampilan", "storageData": "Storan dan data", "helpFeedback": "Bantuan dan maklum balas", "inviteFriend": "Jemput rakan", "block": "Sekat", "unblock": "Nyahsekat", "backup": "Sandaran", "downloadMedia": "Muat turun", "settingsSaved": "Disimpan", "openSection": "Buka", "retry": "Hantar semula", "microphone": "Mikrofon", "end": "Tamat"},
  zh: {"chats": "聊天", "status": "动态", "calls": "通话", "settings": "设置", "conversations": "聊天", "search": "搜索姓名或消息", "newChat": "新聊天", "message": "输入消息", "send": "发送消息", "voice": "录制语音消息", "notifications": "通知", "language": "语言", "wallpaper": "聊天壁纸", "tone": "消息提示音", "preview": "试听", "welcome": "欢迎", "createProfile": "创建你的资料", "yourName": "你的名字", "gmail": "Gmail 地址", "saving": "保存中…", "start": "开始", "close": "关闭", "addContact": "添加联系人", "contactName": "联系人姓名", "enterName": "输入姓名", "createChat": "创建聊天", "creating": "创建中…", "profile": "个人资料", "about": "简介", "save": "保存", "newStatus": "新动态", "postStatus": "发布动态", "audioMessage": "语音消息", "imageMessage": "照片", "chooseImage": "发送照片", "noMessages": "暂无消息", "playVoice": "播放语音消息", "pauseVoice": "暂停语音消息", "micPermission": "需要麦克风权限。", "stopSend": "停止录音并发送", "voiceSaving": "正在保存语音消息…", "loadingChat": "正在打开聊天…", "backChats": "返回聊天列表", "videoCall": "视频通话", "audioCall": "语音通话", "startChat": "开始聊天", "you": "你", "myStatus": "我的动态", "delete": "删除", "firstChat": "开始你的第一次聊天", "noSearch": "未找到聊天。", "addStatus": "添加你的动态", "contactStatuses": "联系人的动态", "newCall": "新通话", "noCalls": "暂无通话", "call": "通话", "editProfile": "编辑资料", "mute": "静音麦克风", "unmute": "取消静音", "endCall": "结束通话", "speaker": "扬声器", "loadingApp": "正在准备你的聊天…", "appError": "无法打开应用", "tryAgain": "请重试。", "reopen": "重新打开", "navigation": "主导航", "justNow": "刚刚", "hoursAgo": "小时前", "color": "颜色", "theme": "主题", "systemTheme": "跟随设备", "lightTheme": "浅色", "darkTheme": "深色", "username": "用户名", "chooseVoice": "语音风格", "originalVoice": "原声", "softVoice": "柔和", "deepVoice": "低沉", "brightVoice": "明亮", "quickVoice": "快速", "slowVoice": "慢速", "chipmunkVoice": "花栗鼠", "heliumVoice": "氦气声", "robotVoice": "机器人", "monsterVoice": "怪兽", "echoVoice": "回声", "caveVoice": "山洞", "voiceStyle": "语音风格", "voiceStyleHint": "此风格会应用于你发送的每条语音消息。选择原声，就会发送你的真实声音，和 WhatsApp 一样。风格在此处（设置）更改，录音时不会弹出窗口。", "recordingNow": "录音中…", "moreOptions": "更多选项", "timedVoice": "定时并带密码的语音", "password": "密码", "unlockVoice": "解锁语音", "cancelRecording": "取消录音", "scheduleAndSend": "保存并发送", "prepareVoice": "录音已就绪", "sendNow": "立即发送", "afterMinute": "1 分钟后", "afterHour": "1 小时后", "customDelay": "自定义时间", "minutes": "分钟", "mobileNumber": "手机号码", "profilePhoto": "头像", "changePhoto": "更换照片", "addPhoto": "添加照片", "removePhoto": "移除照片", "photoStatus": "照片动态", "textStatus": "文字动态", "findUser": "查找用户", "appLanguage": "应用语言", "account": "账号", "privacy": "隐私", "lists": "列表", "chatsSection": "聊天", "appearance": "外观", "storageData": "存储和数据", "helpFeedback": "帮助与反馈", "inviteFriend": "邀请朋友", "block": "拉黑", "unblock": "取消拉黑", "backup": "备份", "downloadMedia": "下载", "settingsSaved": "已保存", "openSection": "打开", "retry": "重新发送", "microphone": "麦克风", "end": "结束"},
  ja: {"chats": "チャット", "status": "ステータス", "calls": "通話", "settings": "設定", "conversations": "チャット", "search": "名前やメッセージを検索", "newChat": "新しいチャット", "message": "メッセージを入力", "send": "メッセージを送信", "voice": "音声メッセージを録音", "notifications": "通知", "language": "言語", "wallpaper": "チャットの壁紙", "tone": "メッセージ音", "preview": "試聴", "welcome": "ようこそ", "createProfile": "プロフィールを作成", "yourName": "お名前", "gmail": "Gmailアドレス", "saving": "保存中…", "start": "始める", "close": "閉じる", "addContact": "連絡先を追加", "contactName": "連絡先の名前", "enterName": "名前を入力", "createChat": "チャットを作成", "creating": "作成中…", "profile": "プロフィール", "about": "自己紹介", "save": "保存", "newStatus": "新しいステータス", "postStatus": "ステータスを投稿", "audioMessage": "音声メッセージ", "imageMessage": "写真", "chooseImage": "写真を送信", "noMessages": "まだメッセージがありません", "playVoice": "音声メッセージを再生", "pauseVoice": "音声メッセージを一時停止", "micPermission": "マイクの許可が必要です。", "stopSend": "録音を止めて送信", "voiceSaving": "音声メッセージを保存中…", "loadingChat": "チャットを開いています…", "backChats": "チャットに戻る", "videoCall": "ビデオ通話", "audioCall": "音声通話", "startChat": "会話を始めましょう", "you": "あなた", "myStatus": "自分のステータス", "delete": "削除", "firstChat": "最初のチャットを始める", "noSearch": "チャットが見つかりません。", "addStatus": "ステータスを追加", "contactStatuses": "連絡先のステータス", "newCall": "新しい通話", "noCalls": "まだ通話がありません", "call": "通話", "editProfile": "プロフィールを編集", "mute": "マイクをミュート", "unmute": "ミュートを解除", "endCall": "通話を終了", "speaker": "スピーカー", "loadingApp": "チャットを準備中…", "appError": "アプリを開けませんでした", "tryAgain": "もう一度お試しください。", "reopen": "もう一度開く", "navigation": "メインナビゲーション", "justNow": "たった今", "hoursAgo": "時間前", "color": "色", "theme": "テーマ", "systemTheme": "端末に合わせる", "lightTheme": "ライト", "darkTheme": "ダーク", "username": "ユーザー名", "chooseVoice": "音声スタイル", "originalVoice": "オリジナル", "softVoice": "ソフト", "deepVoice": "ディープ", "brightVoice": "ブライト", "quickVoice": "クイック", "slowVoice": "スロー", "chipmunkVoice": "シマリス", "heliumVoice": "ヘリウム", "robotVoice": "ロボット", "monsterVoice": "モンスター", "echoVoice": "エコー", "caveVoice": "洞窟", "voiceStyle": "音声スタイル", "voiceStyleHint": "このスタイルは送信するすべての音声メッセージに適用されます。オリジナルを選ぶと、WhatsAppと同じようにあなたの本当の声が送られます。スタイルはここ（設定）で変更します。録音中にポップアップは表示されません。", "recordingNow": "録音中…", "moreOptions": "その他のオプション", "timedVoice": "パスワード付きタイマー音声", "password": "パスワード", "unlockVoice": "音声を開く", "cancelRecording": "録音をキャンセル", "scheduleAndSend": "保存して送信", "prepareVoice": "録音の準備完了", "sendNow": "今すぐ送信", "afterMinute": "1分後", "afterHour": "1時間後", "customDelay": "カスタム時間", "minutes": "分", "mobileNumber": "携帯番号", "profilePhoto": "プロフィール写真", "changePhoto": "写真を変更", "addPhoto": "写真を追加", "removePhoto": "写真を削除", "photoStatus": "写真ステータス", "textStatus": "テキストステータス", "findUser": "ユーザーを探す", "appLanguage": "アプリの言語", "account": "アカウント", "privacy": "プライバシー", "lists": "リスト", "chatsSection": "チャット", "appearance": "外観", "storageData": "ストレージとデータ", "helpFeedback": "ヘルプとフィードバック", "inviteFriend": "友達を招待", "block": "ブロック", "unblock": "ブロック解除", "backup": "バックアップ", "downloadMedia": "ダウンロード", "settingsSaved": "保存しました", "openSection": "開く", "retry": "再送信", "microphone": "マイク", "end": "終了"},
  ko: {"chats": "채팅", "status": "상태", "calls": "통화", "settings": "설정", "conversations": "채팅", "search": "이름이나 메시지 검색", "newChat": "새 채팅", "message": "메시지를 입력하세요", "send": "메시지 보내기", "voice": "음성 메시지 녹음", "notifications": "알림", "language": "언어", "wallpaper": "채팅 배경화면", "tone": "메시지 소리", "preview": "들어보기", "welcome": "환영합니다", "createProfile": "프로필을 만드세요", "yourName": "이름", "gmail": "Gmail 주소", "saving": "저장 중…", "start": "시작하기", "close": "닫기", "addContact": "연락처 추가", "contactName": "연락처 이름", "enterName": "이름을 입력하세요", "createChat": "채팅 만들기", "creating": "만드는 중…", "profile": "프로필", "about": "소개", "save": "저장", "newStatus": "새 상태", "postStatus": "상태 올리기", "audioMessage": "음성 메시지", "imageMessage": "사진", "chooseImage": "사진 보내기", "noMessages": "아직 메시지가 없습니다", "playVoice": "음성 메시지 재생", "pauseVoice": "음성 메시지 일시정지", "micPermission": "마이크 권한이 필요합니다.", "stopSend": "녹음 중지하고 보내기", "voiceSaving": "음성 메시지 저장 중…", "loadingChat": "채팅 여는 중…", "backChats": "채팅으로 돌아가기", "videoCall": "영상 통화", "audioCall": "음성 통화", "startChat": "대화를 시작하세요", "you": "나", "myStatus": "내 상태", "delete": "삭제", "firstChat": "첫 채팅을 시작하세요", "noSearch": "채팅을 찾을 수 없습니다.", "addStatus": "내 상태 추가", "contactStatuses": "연락처 상태", "newCall": "새 통화", "noCalls": "아직 통화가 없습니다", "call": "통화", "editProfile": "프로필 편집", "mute": "마이크 끄기", "unmute": "마이크 켜기", "endCall": "통화 종료", "speaker": "스피커", "loadingApp": "채팅을 준비하는 중…", "appError": "앱을 열 수 없습니다", "tryAgain": "다시 시도하세요.", "reopen": "다시 열기", "navigation": "주요 탐색", "justNow": "방금", "hoursAgo": "시간 전", "color": "색상", "theme": "테마", "systemTheme": "기기 설정", "lightTheme": "밝게", "darkTheme": "어둡게", "username": "사용자 이름", "chooseVoice": "음성 스타일", "originalVoice": "원본", "softVoice": "부드럽게", "deepVoice": "저음", "brightVoice": "밝게", "quickVoice": "빠르게", "slowVoice": "느리게", "chipmunkVoice": "다람쥐", "heliumVoice": "헬륨", "robotVoice": "로봇", "monsterVoice": "괴물", "echoVoice": "메아리", "caveVoice": "동굴", "voiceStyle": "음성 스타일", "voiceStyleHint": "이 스타일은 보내는 모든 음성 메시지에 적용됩니다. 원본을 선택하면 WhatsApp처럼 실제 목소리가 전송됩니다. 스타일은 여기 설정에서 변경하며, 녹음 중에는 팝업이 뜨지 않습니다.", "recordingNow": "녹음 중…", "moreOptions": "옵션 더 보기", "timedVoice": "비밀번호가 있는 예약 음성", "password": "비밀번호", "unlockVoice": "음성 열기", "cancelRecording": "녹음 취소", "scheduleAndSend": "저장하고 보내기", "prepareVoice": "녹음 준비 완료", "sendNow": "지금 보내기", "afterMinute": "1분 후", "afterHour": "1시간 후", "customDelay": "직접 설정", "minutes": "분", "mobileNumber": "휴대폰 번호", "profilePhoto": "프로필 사진", "changePhoto": "사진 변경", "addPhoto": "사진 추가", "removePhoto": "사진 삭제", "photoStatus": "사진 상태", "textStatus": "글 상태", "findUser": "사용자 찾기", "appLanguage": "앱 언어", "account": "계정", "privacy": "개인정보", "lists": "목록", "chatsSection": "채팅", "appearance": "화면", "storageData": "저장공간 및 데이터", "helpFeedback": "도움말 및 의견", "inviteFriend": "친구 초대", "block": "차단", "unblock": "차단 해제", "backup": "백업", "downloadMedia": "다운로드", "settingsSaved": "저장됨", "openSection": "열기", "retry": "다시 보내기", "microphone": "마이크", "end": "종료"},
  it: {"chats": "Chat", "status": "Stato", "calls": "Chiamate", "settings": "Impostazioni", "conversations": "Chat", "search": "Cerca nome o messaggio", "newChat": "Nuova chat", "message": "Scrivi un messaggio", "send": "Invia messaggio", "voice": "Registra messaggio vocale", "notifications": "Notifiche", "language": "Lingua", "wallpaper": "Sfondo della chat", "tone": "Suono messaggio", "preview": "Ascolta", "welcome": "Benvenuto", "createProfile": "Crea il tuo profilo", "yourName": "Il tuo nome", "gmail": "Indirizzo Gmail", "saving": "Salvataggio…", "start": "Inizia", "close": "Chiudi", "addContact": "Aggiungi contatto", "contactName": "Nome del contatto", "enterName": "Inserisci un nome", "createChat": "Crea chat", "creating": "Creazione…", "profile": "Profilo", "about": "Info", "save": "Salva", "newStatus": "Nuovo stato", "postStatus": "Pubblica stato", "audioMessage": "Messaggio vocale", "imageMessage": "Foto", "chooseImage": "Invia una foto", "noMessages": "Ancora nessun messaggio", "playVoice": "Ascolta messaggio vocale", "pauseVoice": "Pausa messaggio vocale", "micPermission": "Serve il permesso per il microfono.", "stopSend": "Ferma la registrazione e invia", "voiceSaving": "Salvataggio del messaggio vocale…", "loadingChat": "Apertura chat…", "backChats": "Torna alle chat", "videoCall": "Videochiamata", "audioCall": "Chiamata audio", "startChat": "Inizia la conversazione", "you": "Tu", "myStatus": "Il mio stato", "delete": "Elimina", "firstChat": "Inizia la tua prima chat", "noSearch": "Nessuna chat trovata.", "addStatus": "Aggiungi il tuo stato", "contactStatuses": "Stati dei contatti", "newCall": "Nuova chiamata", "noCalls": "Ancora nessuna chiamata", "call": "Chiamata", "editProfile": "Modifica profilo", "mute": "Disattiva microfono", "unmute": "Riattiva microfono", "endCall": "Termina chiamata", "speaker": "Altoparlante", "loadingApp": "Preparazione delle chat…", "appError": "Impossibile aprire l'app", "tryAgain": "Riprova.", "reopen": "Riapri", "navigation": "Navigazione principale", "justNow": "Adesso", "hoursAgo": "ore fa", "color": "Colore", "theme": "Tema", "systemTheme": "Come il dispositivo", "lightTheme": "Chiaro", "darkTheme": "Scuro", "username": "Nome utente", "chooseVoice": "Stile vocale", "originalVoice": "Originale", "softVoice": "Morbida", "deepVoice": "Profonda", "brightVoice": "Brillante", "quickVoice": "Veloce", "slowVoice": "Lenta", "chipmunkVoice": "Scoiattolo", "heliumVoice": "Elio", "robotVoice": "Robot", "monsterVoice": "Mostro", "echoVoice": "Eco", "caveVoice": "Grotta", "voiceStyle": "Stile vocale", "voiceStyleHint": "Questo stile si applica a ogni messaggio vocale che invii. Scegli Originale e verrà inviata la tua vera voce, come su WhatsApp. Lo stile si cambia qui, nelle Impostazioni — durante la registrazione non compare nessuna finestra.", "recordingNow": "Registrazione…", "moreOptions": "Altre opzioni", "timedVoice": "Vocale a tempo con password", "password": "Password", "unlockVoice": "Sblocca vocale", "cancelRecording": "Annulla registrazione", "scheduleAndSend": "Salva e invia", "prepareVoice": "Registrazione pronta", "sendNow": "Invia ora", "afterMinute": "Dopo 1 minuto", "afterHour": "Dopo 1 ora", "customDelay": "Tempo personalizzato", "minutes": "minuti", "mobileNumber": "Numero di cellulare", "profilePhoto": "Foto profilo", "changePhoto": "Cambia foto", "addPhoto": "Aggiungi foto", "removePhoto": "Rimuovi foto", "photoStatus": "Stato con foto", "textStatus": "Stato di testo", "findUser": "Trova utente", "appLanguage": "Lingua dell'app", "account": "Account", "privacy": "Privacy", "lists": "Elenchi", "chatsSection": "Chat", "appearance": "Aspetto", "storageData": "Spazio e dati", "helpFeedback": "Aiuto e feedback", "inviteFriend": "Invita un amico", "block": "Blocca", "unblock": "Sblocca", "backup": "Backup", "downloadMedia": "Scarica", "settingsSaved": "Salvato", "openSection": "Apri", "retry": "Invia di nuovo", "microphone": "Microfono", "end": "Termina"},
  nl: {"chats": "Chats", "status": "Status", "calls": "Oproepen", "settings": "Instellingen", "conversations": "Chats", "search": "Zoek naam of bericht", "newChat": "Nieuwe chat", "message": "Typ een bericht", "send": "Bericht versturen", "voice": "Spraakbericht opnemen", "notifications": "Meldingen", "language": "Taal", "wallpaper": "Chat-achtergrond", "tone": "Berichttoon", "preview": "Beluisteren", "welcome": "Welkom", "createProfile": "Maak je profiel aan", "yourName": "Je naam", "gmail": "Gmail-adres", "saving": "Opslaan…", "start": "Starten", "close": "Sluiten", "addContact": "Contact toevoegen", "contactName": "Naam van contact", "enterName": "Voer een naam in", "createChat": "Chat maken", "creating": "Maken…", "profile": "Profiel", "about": "Info", "save": "Opslaan", "newStatus": "Nieuwe status", "postStatus": "Status plaatsen", "audioMessage": "Spraakbericht", "imageMessage": "Foto", "chooseImage": "Foto sturen", "noMessages": "Nog geen berichten", "playVoice": "Spraakbericht afspelen", "pauseVoice": "Spraakbericht pauzeren", "micPermission": "Microfoontoegang is nodig.", "stopSend": "Opname stoppen en sturen", "voiceSaving": "Spraakbericht opslaan…", "loadingChat": "Chat openen…", "backChats": "Terug naar chats", "videoCall": "Videogesprek", "audioCall": "Audiogesprek", "startChat": "Begin het gesprek", "you": "Jij", "myStatus": "Mijn status", "delete": "Verwijderen", "firstChat": "Start je eerste chat", "noSearch": "Geen chats gevonden.", "addStatus": "Voeg je status toe", "contactStatuses": "Statussen van contacten", "newCall": "Nieuw gesprek", "noCalls": "Nog geen oproepen", "call": "Oproep", "editProfile": "Profiel bewerken", "mute": "Microfoon dempen", "unmute": "Microfoon aanzetten", "endCall": "Gesprek beëindigen", "speaker": "Luidspreker", "loadingApp": "Je chats worden voorbereid…", "appError": "De app kon niet worden geopend", "tryAgain": "Probeer het opnieuw.", "reopen": "Opnieuw openen", "navigation": "Hoofdnavigatie", "justNow": "Zojuist", "hoursAgo": "uur geleden", "color": "Kleur", "theme": "Thema", "systemTheme": "Zoals apparaat", "lightTheme": "Licht", "darkTheme": "Donker", "username": "Gebruikersnaam", "chooseVoice": "Stemstijl", "originalVoice": "Origineel", "softVoice": "Zacht", "deepVoice": "Diep", "brightVoice": "Helder", "quickVoice": "Snel", "slowVoice": "Langzaam", "chipmunkVoice": "Chipmunk", "heliumVoice": "Helium", "robotVoice": "Robot", "monsterVoice": "Monster", "echoVoice": "Echo", "caveVoice": "Grot", "voiceStyle": "Stemstijl", "voiceStyleHint": "Deze stijl geldt voor elk spraakbericht dat je stuurt. Kies Origineel en je echte stem wordt verstuurd, net als bij WhatsApp. De stijl wijzig je hier in Instellingen — tijdens het opnemen verschijnt er geen venster.", "recordingNow": "Opnemen…", "moreOptions": "Meer opties", "timedVoice": "Getimed spraakbericht met wachtwoord", "password": "Wachtwoord", "unlockVoice": "Stem ontgrendelen", "cancelRecording": "Opname annuleren", "scheduleAndSend": "Opslaan en sturen", "prepareVoice": "Opname is klaar", "sendNow": "Nu sturen", "afterMinute": "Na 1 minuut", "afterHour": "Na 1 uur", "customDelay": "Eigen tijd", "minutes": "minuten", "mobileNumber": "Mobiel nummer", "profilePhoto": "Profielfoto", "changePhoto": "Foto wijzigen", "addPhoto": "Foto toevoegen", "removePhoto": "Foto verwijderen", "photoStatus": "Foto-status", "textStatus": "Tekst-status", "findUser": "Gebruiker zoeken", "appLanguage": "App-taal", "account": "Account", "privacy": "Privacy", "lists": "Lijsten", "chatsSection": "Chats", "appearance": "Weergave", "storageData": "Opslag en data", "helpFeedback": "Help en feedback", "inviteFriend": "Vriend uitnodigen", "block": "Blokkeren", "unblock": "Deblokkeren", "backup": "Back-up", "downloadMedia": "Downloaden", "settingsSaved": "Opgeslagen", "openSection": "Openen", "retry": "Opnieuw sturen", "microphone": "Microfoon", "end": "Beëindigen"},
  th: {"chats": "แชท", "status": "สถานะ", "calls": "การโทร", "settings": "การตั้งค่า", "conversations": "แชท", "search": "ค้นหาชื่อหรือข้อความ", "newChat": "แชทใหม่", "message": "พิมพ์ข้อความ", "send": "ส่งข้อความ", "voice": "บันทึกข้อความเสียง", "notifications": "การแจ้งเตือน", "language": "ภาษา", "wallpaper": "วอลเปเปอร์แชท", "tone": "เสียงข้อความ", "preview": "ฟัง", "welcome": "ยินดีต้อนรับ", "createProfile": "สร้างโปรไฟล์ของคุณ", "yourName": "ชื่อของคุณ", "gmail": "ที่อยู่ Gmail", "saving": "กำลังบันทึก…", "start": "เริ่มต้น", "close": "ปิด", "addContact": "เพิ่มผู้ติดต่อ", "contactName": "ชื่อผู้ติดต่อ", "enterName": "กรอกชื่อ", "createChat": "สร้างแชท", "creating": "กำลังสร้าง…", "profile": "โปรไฟล์", "about": "เกี่ยวกับ", "save": "บันทึก", "newStatus": "สถานะใหม่", "postStatus": "โพสต์สถานะ", "audioMessage": "ข้อความเสียง", "imageMessage": "รูปภาพ", "chooseImage": "ส่งรูปภาพ", "noMessages": "ยังไม่มีข้อความ", "playVoice": "เล่นข้อความเสียง", "pauseVoice": "หยุดข้อความเสียงชั่วคราว", "micPermission": "ต้องอนุญาตไมโครโฟน", "stopSend": "หยุดบันทึกและส่ง", "voiceSaving": "กำลังบันทึกข้อความเสียง…", "loadingChat": "กำลังเปิดแชท…", "backChats": "กลับไปแชท", "videoCall": "วิดีโอคอล", "audioCall": "โทรเสียง", "startChat": "เริ่มการสนทนา", "you": "คุณ", "myStatus": "สถานะของฉัน", "delete": "ลบ", "firstChat": "เริ่มแชทแรกของคุณ", "noSearch": "ไม่พบแชท", "addStatus": "เพิ่มสถานะของคุณ", "contactStatuses": "สถานะของผู้ติดต่อ", "newCall": "การโทรใหม่", "noCalls": "ยังไม่มีการโทร", "call": "โทร", "editProfile": "แก้ไขโปรไฟล์", "mute": "ปิดเสียงไมค์", "unmute": "เปิดเสียงไมค์", "endCall": "วางสาย", "speaker": "ลำโพง", "loadingApp": "กำลังเตรียมแชทของคุณ…", "appError": "เปิดแอปไม่ได้", "tryAgain": "ลองอีกครั้ง", "reopen": "เปิดอีกครั้ง", "navigation": "เมนูหลัก", "justNow": "เมื่อสักครู่", "hoursAgo": "ชั่วโมงที่แล้ว", "color": "สี", "theme": "ธีม", "systemTheme": "ตามอุปกรณ์", "lightTheme": "สว่าง", "darkTheme": "มืด", "username": "ชื่อผู้ใช้", "chooseVoice": "สไตล์เสียง", "originalVoice": "เสียงจริง", "softVoice": "นุ่ม", "deepVoice": "ทุ้ม", "brightVoice": "สดใส", "quickVoice": "เร็ว", "slowVoice": "ช้า", "chipmunkVoice": "ชิพมังก์", "heliumVoice": "ฮีเลียม", "robotVoice": "หุ่นยนต์", "monsterVoice": "สัตว์ประหลาด", "echoVoice": "เสียงสะท้อน", "caveVoice": "ถ้ำ", "voiceStyle": "สไตล์เสียง", "voiceStyleHint": "สไตล์นี้จะใช้กับทุกข้อความเสียงที่คุณส่ง เลือกเสียงจริง เสียงจริงของคุณจะถูกส่ง เหมือน WhatsApp สไตล์เปลี่ยนได้ที่นี่ในการตั้งค่า — ขณะบันทึกจะไม่มีหน้าต่างเด้งขึ้นมา", "recordingNow": "กำลังบันทึก…", "moreOptions": "ตัวเลือกเพิ่มเติม", "timedVoice": "ข้อความเสียงตั้งเวลาพร้อมรหัสผ่าน", "password": "รหัสผ่าน", "unlockVoice": "ปลดล็อกเสียง", "cancelRecording": "ยกเลิกการบันทึก", "scheduleAndSend": "บันทึกและส่ง", "prepareVoice": "บันทึกพร้อมแล้ว", "sendNow": "ส่งตอนนี้", "afterMinute": "หลัง 1 นาที", "afterHour": "หลัง 1 ชั่วโมง", "customDelay": "กำหนดเอง", "minutes": "นาที", "mobileNumber": "เบอร์มือถือ", "profilePhoto": "รูปโปรไฟล์", "changePhoto": "เปลี่ยนรูป", "addPhoto": "เพิ่มรูป", "removePhoto": "ลบรูป", "photoStatus": "สถานะรูปภาพ", "textStatus": "สถานะข้อความ", "findUser": "ค้นหาผู้ใช้", "appLanguage": "ภาษาของแอป", "account": "บัญชี", "privacy": "ความเป็นส่วนตัว", "lists": "รายการ", "chatsSection": "แชท", "appearance": "รูปลักษณ์", "storageData": "พื้นที่จัดเก็บและข้อมูล", "helpFeedback": "ความช่วยเหลือและคำติชม", "inviteFriend": "เชิญเพื่อน", "block": "บล็อก", "unblock": "เลิกบล็อก", "backup": "สำรองข้อมูล", "downloadMedia": "ดาวน์โหลด", "settingsSaved": "บันทึกแล้ว", "openSection": "เปิด", "retry": "ส่งอีกครั้ง", "microphone": "ไมโครโฟน", "end": "สิ้นสุด"},
  vi: {"chats": "Trò chuyện", "status": "Trạng thái", "calls": "Cuộc gọi", "settings": "Cài đặt", "conversations": "Trò chuyện", "search": "Tìm tên hoặc tin nhắn", "newChat": "Trò chuyện mới", "message": "Nhập tin nhắn", "send": "Gửi tin nhắn", "voice": "Ghi âm tin nhắn thoại", "notifications": "Thông báo", "language": "Ngôn ngữ", "wallpaper": "Hình nền trò chuyện", "tone": "Âm tin nhắn", "preview": "Nghe thử", "welcome": "Chào mừng", "createProfile": "Tạo hồ sơ của bạn", "yourName": "Tên của bạn", "gmail": "Địa chỉ Gmail", "saving": "Đang lưu…", "start": "Bắt đầu", "close": "Đóng", "addContact": "Thêm liên hệ", "contactName": "Tên liên hệ", "enterName": "Nhập tên", "createChat": "Tạo trò chuyện", "creating": "Đang tạo…", "profile": "Hồ sơ", "about": "Giới thiệu", "save": "Lưu", "newStatus": "Trạng thái mới", "postStatus": "Đăng trạng thái", "audioMessage": "Tin nhắn thoại", "imageMessage": "Ảnh", "chooseImage": "Gửi ảnh", "noMessages": "Chưa có tin nhắn", "playVoice": "Phát tin nhắn thoại", "pauseVoice": "Tạm dừng tin nhắn thoại", "micPermission": "Cần quyền dùng micrô.", "stopSend": "Dừng ghi và gửi", "voiceSaving": "Đang lưu tin nhắn thoại…", "loadingChat": "Đang mở trò chuyện…", "backChats": "Quay lại trò chuyện", "videoCall": "Gọi video", "audioCall": "Gọi thoại", "startChat": "Bắt đầu cuộc trò chuyện", "you": "Bạn", "myStatus": "Trạng thái của tôi", "delete": "Xóa", "firstChat": "Bắt đầu trò chuyện đầu tiên", "noSearch": "Không tìm thấy trò chuyện.", "addStatus": "Thêm trạng thái của bạn", "contactStatuses": "Trạng thái của liên hệ", "newCall": "Cuộc gọi mới", "noCalls": "Chưa có cuộc gọi", "call": "Cuộc gọi", "editProfile": "Sửa hồ sơ", "mute": "Tắt mic", "unmute": "Bật mic", "endCall": "Kết thúc cuộc gọi", "speaker": "Loa ngoài", "loadingApp": "Đang chuẩn bị trò chuyện…", "appError": "Không mở được ứng dụng", "tryAgain": "Thử lại.", "reopen": "Mở lại", "navigation": "Điều hướng chính", "justNow": "Vừa xong", "hoursAgo": "giờ trước", "color": "Màu", "theme": "Chủ đề", "systemTheme": "Theo thiết bị", "lightTheme": "Sáng", "darkTheme": "Tối", "username": "Tên người dùng", "chooseVoice": "Phong cách giọng", "originalVoice": "Gốc", "softVoice": "Nhẹ", "deepVoice": "Trầm", "brightVoice": "Sáng", "quickVoice": "Nhanh", "slowVoice": "Chậm", "chipmunkVoice": "Sóc chuột", "heliumVoice": "Heli", "robotVoice": "Robot", "monsterVoice": "Quái vật", "echoVoice": "Vang", "caveVoice": "Hang động", "voiceStyle": "Phong cách giọng", "voiceStyleHint": "Phong cách này áp dụng cho mọi tin nhắn thoại bạn gửi. Chọn Gốc, giọng thật của bạn sẽ được gửi, giống như WhatsApp. Phong cách được đổi tại đây, trong Cài đặt — không có cửa sổ hiện lên khi ghi âm.", "recordingNow": "Đang ghi…", "moreOptions": "Tùy chọn khác", "timedVoice": "Tin nhắn thoại hẹn giờ có mật khẩu", "password": "Mật khẩu", "unlockVoice": "Mở khóa thoại", "cancelRecording": "Hủy ghi âm", "scheduleAndSend": "Lưu và gửi", "prepareVoice": "Đã ghi xong", "sendNow": "Gửi ngay", "afterMinute": "Sau 1 phút", "afterHour": "Sau 1 giờ", "customDelay": "Tự chọn thời gian", "minutes": "phút", "mobileNumber": "Số điện thoại", "profilePhoto": "Ảnh hồ sơ", "changePhoto": "Đổi ảnh", "addPhoto": "Thêm ảnh", "removePhoto": "Xóa ảnh", "photoStatus": "Trạng thái ảnh", "textStatus": "Trạng thái chữ", "findUser": "Tìm người dùng", "appLanguage": "Ngôn ngữ ứng dụng", "account": "Tài khoản", "privacy": "Quyền riêng tư", "lists": "Danh sách", "chatsSection": "Trò chuyện", "appearance": "Giao diện", "storageData": "Bộ nhớ và dữ liệu", "helpFeedback": "Trợ giúp và góp ý", "inviteFriend": "Mời bạn bè", "block": "Chặn", "unblock": "Bỏ chặn", "backup": "Sao lưu", "downloadMedia": "Tải xuống", "settingsSaved": "Đã lưu", "openSection": "Mở", "retry": "Gửi lại", "microphone": "Micrô", "end": "Kết thúc"},
  sw: {"chats": "Gumzo", "status": "Hali", "calls": "Simu", "settings": "Mipangilio", "conversations": "Gumzo", "search": "Tafuta jina au ujumbe", "newChat": "Gumzo jipya", "message": "Andika ujumbe", "send": "Tuma ujumbe", "voice": "Rekodi ujumbe wa sauti", "notifications": "Arifa", "language": "Lugha", "wallpaper": "Mandharinyuma ya gumzo", "tone": "Sauti ya ujumbe", "preview": "Sikiliza", "welcome": "Karibu", "createProfile": "Tengeneza wasifu wako", "yourName": "Jina lako", "gmail": "Anwani ya Gmail", "saving": "Inahifadhi…", "start": "Anza", "close": "Funga", "addContact": "Ongeza anwani", "contactName": "Jina la anwani", "enterName": "Andika jina", "createChat": "Tengeneza gumzo", "creating": "Inatengeneza…", "profile": "Wasifu", "about": "Kuhusu", "save": "Hifadhi", "newStatus": "Hali mpya", "postStatus": "Weka hali", "audioMessage": "Ujumbe wa sauti", "imageMessage": "Picha", "chooseImage": "Tuma picha", "noMessages": "Hakuna ujumbe bado", "playVoice": "Cheza ujumbe wa sauti", "pauseVoice": "Sitisha ujumbe wa sauti", "micPermission": "Ruhusa ya kipaza sauti inahitajika.", "stopSend": "Acha kurekodi na utume", "voiceSaving": "Inahifadhi ujumbe wa sauti…", "loadingChat": "Inafungua gumzo…", "backChats": "Rudi kwenye gumzo", "videoCall": "Simu ya video", "audioCall": "Simu ya sauti", "startChat": "Anzisha mazungumzo", "you": "Wewe", "myStatus": "Hali yangu", "delete": "Futa", "firstChat": "Anzisha gumzo lako la kwanza", "noSearch": "Hakuna gumzo lililopatikana.", "addStatus": "Ongeza hali yako", "contactStatuses": "Hali za anwani", "newCall": "Simu mpya", "noCalls": "Hakuna simu bado", "call": "Simu", "editProfile": "Hariri wasifu", "mute": "Zima kipaza sauti", "unmute": "Washa kipaza sauti", "endCall": "Maliza simu", "speaker": "Spika", "loadingApp": "Gumzo zako zinaandaliwa…", "appError": "Programu haikufunguka", "tryAgain": "Jaribu tena.", "reopen": "Fungua tena", "navigation": "Urambazaji mkuu", "justNow": "Sasa hivi", "hoursAgo": "saa zilizopita", "color": "Rangi", "theme": "Mandhari", "systemTheme": "Kama kifaa", "lightTheme": "Nyepesi", "darkTheme": "Giza", "username": "Jina la mtumiaji", "chooseVoice": "Mtindo wa sauti", "originalVoice": "Asili", "softVoice": "Laini", "deepVoice": "Nzito", "brightVoice": "Angavu", "quickVoice": "Haraka", "slowVoice": "Polepole", "chipmunkVoice": "Kindi", "heliumVoice": "Heliamu", "robotVoice": "Roboti", "monsterVoice": "Jitu", "echoVoice": "Mwangwi", "caveVoice": "Pango", "voiceStyle": "Mtindo wa sauti", "voiceStyleHint": "Mtindo huu hutumika kwa kila ujumbe wa sauti unaotuma. Chagua Asili, sauti yako halisi itatumwa, kama WhatsApp. Mtindo hubadilishwa hapa, kwenye Mipangilio — hakuna dirisha linalojitokeza wakati wa kurekodi.", "recordingNow": "Inarekodi…", "moreOptions": "Chaguo zaidi", "timedVoice": "Ujumbe wa sauti wa muda wenye nenosiri", "password": "Nenosiri", "unlockVoice": "Fungua sauti", "cancelRecording": "Ghairi kurekodi", "scheduleAndSend": "Hifadhi na utume", "prepareVoice": "Rekodi iko tayari", "sendNow": "Tuma sasa", "afterMinute": "Baada ya dakika 1", "afterHour": "Baada ya saa 1", "customDelay": "Muda maalum", "minutes": "dakika", "mobileNumber": "Namba ya simu", "profilePhoto": "Picha ya wasifu", "changePhoto": "Badilisha picha", "addPhoto": "Ongeza picha", "removePhoto": "Ondoa picha", "photoStatus": "Hali ya picha", "textStatus": "Hali ya maandishi", "findUser": "Tafuta mtumiaji", "appLanguage": "Lugha ya programu", "account": "Akaunti", "privacy": "Faragha", "lists": "Orodha", "chatsSection": "Gumzo", "appearance": "Muonekano", "storageData": "Hifadhi na data", "helpFeedback": "Msaada na maoni", "inviteFriend": "Mkaribishe rafiki", "block": "Zuia", "unblock": "Ondoa zuio", "backup": "Nakala rudufu", "downloadMedia": "Pakua", "settingsSaved": "Imehifadhiwa", "openSection": "Fungua", "retry": "Tuma tena", "microphone": "Kipaza sauti", "end": "Maliza"},
  uk: {"chats": "Чати", "status": "Статус", "calls": "Дзвінки", "settings": "Налаштування", "conversations": "Чати", "search": "Пошук за іменем чи повідомленням", "newChat": "Новий чат", "message": "Напишіть повідомлення", "send": "Надіслати повідомлення", "voice": "Записати голосове повідомлення", "notifications": "Сповіщення", "language": "Мова", "wallpaper": "Фон чату", "tone": "Звук повідомлення", "preview": "Слухати", "welcome": "Ласкаво просимо", "createProfile": "Створіть профіль", "yourName": "Ваше ім’я", "gmail": "Адреса Gmail", "saving": "Збереження…", "start": "Почати", "close": "Закрити", "addContact": "Додати контакт", "contactName": "Ім’я контакту", "enterName": "Введіть ім’я", "createChat": "Створити чат", "creating": "Створення…", "profile": "Профіль", "about": "Про себе", "save": "Зберегти", "newStatus": "Новий статус", "postStatus": "Опублікувати статус", "audioMessage": "Голосове повідомлення", "imageMessage": "Фото", "chooseImage": "Надіслати фото", "noMessages": "Повідомлень ще немає", "playVoice": "Слухати голосове повідомлення", "pauseVoice": "Пауза", "micPermission": "Потрібен доступ до мікрофона.", "stopSend": "Зупинити запис і надіслати", "voiceSaving": "Збереження голосового повідомлення…", "loadingChat": "Відкриття чату…", "backChats": "Назад до чатів", "videoCall": "Відеодзвінок", "audioCall": "Аудіодзвінок", "startChat": "Почніть розмову", "you": "Ви", "myStatus": "Мій статус", "delete": "Видалити", "firstChat": "Почніть перший чат", "noSearch": "Чатів не знайдено.", "addStatus": "Додайте статус", "contactStatuses": "Статуси контактів", "newCall": "Новий дзвінок", "noCalls": "Дзвінків ще немає", "call": "Дзвінок", "editProfile": "Редагувати профіль", "mute": "Вимкнути мікрофон", "unmute": "Увімкнути мікрофон", "endCall": "Завершити дзвінок", "speaker": "Динамік", "loadingApp": "Підготовка чатів…", "appError": "Не вдалося відкрити додаток", "tryAgain": "Спробуйте ще раз.", "reopen": "Відкрити знову", "navigation": "Головна навігація", "justNow": "Щойно", "hoursAgo": "год тому", "color": "Колір", "theme": "Тема", "systemTheme": "Як на пристрої", "lightTheme": "Світла", "darkTheme": "Темна", "username": "Ім’я користувача", "chooseVoice": "Стиль голосу", "originalVoice": "Оригінал", "softVoice": "М’який", "deepVoice": "Глибокий", "brightVoice": "Яскравий", "quickVoice": "Швидкий", "slowVoice": "Повільний", "chipmunkVoice": "Бурундук", "heliumVoice": "Гелій", "robotVoice": "Робот", "monsterVoice": "Монстр", "echoVoice": "Луна", "caveVoice": "Печера", "voiceStyle": "Стиль голосу", "voiceStyleHint": "Цей стиль застосовується до кожного голосового повідомлення, яке ви надсилаєте. Оберіть «Оригінал» — і надсилатиметься ваш справжній голос, як у WhatsApp. Стиль змінюється тут, у Налаштуваннях, — під час запису вікно не з’являється.", "recordingNow": "Йде запис…", "moreOptions": "Більше варіантів", "timedVoice": "Голос за розкладом із паролем", "password": "Пароль", "unlockVoice": "Відкрити голос", "cancelRecording": "Скасувати запис", "scheduleAndSend": "Зберегти й надіслати", "prepareVoice": "Запис готовий", "sendNow": "Надіслати зараз", "afterMinute": "Через 1 хвилину", "afterHour": "Через 1 годину", "customDelay": "Свій час", "minutes": "хвилин", "mobileNumber": "Номер телефону", "profilePhoto": "Фото профілю", "changePhoto": "Змінити фото", "addPhoto": "Додати фото", "removePhoto": "Прибрати фото", "photoStatus": "Статус із фото", "textStatus": "Текстовий статус", "findUser": "Знайти користувача", "appLanguage": "Мова додатка", "account": "Акаунт", "privacy": "Конфіденційність", "lists": "Списки", "chatsSection": "Чати", "appearance": "Оформлення", "storageData": "Сховище й дані", "helpFeedback": "Допомога та відгуки", "inviteFriend": "Запросити друга", "block": "Заблокувати", "unblock": "Розблокувати", "backup": "Резервна копія", "downloadMedia": "Завантажити", "settingsSaved": "Збережено", "openSection": "Відкрити", "retry": "Надіслати знову", "microphone": "Мікрофон", "end": "Завершити"},
  pl: {"chats": "Czaty", "status": "Status", "calls": "Połączenia", "settings": "Ustawienia", "conversations": "Czaty", "search": "Szukaj nazwy lub wiadomości", "newChat": "Nowy czat", "message": "Napisz wiadomość", "send": "Wyślij wiadomość", "voice": "Nagraj wiadomość głosową", "notifications": "Powiadomienia", "language": "Język", "wallpaper": "Tapeta czatu", "tone": "Dźwięk wiadomości", "preview": "Posłuchaj", "welcome": "Witaj", "createProfile": "Utwórz swój profil", "yourName": "Twoje imię", "gmail": "Adres Gmail", "saving": "Zapisywanie…", "start": "Zacznij", "close": "Zamknij", "addContact": "Dodaj kontakt", "contactName": "Nazwa kontaktu", "enterName": "Wpisz nazwę", "createChat": "Utwórz czat", "creating": "Tworzenie…", "profile": "Profil", "about": "O mnie", "save": "Zapisz", "newStatus": "Nowy status", "postStatus": "Opublikuj status", "audioMessage": "Wiadomość głosowa", "imageMessage": "Zdjęcie", "chooseImage": "Wyślij zdjęcie", "noMessages": "Brak wiadomości", "playVoice": "Odtwórz wiadomość głosową", "pauseVoice": "Wstrzymaj wiadomość głosową", "micPermission": "Potrzebna jest zgoda na mikrofon.", "stopSend": "Zatrzymaj nagrywanie i wyślij", "voiceSaving": "Zapisywanie wiadomości głosowej…", "loadingChat": "Otwieranie czatu…", "backChats": "Wróć do czatów", "videoCall": "Połączenie wideo", "audioCall": "Połączenie głosowe", "startChat": "Rozpocznij rozmowę", "you": "Ty", "myStatus": "Mój status", "delete": "Usuń", "firstChat": "Rozpocznij pierwszy czat", "noSearch": "Nie znaleziono czatów.", "addStatus": "Dodaj swój status", "contactStatuses": "Statusy kontaktów", "newCall": "Nowe połączenie", "noCalls": "Brak połączeń", "call": "Połączenie", "editProfile": "Edytuj profil", "mute": "Wycisz mikrofon", "unmute": "Wyłącz wyciszenie", "endCall": "Zakończ połączenie", "speaker": "Głośnik", "loadingApp": "Przygotowywanie czatów…", "appError": "Nie udało się otworzyć aplikacji", "tryAgain": "Spróbuj ponownie.", "reopen": "Otwórz ponownie", "navigation": "Nawigacja główna", "justNow": "Przed chwilą", "hoursAgo": "godz. temu", "color": "Kolor", "theme": "Motyw", "systemTheme": "Jak urządzenie", "lightTheme": "Jasny", "darkTheme": "Ciemny", "username": "Nazwa użytkownika", "chooseVoice": "Styl głosu", "originalVoice": "Oryginał", "softVoice": "Łagodny", "deepVoice": "Głęboki", "brightVoice": "Jasny", "quickVoice": "Szybki", "slowVoice": "Wolny", "chipmunkVoice": "Wiewiórka", "heliumVoice": "Hel", "robotVoice": "Robot", "monsterVoice": "Potwór", "echoVoice": "Echo", "caveVoice": "Jaskinia", "voiceStyle": "Styl głosu", "voiceStyleHint": "Ten styl jest stosowany do każdej wysyłanej wiadomości głosowej. Wybierz Oryginał, a wyślesz swój prawdziwy głos — jak w WhatsApp. Styl zmienia się tutaj, w Ustawieniach — podczas nagrywania nie pojawia się żadne okno.", "recordingNow": "Nagrywanie…", "moreOptions": "Więcej opcji", "timedVoice": "Wiadomość głosowa z timerem i hasłem", "password": "Hasło", "unlockVoice": "Odblokuj głos", "cancelRecording": "Anuluj nagrywanie", "scheduleAndSend": "Zapisz i wyślij", "prepareVoice": "Nagranie gotowe", "sendNow": "Wyślij teraz", "afterMinute": "Po 1 minucie", "afterHour": "Po 1 godzinie", "customDelay": "Własny czas", "minutes": "minut", "mobileNumber": "Numer telefonu", "profilePhoto": "Zdjęcie profilowe", "changePhoto": "Zmień zdjęcie", "addPhoto": "Dodaj zdjęcie", "removePhoto": "Usuń zdjęcie", "photoStatus": "Status ze zdjęciem", "textStatus": "Status tekstowy", "findUser": "Znajdź użytkownika", "appLanguage": "Język aplikacji", "account": "Konto", "privacy": "Prywatność", "lists": "Listy", "chatsSection": "Czaty", "appearance": "Wygląd", "storageData": "Pamięć i dane", "helpFeedback": "Pomoc i opinie", "inviteFriend": "Zaproś znajomego", "block": "Zablokuj", "unblock": "Odblokuj", "backup": "Kopia zapasowa", "downloadMedia": "Pobierz", "settingsSaved": "Zapisano", "openSection": "Otwórz", "retry": "Wyślij ponownie", "microphone": "Mikrofon", "end": "Zakończ"},
};
const LocaleContext = createContext<Language>("ur");
function useLocale() { const language = useContext(LocaleContext); return { language, t: (key: TextKey): string => UI_TEXT[language][key] ?? UI_TEXT.en[key] ?? UR_TEXT[key], dir: RTL_LANGUAGES.includes(language) ? "rtl" as const : "ltr" as const, locale: LANGUAGE_LOCALES[language] }; }

function playTone(tone: MessageTone) {
  if (tone === "none") return;
  try {
    const AudioContextClass = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const context = new AudioContextClass();
    const now = context.currentTime;
    const scores: Record<Exclude<MessageTone, "none">, { notes: number[]; step: number; wave: OscillatorType }> = {
      saba: { notes: [587, 784, 988], step: .075, wave: "sine" },
      noor: { notes: [740, 932], step: .13, wave: "triangle" },
      raqs: { notes: [392, 523, 659, 523], step: .065, wave: "square" },
      aabshar: { notes: [1047, 880, 698], step: .085, wave: "sine" },
      sukoon: { notes: [440, 554], step: .18, wave: "sine" },
    };
    const score = scores[tone];
    score.notes.forEach((frequency, index) => {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = score.wave;
      oscillator.frequency.setValueAtTime(frequency, now + index * score.step);
      const start = now + index * score.step;
      gain.gain.setValueAtTime(.0001, start);
      gain.gain.exponentialRampToValueAtTime(tone === "raqs" ? .045 : .085, start + .012);
      gain.gain.exponentialRampToValueAtTime(.0001, start + .14);
      oscillator.connect(gain); gain.connect(context.destination);
      oscillator.start(start); oscillator.stop(start + .15);
    });
    window.setTimeout(() => void context.close(), 900);
  } catch { /* Sound preview is optional when the host blocks audio. */ }
}

function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0] ?? "").join("").toUpperCase() || "ر";
}

function Avatar({ name, photo, size = "" }: { name: string; photo?: string | null; size?: "" | "small" | "large" | "xlarge" }) {
  return <div className={`avatar${size ? ` ${size}` : ""}`} aria-hidden="true">{photo ? <img src={photo} alt=""/> : initials(name)}</div>;
}

function dataUrlToUpload(dataUrl: string | null): { data_base64: string; mime_type: "image/jpeg" | "image/png" | "image/webp" } | null {
  if (!dataUrl) return null;
  const match = /^data:(image\/(?:jpeg|png|webp));base64,(.+)$/.exec(dataUrl);
  if (!match) return null;
  return { data_base64: match[2] ?? "", mime_type: match[1] as "image/jpeg" | "image/png" | "image/webp" };
}

function useProfilePhotoDraft(initialPhoto: string | null, errorText: string) {
  const [photo, setPhoto] = useState<string | null>(initialPhoto);
  const [photoChanged, setPhotoChanged] = useState(false);
  const [photoError, setPhotoError] = useState("");
  const [photoBusy, setPhotoBusy] = useState(false);
  const pickPhoto = async (file: File | undefined) => {
    if (!file) return;
    if (!(["image/jpeg", "image/png", "image/webp"] as string[]).includes(file.type)) { setPhotoError(errorText); return; }
    setPhotoBusy(true); setPhotoError("");
    try {
      const dataUrl = await profileImageFileToDataUrl(file);
      setPhoto(dataUrl); setPhotoChanged(true);
    } catch { setPhotoError(errorText); }
    finally { setPhotoBusy(false); }
  };
  const removePhoto = () => { setPhoto(null); setPhotoChanged(true); setPhotoError(""); };
  return { photo, setPhoto, photoChanged, setPhotoChanged, photoError, photoBusy, pickPhoto, removePhoto };
}

async function saveProfilePhotoDraft(draft: { photo: string | null; photoChanged: boolean }) {
  if (!draft.photoChanged) return;
  const upload = dataUrlToUpload(draft.photo);
  await backend.saveProfilePhoto(upload ? { data_base64: upload.data_base64, mime_type: upload.mime_type } : { data_base64: null });
}

type PhotoDraft = ReturnType<typeof useProfilePhotoDraft>;

function ProfilePhotoField({ name, draft, inputId }: { name: string; draft: PhotoDraft; inputId: string }) {
  const { t } = useLocale();
  return <div className="photo-field"><Avatar name={name || "?"} photo={draft.photo} size="large"/><div className="photo-actions"><label className="photo-button" htmlFor={inputId}><Icon name="camera" size={17}/> {draft.photo ? t("changePhoto") : t("addPhoto")}</label><input id={inputId} className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" disabled={draft.photoBusy} onChange={(event) => { void draft.pickPhoto(event.target.files?.[0]); event.currentTarget.value = ""; }}/>{draft.photo && <button type="button" className="text-button danger" onClick={draft.removePhoto}>{t("removePhoto")}</button>}</div>{draft.photoError && <InlineError message={draft.photoError}/>}</div>;
}
function formatListTime(value: string, locale: string) { const date = new Date(value); const sameDay = date.toDateString() === new Date().toDateString(); return new Intl.DateTimeFormat(locale, sameDay ? { hour: "numeric", minute: "2-digit" } : { day: "numeric", month: "short" }).format(date); }
function formatMessageTime(value: string, locale: string) { return new Intl.DateTimeFormat(locale, { hour: "numeric", minute: "2-digit" }).format(new Date(value)); }
function formatDuration(seconds: number) { return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`; }
function statusAge(value: string, language: Language) { const hours = Math.floor((Date.now() - new Date(value).getTime()) / 3_600_000); const text = UI_TEXT[language]; const locale = LANGUAGE_LOCALES[language]; return hours < 1 ? text.justNow : `${new Intl.NumberFormat(locale).format(hours)} ${text.hoursAgo}`; }
function InlineError({ message }: { message: string }) { return <p className="form-error" role="alert">{message}</p>; }

function AppLogo({ size = 30 }: { size?: number }) {
  return <img className="brand-logo-img" src={boloLogoIcon} alt="" aria-hidden="true" width={size} height={size}/>;
}

function BrandWordmark({ compact = false }: { compact?: boolean }) {
  if (!compact) {
    return <div className="brand-wordmark full" dir="ltr" aria-label="Bolo Chat"><img className="brand-logo-full" src={boloLogoFull} alt="Bolo Chat"/></div>;
  }
  return <div className="brand-wordmark compact" dir="ltr" aria-label="Bolo Chat"><span className="brand-symbol" aria-hidden="true"><AppLogo size={24}/></span><span className="brand-name"><b>Bolo&nbsp;<span className="brand-name-accent">Chat</span></b></span></div>;
}

type LockMethod = "none" | "pin" | "password" | "biometric";
const BIOMETRIC_CRED_KEY = "rabta-biometric-credential";
/* Stored under BIOMETRIC_CRED_KEY when the biometric lock was enrolled
   through the native (Capacitor) prompt instead of a WebAuthn credential. */
const NATIVE_BIOMETRIC_MARKER = "native";

function bufferToBase64Url(buffer: ArrayBuffer): string {
  let binary = "";
  new Uint8Array(buffer).forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function base64UrlToBuffer(value: string): ArrayBuffer {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = base64 + "=".repeat((4 - (base64.length % 4)) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes.buffer as ArrayBuffer;
}
function biometricSupported(): boolean {
  if (isNativeApp()) return true;
  return typeof window !== "undefined" && "PublicKeyCredential" in window && typeof navigator !== "undefined" && Boolean(navigator.credentials);
}
async function registerBiometric(email: string): Promise<void> {
  if (isNativeApp()) {
    // Native APK: WebAuthn cannot reach the phone's fingerprint/face sensor
    // from inside the WebView, so enrollment is proven with the device's
    // native biometric prompt instead.
    const enrolled = await nativeEnrollBiometric("Bolo Chat", "Fingerprint / Face");
    if (!enrolled) throw new Error("unsupported");
    window.localStorage.setItem(BIOMETRIC_CRED_KEY, NATIVE_BIOMETRIC_MARKER);
    return;
  }
  if (!biometricSupported()) throw new Error("unsupported");
  const credential = await navigator.credentials.create({ publicKey: {
    challenge: crypto.getRandomValues(new Uint8Array(32)),
    rp: { name: "Bolo Chat" },
    user: { id: new TextEncoder().encode(email), name: email, displayName: email },
    pubKeyCredParams: [{ type: "public-key", alg: -7 }, { type: "public-key", alg: -257 }],
    authenticatorSelection: { userVerification: "required" },
    timeout: 60000,
  } }) as PublicKeyCredential | null;
  if (!credential) throw new Error("cancelled");
  window.localStorage.setItem(BIOMETRIC_CRED_KEY, bufferToBase64Url(credential.rawId));
}
async function verifyBiometric(): Promise<boolean> {
  if (isNativeApp()) {
    // Native APK: unlock with the device's native fingerprint/face prompt.
    if (window.localStorage.getItem(BIOMETRIC_CRED_KEY) !== NATIVE_BIOMETRIC_MARKER) return false;
    return nativeVerifyBiometric("Bolo Chat", "Fingerprint / Face");
  }
  if (!biometricSupported()) return false;
  const stored = window.localStorage.getItem(BIOMETRIC_CRED_KEY);
  if (!stored) return false;
  try {
    const result = await navigator.credentials.get({ publicKey: {
      challenge: crypto.getRandomValues(new Uint8Array(32)),
      allowCredentials: [{ type: "public-key", id: base64UrlToBuffer(stored) }],
      userVerification: "required",
      timeout: 60000,
    } });
    return result !== null;
  } catch { return false; }
}

function LockVerify({ method, secretHash, secretSalt, title, onSuccess }: { method: LockMethod; secretHash: string | null; secretSalt: string | null; title: string; onSuccess: () => void }) {
  const { t } = useLocale();
  const [secret, setSecret] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const hasSecret = Boolean(secretHash && secretSalt);
  const submitSecret = async () => {
    if (!secretHash || !secretSalt || !secret) return;
    setBusy(true); setError("");
    const candidate = await hashFirebaseVoicePassword(secret, secretSalt);
    setBusy(false);
    if (candidate === secretHash) { onSuccess(); return; }
    setError(t("wrongSecret")); setSecret("");
  };
  const tryBiometric = async () => {
    setBusy(true); setError("");
    const ok = await verifyBiometric();
    setBusy(false);
    if (ok) { onSuccess(); return; }
    setError(t("fingerprintFailed"));
  };
  return <div className="lock-verify">
    <span className="lock-badge" aria-hidden="true"><Icon name={method === "biometric" ? "fingerprint" : "lock"} size={30}/></span>
    <h2>{title}</h2>
    {method === "biometric" && <><button type="button" className="primary-button" onClick={() => void tryBiometric()} disabled={busy}><Icon name="fingerprint" size={19}/> {t("useFingerprint")}</button><p className="field-note">{t("tapFingerprint")}</p></>}
    {(method !== "biometric" || hasSecret) && <form onSubmit={(event) => { event.preventDefault(); void submitSecret(); }}>
      <label htmlFor="lock-secret">{method === "password" ? t("passwordMethod") : t("pinMethod")}</label>
      <input id="lock-secret" dir="ltr" type={method === "password" ? "text" : "password"} inputMode={method === "pin" ? "numeric" : undefined} autoComplete="off" value={secret} onChange={(event) => setSecret(event.target.value)} placeholder={t("enterSecret")} autoFocus={method !== "biometric"}/>
      {error && <InlineError message={error}/>}
      <button type="submit" className="primary-button" disabled={busy || !secret}>{t("unlockApp")}</button>
    </form>}
    {method === "biometric" && !hasSecret && error && <InlineError message={error}/>}
  </div>;
}

function LockSetupSheet({ email, appLockEnabled, onClose, onSaved }: { email: string; appLockEnabled: boolean; onClose: () => void; onSaved: () => void }) {
  const { t } = useLocale();
  const queryClient = useQueryClient();
  const [method, setMethod] = useState<LockMethod>("pin");
  const [secret, setSecret] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const save = useMutation({
    mutationFn: async () => {
      if (method === "biometric" && !window.localStorage.getItem(BIOMETRIC_CRED_KEY)) {
        try { await registerBiometric(email); } catch { throw new Error("biometric"); }
      }
      let secretHash: string | null = null;
      let secretSalt: string | null = null;
      if (secret) {
        if (secret.length < 4 || secret !== confirm) throw new Error("mismatch");
        secretSalt = crypto.randomUUID();
        secretHash = await hashFirebaseVoicePassword(secret, secretSalt);
      } else if (method !== "biometric") {
        throw new Error("mismatch");
      }
      await backend.saveAppLock({ enabled: appLockEnabled, method, secret_hash: secretHash, secret_salt: secretSalt });
    },
    onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ["app-state"] }); onSaved(); },
    onError: (issue) => setError(issue instanceof Error && issue.message === "biometric" ? t("biometricUnavailable") : t("secretMismatch")),
  });
  return <SheetFrame title={t("appLock")} eyebrow={t("lockChat")} onClose={onClose} compact>
    <p className="field-note">{t("appLockHint")}</p>
    <div className="lock-methods" role="group" aria-label={t("appLock")}>
      {([["pin", "pinMethod"], ["password", "passwordMethod"], ["biometric", "biometricMethod"]] as [LockMethod, TextKey][]).map(([value, label]) => <button type="button" key={value} className={method === value ? "selected" : ""} onClick={() => setMethod(value)} aria-pressed={method === value}><Icon name={value === "biometric" ? "fingerprint" : "lock"} size={19}/><span>{t(label)}</span></button>)}
    </div>
    <div className="sheet-form-block">
      <label htmlFor="setup-lock-secret">{t("setSecret")}{method === "biometric" ? ` (${t("optional")})` : ""}</label>
      <input id="setup-lock-secret" dir="ltr" type="password" inputMode={method === "pin" ? "numeric" : undefined} autoComplete="new-password" value={secret} onChange={(event) => setSecret(event.target.value)} minLength={4} maxLength={40}/>
      <label htmlFor="setup-lock-confirm">{t("confirmSecret")}</label>
      <input id="setup-lock-confirm" dir="ltr" type="password" inputMode={method === "pin" ? "numeric" : undefined} autoComplete="new-password" value={confirm} onChange={(event) => setConfirm(event.target.value)} minLength={4} maxLength={40}/>
    </div>
    {error && <InlineError message={error}/>}
    <button type="button" className="primary-button" onClick={() => { setError(""); save.mutate(); }} disabled={save.isPending}>{save.isPending ? t("saving") : t("save")}</button>
  </SheetFrame>;
}

const WALLPAPER_LABELS_UR = ["ڈوڈل", "گرڈ", "سادہ", "باغ", "نصف شب", "غروب", "سمندر", "کتان", "سنگ ریزے", "ستارے", "لہریں", "شگوفے", "جنگل", "گھنا جنگل", "چراگاہ", "صنوبر", "بانس", "خزاں", "پت جھڑ", "آبشار", "جھیل", "صحرا", "گہری وادی", "گھاس میدان", "شہر کا منظر", "مینار", "رات کا شہر", "پرانا شہر", "نواحی بستی", "گاؤں", "بندرگاہ", "پل", "بازار گلی", "چھتیں", "قطبی روشنی", "انگارہ", "نیلگوں جھیل", "آرکڈ", "شہد", "دھند", "مرجانی", "پودینہ", "ہیرن بون", "شیوران", "نقطے", "ہیرے", "محرابیں", "موزیک", "منشور", "ٹائلیں"];
const WALLPAPER_LABELS_HI = ["डूडल", "ग्रिड", "सादा", "बाग़", "आधी रात", "सूर्यास्त", "समुद्र", "लिनेन", "टेराज़ो", "सितारे", "लहरें", "फूल", "जंगल", "घना जंगल", "मैदान", "चीड़", "बाँस", "पतझड़", "पत्ते", "झरना", "झील", "रेगिस्तान", "घाटी", "सवाना", "शहर का नज़ारा", "मीनारें", "रात का शहर", "पुराना शहर", "बस्ती", "गाँव", "बंदरगाह", "पुल", "गली", "छतें", "ध्रुवीय रोशनी", "अंगारा", "लैगून", "ऑर्किड", "शहद", "धुंध", "मूंगा", "पुदीना", "हेरिंगबोन", "शेवरॉन", "बिंदु", "हीरे", "मेहराब", "मोज़ेक", "प्रिज़्म", "टाइलें"];
const WALLPAPER_LABELS_EN = ["Doodle", "Grid", "Plain", "Garden", "Midnight", "Sunset", "Ocean", "Linen", "Terrazzo", "Stars", "Waves", "Blossom", "Forest", "Jungle", "Meadow", "Pinewood", "Bamboo", "Autumn", "Leaves", "Waterfall", "Lake", "Desert", "Canyon", "Savanna", "Skyline", "Towers", "City Night", "Old Town", "Suburb", "Village", "Harbor", "Bridge", "Street", "Rooftops", "Aurora", "Ember", "Lagoon", "Orchid", "Honey", "Mist", "Coral", "Mint", "Herringbone", "Chevron", "Dots", "Diamonds", "Arcs", "Mosaic", "Prism", "Tiles"];

function useWallpaperOptions(): { value: Wallpaper; label: string }[] {
  const { language } = useLocale();
  const labels = language === "ur" ? WALLPAPER_LABELS_UR : language === "hi" ? WALLPAPER_LABELS_HI : WALLPAPER_LABELS_EN;
  return WALLPAPER_VALUES.map((value, index) => ({ value, label: labels[index] ?? value }));
}

function WallpaperPicker({ value, onPick }: { value: Wallpaper; onPick: (wallpaper: Wallpaper) => void }) {
  const { t } = useLocale();
  const options = useWallpaperOptions();
  return <div className="preference-card sheet-card"><div className="preference-heading"><span className="setting-icon"><Icon name="wallpaper"/></span><div><strong>{t("chatWallpaper")}</strong><small>{t("wallpaperHint")}</small></div></div><div className="wallpaper-options" role="group" aria-label={t("chatWallpaper")}>{options.map((option) => <button type="button" key={option.value} className={`wallpaper-swatch ${option.value}${value === option.value ? " selected" : ""}`} onClick={() => onPick(option.value)} aria-label={option.label} aria-pressed={value === option.value}><i/><span>{option.label}</span></button>)}</div></div>;
}

function ProfileSetup() {
  const queryClient = useQueryClient(); const [language, setLanguage] = useState<Language>("ur"); const [displayName, setDisplayName] = useState(""); const [username, setUsername] = useState(""); const [email, setEmail] = useState(""); const [mobile, setMobile] = useState(""); const t = (key: TextKey): string => UI_TEXT[language][key] ?? UI_TEXT.en[key] ?? UR_TEXT[key]; const dir = RTL_LANGUAGES.includes(language) ? "rtl" : "ltr";
  const [authMode, setAuthMode] = useState<"login" | "create">("create");
  const [loginEmail, setLoginEmail] = useState("");
  const [loginError, setLoginError] = useState("");
  const draft = useProfilePhotoDraft(null, t("photoError"));
  const save = useMutation({ mutationFn: async () => { await backend.saveProfile({ display_name: displayName, username, email, mobile_number: mobile.trim() || null }); await saveProfilePhotoDraft(draft); await backend.savePreferences({ language, theme_mode: "system", wallpaper: "doodle", message_tone: "saba", conversation_tones_enabled: true }); }, onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });
  const login = useMutation({
    mutationFn: async () => {
      const found = await fetchFirebaseProfileByEmail(loginEmail);
      if (!found) return false;
      const restoredEmail = (found.email ?? loginEmail).trim().toLocaleLowerCase();
      await backend.saveProfile({ display_name: found.name, username: found.username ?? "", email: restoredEmail, mobile_number: found.mobile });
      if (found.photo) {
        const upload = dataUrlToUpload(found.photo);
        if (upload) await backend.saveProfilePhoto({ data_base64: upload.data_base64, mime_type: upload.mime_type });
      }
      await backend.savePreferences({ language, theme_mode: "system", wallpaper: "doodle", message_tone: "saba", conversation_tones_enabled: true });
      return true;
    },
    onSuccess: async (found) => {
      if (!found) { setLoginError("اس Gmail سے کوئی اکاؤنٹ نہیں ملا۔"); return; }
      setLoginError("");
      await queryClient.invalidateQueries({ queryKey: ["app-state"] });
    },
    onError: () => setLoginError(t("loginFailed")),
  });
  return <LocaleContext.Provider value={language}><main className="onboarding" dir={dir}><div className="onboarding-card">
    <BrandWordmark/><div className="onboarding-language" role="group" aria-label={t("language")}>{LANGUAGE_OPTIONS.map((option) => <button key={option.value} type="button" className={language === option.value ? "active" : ""} onClick={() => setLanguage(option.value)}>{option.label}</button>)}</div>
    <div className="status-mode-tabs auth-mode-tabs" role="tablist" aria-label={`${t("login")} / ${t("createAccount")}`}>
      <button type="button" role="tab" aria-selected={authMode === "login"} className={authMode === "login" ? "selected" : ""} onClick={() => { setAuthMode("login"); setLoginError(""); }}>{t("login")}</button>
      <button type="button" role="tab" aria-selected={authMode === "create"} className={authMode === "create" ? "selected" : ""} onClick={() => setAuthMode("create")}>{t("createAccount")}</button>
    </div>
    <p className="eyebrow">{t("welcome")}</p><h1>{authMode === "login" ? t("login") : t("createProfile")}</h1>
    <p className="intro">{authMode === "login" ? t("loginIntro") : t("profileIntro")}</p>
    {authMode === "login" ? <form className="setup-form" onSubmit={(event) => { event.preventDefault(); if (!login.isPending) { setLoginError(""); login.mutate(); } }}>
      <label htmlFor="login-gmail">{t("gmail")}</label><input id="login-gmail" dir="ltr" type="email" autoComplete="email" value={loginEmail} onChange={(event) => { setLoginEmail(event.target.value); if (loginError) setLoginError(""); }} placeholder="name@gmail.com" required/>
      <p className="field-note">{t("emailNote")}</p>
      {loginError && <InlineError message={loginError}/>}<button className="primary-button" disabled={login.isPending}>{login.isPending ? t("loggingIn") : t("login")}</button>
    </form> : <form className="setup-form" onSubmit={(event) => { event.preventDefault(); if (!save.isPending) save.mutate(); }}>
      <span className="field-label">{t("profilePhoto")} <span>{t("optional")}</span></span><ProfilePhotoField name={displayName} draft={draft} inputId="setup-photo"/>
      <label htmlFor="display-name">{t("yourName")}</label><input id="display-name" autoComplete="name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} placeholder={t("nameExample")} required minLength={2}/>
      <label htmlFor="username">{t("username")}</label><div className="username-field"><span>@</span><input id="username" dir="ltr" value={username} onChange={(event) => setUsername(event.target.value.replace(/[^A-Za-z0-9_.]/g, ""))} placeholder="Yousuf_786" required minLength={3} maxLength={30} pattern="[A-Za-z0-9_.]{3,30}"/></div><p className="field-note">{t("usernameHint")}</p>
      <label htmlFor="gmail-address">{t("gmail")}</label><input id="gmail-address" dir="ltr" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="name@gmail.com" required/>
      <p className="field-note">{t("emailNote")}</p>
      <label htmlFor="mobile-number">{t("mobileNumber")} <span>{t("optional")}</span></label><input id="mobile-number" dir="ltr" type="tel" autoComplete="tel" value={mobile} onChange={(event) => setMobile(event.target.value.replace(/[^+0-9\s-]/g, ""))} placeholder="+92 300 1234567" maxLength={24}/>
      <p className="field-note">{t("mobileHint")}</p>
      {save.isError && <InlineError message={t("profileSaveError")}/>}<button className="primary-button" disabled={save.isPending}>{save.isPending ? t("saving") : t("start")}</button>
    </form>}
  </div></main></LocaleContext.Provider>;
}

function SheetFrame({ title, eyebrow, onClose, children, compact = false }: { title: string; eyebrow?: string; onClose: () => void; children: ReactNode; compact?: boolean }) {
  const { t, dir } = useLocale();
  return <div className="modal-layer" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className={`sheet${compact ? " compact" : ""}`} role="dialog" aria-modal="true" aria-label={title} dir={dir}><div className="sheet-handle"/><div className="sheet-title-row"><div>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h2>{title}</h2></div><button className="icon-button" onClick={onClose} aria-label={t("close")}><Icon name="close"/></button></div>{children}</section></div>;
}
function NewConversationSheet({ currentUser, onClose, onCreated, onNewGroup }: { currentUser: FirebaseContact; onClose: () => void; onCreated: (id: string) => void; onNewGroup: () => void }) {
  const { t } = useLocale(); const [name, setName] = useState(""); const [username, setUsername] = useState(""); const [email, setEmail] = useState(""); const [mobile, setMobile] = useState("");
  const [searchTerm, setSearchTerm] = useState(""); const [results, setResults] = useState<FirebaseContact[]>([]); const [searching, setSearching] = useState(false); const [searched, setSearched] = useState(false);
  useEffect(() => {
    const term = searchTerm.trim().toLocaleLowerCase().replace(/^@+/, "");
    if (term.length < 2) { setResults([]); setSearching(false); setSearched(false); return; }
    setSearching(true);
    let cancelled = false;
    const timer = window.setTimeout(() => {
      void searchFirebaseProfilesByUsername(term).then((found) => {
        if (cancelled) return;
        setResults(found.filter((item) => item.id !== currentUser.id));
        setSearched(true);
      }).catch(() => { if (!cancelled) { setResults([]); setSearched(true); } }).finally(() => { if (!cancelled) setSearching(false); });
    }, 350);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [searchTerm, currentUser.id]);
  const openWith = useMutation({
    mutationFn: async (target: FirebaseContact) => {
      const id = await ensureFirebaseConversation({ current: currentUser, target });
      void backend.getOrCreateConversationId({
        current_user_id: currentUser.id,
        target_user_id: target.id,
        contact_name: target.name,
        contact_email: target.email,
        contact_photo_url: target.photo,
      }).catch(() => undefined);
      return id;
    },
    onSuccess: (id) => onCreated(id),
  });
  const create = useMutation({
    mutationFn: async () => {
      const normalizedEmail = email.trim().toLocaleLowerCase();
      const displayUsername = username.trim();
      const usernameKey = displayUsername.toLocaleLowerCase();
      const mobileDigits = mobile.replace(/[^0-9]/g, "");
      const fallbackId = normalizedEmail || (usernameKey ? `@${usernameKey}` : mobileDigits.length >= 7 ? `mobile:${mobileDigits}` : `local:${name.trim().toLocaleLowerCase()}`);
      let found: FirebaseContact | null = null;
      try { found = await lookupFirebaseProfile(normalizedEmail || (displayUsername ? `@${displayUsername}` : mobile.trim())); } catch { found = null; }
      const target: FirebaseContact = found ?? { id: fallbackId, name: name.trim(), email: normalizedEmail || null, username: displayUsername || null, mobile: mobile.trim() || null, photo: null };
      const id = await ensureFirebaseConversation({ current: currentUser, target });
      void backend.getOrCreateConversationId({
        current_user_id: currentUser.id,
        target_user_id: target.id,
        contact_name: target.name,
        contact_email: target.email,
        contact_photo_url: target.photo,
      }).catch(() => undefined);
      return id;
    },
    onSuccess: (id) => onCreated(id),
  });
  return <SheetFrame title={t("newChat")} eyebrow={t("addContact")} onClose={onClose}><button type="button" className="new-group-button" onClick={onNewGroup}><span className="folder-icon"><Icon name="users" size={21}/></span><span className="folder-copy"><strong>{t("newGroup")}</strong><small>{t("createGroup")}</small></span></button><div className="find-user"><h3 className="find-user-title"><Icon name="search" size={18}/> {t("findUser")}</h3><p className="field-note">{t("findUserHint")}</p><div className="username-field"><span>@</span><input id="user-search" dir="ltr" value={searchTerm} onChange={(event) => setSearchTerm(event.target.value.replace(/[^A-Za-z0-9_.]/g, ""))} placeholder={t("usernameSearchPlaceholder")} aria-label={t("findUser")} maxLength={30} autoFocus/></div>{searching && <p className="search-status">{t("searchingUsers")}</p>}{!searching && searched && results.length === 0 && <p className="search-status">{t("noUserFound")}</p>}{results.length > 0 && <div className="user-results">{results.map((result) => <button type="button" className="user-result" key={result.id} disabled={openWith.isPending} onClick={() => openWith.mutate(result)} aria-label={`${result.name} — ${t("openChat")}`}><Avatar name={result.name} photo={result.photo}/><span className="user-result-copy"><strong>{result.name}</strong>{result.username && <small dir="ltr">@{result.username}</small>}{result.mobile && <small dir="ltr">{result.mobile}</small>}</span><Icon name="chat" size={19}/></button>)}</div>}{openWith.isError && <InlineError message={t("chatCreateError")}/>}</div><p className="sheet-divider"><span>{t("orAddManually")}</span></p><form onSubmit={(event) => { event.preventDefault(); create.mutate(); }}><label htmlFor="contact-name">{t("contactName")}</label><input id="contact-name" value={name} onChange={(event) => setName(event.target.value)} placeholder={t("enterName")} required minLength={2}/><label htmlFor="contact-username">{t("contactUsername")} <span>{t("optional")}</span></label><div className="username-field"><span>@</span><input id="contact-username" dir="ltr" value={username} onChange={(event) => setUsername(event.target.value.replace(/[^A-Za-z0-9_.]/g, ""))} placeholder="Friend_123" minLength={3} maxLength={30} pattern="[A-Za-z0-9_.]{3,30}"/></div><label htmlFor="contact-email">{t("emailOptional")} <span>{t("optional")}</span></label><input id="contact-email" type="email" dir="ltr" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="friend@gmail.com"/><label htmlFor="contact-mobile">{t("contactMobile")} <span>{t("optional")}</span></label><input id="contact-mobile" type="tel" dir="ltr" value={mobile} onChange={(event) => setMobile(event.target.value.replace(/[^+0-9\s-]/g, ""))} placeholder="+92 300 1234567" maxLength={24}/>{create.isError && <InlineError message={t("chatCreateError")}/>}<button className="primary-button" disabled={create.isPending}>{create.isPending ? t("creating") : t("createChat")}</button></form></SheetFrame>;
}
function GroupCreateSheet({ currentUser, contacts, onClose, onCreated }: { currentUser: FirebaseContact; contacts: Conversation[]; onClose: () => void; onCreated: (id: string) => void }) {
  const { t } = useLocale();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [photo, setPhoto] = useState<string | null>(null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [selected, setSelected] = useState<ReadonlySet<string>>(new Set());
  const [error, setError] = useState("");
  const candidates = contacts.filter((item) => !item.is_group);
  const pickPhoto = async (file: File | undefined) => {
    if (!file || !( ["image/jpeg", "image/png", "image/webp"] as string[]).includes(file.type)) return;
    setPhotoBusy(true);
    try { setPhoto(await profileImageFileToDataUrl(file)); } catch { /* keep no photo */ }
    finally { setPhotoBusy(false); }
  };
  const toggleMember = (id: string) => setSelected((items) => { const next = new Set(items); if (next.has(id)) next.delete(id); else next.add(id); return next; });
  const create = useMutation({
    mutationFn: async () => {
      const members: FirebaseContact[] = candidates.filter((item) => selected.has(item.id)).map((item) => ({ id: item.target_user_id, name: item.contact_name, email: item.contact_email, username: item.contact_username, mobile: item.contact_mobile, photo: item.contact_photo }));
      const groupId = await createFirebaseGroup({ creator: currentUser, name: name.trim(), photo, description: description.trim(), members });
      return groupConversationId(groupId);
    },
    onSuccess: (id) => onCreated(id),
    onError: () => setError(t("chatCreateError")),
  });
  const submit = () => {
    setError("");
    if (!name.trim() || selected.size === 0) { setError(t("groupNameRequired")); return; }
    create.mutate();
  };
  return <SheetFrame title={t("newGroup")} eyebrow={t("createGroup")} onClose={onClose}>
    <div className="photo-field"><Avatar name={name || "?"} photo={photo} size="large"/><div className="photo-actions"><label className="photo-button" htmlFor="group-create-photo"><Icon name="camera" size={17}/> {t("groupPhoto")}</label><input id="group-create-photo" className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" disabled={photoBusy} onChange={(event) => { void pickPhoto(event.target.files?.[0]); event.currentTarget.value = ""; }}/></div></div>
    <form onSubmit={(event) => { event.preventDefault(); submit(); }}>
      <label htmlFor="group-name">{t("groupName")}</label>
      <input id="group-name" value={name} onChange={(event) => setName(event.target.value)} maxLength={60} required/>
      <label htmlFor="group-description">{t("groupDescription")} <span>{t("optional")}</span></label>
      <input id="group-description" value={description} onChange={(event) => setDescription(event.target.value)} maxLength={240}/>
      <span className="field-label">{t("selectMembers")}</span>
      {candidates.length === 0 ? <p className="picker-empty">{t("addContactFirst")}</p> : <div className="member-select-list">{candidates.map((item) => <label className="member-select-row" key={item.id}><input type="checkbox" checked={selected.has(item.id)} onChange={() => toggleMember(item.id)} aria-label={item.contact_name}/><Avatar name={item.contact_name} photo={item.contact_photo} size="small"/><span className="person-copy"><strong>{item.contact_name}</strong>{item.contact_username && <small dir="ltr">@{item.contact_username}</small>}</span></label>)}</div>}
      {error && <InlineError message={error}/>}
      <button className="primary-button" disabled={create.isPending || photoBusy}>{create.isPending ? t("creating") : t("createGroup")}</button>
    </form>
  </SheetFrame>;
}

function EditProfileSheet({ profile, initialPhoto, onClose }: { profile: NonNullable<AppState["profile"]>; initialPhoto: string | null; onClose: () => void }) {
  const { t } = useLocale(); const queryClient = useQueryClient(); const [name, setName] = useState(profile.display_name); const [username, setUsername] = useState(profile.username); const [email, setEmail] = useState(profile.email); const [mobile, setMobile] = useState(profile.mobile_number ?? ""); const [about, setAbout] = useState(profile.about);
  const draft = useProfilePhotoDraft(initialPhoto, t("photoError"));
  const save = useMutation({ mutationFn: async () => { await backend.saveProfile({ display_name: name, username, email, mobile_number: mobile.trim() || null, about }); await saveProfilePhotoDraft(draft); }, onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ["app-state"] }); onClose(); } });
  return <SheetFrame title={t("profile")} onClose={onClose} compact><form onSubmit={(event) => { event.preventDefault(); save.mutate(); }}><span className="field-label">{t("profilePhoto")}</span><ProfilePhotoField name={name} draft={draft} inputId="edit-photo"/><label htmlFor="edit-name">{t("yourName")}</label><input id="edit-name" value={name} onChange={(event) => setName(event.target.value)} required minLength={2}/><label htmlFor="edit-username">{t("username")}</label><div className="username-field"><span>@</span><input id="edit-username" dir="ltr" value={username} onChange={(event) => setUsername(event.target.value.replace(/[^A-Za-z0-9_.]/g, ""))} placeholder="Yousuf_786" required minLength={3} maxLength={30} pattern="[A-Za-z0-9_.]{3,30}"/></div><p className="field-note">{t("usernameHint")}</p><label htmlFor="edit-about">{t("about")}</label><input id="edit-about" value={about} onChange={(event) => setAbout(event.target.value)} maxLength={120}/><label htmlFor="edit-email">{t("gmail")}</label><input id="edit-email" type="email" dir="ltr" value={email} onChange={(event) => setEmail(event.target.value)} required/><label htmlFor="edit-mobile">{t("mobileNumber")} <span>{t("optional")}</span></label><input id="edit-mobile" dir="ltr" type="tel" autoComplete="tel" value={mobile} onChange={(event) => setMobile(event.target.value.replace(/[^+0-9\s-]/g, ""))} placeholder="+92 300 1234567" maxLength={24}/><p className="field-note">{t("mobileHint")}</p>{save.isError && <InlineError message={t("changeSaveError")}/>}<button className="primary-button" disabled={save.isPending}>{save.isPending ? t("saving") : t("save")}</button></form></SheetFrame>;
}
function StatusSheet({ currentUser, onClose }: { currentUser: FirebaseContact; onClose: () => void }) {
  const { t } = useLocale(); const queryClient = useQueryClient();
  const [mode, setMode] = useState<"text" | "photo">("text");
  const [body, setBody] = useState(""); const [accent, setAccent] = useState<StatusAccent>("teal");
  const [photoDataUrl, setPhotoDataUrl] = useState<string | null>(null); const [caption, setCaption] = useState(""); const [photoBusy, setPhotoBusy] = useState(false); const [photoError, setPhotoError] = useState("");
  const create = useMutation({
    mutationFn: async () => {
      await backend.createStatus({ body, accent });
      void publishFirebaseStatus({ author: currentUser, statusType: "text", body: body.trim(), accent }).catch(() => undefined);
    },
    onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ["app-state"] }); onClose(); },
  });
  const createPhoto = useMutation({
    mutationFn: async () => {
      if (!photoDataUrl) throw new Error("photo");
      const parsed = dataUrlToUpload(photoDataUrl);
      if (!parsed) throw new Error("photo");
      await backend.createPhotoStatus({ data_base64: parsed.data_base64, mime_type: parsed.mime_type, caption: caption.trim() || undefined });
      void publishFirebaseStatus({ author: currentUser, statusType: "photo", body: caption.trim(), accent: "teal", imageDataUrl: photoDataUrl }).catch(() => undefined);
    },
    onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ["app-state"] }); onClose(); },
  });
  const pickPhoto = async (file: File | undefined) => {
    if (!file) return;
    if (!(["image/jpeg", "image/png", "image/webp"] as string[]).includes(file.type)) { setPhotoError(t("statusPhotoError")); return; }
    setPhotoBusy(true); setPhotoError("");
    try { setPhotoDataUrl(await statusImageFileToDataUrl(file)); } catch { setPhotoError(t("statusPhotoError")); }
    finally { setPhotoBusy(false); }
  };
  return <SheetFrame title={t("newStatus")} eyebrow={t("for24Hours")} onClose={onClose}><div className="status-mode-tabs" role="group" aria-label={t("newStatus")}><button type="button" className={mode === "text" ? "selected" : ""} onClick={() => setMode("text")} aria-pressed={mode === "text"}><Icon name="edit" size={17}/> {t("textStatus")}</button><button type="button" className={mode === "photo" ? "selected" : ""} onClick={() => setMode("photo")} aria-pressed={mode === "photo"}><Icon name="image" size={17}/> {t("photoStatus")}</button></div>{mode === "text" ? <form onSubmit={(event) => { event.preventDefault(); create.mutate(); }}><label htmlFor="status-text">{t("sharePrompt")}</label><textarea id="status-text" className={`status-compose ${accent}`} value={body} onChange={(event) => setBody(event.target.value)} maxLength={240} placeholder={t("statusPlaceholder")} required autoFocus/><div className="color-choices" aria-label={t("statusColor")}>{STATUS_ACCENTS.map((color) => <button type="button" key={color} className={`color-dot ${color}${accent === color ? " selected" : ""}`} onClick={() => setAccent(color)} aria-label={`${color} ${t("color")}`} aria-pressed={accent === color}/>)}</div>{create.isError && <InlineError message={t("statusError")}/>}<button className="primary-button" disabled={create.isPending || !body.trim()}>{t("postStatus")}</button></form> : <form onSubmit={(event) => { event.preventDefault(); createPhoto.mutate(); }}>{photoDataUrl ? <div className="status-photo-preview"><img src={photoDataUrl} alt={t("photoStatus")}/><button type="button" className="text-button" onClick={() => setPhotoDataUrl(null)}>{t("chooseStatusPhoto")}</button></div> : <label className="status-photo-picker" htmlFor="status-photo-input"><Icon name="camera" size={30}/><span>{t("chooseStatusPhoto")}</span></label>}<input id="status-photo-input" className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" disabled={photoBusy} onChange={(event) => { void pickPhoto(event.target.files?.[0]); event.currentTarget.value = ""; }}/><label htmlFor="status-caption">{t("statusCaption")}</label><input id="status-caption" value={caption} onChange={(event) => setCaption(event.target.value)} maxLength={240} placeholder={t("statusPlaceholder")}/>{photoError && <InlineError message={photoError}/>}{createPhoto.isError && <InlineError message={t("statusPhotoError")}/>}<button className="primary-button" disabled={createPhoto.isPending || photoBusy || !photoDataUrl}>{t("postPhotoStatus")}</button></form>}</SheetFrame>;
}
type ChatRowAction = "archive" | "lock" | "mute" | "delete";

function ConversationRow({ conversation, active, currentUserId, onOpen, archived = false, locked = false, lockedState, muted = false, onAction }: { conversation: Conversation; active: boolean; currentUserId: string; onOpen: () => void; archived?: boolean; locked?: boolean; lockedState?: boolean; muted?: boolean; onAction?: (action: ChatRowAction) => void }) {
  const { t, locale } = useLocale();
  const [menuOpen, setMenuOpen] = useState(false);
  const preview = locked ? t("lockedPreview") : conversation.last_message_type === "audio" ? t("audioMessage") : conversation.last_message_type === "image" ? t("imageMessage") : conversation.last_message ?? t("noMessages");
  const fromSelf = conversation.last_sender_id?.toLocaleLowerCase() === currentUserId.toLocaleLowerCase();
  const act = (action: ChatRowAction) => { setMenuOpen(false); onAction?.(action); };
  return <div className="conversation-row-wrap">
    <button className={`conversation-row${active ? " active" : ""}`} onClick={onOpen} aria-label={`${conversation.contact_name} ${t("openChat")}`}><Avatar name={conversation.contact_name} photo={conversation.contact_photo}/><div className="conversation-copy"><div className="row-top"><strong>{conversation.contact_name}</strong><time>{formatListTime(conversation.updated_at, locale)}</time></div><div className="row-bottom"><span>{locked && <Icon name="lock" size={12}/>} {conversation.is_group && <Icon name="users" size={12}/>} {fromSelf && !locked ? `${t("you")}: ` : ""}{preview}</span>{muted && <Icon name="bellOff" size={14}/>}{conversation.unread_count > 0 && !muted && <b>{conversation.unread_count}</b>}</div></div></button>
    {onAction && <div className="popup-wrap row-menu-wrap"><button type="button" className="row-menu-button" onClick={() => setMenuOpen((value) => !value)} aria-label={`${conversation.contact_name} — ${t("chatActions")}`} aria-expanded={menuOpen} aria-haspopup="menu"><Icon name="more" size={19}/></button>{menuOpen && <div className="popup-menu row-menu" role="menu"><button type="button" role="menuitem" onClick={() => act("archive")}><Icon name="archive" size={17}/><span>{archived ? t("unarchiveChat") : t("archiveChat")}</span></button><button type="button" role="menuitem" onClick={() => act("lock")}><Icon name="lock" size={17}/><span>{(lockedState ?? locked) ? t("unlockChat") : t("lockChat")}</span></button><button type="button" role="menuitem" onClick={() => act("mute")}><Icon name={muted ? "bell" : "bellOff"} size={17}/><span>{muted ? t("unmuteChat") : t("muteChat")}</span></button><button type="button" role="menuitem" className="danger" onClick={() => act("delete")}><Icon name="trash" size={17}/><span>{t("deleteChat")}</span></button></div>}</div>}
  </div>;
}
const VOICE_STYLES: Record<VoiceEffect, { rate: number; pitch: boolean }> = { original: { rate: 1, pitch: true }, soft: { rate: .92, pitch: true }, deep: { rate: .72, pitch: false }, bright: { rate: 1.14, pitch: true }, quick: { rate: 1.32, pitch: true }, slow: { rate: .78, pitch: true }, chipmunk: { rate: 1.5, pitch: false }, helium: { rate: 1.75, pitch: false }, robot: { rate: .95, pitch: false }, monster: { rate: .55, pitch: false }, echo: { rate: 1, pitch: true }, cave: { rate: .98, pitch: true } };

function VoicePlayer({ src, duration, effect }: { src: string; duration: number | null; effect: VoiceEffect }) {
  const { t } = useLocale();
  const audioRef = useRef<HTMLAudioElement>(null); const [playing, setPlaying] = useState(false); const [progress, setProgress] = useState(0); const [elapsed, setElapsed] = useState(0);
  const graphRef = useRef<AudioContext | null>(null);
  const ensureGraph = () => {
    const audio = audioRef.current;
    if (!audio || graphRef.current || (effect !== "echo" && effect !== "cave" && effect !== "robot")) return;
    try {
      const AudioContextClass = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const context = new AudioContextClass();
      const input = context.createGain();
      if (effect === "robot") {
        const carrier = context.createOscillator(); carrier.type = "square"; carrier.frequency.value = 42;
        const depth = context.createGain(); depth.gain.value = .85;
        const ring = context.createGain(); ring.gain.value = 0;
        carrier.connect(depth); depth.connect(ring.gain);
        input.connect(ring); ring.connect(context.destination);
        const source = context.createMediaElementSource(audio); source.connect(input); carrier.start();
      } else {
        const delay = context.createDelay(1); delay.delayTime.value = effect === "echo" ? .16 : .34;
        const feedback = context.createGain(); feedback.gain.value = effect === "echo" ? .34 : .52;
        const wet = context.createGain(); wet.gain.value = effect === "echo" ? .38 : .5;
        input.connect(context.destination);
        input.connect(delay); delay.connect(feedback); feedback.connect(delay); delay.connect(wet); wet.connect(context.destination);
        const source = context.createMediaElementSource(audio); source.connect(input);
      }
      graphRef.current = context;
    } catch { graphRef.current = null; }
  };
  const toggle = () => { const audio = audioRef.current; if (!audio) return; const style = VOICE_STYLES[effect]; audio.playbackRate = style.rate; if ("preservesPitch" in audio) audio.preservesPitch = style.pitch; if (audio.paused) { ensureGraph(); if (graphRef.current?.state === "suspended") void graphRef.current.resume(); void audio.play(); } else audio.pause(); };
  return <div className="voice-player" dir="ltr"><audio ref={audioRef} src={src} preload="metadata" onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => { setPlaying(false); setProgress(0); setElapsed(0); }} onTimeUpdate={(event) => { const audio = event.currentTarget; setElapsed(Math.floor(audio.currentTime)); setProgress(audio.duration ? audio.currentTime / audio.duration : 0); }}/><button onClick={toggle} aria-label={playing ? t("pauseVoice") : t("playVoice")}><Icon name={playing ? "pause" : "play"} size={16}/></button><div className="voice-track"><div className="waveform" aria-hidden="true">{[8,14,20,11,24,17,9,22,15,25,12,19,8,21,13,18,10,23].map((height, index) => <i key={index} className={index / 18 <= progress ? "played" : ""} style={{ height: Math.round(height * .78) }}/>)}</div><span>{formatDuration(elapsed || duration || 0)}</span></div><Icon name="mic" size={15}/></div>;
}

function LockedVoice({ audioUrl, duration, effect, unlockAt, passwordHash, passwordSalt }: { audioUrl: string; duration: number | null; effect: VoiceEffect; unlockAt: string; passwordHash: string; passwordSalt: string }) {
  const { t } = useLocale();
  const [password, setPassword] = useState("");
  const [now, setNow] = useState(Date.now());
  const [unlocked, setUnlocked] = useState(false);
  const [feedback, setFeedback] = useState("");
  useEffect(() => { const timer = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(timer); }, []);
  const unlockTime = new Date(unlockAt).getTime();
  const remaining = Math.max(0, Math.ceil((unlockTime - now) / 1000));
  const unlock = async () => {
    if (remaining > 0) { setFeedback(t("tooEarly")); return; }
    const candidate = await hashFirebaseVoicePassword(password, passwordSalt);
    if (candidate !== passwordHash) { setFeedback(t("wrongPassword")); return; }
    setFeedback(""); setPassword(""); setUnlocked(true);
  };
  if (unlocked) return <VoicePlayer src={audioUrl} duration={duration} effect={effect}/>;
  return <div className="locked-voice"><div className="locked-title"><span><Icon name={remaining > 0 ? "clock" : "lock"} size={19}/></span><div><strong>{t("timedVoice")}</strong><small>{remaining > 0 ? `${t("unlocksIn")} ${formatDuration(remaining)}` : t("readyToUnlock")}</small></div></div><form onSubmit={(event) => { event.preventDefault(); void unlock(); }}><input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder={t("password")} aria-label={t("password")} minLength={4} required/><button type="submit" disabled={remaining > 0}><Icon name="lock" size={16}/> {t("unlockVoice")}</button></form>{feedback && <span className="unlock-feedback" role="alert">{feedback}</span>}</div>;
}
type VoiceSendPayload = { data_url: string; duration: number; voice_effect: VoiceEffect; unlock_delay_seconds: number; password?: string };

function VoiceButton({ onSend, tone, tonesEnabled, voiceEffect }: { onSend: (input: VoiceSendPayload) => Promise<void>; tone: MessageTone; tonesEnabled: boolean; voiceEffect: VoiceEffect }) {
  const { t } = useLocale();
  const [recording, setRecording] = useState(false); const [seconds, setSeconds] = useState(0); const [error, setError] = useState("");
  const [menuOpen, setMenuOpen] = useState(false); const [timedArmed, setTimedArmed] = useState(false);
  const [pending, setPending] = useState<{ data_base64: string; mime_type: "audio/webm" | "audio/mp4" | "audio/ogg"; duration: number } | null>(null);
  const [delay, setDelay] = useState<"minute" | "hour" | "custom">("minute"); const [customMinutes, setCustomMinutes] = useState(5); const [password, setPassword] = useState("");
  const recorder = useRef<MediaRecorder | null>(null); const chunks = useRef<Blob[]>([]); const stream = useRef<MediaStream | null>(null); const recordingStartedAt = useRef<number | null>(null); const discardRef = useRef(false); const timedRef = useRef(false);
  const send = useMutation({ mutationFn: (input: VoiceSendPayload) => onSend(input), onSuccess: () => { setPending(null); setPassword(""); setTimedArmed(false); if (tonesEnabled) playTone(tone); }, onError: () => setError(t("voiceSaveError")) });
  useEffect(() => { if (!recording) return; const timer = window.setInterval(() => setSeconds((value) => value + 1), 1000); return () => window.clearInterval(timer); }, [recording]);
  useEffect(() => () => { if (recorder.current?.state === "recording") recorder.current.stop(); stream.current?.getTracks().forEach((track) => track.stop()); }, []);
  const startRecording = async () => {
    setError(""); setMenuOpen(false); setSeconds(0); chunks.current = []; discardRef.current = false; timedRef.current = timedArmed;
    try {
      const media = await navigator.mediaDevices.getUserMedia({ audio: true }); stream.current = media;
      const options = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? { mimeType: "audio/webm;codecs=opus" } : undefined;
      const next = new MediaRecorder(media, options); recorder.current = next;
      next.ondataavailable = (event) => { if (event.data.size > 0) chunks.current.push(event.data); };
      next.onstop = () => {
        setRecording(false); media.getTracks().forEach((track) => track.stop());
        if (discardRef.current) { discardRef.current = false; chunks.current = []; return; }
        const startedAt = recordingStartedAt.current; const duration = Math.max(1, Math.ceil(startedAt === null ? 0 : (performance.now() - startedAt) / 1000)); recordingStartedAt.current = null; const rawType = next.mimeType.split(";")[0] ?? "audio/webm"; const mime = rawType === "audio/mp4" || rawType === "audio/ogg" ? rawType : "audio/webm"; const blob = new Blob(chunks.current, { type: mime });
        void fileToBase64(blob).then((encoded) => {
          if (timedRef.current) setPending({ data_base64: encoded.dataBase64, mime_type: mime, duration });
          else send.mutate({ data_url: `data:${mime};base64,${encoded.dataBase64}`, duration, voice_effect: voiceEffect, unlock_delay_seconds: 0 });
        });
      };
      recordingStartedAt.current = performance.now(); next.start(); setRecording(true);
    } catch { setError(t("micPermission")); }
  };
  const stopRecording = () => { if (recorder.current?.state === "recording") recorder.current.stop(); };
  const cancelRecording = () => { discardRef.current = true; setTimedArmed(false); stopRecording(); };
  const delaySeconds = delay === "minute" ? 60 : delay === "hour" ? 3600 : Math.max(1, customMinutes) * 60;
  const submitTimed = () => { if (!pending || send.isPending || password.length < 4) return; send.mutate({ data_url: `data:${pending.mime_type};base64,${pending.data_base64}`, duration: pending.duration, voice_effect: voiceEffect, unlock_delay_seconds: delaySeconds, password }); };
  const effectLabel = VOICE_EFFECT_OPTIONS.find((option) => option.value === voiceEffect)?.label ?? "originalVoice";
  return <div className={`voice-control${recording ? " recording" : ""}`}>{recording ? <><span className="rec-dot" aria-hidden="true"/><span className="rec-time">{formatDuration(seconds)}</span><span className="rec-wave" aria-hidden="true"><i/><i/><i/><i/><i/><i/><i/></span><span className="rec-label">{t("recordingNow")}</span><button type="button" className="rec-cancel" onClick={cancelRecording} aria-label={t("cancelRecording")}><Icon name="trash" size={19}/></button><button type="button" className="mic-button recording" onClick={stopRecording} aria-label={t("stopSend")}><Icon name="send" size={20}/></button></> : <><div className="voice-menu-wrap"><button type="button" className="mic-menu-button" onClick={() => setMenuOpen((value) => !value)} aria-label={t("moreOptions")} aria-expanded={menuOpen} aria-haspopup="menu"><Icon name="more" size={19}/></button>{menuOpen && <div className="voice-menu" role="menu"><button type="button" role="menuitem" onClick={() => { setTimedArmed(true); setMenuOpen(false); }}><Icon name="clock" size={17}/><span>{t("timedVoice")}</span></button></div>}</div><button type="button" className={`mic-button${timedArmed ? " armed" : ""}`} onClick={() => void startRecording()} disabled={send.isPending || Boolean(pending)} aria-label={t("voice")}><Icon name="mic" size={20}/></button></>}{timedArmed && !recording && <span className="timed-chip"><Icon name="clock" size={13}/> {t("timedVoice")}<button type="button" onClick={() => setTimedArmed(false)} aria-label={t("cancelRecording")}><Icon name="close" size={13}/></button></span>}{send.isPending && <span className="recording-time">{t("voiceSaving")}</span>}{error && <span className="voice-error" role="alert">{error}</span>}{pending && <SheetFrame title={t("timedVoice")} eyebrow={`${t("prepareVoice")} · ${formatDuration(pending.duration)}`} onClose={() => { setPending(null); setTimedArmed(false); }} compact><div className="voice-studio"><div className="delay-options" role="group" aria-label={t("timedVoice")}><button type="button" className={delay === "minute" ? "selected" : ""} onClick={() => setDelay("minute")}>{t("afterMinute")}</button><button type="button" className={delay === "hour" ? "selected" : ""} onClick={() => setDelay("hour")}>{t("afterHour")}</button><button type="button" className={delay === "custom" ? "selected" : ""} onClick={() => setDelay("custom")}>{t("customDelay")}</button></div>{delay === "custom" && <label className="custom-delay"><span>{t("minutes")}</span><input type="number" min={1} max={10080} value={customMinutes} onChange={(event) => setCustomMinutes(Math.max(1, Number(event.target.value) || 1))}/></label>}<label htmlFor="voice-password">{t("password")}</label><input id="voice-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} minLength={4} maxLength={40} required/><p className="field-note lock-note"><Icon name="lock" size={15}/> {t("passwordHint")}</p><p className="field-note lock-note"><Icon name="mic" size={15}/> {t("voiceStyle")}: {t(effectLabel)}</p>{send.isError && <InlineError message={t("voiceSaveError")}/>}<div className="voice-studio-actions"><button type="button" className="text-button" onClick={() => { setPending(null); setTimedArmed(false); }}>{t("cancelRecording")}</button><button type="button" className="primary-button" onClick={submitTimed} disabled={send.isPending || password.length < 4}>{t("scheduleAndSend")}</button></div></div></SheetFrame>}</div>;
}
function ImageButton({ onSend, tone, tonesEnabled }: { onSend: (dataUrl: string) => Promise<void>; tone: MessageTone; tonesEnabled: boolean }) {
  const { t } = useLocale();
  const inputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState("");
  const upload = useMutation({
    mutationFn: async (file: File) => {
      if (!( ["image/jpeg", "image/png", "image/webp"] as string[]).includes(file.type)) throw new Error("unsupported");
      const dataUrl = await imageFileToDataUrl(file);
      await onSend(dataUrl);
    },
    onSuccess: () => { setError(""); if (tonesEnabled) playTone(tone); },
    onError: () => setError(t("imageSaveError")),
  });
  return <div className="image-control"><input ref={inputRef} className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => { const file = event.target.files?.[0]; if (file) upload.mutate(file); event.currentTarget.value = ""; }}/><button className="attachment-button" type="button" onClick={() => inputRef.current?.click()} disabled={upload.isPending} aria-label={t("chooseImage")}><Icon name="image" size={20}/></button>{error && <span className="voice-error" role="alert">{error}</span>}</div>;
}

type RenderableMessage = FirebaseMessage & { failed?: boolean; pending?: boolean; retry_input?: FirebaseMessageInput };

function failedMessageFromInput(input: FirebaseMessageInput, pending = false): RenderableMessage {
  return {
    id: input.id ?? crypto.randomUUID(),
    body: input.body,
    direction: "self",
    sender_id: input.senderId,
    receiver_id: input.receiverId,
    message_type: input.type,
    audio_url: input.type === "audio" ? input.dataUrl ?? null : null,
    image_url: input.type === "image" ? input.dataUrl ?? null : null,
    delivery_status: "sent",
    audio_duration: input.audioDuration ?? null,
    voice_effect: input.voiceEffect ?? "original",
    unlock_at: input.unlockAt ? new Date(input.unlockAt).toISOString() : null,
    password_hash: input.passwordHash ?? null,
    password_salt: input.passwordSalt ?? null,
    expires_at: input.ttlSeconds ? new Date((input.createdAt ?? Date.now()) + input.ttlSeconds * 1000).toISOString() : null,
    created_at: new Date(input.createdAt ?? Date.now()).toISOString(),
    failed: !pending,
    pending,
    retry_input: input,
  };
}

type ChatMenuActions = { archived: boolean; locked: boolean; muted: boolean; onToggleArchive: () => void; onToggleLock: () => void; onToggleMute: () => void; onDeleteChat: () => void };

function Thread({ currentUserId, targetUserId, contactName, contactEmail, contactUsername, contactPhoto, onBack, onCall, onContactInfo, wallpaper, tone, tonesEnabled, voiceEffect, blocked, autoDownloadPhotos, autoDownloadVoice, group = null, sender = null, chatMenu = null }: { currentUserId: string; targetUserId: string; contactName: string; contactEmail: string | null; contactUsername: string | null; contactPhoto: string | null; onBack: () => void; onCall: (target: CallTarget) => void; onContactInfo: () => void; wallpaper: Wallpaper; tone: MessageTone; tonesEnabled: boolean; voiceEffect: VoiceEffect; blocked: boolean; autoDownloadPhotos: boolean; autoDownloadVoice: boolean; group?: { id: string; members: FirebaseContact[] } | null; sender?: FirebaseContact | null; chatMenu?: ChatMenuActions | null }) {
  const { t, dir, locale } = useLocale();
  const [body, setBody] = useState(""); const endRef = useRef<HTMLDivElement>(null);
  const cachedThreadId = group ? group.id : firebaseThreadId(currentUserId, targetUserId);
  const [messages, setMessages] = useState<FirebaseMessage[]>(() => threadMessageCache.get(cachedThreadId) ?? []);
  const [failedMessages, setFailedMessages] = useState<RenderableMessage[]>([]);
  const [loading, setLoading] = useState(() => !threadMessageCache.has(cachedThreadId));
  const [listenerError, setListenerError] = useState(false);
  const [disappearingSeconds, setDisappearingSeconds] = useState(0);
  const [downloadedMedia, setDownloadedMedia] = useState<ReadonlySet<string>>(new Set());
  const [presence, setPresence] = useState<{ online: boolean; last_active_at: string | null } | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<RenderableMessage | null>(null);
  const [deleting, setDeleting] = useState(false);
  const isGroup = group !== null;
  const threadId = useMemo(() => group ? group.id : firebaseThreadId(currentUserId, targetUserId), [group, currentUserId, targetUserId]);
  const [renderThreadId, setRenderThreadId] = useState(threadId);
  if (renderThreadId !== threadId) {
    // Switching chats: swap in the cached thread during render so the new
    // conversation paints instantly — never a loading flash of the old one.
    setRenderThreadId(threadId);
    setMessages(threadMessageCache.get(threadId) ?? []);
    setLoading(!threadMessageCache.has(threadId));
    setListenerError(false);
  }

  useEffect(() => {
    if (isGroup) { setDisappearingSeconds(0); return; }
    const unsubscribe = listenToFirebaseDisappearing(threadId, currentUserId, (seconds) => setDisappearingSeconds(seconds));
    return () => unsubscribe();
  }, [threadId, currentUserId, isGroup]);

  useEffect(() => {
    if (isGroup) { setPresence(null); return; }
    const unsubscribe = listenToFirebasePresence(targetUserId, (value) => setPresence(value));
    return () => unsubscribe();
  }, [targetUserId, isGroup]);

  const markDownloaded = (id: string) => setDownloadedMedia((items) => { const next = new Set(items); next.add(id); return next; });

  useEffect(() => {
    const cached = threadMessageCache.get(threadId);
    setListenerError(false); setMessages(cached ?? []); setLoading(!cached);
    const onItems = (items: FirebaseMessage[]) => { threadMessageCache.set(threadId, items); setMessages(items); setLoading(false); };
    const onFail = () => { setListenerError(true); setLoading(false); };
    const unsubscribe = isGroup ? listenToFirebaseGroupMessages(threadId, currentUserId, onItems, onFail) : listenToFirebaseMessages(threadId, currentUserId, onItems, onFail);
    return () => unsubscribe();
  }, [threadId, currentUserId, isGroup]);

  useEffect(() => {
    if (loading || listenerError) return;
    if (isGroup) void markFirebaseGroupMessagesRead(threadId, currentUserId).catch(() => undefined); else void markFirebaseMessagesRead(threadId, currentUserId).catch(() => undefined);
  }, [threadId, currentUserId, messages.length, loading, listenerError, isGroup]);

  const visibleMessages = useMemo(() => blocked ? messages.filter((message) => message.direction === "self") : messages, [messages, blocked]);
  const allMessages = useMemo<RenderableMessage[]>(() => [...visibleMessages, ...failedMessages.filter((failed) => (!failed.retry_input || failed.retry_input.threadId === threadId) && !visibleMessages.some((message) => message.id === failed.id))].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()), [visibleMessages, failedMessages, threadId]);
  useEffect(() => { if (messages.length > 0) setFailedMessages((items) => items.filter((item) => !messages.some((message) => message.id === item.id))); }, [messages]);
  useEffect(() => { endRef.current?.scrollIntoView({ block: "end" }); }, [allMessages.length]);

  const sendWithFailure = async (input: FirebaseMessageInput) => {
    // Optimistic UI: the bubble appears in the chat the instant the user
    // hits send; the network sync below runs in the background.
    const optimistic = failedMessageFromInput(input, true);
    setFailedMessages((items) => [...items.filter((item) => item.id !== optimistic.id), optimistic]);
    try {
      if (isGroup && group) {
        await sendFirebaseGroupMessage({ ...input, memberIds: group.members.map((member) => member.id), senderName: sender?.name ?? "", senderPhoto: sender?.photo ?? null });
      } else {
        await sendFirebaseMessage(input);
      }
      // Success: keep the optimistic bubble on screen until the live
      // snapshot echoes the message back (the prune effect then drops it).
    } catch (error) {
      const failed = failedMessageFromInput(input);
      setFailedMessages((items) => [...items.filter((item) => item.id !== failed.id), failed]);
      throw error;
    }
  };

  const confirmDeleteMessage = async () => {
    if (!deleteTarget || deleting) return;
    const target = deleteTarget;
    setDeleting(true);
    try {
      if (target.failed || target.pending) {
        setFailedMessages((items) => items.filter((item) => item.id !== target.id));
      } else {
        await deleteFirebaseMessage(isGroup ? "groups" : "conversations", threadId, target.id);
        setMessages((items) => items.filter((item) => item.id !== target.id));
      }
      setDeleteTarget(null);
    } catch { /* keep the sheet open so the user can retry */ }
    finally { setDeleting(false); }
  };

  const statusLine = isGroup
    ? `${new Intl.NumberFormat(locale).format(group?.members.length ?? 0)} ${t("groupMembers")}`
    : presence
      ? presence.online
        ? t("onlineNow")
        : presence.last_active_at
          ? `${t("lastSeen")} ${new Intl.DateTimeFormat(locale, { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" }).format(new Date(presence.last_active_at))}`
          : contactUsername ? `@${contactUsername}` : contactEmail ?? t("offline")
      : contactUsername ? `@${contactUsername}` : contactEmail ?? t("offline");

  const submit = () => {
    const trimmed = body.trim();
    if (!trimmed) return;
    const input: FirebaseMessageInput = { id: crypto.randomUUID(), threadId, senderId: currentUserId, receiverId: targetUserId, body: trimmed, type: "text", createdAt: Date.now(), ttlSeconds: disappearingSeconds > 0 ? disappearingSeconds : null };
    setBody("");
    if (tonesEnabled) playTone(tone);
    void sendWithFailure(input).catch(() => undefined);
  };
  const handleKey = (event: KeyboardEvent<HTMLTextAreaElement>) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); submit(); } };
  const sendImage = async (dataUrl: string) => { void sendWithFailure({ id: crypto.randomUUID(), threadId, senderId: currentUserId, receiverId: targetUserId, body: t("imageMessage"), type: "image", dataUrl, createdAt: Date.now(), ttlSeconds: disappearingSeconds > 0 ? disappearingSeconds : null }).catch(() => undefined); };
  const sendVoice = async (input: VoiceSendPayload) => {
    const unlockAt = input.unlock_delay_seconds > 0 ? Date.now() + input.unlock_delay_seconds * 1000 : null;
    const passwordSalt = unlockAt ? crypto.randomUUID() : null;
    const passwordHash = unlockAt && passwordSalt && input.password ? await hashFirebaseVoicePassword(input.password, passwordSalt) : null;
    void sendWithFailure({ id: crypto.randomUUID(), threadId, senderId: currentUserId, receiverId: targetUserId, body: t("audioMessage"), type: "audio", dataUrl: input.data_url, audioDuration: input.duration, voiceEffect: input.voice_effect, unlockAt, passwordHash, passwordSalt, createdAt: Date.now(), ttlSeconds: disappearingSeconds > 0 ? disappearingSeconds : null }).catch(() => undefined);
  };

  if (loading) return <section className="thread-panel loading-panel">{t("loadingChat")}</section>;
  if (listenerError) return <section className="thread-panel loading-panel"><p>{t("chatMissing")}</p><button className="text-button" onClick={onBack}>{t("goBack")}</button></section>;
  return <section className="thread-panel" dir={dir}><header className="thread-header"><button className="icon-button mobile-back" onClick={onBack} aria-label={t("backChats")}><Icon name="back"/></button><button type="button" className="thread-contact" onClick={onContactInfo} aria-label={`${contactName} — ${t("viewContact")}`}><Avatar name={contactName} photo={contactPhoto} size="small"/><span className="thread-identity"><strong>{contactName}</strong><span className="presence-line" dir="auto">{statusLine}</span></span></button><div className="thread-actions"><button className="icon-button" onClick={() => onCall({ name: contactName, email: contactEmail, photo: contactPhoto, type: "video" })} aria-label={t("videoCall")}><Icon name="video"/></button><button className="icon-button" onClick={() => onCall({ name: contactName, email: contactEmail, photo: contactPhoto, type: "audio" })} aria-label={t("audioCall")}><Icon name="phone"/></button>{chatMenu && <div className="popup-wrap"><button type="button" className="icon-button" onClick={() => setMenuOpen((value) => !value)} aria-label={t("chatActions")} aria-expanded={menuOpen} aria-haspopup="menu"><Icon name="more"/></button>{menuOpen && <div className="popup-menu thread-menu" role="menu"><button type="button" role="menuitem" onClick={() => { setMenuOpen(false); onContactInfo(); }}><Icon name="user" size={17}/><span>{isGroup ? t("groupInfo") : t("contactInfo")}</span></button><button type="button" role="menuitem" onClick={() => { setMenuOpen(false); chatMenu.onToggleArchive(); }}><Icon name="archive" size={17}/><span>{chatMenu.archived ? t("unarchiveChat") : t("archiveChat")}</span></button><button type="button" role="menuitem" onClick={() => { setMenuOpen(false); chatMenu.onToggleLock(); }}><Icon name="lock" size={17}/><span>{chatMenu.locked ? t("unlockChat") : t("lockChat")}</span></button><button type="button" role="menuitem" onClick={() => { setMenuOpen(false); chatMenu.onToggleMute(); }}><Icon name={chatMenu.muted ? "bell" : "bellOff"} size={17}/><span>{chatMenu.muted ? t("unmuteChat") : t("muteChat")}</span></button><button type="button" role="menuitem" className="danger" onClick={() => { setMenuOpen(false); chatMenu.onDeleteChat(); }}><Icon name="trash" size={17}/><span>{t("deleteChat")}</span></button></div>}</div>}</div></header><div className={`messages wallpaper-${wallpaper}`} aria-live="polite"><div className="local-banner">{t("localBanner")}</div>{disappearingSeconds > 0 && <div className="local-banner timer-banner"><Icon name="clock" size={13}/> {t("timerActive")} · {disappearingSeconds >= 86400 ? `${Math.round(disappearingSeconds / 86400)} × 24h` : formatDuration(disappearingSeconds)}</div>}{blocked && <div className="local-banner blocked-banner"><Icon name="lock" size={13}/> {t("blockedBanner")}</div>}{allMessages.length === 0 ? <div className="thread-empty"><div className="thread-empty-mark"><Icon name="chat"/></div><h3>{t("startChat")}</h3><p>{t("startChatHint")}</p></div> : allMessages.map((message) => <div className={`message-line ${message.direction}`} key={message.id}><div className={`message-bubble ${message.message_type}${message.failed ? " failed" : ""}`}>{isGroup && message.direction === "contact" && message.sender_name && <span className="group-sender">{message.sender_name}</span>}{message.message_type === "audio" ? (message.audio_url ? (message.direction === "contact" && !autoDownloadVoice && !downloadedMedia.has(message.id) ? <button type="button" className="media-download" onClick={() => markDownloaded(message.id)} aria-label={t("downloadMedia")}><Icon name="mic" size={20}/><span>{t("tapToDownloadVoice")}</span><b>{t("downloadMedia")}</b></button> : message.unlock_at && message.password_hash && message.password_salt ? <LockedVoice audioUrl={message.audio_url} duration={message.audio_duration} effect={message.voice_effect} unlockAt={message.unlock_at} passwordHash={message.password_hash} passwordSalt={message.password_salt}/> : <VoicePlayer src={message.audio_url} duration={message.audio_duration} effect={message.voice_effect}/>) : <p>{t("audioMessage")}</p>) : message.message_type === "image" && message.image_url ? (message.direction === "contact" && !autoDownloadPhotos && !downloadedMedia.has(message.id) ? <button type="button" className="media-download" onClick={() => markDownloaded(message.id)} aria-label={t("downloadMedia")}><Icon name="image" size={22}/><span>{t("tapToDownloadPhoto")}</span><b>{t("downloadMedia")}</b></button> : <figure className="message-image"><img src={message.image_url} alt={message.body || t("imageMessage")}/>{message.body !== t("imageMessage") && <figcaption>{message.body}</figcaption>}</figure>) : <p>{message.body}</p>}<div className="message-meta"><time>{formatMessageTime(message.created_at, locale)}</time>{message.direction === "self" && <button type="button" className="message-delete" onClick={() => setDeleteTarget(message)} aria-label={`${t("delete")} — ${message.message_type === "audio" ? t("audioMessage") : message.message_type === "image" ? t("imageMessage") : message.body}`}><Icon name="trash" size={12}/></button>}{message.direction === "self" && (message.pending && !message.failed ? <span className="delivery pending" title={t("deliverySent")}><Icon name="clock" size={13}/></span> : message.failed && message.retry_input ? <button className="retry-message" onClick={() => { const retryInput = message.retry_input; if (retryInput) void sendWithFailure(retryInput).catch(() => undefined); }} aria-label={t("retry")}><span>{t("sendFailed")}</span> · {t("retry")}</button> : <span className={`delivery ${message.delivery_status}`} title={t(message.delivery_status === "read" ? "deliveryRead" : message.delivery_status === "delivered" ? "deliveryDelivered" : "deliverySent")}><Icon name="checks" size={13}/></span>)}</div></div></div>)}<div ref={endRef}/></div><div className="composer-wrap">{blocked ? <p className="blocked-composer"><Icon name="lock" size={16}/> {t("blockedBanner")}</p> : <div className="composer"><ImageButton onSend={sendImage} tone={tone} tonesEnabled={tonesEnabled}/><VoiceButton onSend={sendVoice} tone={tone} tonesEnabled={tonesEnabled} voiceEffect={voiceEffect}/><textarea aria-label={t("message")} rows={1} value={body} onChange={(event) => setBody(event.target.value)} onKeyDown={handleKey} placeholder={t("message")}/><button className="send-button" onClick={submit} disabled={!body.trim()} aria-label={t("send")}><Icon name="send" size={20}/></button></div>}</div>{deleteTarget && <SheetFrame title={t("delete")} onClose={() => setDeleteTarget(null)} compact><p className="help-body">{t("deleteMessageConfirm")}</p><div className="sheet-actions"><button type="button" className="text-button" onClick={() => setDeleteTarget(null)}>{t("cancel")}</button><button type="button" className="primary-button danger-button" onClick={() => void confirmDeleteMessage()} disabled={deleting}><Icon name="trash" size={17}/> {t("deleteForEveryone")}</button></div></SheetFrame>}</section>;
}

export function ChatRoom({ currentUser, targetUserId, contactName, contactEmail, contactUsername, contactPhoto, onBack, onCall, onContactInfo, wallpaper, tone, tonesEnabled, voiceEffect, blocked, autoDownloadPhotos, autoDownloadVoice, group = null, chatMenu = null }: { currentUser: FirebaseContact; targetUserId: string; contactName: string; contactEmail: string | null; contactUsername: string | null; contactPhoto: string | null; onBack: () => void; onCall: (target: CallTarget) => void; onContactInfo: () => void; wallpaper: Wallpaper; tone: MessageTone; tonesEnabled: boolean; voiceEffect: VoiceEffect; blocked: boolean; autoDownloadPhotos: boolean; autoDownloadVoice: boolean; group?: { id: string; members: FirebaseContact[] } | null; chatMenu?: ChatMenuActions | null }) {
  useEffect(() => {
    if (group) return;
    // Background only: the thread renders instantly from the message cache
    // and its live listener; it never waits for this ensure call.
    void ensureFirebaseConversation({ current: currentUser, target: { id: targetUserId, name: contactName, email: contactEmail, username: contactUsername, mobile: null, photo: contactPhoto } }).catch(() => undefined);
  }, [currentUser, targetUserId, contactName, contactEmail, contactUsername, contactPhoto, group]);
  return <Thread currentUserId={currentUser.id} targetUserId={targetUserId} contactName={contactName} contactEmail={contactEmail} contactUsername={contactUsername} contactPhoto={contactPhoto} onBack={onBack} onCall={onCall} onContactInfo={onContactInfo} wallpaper={wallpaper} tone={tone} tonesEnabled={tonesEnabled} voiceEffect={voiceEffect} blocked={blocked} autoDownloadPhotos={autoDownloadPhotos} autoDownloadVoice={autoDownloadVoice} group={group} sender={currentUser} chatMenu={chatMenu}/>;
}

type InfoScreenProps = {
  conversation: Conversation;
  currentUser: FirebaseContact;
  contacts: Conversation[];
  blocked: boolean;
  muted: boolean;
  archived: boolean;
  locked: boolean;
  wallpaper: Wallpaper;
  onPickWallpaper: (wallpaper: Wallpaper) => void;
  onClose: () => void;
  onCall: (target: CallTarget) => void;
  onToggleBlock: () => void;
  onToggleMute: () => void;
  onToggleArchive: () => void;
  onToggleLock: () => void;
  onDeleteChat: () => void;
};

function ContactInfoScreen(props: InfoScreenProps) {
  const { conversation, currentUser, contacts, blocked, muted, archived, locked, wallpaper, onPickWallpaper, onClose, onCall, onToggleBlock, onToggleMute, onToggleArchive, onToggleLock, onDeleteChat } = props;
  const { t, dir } = useLocale();
  const isGroup = Boolean(conversation.is_group);
  const groupId = conversation.group_id ?? "";
  const members = conversation.group_members ?? [];
  const admins = conversation.group_admins ?? [];
  const currentId = currentUser.id.toLocaleLowerCase();
  const isAdmin = admins.some((id) => id.toLocaleLowerCase() === currentId);
  const [media, setMedia] = useState<string[]>(() => { const cached = threadMessageCache.get(conversation.is_group ? (conversation.group_id ?? conversation.target_user_id) : firebaseThreadId(currentUser.id, conversation.target_user_id)); return cached ? cached.filter((item) => item.message_type === "image" && item.image_url).map((item) => item.image_url as string) : []; });
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [groupName, setGroupName] = useState(conversation.contact_name);
  const [groupDescription, setGroupDescription] = useState(conversation.group_description ?? "");
  const [groupPhoto, setGroupPhoto] = useState<string | null>(conversation.contact_photo);
  const [groupBusy, setGroupBusy] = useState(false);
  const [groupSaved, setGroupSaved] = useState(false);
  const [memberTarget, setMemberTarget] = useState<FirebaseContact | null>(null);
  const [addOpen, setAddOpen] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const cacheKey = isGroup ? (conversation.group_id ?? conversation.target_user_id) : firebaseThreadId(currentUser.id, conversation.target_user_id);
    const cached = threadMessageCache.get(cacheKey);
    if (cached) setMedia(cached.filter((item) => item.message_type === "image" && item.image_url).map((item) => item.image_url as string));
    const load = async () => {
      const items = isGroup ? await fetchFirebaseGroupMessagesOnce(groupId, currentUser.id) : await fetchFirebaseMessagesOnce(cacheKey, currentUser.id);
      threadMessageCache.set(cacheKey, items);
      if (!cancelled) setMedia(items.filter((item) => item.message_type === "image" && item.image_url).map((item) => item.image_url as string));
    };
    void load().catch(() => undefined);
    return () => { cancelled = true; };
  }, [isGroup, groupId, currentUser.id, conversation.target_user_id]);

  const pickGroupPhoto = async (file: File | undefined) => {
    if (!file || !( ["image/jpeg", "image/png", "image/webp"] as string[]).includes(file.type)) return;
    try { setGroupPhoto(await profileImageFileToDataUrl(file)); } catch { /* keep old photo */ }
  };
  const saveGroup = async () => {
    if (!groupName.trim() || groupBusy) return;
    setGroupBusy(true);
    try {
      await updateFirebaseGroup(groupId, { name: groupName.trim(), description: groupDescription.trim(), photo: groupPhoto });
      setGroupSaved(true);
    } catch { setGroupSaved(false); }
    finally { setGroupBusy(false); }
  };
  const applyMembers = async (nextMembers: FirebaseContact[], nextAdmins: string[]) => {
    await setFirebaseGroupMembers(groupId, nextMembers, nextAdmins).catch(() => undefined);
    setMemberTarget(null); setAddOpen(false);
  };
  const memberIsAdmin = (member: FirebaseContact) => admins.some((id) => id.toLocaleLowerCase() === member.id.toLocaleLowerCase());
  const addableContacts = contacts.filter((item) => !item.is_group && !members.some((member) => member.id.toLocaleLowerCase() === item.target_user_id.toLocaleLowerCase()));

  return <div className="info-screen" role="dialog" aria-modal="true" aria-label={isGroup ? t("groupInfo") : t("contactInfo")} dir={dir}>
    <header className="info-header"><button className="icon-button" onClick={onClose} aria-label={t("backChats")}><Icon name="back"/></button><strong>{isGroup ? t("groupInfo") : t("contactInfo")}</strong></header>
    <div className="info-scroll">
      <div className="contact-info">
        <Avatar name={conversation.contact_name} photo={conversation.contact_photo} size="xlarge"/>
        <h3>{conversation.contact_name}</h3>
        {!isGroup && conversation.contact_username && <p dir="ltr">@{conversation.contact_username}</p>}
        {!isGroup && conversation.contact_mobile && <p dir="ltr">{conversation.contact_mobile}</p>}
        {!isGroup && conversation.contact_email && <p dir="ltr">{conversation.contact_email}</p>}
        {isGroup && <p>{members.length} {t("groupMembers")}</p>}
        {isGroup && conversation.group_description && <p className="info-about">{conversation.group_description}</p>}
        {isGroup && conversation.group_created_by && <p className="contact-info-note">{t("createdBy")}: {members.find((member) => member.id.toLocaleLowerCase() === conversation.group_created_by?.toLocaleLowerCase())?.name ?? conversation.group_created_by}</p>}
        {!isGroup && !conversation.contact_photo && <p className="contact-info-note">{t("noPhoto")}</p>}
      </div>
      <div className="info-actions">
        <button type="button" onClick={() => onCall({ name: conversation.contact_name, email: conversation.contact_email, photo: conversation.contact_photo, type: "audio" })} aria-label={t("audioCall")}><Icon name="phone"/><span>{t("audioCall")}</span></button>
        <button type="button" onClick={() => onCall({ name: conversation.contact_name, email: conversation.contact_email, photo: conversation.contact_photo, type: "video" })} aria-label={t("videoCall")}><Icon name="video"/><span>{t("videoCall")}</span></button>
        <button type="button" onClick={onToggleMute} aria-label={muted ? t("unmuteChat") : t("muteChat")}><Icon name={muted ? "bell" : "bellOff"}/><span>{muted ? t("unmuteChat") : t("muteChat")}</span></button>
      </div>

      {isGroup && isAdmin && <div className="info-block">
        <h3 className="sheet-subhead">{t("groupSettings")}</h3>
        <div className="photo-field"><Avatar name={groupName || "?"} photo={groupPhoto} size="large"/><div className="photo-actions"><label className="photo-button" htmlFor="group-photo-input"><Icon name="camera" size={17}/> {t("groupPhoto")}</label><input id="group-photo-input" className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => { void pickGroupPhoto(event.target.files?.[0]); event.currentTarget.value = ""; }}/></div></div>
        <label htmlFor="group-name-edit">{t("groupName")}</label>
        <input id="group-name-edit" className="info-input" value={groupName} onChange={(event) => setGroupName(event.target.value)} maxLength={60}/>
        <label htmlFor="group-desc-edit">{t("groupDescription")}</label>
        <textarea id="group-desc-edit" className="info-input" rows={2} value={groupDescription} onChange={(event) => setGroupDescription(event.target.value)} maxLength={240}/>
        {groupSaved && <p className="saved-note">{t("settingsSaved")}</p>}
        <button type="button" className="primary-button" onClick={() => void saveGroup()} disabled={groupBusy || !groupName.trim()}>{t("save")}</button>
      </div>}

      {isGroup && <div className="info-block">
        <h3 className="sheet-subhead">{t("groupMembers")} · {members.length}</h3>
        {isAdmin && <button type="button" className="add-members-button" onClick={() => setAddOpen(true)}><Icon name="plus" size={18}/> {t("addMembers")}</button>}
        {members.map((member) => <div className="person-row" key={member.id}>
          <Avatar name={member.name} photo={member.photo} size="small"/>
          <span className="person-copy"><strong>{member.name}{member.id.toLocaleLowerCase() === currentId ? ` (${t("you")})` : ""}</strong>{member.username && <small dir="ltr">@{member.username}</small>}</span>
          {memberIsAdmin(member) && <span className="admin-chip">{t("admin")}</span>}
          {(isAdmin || member.id.toLocaleLowerCase() === currentId) && <button type="button" className="icon-button" onClick={() => setMemberTarget(member)} aria-label={`${member.name} — ${t("memberActions")}`}><Icon name="more" size={19}/></button>}
        </div>)}
        <button type="button" className="text-button danger leave-group" onClick={() => { const me = members.find((member) => member.id.toLocaleLowerCase() === currentId); if (me) void applyMembers(members.filter((member) => member.id.toLocaleLowerCase() !== currentId), admins.filter((id) => id.toLocaleLowerCase() !== currentId)).then(onClose); }}>{t("leaveGroup")}</button>
      </div>}

      <div className="info-block">
        <h3 className="sheet-subhead">{t("sharedMedia")}</h3>
        {media.length === 0 ? <p className="picker-empty">{t("noSharedMedia")}</p> : <div className="media-grid">{media.map((url, index) => <img key={index} src={url} alt={`${t("imageMessage")} ${index + 1}`}/>)}</div>}
      </div>

      <div className="info-block"><WallpaperPicker value={wallpaper} onPick={onPickWallpaper}/></div>

      <div className="info-block settings-list sheet-list info-list">
        <button type="button" className="settings-menu-row" onClick={onToggleArchive}><span className="setting-icon"><Icon name="archive"/></span><span className="settings-menu-copy"><strong>{archived ? t("unarchiveChat") : t("archiveChat")}</strong></span></button>
        <button type="button" className="settings-menu-row" onClick={onToggleLock}><span className="setting-icon"><Icon name="lock"/></span><span className="settings-menu-copy"><strong>{locked ? t("unlockChat") : t("lockChat")}</strong></span></button>
        {!isGroup && <button type="button" className="settings-menu-row" onClick={onToggleBlock}><span className="setting-icon"><Icon name="lock"/></span><span className="settings-menu-copy"><strong>{blocked ? t("unblock") : t("block")}</strong></span></button>}
        <button type="button" className="settings-menu-row danger-row" onClick={() => setConfirmDelete(true)}><span className="setting-icon"><Icon name="trash"/></span><span className="settings-menu-copy"><strong>{t("deleteChat")}</strong></span></button>
      </div>
    </div>
    {confirmDelete && <SheetFrame title={t("deleteChat")} onClose={() => setConfirmDelete(false)} compact><p className="help-body">{t("deleteChatConfirm")}</p><div className="sheet-actions"><button type="button" className="text-button" onClick={() => setConfirmDelete(false)}>{t("cancel")}</button><button type="button" className="primary-button danger-button" onClick={onDeleteChat}><Icon name="trash" size={17}/> {t("deleteChat")}</button></div></SheetFrame>}
    {memberTarget && <SheetFrame title={memberTarget.name} eyebrow={t("memberActions")} onClose={() => setMemberTarget(null)} compact>
      <div className="member-actions">
        {isAdmin && memberTarget.id.toLocaleLowerCase() !== currentId && (memberIsAdmin(memberTarget)
          ? <button type="button" className="primary-button" onClick={() => void applyMembers(members, admins.filter((id) => id.toLocaleLowerCase() !== memberTarget.id.toLocaleLowerCase()))}>{t("removeAdmin")}</button>
          : <button type="button" className="primary-button" onClick={() => void applyMembers(members, [...admins, memberTarget.id])}>{t("makeAdmin")}</button>)}
        {isAdmin && memberTarget.id.toLocaleLowerCase() !== currentId && <button type="button" className="primary-button danger-button" onClick={() => void applyMembers(members.filter((member) => member.id.toLocaleLowerCase() !== memberTarget.id.toLocaleLowerCase()), admins.filter((id) => id.toLocaleLowerCase() !== memberTarget.id.toLocaleLowerCase()))}>{t("removeMember")}</button>}
        {memberTarget.id.toLocaleLowerCase() === currentId && <button type="button" className="primary-button danger-button" onClick={() => { void applyMembers(members.filter((member) => member.id.toLocaleLowerCase() !== currentId), admins.filter((id) => id.toLocaleLowerCase() !== currentId)).then(onClose); }}>{t("leaveGroup")}</button>}
      </div>
    </SheetFrame>}
    {addOpen && <SheetFrame title={t("addMembers")} onClose={() => setAddOpen(false)}>
      {addableContacts.length === 0 ? <p className="picker-empty">{t("addContactFirst")}</p> : addableContacts.map((item) => <div className="person-row" key={item.id}><Avatar name={item.contact_name} photo={item.contact_photo} size="small"/><span className="person-copy"><strong>{item.contact_name}</strong>{item.contact_username && <small dir="ltr">@{item.contact_username}</small>}</span><button type="button" className="text-button" onClick={() => void applyMembers([...members, { id: item.target_user_id, name: item.contact_name, email: item.contact_email, username: item.contact_username, mobile: item.contact_mobile, photo: item.contact_photo }], admins)}>{t("addPeople")}</button></div>)}
    </SheetFrame>}
  </div>;
}
const STATUS_SLIDE_MS = 5000;
function StatusViewer({ slides, startIndex, onClose }: { slides: ViewerSlide[]; startIndex: number; onClose: () => void }) {
  const { t, language } = useLocale(); const queryClient = useQueryClient();
  const [index, setIndex] = useState(startIndex); const [paused, setPaused] = useState(false); const [cycle, setCycle] = useState(0);
  const slide = slides[Math.min(index, slides.length - 1)];
  const remove = useMutation({ mutationFn: (id: number) => backend.deleteStatus({ id }), onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ["app-state"] }); onClose(); } });
  useEffect(() => {
    if (paused || !slide) return;
    const timer = window.setTimeout(() => {
      if (index + 1 < slides.length) { setIndex(index + 1); setCycle((value) => value + 1); } else onClose();
    }, STATUS_SLIDE_MS);
    return () => window.clearTimeout(timer);
  }, [index, paused, cycle, slides.length, onClose, slide]);
  if (!slide) return null;
  const goNext = () => { if (index + 1 < slides.length) { setIndex(index + 1); setCycle((value) => value + 1); } else onClose(); };
  const goPrev = () => { if (index > 0) { setIndex(index - 1); setCycle((value) => value + 1); } };
  const isPhoto = slide.status_type === "photo";
  return <div className={`status-viewer ${isPhoto ? "photo" : slide.accent}`} role="dialog" aria-modal="true" aria-label={t("status")} onPointerDown={() => setPaused(true)} onPointerUp={() => setPaused(false)} onPointerLeave={() => setPaused(false)}><div className="story-progress-row">{slides.map((item, itemIndex) => <div className="story-progress" key={item.key}>{itemIndex < index ? <i className="done"/> : itemIndex === index ? <i key={`${slide.key}-${cycle}`} className={paused ? "fill paused" : "fill"}/> : null}</div>)}</div><header><Avatar name={slide.author_name} photo={slide.author_photo} size="small"/><div><strong>{slide.own ? t("myStatus") : slide.author_name}</strong><span>{statusAge(slide.created_at, language)}</span></div><button className="icon-button" onClick={onClose} aria-label={t("close")}><Icon name="close"/></button></header>{isPhoto ? <figure className="status-viewer-photo"><img src={slide.image_url ?? ""} alt={slide.body || t("photoStatus")}/>{slide.body && <figcaption>{slide.body}</figcaption>}</figure> : <p>{slide.body}</p>}<button type="button" className="story-tap prev" onClick={goPrev} aria-label={t("prevStatus")}/><button type="button" className="story-tap next" onClick={goNext} aria-label={t("nextStatus")}/>{slide.own && slide.status_id !== undefined && <button className="delete-status" onClick={() => remove.mutate(slide.status_id as number)} disabled={remove.isPending}><Icon name="trash" size={18}/> {t("delete")}</button>}</div>;
}
type ChatFolder = "main" | "archived" | "locked";

function ChatsScreen({ conversations, archivedList, lockedList, folder, onFolderChange, selectedId, currentUserId, onSelect, onNew, onRowAction, archivedIds, lockedIds, mutedIds }: { conversations: Conversation[]; archivedList: Conversation[]; lockedList: Conversation[]; folder: ChatFolder; onFolderChange: (folder: ChatFolder) => void; selectedId: string | null; currentUserId: string; onSelect: (conversation: Conversation) => void; onNew: () => void; onRowAction: (conversation: Conversation, action: ChatRowAction) => void; archivedIds: ReadonlySet<string>; lockedIds: ReadonlySet<string>; mutedIds: ReadonlySet<string> }) {
  const { t, language } = useLocale(); const [search, setSearch] = useState("");
  const visible = folder === "archived" ? archivedList : folder === "locked" ? lockedList : conversations;
  const filtered = useMemo(() => { const term = search.trim().toLocaleLowerCase(language); if (!term) return visible; return visible.filter((item) => `${item.contact_name} ${item.contact_username ?? ""} ${item.contact_mobile ?? ""} ${item.contact_email ?? ""} ${item.last_message ?? ""}`.toLocaleLowerCase(language).includes(term)); }, [visible, search, language]);
  const rowFor = (conversation: Conversation) => <ConversationRow key={conversation.id} conversation={conversation} active={selectedId === conversation.id} currentUserId={currentUserId} archived={archivedIds.has(conversation.id)} locked={lockedIds.has(conversation.id) && folder !== "locked"} lockedState={lockedIds.has(conversation.id)} muted={mutedIds.has(conversation.id)} onAction={(action) => onRowAction(conversation, action)} onOpen={() => onSelect(conversation)}/>;
  if (folder !== "main") {
    return <section className={`list-pane${selectedId ? " has-selection" : ""}`}><header className="page-header folder-header"><button className="icon-button" onClick={() => onFolderChange("main")} aria-label={t("backChats")}><Icon name="back"/></button><h1>{folder === "archived" ? t("archived") : t("lockedChats")}</h1></header><div className="conversation-list">{filtered.length === 0 ? <div className="no-results"><p>{t("noSearch")}</p></div> : filtered.map(rowFor)}</div></section>;
  }
  return <section className={`list-pane${selectedId ? " has-selection" : ""}`}><header className="page-header chats-header"><div><BrandWordmark compact/><h1>{t("conversations")}</h1></div><button className="round-action" onClick={onNew} aria-label={t("newChat")}><Icon name="edit" size={20}/></button></header><label className="search-box"><span className="sr-only">{t("searchLabel")}</span><Icon name="search" size={19}/><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={t("search")}/></label><div className="conversation-list">{archivedList.length > 0 && <button type="button" className="folder-row" onClick={() => onFolderChange("archived")} aria-label={t("archived")}><span className="folder-icon"><Icon name="archive" size={20}/></span><span className="folder-copy"><strong>{t("archived")}</strong></span><b className="folder-count">{archivedList.length}</b></button>}{lockedList.length > 0 && <button type="button" className="folder-row" onClick={() => onFolderChange("locked")} aria-label={t("lockedChats")}><span className="folder-icon"><Icon name="lock" size={20}/></span><span className="folder-copy"><strong>{t("lockedChats")}</strong><small>{t("lockedPreview")}</small></span><b className="folder-count">{lockedList.length}</b></button>}{conversations.length === 0 && archivedList.length === 0 && lockedList.length === 0 ? <div className="empty-list"><div className="empty-icon"><Icon name="chat" size={33}/></div><h2>{t("firstChat")}</h2><p>{t("firstChatHint")}</p><button className="primary-button narrow" onClick={onNew}><Icon name="plus" size={19}/> {t("newChat")}</button></div> : filtered.length === 0 && (archivedList.length > 0 || lockedList.length > 0 || conversations.length > 0) ? <div className="no-results"><p>{t("noSearch")}</p><button className="text-button" onClick={() => setSearch("")}>{t("clearSearch")}</button></div> : filtered.map(rowFor)}</div></section>;
}
function StatusScreen({ profile, ownPhoto, statuses, contactStatuses, onNew, onViewOwn, onViewContact }: { profile: NonNullable<AppState["profile"]>; ownPhoto: string | null; statuses: Status[]; contactStatuses: FirebaseStatus[]; onNew: () => void; onViewOwn: () => void; onViewContact: (authorId: string) => void }) {
  const { t, language } = useLocale();
  const groups = useMemo(() => {
    const byAuthor = new Map<string, FirebaseStatus[]>();
    for (const item of contactStatuses) {
      const list = byAuthor.get(item.author_id) ?? [];
      list.push(item);
      byAuthor.set(item.author_id, list);
    }
    return [...byAuthor.entries()].map(([authorId, items]) => ({ authorId, items: [...items].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()) })).sort((a, b) => new Date(b.items[b.items.length - 1]?.created_at ?? 0).getTime() - new Date(a.items[a.items.length - 1]?.created_at ?? 0).getTime());
  }, [contactStatuses]);
  const latestOwn = statuses[0];
  return <section className="page-pane"><header className="page-header"><div><p className="eyebrow">{t("update24")}</p><h1>{t("status")}</h1></div><button className="round-action" onClick={onNew} aria-label={t("newStatus")}><Icon name="plus"/></button></header><button type="button" className="status-profile status-profile-button" onClick={statuses.length > 0 ? onViewOwn : onNew} aria-label={t("myStatus")}><div className={`status-ring${statuses.length > 0 ? " has-status" : ""}`}><Avatar name={profile.display_name} photo={ownPhoto} size="large"/><span className="status-ring-add" aria-hidden="true"><Icon name="plus" size={14}/></span></div><div><strong>{t("myStatus")}</strong><span>{statuses.length ? `${statuses.length} ${t("activeUpdate")} · ${latestOwn ? statusAge(latestOwn.created_at, language) : ""}` : t("tapAddUpdate")}</span></div></button>{groups.length > 0 && <><h2 className="section-label">{t("recentUpdates")}</h2><div className="contact-status-list">{groups.map((group) => { const latest = group.items[group.items.length - 1]; if (!latest) return null; return <button type="button" className="contact-status-row" key={group.authorId} onClick={() => onViewContact(group.authorId)} aria-label={`${latest.author_name} — ${t("status")}`}><span className="status-ring has-status contact"><Avatar name={latest.author_name} photo={latest.author_photo}/></span><span className="contact-status-copy"><strong>{latest.author_name}</strong><small>{statusAge(latest.created_at, language)}{group.items.length > 1 ? ` · ${group.items.length}` : ""}</small></span></button>; })}</div></>}{groups.length === 0 && <div className="server-empty"><Icon name="status" size={32}/><h2>{t("contactStatuses")}</h2><p>{t("statusServerHint")}</p></div>}</section>;
}
function CallsScreen({ conversations, calls, onCall }: { conversations: Conversation[]; calls: AppState["calls"]; onCall: (target: CallTarget) => void }) {
  const { t, locale } = useLocale(); const [picker, setPicker] = useState(false);
  return <section className="page-pane"><header className="page-header"><div><p className="eyebrow">{t("recentActivity")}</p><h1>{t("calls")}</h1></div><button className="round-action" onClick={() => setPicker(true)} aria-label={t("newCall")}><Icon name="phone" size={20}/></button></header><div className="call-note"><Icon name="phone" size={19}/><p>{t("callNote")}</p></div>{calls.length === 0 ? <div className="empty-list compact"><div className="empty-icon"><Icon name="phone" size={31}/></div><h2>{t("noCalls")}</h2><p>{t("noCallsHint")}</p></div> : <div className="call-list">{calls.map((call) => <div className="call-row" key={call.id}><div className="avatar">{initials(call.contact_name)}</div><div><strong>{call.contact_name}</strong><span><Icon name={call.call_type === "video" ? "video" : "phone"} size={14}/> {t("test")} {call.call_type === "video" ? t("videoCall") : t("audioCall")} · {formatListTime(call.started_at, locale)}</span></div><button className="icon-button" onClick={() => onCall({ name: call.contact_name, email: call.contact_email, photo: null, type: call.call_type })} aria-label={`${call.contact_name} ${t("callAgain")}`}><Icon name={call.call_type === "video" ? "video" : "phone"}/></button></div>)}</div>}{picker && <SheetFrame title={t("newCall")} onClose={() => setPicker(false)}><div className="contact-picker">{conversations.length === 0 ? <p className="picker-empty">{t("addContactFirst")}</p> : conversations.map((conversation) => <div className="picker-row" key={conversation.id}><Avatar name={conversation.contact_name} photo={conversation.contact_photo} size="small"/><strong>{conversation.contact_name}</strong><button className="icon-button" onClick={() => { setPicker(false); onCall({ name: conversation.contact_name, email: conversation.contact_email, photo: conversation.contact_photo, type: "audio" }); }} aria-label={`${conversation.contact_name} — ${t("audioCall")}`}><Icon name="phone"/></button><button className="icon-button" onClick={() => { setPicker(false); onCall({ name: conversation.contact_name, email: conversation.contact_email, photo: conversation.contact_photo, type: "video" }); }} aria-label={`${conversation.contact_name} — ${t("videoCall")}`}><Icon name="video"/></button></div>)}</div></SheetFrame>}</section>;
}
type SettingsSection = "account" | "applock" | "privacy" | "lists" | "chats" | "appearance" | "voice" | "notifications" | "storage" | "language" | "help";

function downloadTextFile(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url; anchor.download = filename;
  document.body.appendChild(anchor); anchor.click(); anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

function SettingsScreen({ profile, ownPhoto, onEdit, conversations, currentUserId, blockedContacts, chatLists, onLockNow }: { profile: NonNullable<AppState["profile"]>; ownPhoto: string | null; onEdit: () => void; conversations: Conversation[]; currentUserId: string; blockedContacts: AppState["blocked_contacts"]; chatLists: AppState["chat_lists"]; onLockNow: () => void }) {
  const { t, locale } = useLocale(); const queryClient = useQueryClient();
  const [section, setSection] = useState<SettingsSection | null>(null);
  const save = useMutation({ mutationFn: (next: { notifications_enabled: boolean; read_receipts_enabled: boolean }) => backend.saveSettings(next), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });
  const preferences = useMutation({ mutationFn: (next: { language: Language; theme_mode: ThemeMode; wallpaper: Wallpaper; message_tone: MessageTone; conversation_tones_enabled: boolean; call_tone?: MessageTone; security_notifications_enabled?: boolean; auto_download_photos?: boolean; auto_download_voice?: boolean; default_voice_effect?: VoiceEffect }) => backend.savePreferences(next), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });
  const change = (field: "notifications_enabled" | "read_receipts_enabled", value: boolean) => save.mutate({ notifications_enabled: field === "notifications_enabled" ? value : profile.notifications_enabled, read_receipts_enabled: field === "read_receipts_enabled" ? value : profile.read_receipts_enabled });
  const basePrefs = { language: profile.language, theme_mode: profile.theme_mode, wallpaper: profile.wallpaper, message_tone: profile.message_tone, conversation_tones_enabled: profile.conversation_tones_enabled, call_tone: profile.call_tone, security_notifications_enabled: profile.security_notifications_enabled, auto_download_photos: profile.auto_download_photos, auto_download_voice: profile.auto_download_voice, default_voice_effect: profile.default_voice_effect };
  const changePreference = (next: Partial<typeof basePrefs>) => preferences.mutate({ ...basePrefs, ...next });
  const languageOptions = LANGUAGE_OPTIONS;
  const themeOptions: { value: ThemeMode; label: string }[] = [{ value: "system", label: t("systemTheme") }, { value: "light", label: t("lightTheme") }, { value: "dark", label: t("darkTheme") }];
  const toneLabels = profile.language === "ur" ? ["صبا", "نور", "رقص", "آبشار", "سکون", "بند"] : profile.language === "hi" ? ["सबा", "नूर", "रक्स", "आबशार", "सुकून", "बंद"] : ["Saba", "Noor", "Raqs", "Aabshar", "Sukoon", "Off"];
  const toneOptions: { value: MessageTone; label: string }[] = (["saba", "noor", "raqs", "aabshar", "sukoon", "none"] as MessageTone[]).map((value, index) => ({ value, label: toneLabels[index] ?? value }));
  const wallpaperOptions = useWallpaperOptions();

  const blockedIds = useMemo(() => new Set(blockedContacts.map((item) => item.target_user_id.toLocaleLowerCase())), [blockedContacts]);
  const directConversations = useMemo(() => conversations.filter((item) => !item.is_group), [conversations]);
  const blockMutation = useMutation({ mutationFn: (conversation: Conversation) => backend.blockContact({ target_user_id: conversation.target_user_id, contact_name: conversation.contact_name, contact_email: conversation.contact_email, contact_username: conversation.contact_username }), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });
  const unblockMutation = useMutation({ mutationFn: (targetUserId: string) => backend.unblockContact({ target_user_id: targetUserId }), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });

  const [newNumber, setNewNumber] = useState(profile.mobile_number ?? "");
  const [numberSaved, setNumberSaved] = useState(false);
  const changeNumber = useMutation({ mutationFn: () => backend.saveProfile({ display_name: profile.display_name, username: profile.username, email: profile.email, mobile_number: newNumber.trim() || null, about: profile.about }), onSuccess: async () => { setNumberSaved(true); await queryClient.invalidateQueries({ queryKey: ["app-state"] }); } });

  const timerOptions: { value: number; label: string }[] = [{ value: 0, label: t("timerOff") }, { value: 86400, label: t("timer24h") }, { value: 604800, label: t("timer7d") }, { value: 7776000, label: t("timer90d") }];
  const [timers, setTimers] = useState<Record<string, number>>({});
  useEffect(() => {
    if (section !== "privacy") return;
    const unsubscribes = directConversations.map((conversation) => listenToFirebaseDisappearing(firebaseThreadId(currentUserId, conversation.target_user_id), currentUserId, (seconds) => setTimers((items) => ({ ...items, [conversation.id]: seconds }))));
    return () => unsubscribes.forEach((unsubscribe) => unsubscribe());
  }, [section, directConversations, currentUserId]);
  const setTimer = (conversation: Conversation, seconds: number) => {
    setTimers((items) => ({ ...items, [conversation.id]: seconds }));
    void setFirebaseDisappearing(firebaseThreadId(currentUserId, conversation.target_user_id), currentUserId, seconds).catch(() => undefined);
  };

  const [newListName, setNewListName] = useState("");
  const createList = useMutation({ mutationFn: (name: string) => backend.createChatList({ name }), onSuccess: async () => { setNewListName(""); await queryClient.invalidateQueries({ queryKey: ["app-state"] }); } });
  const deleteList = useMutation({ mutationFn: (id: number) => backend.deleteChatList({ id }), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });
  const addMember = useMutation({ mutationFn: (input: { list: AppState["chat_lists"][number]; conversation: Conversation }) => backend.addChatListMember({ list_id: input.list.id, target_user_id: input.conversation.target_user_id, contact_name: input.conversation.contact_name, contact_email: input.conversation.contact_email, contact_username: input.conversation.contact_username }), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });
  const removeMember = useMutation({ mutationFn: (input: { listId: number; targetUserId: string }) => backend.removeChatListMember({ list_id: input.listId, target_user_id: input.targetUserId }), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });

  const [exportingId, setExportingId] = useState<string | null>(null);
  const [exportError, setExportError] = useState(false);
  const exportChat = async (conversation: Conversation) => {
    setExportingId(conversation.id); setExportError(false);
    try {
      const items = await fetchFirebaseMessagesOnce(firebaseThreadId(currentUserId, conversation.target_user_id), currentUserId);
      const lines = items.map((item) => {
        const when = new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeStyle: "short" }).format(new Date(item.created_at));
        const who = item.direction === "self" ? profile.display_name : conversation.contact_name;
        const kind = item.message_type === "image" ? t("imageMessage") : item.message_type === "audio" ? t("audioMessage") : item.body;
        return `[${when}] ${who}: ${kind}`;
      });
      downloadTextFile(`bolo-chat-${conversation.contact_name.replace(/[^\p{L}\p{N}]+/gu, "-") || "chat"}.txt`, `${conversation.contact_name}\n${profile.display_name} · Bolo Chat\n\n${lines.join("\n")}\n`);
    } catch { setExportError(true); }
    finally { setExportingId(null); }
  };

  const [usage, setUsage] = useState<{ sent: number; received: number; photos: number; voice: number } | null>(null);
  const [usageError, setUsageError] = useState(false);
  useEffect(() => {
    if (section !== "storage") return;
    let cancelled = false;
    setUsageError(false);
    void fetchFirebaseUsage(currentUserId).then((result) => { if (!cancelled) setUsage(result); }).catch(() => { if (!cancelled) setUsage((current) => { if (current === null) setUsageError(true); return current; }); });
    return () => { cancelled = true; };
  }, [section, currentUserId]);

  const [lockMethod, setLockMethod] = useState<LockMethod>(profile.app_lock_method);
  const [lockSecret, setLockSecret] = useState("");
  const [lockConfirm, setLockConfirm] = useState("");
  const [lockError, setLockError] = useState("");
  const [lockSavedNote, setLockSavedNote] = useState(false);
  const saveLock = useMutation({ mutationFn: (input: { enabled: boolean; method: LockMethod; secret_hash?: string | null; secret_salt?: string | null }) => backend.saveAppLock(input), onSuccess: async () => { setLockSavedNote(true); setLockSecret(""); setLockConfirm(""); await queryClient.invalidateQueries({ queryKey: ["app-state"] }); }, onError: () => setLockError(t("changeSaveError")) });
  const applyLock = async (enabled: boolean) => {
    setLockError(""); setLockSavedNote(false);
    if (!enabled) { saveLock.mutate({ enabled: false, method: "none" }); return; }
    if (lockMethod === "none") { setLockError(t("setSecret")); return; }
    if (lockMethod === "biometric" && !window.localStorage.getItem(BIOMETRIC_CRED_KEY)) {
      try { await registerBiometric(profile.email); } catch { setLockError(t("biometricUnavailable")); return; }
    }
    let secretHash = profile.app_lock_hash;
    let secretSalt = profile.app_lock_salt;
    if (lockSecret) {
      if (lockSecret.length < 4 || lockSecret !== lockConfirm) { setLockError(t("secretMismatch")); return; }
      secretSalt = crypto.randomUUID();
      secretHash = await hashFirebaseVoicePassword(lockSecret, secretSalt);
    } else if (lockMethod !== "biometric" && !secretHash) { setLockError(t("setSecret")); return; }
    saveLock.mutate({ enabled: true, method: lockMethod, secret_hash: secretHash, secret_salt: secretSalt });
  };

  const [feedbackBody, setFeedbackBody] = useState("");
  const [feedbackSent, setFeedbackSent] = useState(false);
  const sendFeedback = useMutation({ mutationFn: (body: string) => backend.saveFeedback({ body }), onSuccess: () => { setFeedbackBody(""); setFeedbackSent(true); } });

  const [inviteCopied, setInviteCopied] = useState(false);
  const invite = async () => {
    const text = t("inviteText");
    try {
      if (typeof navigator !== "undefined" && "share" in navigator) { await navigator.share({ text }); return; }
      throw new Error("no-share");
    } catch { try { await navigator.clipboard.writeText(text); setInviteCopied(true); } catch { /* clipboard unavailable */ } }
  };

  const menuRow = (key: SettingsSection, icon: IconName, title: string, hint: string) => <button type="button" className="settings-menu-row" onClick={() => setSection(key)} aria-label={`${title} — ${t("openSection")}`}><span className="setting-icon"><Icon name={icon}/></span><span className="settings-menu-copy"><strong>{title}</strong><small>{hint}</small></span><span className="settings-menu-arrow" aria-hidden="true">‹</span></button>;
  const toggleRow = (icon: IconName, title: string, hint: string, checked: boolean, onToggle: (value: boolean) => void, label: string) => <label className="setting-row"><span className="setting-icon"><Icon name={icon}/></span><span><strong>{title}</strong><small>{hint}</small></span><input type="checkbox" checked={checked} onChange={(event) => onToggle(event.target.checked)} aria-label={label}/></label>;

  return <section className="page-pane settings-page"><header className="page-header"><div><p className="eyebrow">{t("preferences")}</p><h1>{t("settings")}</h1></div></header><button className="profile-card" onClick={onEdit} aria-label={t("editProfile")}><Avatar name={profile.display_name} photo={ownPhoto} size="xlarge"/><div><strong>{profile.display_name}</strong>{profile.username && <span dir="ltr">@{profile.username}</span>}<span>{profile.about}</span>{profile.mobile_number && <small dir="ltr">{profile.mobile_number}</small>}<small dir="ltr">{profile.email}</small></div><Icon name="edit" size={19}/></button>
    <div className="settings-menu">
      {menuRow("account", "user", t("account"), t("accountHint"))}
      {menuRow("applock", "lock", t("appLock"), t("appLockHint"))}
      {menuRow("privacy", "checks", t("privacy"), t("privacyHint"))}
      {menuRow("lists", "user", t("lists"), t("listsHint"))}
      {menuRow("chats", "chat", t("chatsSection"), t("chatsHint"))}
      {menuRow("appearance", "wallpaper", t("appearance"), t("appearanceHint"))}
      {menuRow("voice", "mic", t("voiceStyle"), t("chooseVoice"))}
      {menuRow("notifications", "bell", t("notifications"), t("notificationHint"))}
      {menuRow("storage", "image", t("storageData"), t("storageHint"))}
      {menuRow("language", "language", t("appLanguage"), t("language"))}
      {menuRow("help", "speaker", t("helpFeedback"), t("helpHint"))}
      <button type="button" className="settings-menu-row" onClick={() => void invite()} aria-label={t("inviteFriend")}><span className="setting-icon"><Icon name="send"/></span><span className="settings-menu-copy"><strong>{t("inviteFriend")}</strong><small>{inviteCopied ? t("copied") : t("inviteHint")}</small></span><span className="settings-menu-arrow" aria-hidden="true">‹</span></button>
    </div>
    {preferences.isPending && <p className="preference-saving">{t("saving")}</p>}{preferences.isError && <InlineError message={t("preferenceError")}/>}
    <div className="settings-info"><h2>{t("serverConnection")}</h2><p>{t("serverInfo")}</p><span className="connection-chip"><i/> {t("localMode")}</span><p className="settings-version">ورژن <span dir="ltr">v{APP_VERSION}</span></p></div>
    <div className="settings-brand-footer"><BrandWordmark compact/></div>

    {section === "account" && <SheetFrame title={t("account")} onClose={() => setSection(null)}><div className="settings-list sheet-list">
      {toggleRow("bell", t("securityNotifications"), t("securityHint"), profile.security_notifications_enabled, (value) => changePreference({ security_notifications_enabled: value }), t("securityNotifications"))}
    </div><form className="sheet-form-block" onSubmit={(event) => { event.preventDefault(); setNumberSaved(false); changeNumber.mutate(); }}><label htmlFor="change-number">{t("changeNumber")}</label><input id="change-number" dir="ltr" type="tel" autoComplete="tel" value={newNumber} onChange={(event) => setNewNumber(event.target.value.replace(/[^+0-9\s-]/g, ""))} placeholder="+92 300 1234567" maxLength={24}/><p className="field-note">{t("changeNumberHint")}</p>{changeNumber.isError && <InlineError message={t("changeSaveError")}/>}{numberSaved && <p className="saved-note">{t("settingsSaved")}</p>}<button className="primary-button" disabled={changeNumber.isPending}>{t("save")}</button></form>
    <div className="account-facts"><p><span>{t("yourName")}</span><strong>{profile.display_name}</strong></p>{profile.username && <p><span>{t("username")}</span><strong dir="ltr">@{profile.username}</strong></p>}<p><span>{t("gmail")}</span><strong dir="ltr">{profile.email}</strong></p></div></SheetFrame>}

    {section === "applock" && <SheetFrame title={t("appLock")} onClose={() => setSection(null)}>
      <p className="field-note">{t("appLockHint")} — {profile.app_lock_enabled ? t("lockOn") : t("lockOff")}</p>
      <div className="lock-methods" role="group" aria-label={t("appLock")}>
        {([["pin", "pinMethod"], ["password", "passwordMethod"], ["biometric", "biometricMethod"]] as [LockMethod, TextKey][]).map(([value, label]) => <button type="button" key={value} className={lockMethod === value ? "selected" : ""} onClick={() => setLockMethod(value)} aria-pressed={lockMethod === value}><Icon name={value === "biometric" ? "fingerprint" : "lock"} size={19}/><span>{t(label)}</span></button>)}
      </div>
      {lockMethod !== "none" && <div className="sheet-form-block">
        <label htmlFor="lock-new-secret">{t("setSecret")}{lockMethod === "biometric" ? ` (${t("optional")})` : ""}</label>
        <input id="lock-new-secret" dir="ltr" type="password" inputMode={lockMethod === "pin" ? "numeric" : undefined} autoComplete="new-password" value={lockSecret} onChange={(event) => setLockSecret(event.target.value)} minLength={4} maxLength={40}/>
        <label htmlFor="lock-confirm-secret">{t("confirmSecret")}</label>
        <input id="lock-confirm-secret" dir="ltr" type="password" inputMode={lockMethod === "pin" ? "numeric" : undefined} autoComplete="new-password" value={lockConfirm} onChange={(event) => setLockConfirm(event.target.value)} minLength={4} maxLength={40}/>
      </div>}
      {lockError && <InlineError message={lockError}/>}
      {lockSavedNote && <p className="saved-note">{t("lockSaved")}</p>}
      <div className="sheet-actions">
        {profile.app_lock_enabled && <button type="button" className="text-button danger" onClick={() => void applyLock(false)} disabled={saveLock.isPending}>{t("disableLock")}</button>}
        <button type="button" className="primary-button" onClick={() => void applyLock(true)} disabled={saveLock.isPending || lockMethod === "none"}>{saveLock.isPending ? t("saving") : t("save")}</button>
      </div>
      {profile.app_lock_enabled && <button type="button" className="primary-button lock-now-button" onClick={onLockNow}><Icon name="lock" size={17}/> {t("lockNow")}</button>}
    </SheetFrame>}

    {section === "privacy" && <SheetFrame title={t("privacy")} onClose={() => setSection(null)}><div className="settings-list sheet-list">
      {toggleRow("checks", t("receipts"), t("receiptsHint"), profile.read_receipts_enabled, (value) => change("read_receipts_enabled", value), t("receipts"))}
    </div>
    <h3 className="sheet-subhead">{t("blockedAccounts")}</h3><p className="field-note">{t("blockedHint")}</p>
    {blockedContacts.length === 0 && directConversations.length === 0 && <p className="picker-empty">{t("noBlocked")}</p>}
    {blockedContacts.map((item) => <div className="person-row" key={item.target_user_id}><Avatar name={item.contact_name} size="small"/><span className="person-copy"><strong>{item.contact_name}</strong>{item.contact_username && <small dir="ltr">@{item.contact_username}</small>}</span><button type="button" className="text-button" onClick={() => unblockMutation.mutate(item.target_user_id)} disabled={unblockMutation.isPending}>{t("unblock")}</button></div>)}
    {directConversations.filter((conversation) => !blockedIds.has(conversation.target_user_id.toLocaleLowerCase())).map((conversation) => <div className="person-row" key={conversation.id}><Avatar name={conversation.contact_name} photo={conversation.contact_photo} size="small"/><span className="person-copy"><strong>{conversation.contact_name}</strong>{conversation.contact_username && <small dir="ltr">@{conversation.contact_username}</small>}</span><button type="button" className="text-button danger" onClick={() => blockMutation.mutate(conversation)} disabled={blockMutation.isPending}>{t("block")}</button></div>)}
    <h3 className="sheet-subhead">{t("disappearing")}</h3><p className="field-note">{t("disappearingHint")}</p>
    {directConversations.length === 0 ? <p className="picker-empty">{t("addContactFirst")}</p> : directConversations.map((conversation) => <div className="timer-row" key={conversation.id}><span className="person-copy"><strong>{conversation.contact_name}</strong><small>{t("disappearing")} {t("forChat")} {conversation.contact_name}</small></span><div className="timer-options" role="group" aria-label={`${t("disappearing")} — ${conversation.contact_name}`}>{timerOptions.map((option) => <button type="button" key={option.value} className={(timers[conversation.id] ?? 0) === option.value ? "selected" : ""} onClick={() => setTimer(conversation, option.value)} aria-pressed={(timers[conversation.id] ?? 0) === option.value}>{option.label}</button>)}</div></div>)}
    </SheetFrame>}

    {section === "lists" && <SheetFrame title={t("lists")} onClose={() => setSection(null)}>
      <form className="sheet-form-block" onSubmit={(event) => { event.preventDefault(); if (newListName.trim()) createList.mutate(newListName.trim()); }}><label htmlFor="new-list-name">{t("createList")}</label><div className="inline-form"><input id="new-list-name" value={newListName} onChange={(event) => setNewListName(event.target.value)} placeholder={t("listName")} maxLength={40}/><button className="primary-button" disabled={createList.isPending || !newListName.trim()}>{t("createList")}</button></div></form>
      {chatLists.length === 0 && <p className="picker-empty">{t("noLists")}</p>}
      {chatLists.map((list) => <div className="list-block" key={list.id}><div className="list-block-head"><strong>{list.name}</strong><span>{list.members.length}</span><button type="button" className="icon-button" onClick={() => deleteList.mutate(list.id)} aria-label={`${list.name} — ${t("delete")}`}><Icon name="trash" size={18}/></button></div>
      {list.members.map((member) => <div className="person-row" key={member.target_user_id}><Avatar name={member.contact_name} size="small"/><span className="person-copy"><strong>{member.contact_name}</strong></span><button type="button" className="text-button danger" onClick={() => removeMember.mutate({ listId: list.id, targetUserId: member.target_user_id })}>{t("delete")}</button></div>)}
      {directConversations.filter((conversation) => !list.members.some((member) => member.target_user_id.toLocaleLowerCase() === conversation.target_user_id.toLocaleLowerCase())).map((conversation) => <div className="person-row" key={conversation.id}><Avatar name={conversation.contact_name} photo={conversation.contact_photo} size="small"/><span className="person-copy"><strong>{conversation.contact_name}</strong></span><button type="button" className="text-button" onClick={() => addMember.mutate({ list, conversation })} disabled={addMember.isPending}>{t("addPeople")}</button></div>)}
      </div>)}
    </SheetFrame>}

    {section === "chats" && <SheetFrame title={t("chatsSection")} onClose={() => setSection(null)}>
      <div className="usage-grid"><div><strong>{conversations.length}</strong><span>{t("totalChats")}</span></div><div><strong>{chatLists.length}</strong><span>{t("lists")}</span></div></div>
      <h3 className="sheet-subhead">{t("backup")}</h3>
      {exportError && <InlineError message={t("exportError")}/>}
      {directConversations.length === 0 ? <p className="picker-empty">{t("addContactFirst")}</p> : directConversations.map((conversation) => <div className="person-row" key={conversation.id}><Avatar name={conversation.contact_name} photo={conversation.contact_photo} size="small"/><span className="person-copy"><strong>{conversation.contact_name}</strong><small>{t("chatHistory")}</small></span><button type="button" className="text-button" onClick={() => void exportChat(conversation)} disabled={exportingId !== null}>{exportingId === conversation.id ? t("exporting") : t("exportChat")}</button></div>)}
    </SheetFrame>}

    {section === "appearance" && <SheetFrame title={t("appearance")} onClose={() => setSection(null)}>
      <div className="preference-card sheet-card"><div className="preference-heading"><span className="setting-icon theme-icon" aria-hidden="true">◐</span><div><strong>{t("theme")}</strong><small>{t("themeHint")}</small></div></div><div className="theme-options" role="group" aria-label={t("theme")}>{themeOptions.map((option) => <button key={option.value} className={`${option.value}${profile.theme_mode === option.value ? " selected" : ""}`} onClick={() => changePreference({ theme_mode: option.value })} aria-pressed={profile.theme_mode === option.value}><i/><span>{option.label}</span></button>)}</div></div>
      <div className="preference-card sheet-card"><div className="preference-heading"><span className="setting-icon"><Icon name="wallpaper"/></span><div><strong>{t("wallpaper")}</strong><small>{t("wallpaperHint")}</small></div></div><div className="wallpaper-options" role="group" aria-label={t("wallpaper")}>{wallpaperOptions.map((wallpaper) => <button key={wallpaper.value} className={`wallpaper-swatch ${wallpaper.value}${profile.wallpaper === wallpaper.value ? " selected" : ""}`} onClick={() => changePreference({ wallpaper: wallpaper.value })} aria-label={wallpaper.label} aria-pressed={profile.wallpaper === wallpaper.value}><i/><span>{wallpaper.label}</span></button>)}</div></div>
    </SheetFrame>}

    {section === "voice" && <SheetFrame title={t("voiceStyle")} onClose={() => setSection(null)}>
      <p className="field-note">{t("voiceStyleHint")}</p>
      <div className="voice-effects settings-voice" role="group" aria-label={t("chooseVoice")}>{VOICE_EFFECT_OPTIONS.map((option) => <button type="button" key={option.value} className={profile.default_voice_effect === option.value ? "selected" : ""} onClick={() => changePreference({ default_voice_effect: option.value })} aria-pressed={profile.default_voice_effect === option.value}><Icon name="mic" size={17}/><span>{t(option.label)}</span></button>)}</div>
    </SheetFrame>}

    {section === "notifications" && <SheetFrame title={t("notifications")} onClose={() => setSection(null)}><div className="settings-list sheet-list">
      {toggleRow("bell", t("notifications"), t("notificationHint"), profile.notifications_enabled, (value) => change("notifications_enabled", value), t("notifications"))}
      {toggleRow("music", t("conversationTones"), t("conversationTonesHint"), profile.conversation_tones_enabled, (value) => changePreference({ conversation_tones_enabled: value }), t("conversationTones"))}
    </div>
      <div className="preference-card sheet-card"><div className="preference-heading"><span className="setting-icon"><Icon name="music"/></span><div><strong>{t("tone")}</strong><small>{t("originalTones")}</small></div><button className="tone-preview" onClick={() => playTone(profile.message_tone)} disabled={profile.message_tone === "none"}><Icon name="play" size={14}/> {t("preview")}</button></div><div className="tone-options" role="group" aria-label={t("tone")}>{toneOptions.map((tone) => <button key={tone.value} className={profile.message_tone === tone.value ? "selected" : ""} onClick={() => { changePreference({ message_tone: tone.value }); playTone(tone.value); }} aria-pressed={profile.message_tone === tone.value}>{tone.label}</button>)}</div></div>
      <div className="preference-card sheet-card"><div className="preference-heading"><span className="setting-icon"><Icon name="phone"/></span><div><strong>{t("callTone")}</strong><small>{t("originalTones")}</small></div><button className="tone-preview" onClick={() => playTone(profile.call_tone)} disabled={profile.call_tone === "none"}><Icon name="play" size={14}/> {t("preview")}</button></div><div className="tone-options" role="group" aria-label={t("callTone")}>{toneOptions.map((tone) => <button key={tone.value} className={profile.call_tone === tone.value ? "selected" : ""} onClick={() => { changePreference({ call_tone: tone.value }); playTone(tone.value); }} aria-pressed={profile.call_tone === tone.value}>{tone.label}</button>)}</div></div>
    </SheetFrame>}

    {section === "storage" && <SheetFrame title={t("storageData")} onClose={() => setSection(null)}>
      <h3 className="sheet-subhead">{t("networkUsage")}</h3>
      {usageError ? <InlineError message={t("usageError")}/> : usage === null ? <p className="picker-empty">{t("exporting")}</p> : <div className="usage-grid four"><div><strong>{usage.sent}</strong><span>{t("sentMessages")}</span></div><div><strong>{usage.received}</strong><span>{t("receivedMessages")}</span></div><div><strong>{usage.photos}</strong><span>{t("photosExchanged")}</span></div><div><strong>{usage.voice}</strong><span>{t("voiceExchanged")}</span></div></div>}
      <h3 className="sheet-subhead">{t("autoDownload")}</h3><p className="field-note">{t("autoDownloadHint")}</p>
      <div className="settings-list sheet-list">
        {toggleRow("image", t("imageMessage"), t("autoPhotos"), profile.auto_download_photos, (value) => changePreference({ auto_download_photos: value }), t("autoPhotos"))}
        {toggleRow("mic", t("audioMessage"), t("autoVoice"), profile.auto_download_voice, (value) => changePreference({ auto_download_voice: value }), t("autoVoice"))}
      </div>
    </SheetFrame>}

    {section === "language" && <SheetFrame title={t("appLanguage")} onClose={() => setSection(null)}>
      <div className="preference-card sheet-card"><div className="preference-heading"><span className="setting-icon"><Icon name="language"/></span><div><strong>{t("language")}</strong><small>{t("language")}</small></div></div><div className="language-options" role="group" aria-label={t("language")}>{languageOptions.map((option) => <button key={option.value} className={profile.language === option.value ? "selected" : ""} onClick={() => changePreference({ language: option.value })} aria-pressed={profile.language === option.value}><b>{option.label}</b><span>{option.sample}</span></button>)}</div></div>
    </SheetFrame>}

    {section === "help" && <SheetFrame title={t("helpFeedback")} onClose={() => setSection(null)}>
      <h3 className="sheet-subhead">{t("helpCentre")}</h3><p className="help-body">{t("helpBody")}</p>
      <a className="primary-button contact-link" href="mailto:myousufofficial313@gmail.com?subject=Bolo%20Chat%20Help">{t("contactUs")}</a>
      <h3 className="sheet-subhead">{t("feedback")}</h3>
      <form className="sheet-form-block" onSubmit={(event) => { event.preventDefault(); setFeedbackSent(false); if (feedbackBody.trim()) sendFeedback.mutate(feedbackBody.trim()); }}><label htmlFor="feedback-body">{t("feedback")}</label><textarea id="feedback-body" className="feedback-input" value={feedbackBody} onChange={(event) => setFeedbackBody(event.target.value)} placeholder={t("feedbackPlaceholder")} maxLength={2000} rows={4}/>{sendFeedback.isError && <InlineError message={t("feedbackError")}/>}{feedbackSent && <p className="saved-note">{t("feedbackSent")}</p>}<button className="primary-button" disabled={sendFeedback.isPending || !feedbackBody.trim()}>{t("sendFeedback")}</button></form>
    </SheetFrame>}
  </section>;
}

function CallOverlay({ target, onEnd }: { target: CallTarget; onEnd: () => void }) {
  const { t } = useLocale(); const [seconds, setSeconds] = useState(0); const [muted, setMuted] = useState(false); const [speaker, setSpeaker] = useState(false);
  useEffect(() => { const timer = window.setInterval(() => setSeconds((value) => value + 1), 1000); return () => window.clearInterval(timer); }, []);
  return <div className={`call-screen ${target.type}`} role="dialog" aria-modal="true" aria-label={`${target.name} — ${t("call")}`}><div className="call-top"><span>{t("test")} {target.type === "video" ? t("videoCall") : t("audioCall")}</span><small>{t("serverRequired")}</small></div>{target.type === "video" && <div className="video-placeholder"><Icon name="video" size={42}/><span>{t("videoPlaceholder")}</span></div>}<div className="call-person"><div className="avatar call-avatar">{target.photo ? <img src={target.photo} alt=""/> : initials(target.name)}</div><h2>{target.name}</h2><p>{formatDuration(seconds)}</p></div><div className="call-controls"><button className={muted ? "active" : ""} onClick={() => setMuted(!muted)} aria-label={muted ? t("unmute") : t("mute")}><Icon name="mute"/><span>{t("microphone")}</span></button><button className="end-call" onClick={onEnd} aria-label={t("endCall")}><Icon name="phone"/><span>{t("end")}</span></button><button className={speaker ? "active" : ""} onClick={() => setSpeaker(!speaker)} aria-label={t("speaker")}><Icon name="speaker"/><span>{t("speaker")}</span></button></div></div>;
}
const NAV_ITEMS: { tab: Tab; label: TextKey; icon: IconName }[] = [{ tab: "chats", label: "chats", icon: "chat" }, { tab: "status", label: "status", icon: "status" }, { tab: "calls", label: "calls", icon: "phone" }, { tab: "settings", label: "settings", icon: "settings" }];

export function App() {
  const [tab, setTab] = useState<Tab>("chats"); const [selectedId, setSelectedId] = useState<string | null>(null); const [newOpen, setNewOpen] = useState(false); const [profileOpen, setProfileOpen] = useState(false); const [statusOpen, setStatusOpen] = useState(false); const [viewer, setViewer] = useState<{ slides: ViewerSlide[]; index: number } | null>(null); const [callTarget, setCallTarget] = useState<CallTarget | null>(null); const [infoOpen, setInfoOpen] = useState(false);
  const [groupOpen, setGroupOpen] = useState(false);
  const [updateInfo, setUpdateInfo] = useState<UpdateInfo | null>(null);
  // One silent update check per launch: resolves to a newer release's info
  // or null (up to date / offline / any failure) and never blocks the app.
  useEffect(() => {
    let cancelled = false;
    void checkForUpdate().then((info) => { if (!cancelled && info) setUpdateInfo(info); });
    return () => { cancelled = true; };
  }, []);
  const [folder, setFolder] = useState<ChatFolder>("main");
  const [appUnlocked, setAppUnlocked] = useState(false);
  const [unlockedThreads, setUnlockedThreads] = useState<ReadonlySet<string>>(new Set());
  const [verifyRequest, setVerifyRequest] = useState<{ purpose: "open-chat" | "open-folder" | "unlock-chat"; conversation?: FirebaseConversation } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<FirebaseConversation | null>(null);
  const [lockSetupFor, setLockSetupFor] = useState<FirebaseConversation | null>(null);
  const [firebaseConversations, setFirebaseConversations] = useState<FirebaseConversation[]>([]);
  const [firebaseGroups, setFirebaseGroups] = useState<FirebaseConversation[]>([]);
  const [firebaseStatuses, setFirebaseStatuses] = useState<FirebaseStatus[]>([]);
  const [ownPhoto, setOwnPhoto] = useState<string | null>(null);
  const [avatarVersion, setAvatarVersion] = useState(0);
  const queryClient = useQueryClient(); const [cachedAppState] = useState<AppState | null>(() => readCachedAppState()); const appState = useQuery({ queryKey: ["app-state"], queryFn: () => backend.getAppState(), initialData: cachedAppState ?? undefined, staleTime: 60_000 });
  const profile = appState.data?.profile ?? null;
  useEffect(() => { if (appState.data) writeCachedAppState(appState.data); }, [appState.data]);
  const avatarUrl = profile?.avatar_url ?? null;
  useEffect(() => {
    if (!avatarUrl) { setOwnPhoto(null); return; }
    // Local mode stores the profile photo as a data URL — it already is the
    // renderable image, no fetch round-trip needed.
    if (avatarUrl.startsWith("data:")) { setOwnPhoto(avatarUrl); return; }
    let cancelled = false;
    void fetch(avatarUrl).then((response) => (response.ok ? response.blob() : Promise.reject(new Error("avatar")))).then((blob) => new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = () => reject(new Error("avatar")); reader.readAsDataURL(blob); })).then((dataUrl) => { if (!cancelled) setOwnPhoto(dataUrl); }).catch(() => undefined);
    return () => { cancelled = true; };
  }, [avatarUrl, avatarVersion]);
  const currentUser = useMemo<FirebaseContact | null>(() => profile ? { id: profile.email.trim().toLocaleLowerCase(), name: profile.display_name, email: profile.email.trim().toLocaleLowerCase(), username: profile.username || null, mobile: profile.mobile_number, photo: ownPhoto } : null, [profile?.email, profile?.display_name, profile?.username, profile?.mobile_number, ownPhoto]);
  const localConversationKey = appState.data?.conversations.map((item) => `${item.target_user_id}:${item.updated_at}`).join("|") ?? "";

  useEffect(() => {
    if (!profile || !currentUser) { setFirebaseConversations([]); return; }
    let cancelled = false;
    void ensureFirebaseProfile({ id: currentUser.id, name: currentUser.name, email: currentUser.email ?? currentUser.id, username: currentUser.username ?? "", mobile: currentUser.mobile, photo: currentUser.photo });
    for (const conversation of appState.data?.conversations ?? []) {
      const ensureKey = `${currentUser.id}:${conversation.target_user_id}`;
      if (ensuredConversationKeys.has(ensureKey)) continue;
      ensuredConversationKeys.add(ensureKey);
      void ensureFirebaseConversation({ current: currentUser, target: { id: conversation.target_user_id, name: conversation.contact_name, email: conversation.contact_email, username: conversation.contact_username, mobile: null, photo: conversation.contact_photo_url } }).catch(() => ensuredConversationKeys.delete(ensureKey));
    }
    const unsubscribe = listenToFirebaseConversations(currentUser.id, (items) => { if (!cancelled) setFirebaseConversations(items); }, () => { if (!cancelled) setFirebaseConversations([]); });
    return () => { cancelled = true; unsubscribe(); };
  }, [profile, currentUser, localConversationKey]);

  useEffect(() => {
    if (!profile || !currentUser) { setFirebaseStatuses([]); return; }
    let cancelled = false;
    const unsubscribe = listenToFirebaseStatuses(currentUser.id, (items) => { if (!cancelled) setFirebaseStatuses(items); }, () => { if (!cancelled) setFirebaseStatuses([]); });
    return () => { cancelled = true; unsubscribe(); };
  }, [profile, currentUser]);

  useEffect(() => {
    if (!profile || !currentUser) { setFirebaseGroups([]); return; }
    let cancelled = false;
    const unsubscribe = listenToFirebaseGroups(currentUser.id, (items) => { if (!cancelled) setFirebaseGroups(items); }, () => { if (!cancelled) setFirebaseGroups([]); });
    return () => { cancelled = true; unsubscribe(); };
  }, [profile, currentUser]);

  useEffect(() => {
    if (!currentUser) return;
    const userId = currentUser.id;
    void touchFirebasePresence(userId).catch(() => undefined);
    const timer = window.setInterval(() => { void touchFirebasePresence(userId).catch(() => undefined); }, 45_000);
    const onVisibility = () => { if (document.visibilityState === "visible") void touchFirebasePresence(userId).catch(() => undefined); };
    document.addEventListener("visibilitychange", onVisibility);
    return () => { window.clearInterval(timer); document.removeEventListener("visibilitychange", onVisibility); void markFirebaseOffline(userId).catch(() => undefined); };
  }, [currentUser]);

  const localPhotoKey = appState.data?.conversations.map((item) => `${item.target_user_id}:${item.contact_photo_url ?? ""}`).join("|") ?? "";
  const firebasePhotoKey = firebaseConversations.map((item) => `${item.target_user_id}:${item.contact_photo ?? ""}`).join("|");
  useEffect(() => {
    if (!profile) return;
    const localPhotos = new Map((appState.data?.conversations ?? []).map((item) => [item.target_user_id.toLocaleLowerCase(), item.contact_photo_url]));
    const changed = firebaseConversations.filter((item) => (localPhotos.get(item.target_user_id.toLocaleLowerCase()) ?? null) !== item.contact_photo).map((item) => ({ target_user_id: item.target_user_id, contact_photo_url: item.contact_photo }));
    if (changed.length > 0) void backend.cacheConversationPhotos({ items: changed }).catch(() => undefined);
  }, [profile, localPhotoKey, firebasePhotoKey]);

  const startCall = useMutation({ mutationFn: (target: CallTarget) => backend.startCall({ contact_name: target.name, contact_email: target.email, call_type: target.type }), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });
  const beginCall = (target: CallTarget) => { setCallTarget(target); startCall.mutate(target); };
  const saveOrg = useMutation({ mutationFn: (next: { archived_thread_ids: string[]; locked_thread_ids: string[]; muted_thread_ids: string[]; deleted_thread_ids: string[]; thread_wallpapers: Record<string, string> }) => backend.saveChatOrganization(next), onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });
  const orgBase = () => { const p = appState.data?.profile; return { archived_thread_ids: p?.archived_thread_ids ?? [], locked_thread_ids: p?.locked_thread_ids ?? [], muted_thread_ids: p?.muted_thread_ids ?? [], deleted_thread_ids: p?.deleted_thread_ids ?? [], thread_wallpapers: p?.thread_wallpapers ?? {} }; };
  const toggleOrgList = (key: "archived_thread_ids" | "locked_thread_ids" | "muted_thread_ids", id: string, force?: boolean) => { const base = orgBase(); const list = base[key]; const has = list.includes(id); const next = force === undefined ? (has ? list.filter((item) => item !== id) : [...list, id]) : force ? (has ? list : [...list, id]) : list.filter((item) => item !== id); saveOrg.mutate({ ...base, [key]: next }); };
  const blockToggle = useMutation({ mutationFn: async (input: { conversation: FirebaseConversation; blocked: boolean }) => { if (input.blocked) await backend.unblockContact({ target_user_id: input.conversation.target_user_id }); else await backend.blockContact({ target_user_id: input.conversation.target_user_id, contact_name: input.conversation.contact_name, contact_email: input.conversation.contact_email, contact_username: input.conversation.contact_username }); }, onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-state"] }) });
  if (appState.isPending) return <main className="full-state" dir="rtl"><div className="pulse-mark"><Icon name="chat"/></div><p>{UI_TEXT.ur.loadingApp}</p></main>;
  if (appState.isError) return <main className="full-state" dir="rtl"><h1>{UI_TEXT.ur.appError}</h1><p>{UI_TEXT.ur.tryAgain}</p><button className="primary-button narrow" onClick={() => appState.refetch()}>{UI_TEXT.ur.reopen}</button></main>;
  if (!profile || !currentUser) return <ProfileSetup/>;
  const { statuses, calls } = appState.data;
  const conversationsById = new Map<string, FirebaseConversation>();
  for (const item of firebaseConversations) conversationsById.set(item.id, item);
  for (const item of firebaseGroups) conversationsById.set(item.id, item);
  for (const item of appState.data.conversations) {
    const id = firebaseThreadId(currentUser.id, item.target_user_id);
    if (!conversationsById.has(id)) conversationsById.set(id, { id, contact_name: item.contact_name, contact_email: item.contact_email, contact_username: item.contact_username, contact_mobile: null, contact_photo: item.contact_photo_url, target_user_id: item.target_user_id, last_message: item.last_message, last_message_type: item.last_message_type, last_sender_id: item.last_sender_id, unread_count: item.unread_count, updated_at: item.updated_at });
  }
  const allConversations = [...conversationsById.values()].sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
  const archivedSet = new Set(profile.archived_thread_ids);
  const lockedSet = new Set(profile.locked_thread_ids);
  const mutedSet = new Set(profile.muted_thread_ids);
  const deletedSet = new Set(profile.deleted_thread_ids);
  const conversations = allConversations.filter((item) => !deletedSet.has(item.id) && !archivedSet.has(item.id) && !lockedSet.has(item.id));
  const archivedList = allConversations.filter((item) => !deletedSet.has(item.id) && archivedSet.has(item.id));
  const lockedList = allConversations.filter((item) => !deletedSet.has(item.id) && lockedSet.has(item.id));
  const visibleConversations = allConversations.filter((item) => !deletedSet.has(item.id));
  const text = UI_TEXT[profile.language]; const direction = RTL_LANGUAGES.includes(profile.language) ? "rtl" : "ltr"; const selectedConversation = selectedId === null ? null : allConversations.find((conversation) => conversation.id === selectedId) ?? null;
  const lockConfigured = profile.app_lock_method !== "none" && (Boolean(profile.app_lock_hash) || profile.app_lock_method === "biometric");
  const handleSelectConversation = (conversation: FirebaseConversation) => {
    if (lockedSet.has(conversation.id) && !unlockedThreads.has(conversation.id)) { setVerifyRequest({ purpose: "open-chat", conversation }); return; }
    setSelectedId(conversation.id);
  };
  const handleFolderChange = (next: ChatFolder) => {
    if (next === "locked" && lockedList.length > 0 && !lockedList.every((item) => unlockedThreads.has(item.id))) { setVerifyRequest({ purpose: "open-folder" }); return; }
    setFolder(next);
  };
  const requestLockToggle = (conversation: FirebaseConversation) => {
    if (lockedSet.has(conversation.id)) {
      if (lockConfigured) { setVerifyRequest({ purpose: "unlock-chat", conversation }); return; }
      toggleOrgList("locked_thread_ids", conversation.id, false);
      return;
    }
    if (!lockConfigured) { setLockSetupFor(conversation); return; }
    toggleOrgList("locked_thread_ids", conversation.id, true);
  };
  const handleRowAction = (conversation: FirebaseConversation, action: ChatRowAction) => {
    if (action === "archive") toggleOrgList("archived_thread_ids", conversation.id);
    else if (action === "mute") toggleOrgList("muted_thread_ids", conversation.id);
    else if (action === "lock") requestLockToggle(conversation);
    else if (action === "delete") setDeleteTarget(conversation);
  };
  const handleVerifySuccess = () => {
    const request = verifyRequest;
    setVerifyRequest(null);
    if (!request) return;
    if (request.purpose === "open-chat" && request.conversation) { setUnlockedThreads((items) => new Set(items).add(request.conversation?.id ?? "")); setSelectedId(request.conversation.id); }
    if (request.purpose === "open-folder") { setUnlockedThreads((items) => { const next = new Set(items); lockedList.forEach((item) => next.add(item.id)); return next; }); setFolder("locked"); }
    if (request.purpose === "unlock-chat" && request.conversation) toggleOrgList("locked_thread_ids", request.conversation.id, false);
  };
  const executeDelete = (conversation: FirebaseConversation) => {
    if (!conversation.is_group) void backend.deleteConversation({ target_user_id: conversation.target_user_id }).catch(() => undefined);
    const base = orgBase();
    saveOrg.mutate({ archived_thread_ids: base.archived_thread_ids.filter((item) => item !== conversation.id), locked_thread_ids: base.locked_thread_ids.filter((item) => item !== conversation.id), muted_thread_ids: base.muted_thread_ids.filter((item) => item !== conversation.id), deleted_thread_ids: [...base.deleted_thread_ids, conversation.id], thread_wallpapers: base.thread_wallpapers });
    setDeleteTarget(null); setInfoOpen(false);
    if (selectedId === conversation.id) setSelectedId(null);
  };
  const pickChatWallpaper = (conversation: FirebaseConversation, wallpaper: Wallpaper) => { const base = orgBase(); saveOrg.mutate({ ...base, thread_wallpapers: { ...base.thread_wallpapers, [conversation.id]: wallpaper } }); };
  const effectiveWallpaper = (conversation: FirebaseConversation): Wallpaper => { const value = profile.thread_wallpapers[conversation.id]; return value && (WALLPAPER_VALUES as string[]).includes(value) ? value as Wallpaper : profile.wallpaper; };
  const selectedMenu: ChatMenuActions | null = selectedConversation ? { archived: archivedSet.has(selectedConversation.id), locked: lockedSet.has(selectedConversation.id), muted: mutedSet.has(selectedConversation.id), onToggleArchive: () => handleRowAction(selectedConversation, "archive"), onToggleLock: () => requestLockToggle(selectedConversation), onToggleMute: () => handleRowAction(selectedConversation, "mute"), onDeleteChat: () => setDeleteTarget(selectedConversation) } : null;
  const selectedBlocked = selectedConversation ? appState.data.blocked_contacts.some((item) => item.target_user_id.toLocaleLowerCase() === selectedConversation.target_user_id.toLocaleLowerCase()) : false;
  if (profile.app_lock_enabled && profile.app_lock_method !== "none" && !appUnlocked) {
    return <LocaleContext.Provider value={profile.language}><main className="lock-screen" dir={direction}><div className="lock-card"><BrandWordmark/><LockVerify method={profile.app_lock_method} secretHash={profile.app_lock_hash} secretSalt={profile.app_lock_salt} title={text.appLock ?? UR_TEXT.appLock} onSuccess={() => setAppUnlocked(true)}/></div></main></LocaleContext.Provider>;
  }
  return <LocaleContext.Provider value={profile.language}><main className={`app-shell language-${profile.language}`} data-theme={profile.theme_mode} dir={direction}><nav className="app-nav" aria-label={text.navigation}>{NAV_ITEMS.map((item) => <button key={item.tab} className={tab === item.tab ? "active" : ""} onClick={() => { setTab(item.tab); setSelectedId(null); setFolder("main"); }} aria-current={tab === item.tab ? "page" : undefined}><Icon name={item.icon}/><span>{text[item.label]}</span></button>)}</nav><div className="app-content">{tab === "chats" && <div className="chat-layout"><ChatsScreen conversations={conversations} archivedList={archivedList} lockedList={lockedList} folder={folder} onFolderChange={handleFolderChange} selectedId={selectedId} currentUserId={profile.email} onSelect={handleSelectConversation} onNew={() => setNewOpen(true)} onRowAction={handleRowAction} archivedIds={archivedSet} lockedIds={lockedSet} mutedIds={mutedSet}/>{selectedConversation ? <ChatRoom currentUser={currentUser} targetUserId={selectedConversation.target_user_id} contactName={selectedConversation.contact_name} contactEmail={selectedConversation.contact_email} contactUsername={selectedConversation.contact_username} contactPhoto={selectedConversation.contact_photo} onBack={() => setSelectedId(null)} onCall={beginCall} onContactInfo={() => setInfoOpen(true)} wallpaper={effectiveWallpaper(selectedConversation)} tone={profile.message_tone} tonesEnabled={profile.conversation_tones_enabled} voiceEffect={profile.default_voice_effect} blocked={selectedBlocked} autoDownloadPhotos={profile.auto_download_photos} autoDownloadVoice={profile.auto_download_voice} group={selectedConversation.is_group ? { id: selectedConversation.group_id ?? selectedConversation.target_user_id, members: selectedConversation.group_members ?? [] } : null} chatMenu={selectedMenu}/> : <section className="desktop-idle"><div className="idle-symbol"><Icon name="chat" size={36}/></div><h2>{text.openAChat}</h2><p>{text.openAChatHint}</p></section>}</div>}{tab === "status" && <StatusScreen profile={profile} ownPhoto={ownPhoto} statuses={statuses} contactStatuses={firebaseStatuses} onNew={() => setStatusOpen(true)} onViewOwn={() => setViewer({ slides: [...statuses].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()).map((status) => ownStatusSlide(status, profile, ownPhoto)), index: 0 })} onViewContact={(authorId) => { const slides = firebaseStatuses.filter((item) => item.author_id === authorId).sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()).map(contactStatusSlide); if (slides.length > 0) setViewer({ slides, index: 0 }); }}/>} {tab === "calls" && <CallsScreen conversations={visibleConversations} calls={calls} onCall={beginCall}/>} {tab === "settings" && <SettingsScreen profile={profile} ownPhoto={ownPhoto} onEdit={() => setProfileOpen(true)} conversations={visibleConversations} currentUserId={currentUser.id} blockedContacts={appState.data.blocked_contacts} chatLists={appState.data.chat_lists} onLockNow={() => setAppUnlocked(false)}/>}</div>{newOpen && <NewConversationSheet currentUser={currentUser} onClose={() => setNewOpen(false)} onCreated={(id) => { setNewOpen(false); setSelectedId(id); }} onNewGroup={() => { setNewOpen(false); setGroupOpen(true); }}/>} {groupOpen && <GroupCreateSheet currentUser={currentUser} contacts={visibleConversations} onClose={() => setGroupOpen(false)} onCreated={(id) => { setGroupOpen(false); setTab("chats"); setFolder("main"); setSelectedId(id); }}/>} {profileOpen && <EditProfileSheet key={avatarUrl ?? "none"} profile={profile} initialPhoto={ownPhoto} onClose={() => { setProfileOpen(false); setAvatarVersion((value) => value + 1); }}/>} {infoOpen && selectedConversation && <ContactInfoScreen conversation={selectedConversation} currentUser={currentUser} contacts={visibleConversations} blocked={selectedBlocked} muted={mutedSet.has(selectedConversation.id)} archived={archivedSet.has(selectedConversation.id)} locked={lockedSet.has(selectedConversation.id)} wallpaper={effectiveWallpaper(selectedConversation)} onPickWallpaper={(wallpaper) => pickChatWallpaper(selectedConversation, wallpaper)} onClose={() => setInfoOpen(false)} onCall={(target) => { setInfoOpen(false); beginCall(target); }} onToggleBlock={() => blockToggle.mutate({ conversation: selectedConversation, blocked: selectedBlocked })} onToggleMute={() => handleRowAction(selectedConversation, "mute")} onToggleArchive={() => handleRowAction(selectedConversation, "archive")} onToggleLock={() => requestLockToggle(selectedConversation)} onDeleteChat={() => executeDelete(selectedConversation)}/>} {statusOpen && <StatusSheet currentUser={currentUser} onClose={() => setStatusOpen(false)}/>} {viewer && <StatusViewer slides={viewer.slides} startIndex={viewer.index} onClose={() => setViewer(null)}/>} {callTarget && <CallOverlay target={callTarget} onEnd={() => setCallTarget(null)}/>} {verifyRequest && <SheetFrame title={text.lockedChats ?? UR_TEXT.lockedChats} eyebrow={text.unlockToView ?? UR_TEXT.unlockToView} onClose={() => setVerifyRequest(null)} compact>{lockConfigured ? <LockVerify method={profile.app_lock_method} secretHash={profile.app_lock_hash} secretSalt={profile.app_lock_salt} title={text.lockChat ?? UR_TEXT.lockChat} onSuccess={handleVerifySuccess}/> : <div className="lock-verify"><p className="help-body">{text.unlockToView}</p><button type="button" className="primary-button" onClick={handleVerifySuccess}>{text.unlockApp}</button></div>}</SheetFrame>} {deleteTarget && <SheetFrame title={text.deleteChat ?? UR_TEXT.deleteChat} onClose={() => setDeleteTarget(null)} compact><p className="help-body">{text.deleteChatConfirm}</p><div className="sheet-actions"><button type="button" className="text-button" onClick={() => setDeleteTarget(null)}>{text.cancel}</button><button type="button" className="primary-button danger-button" onClick={() => executeDelete(deleteTarget)}><Icon name="trash" size={17}/> {text.deleteChat}</button></div></SheetFrame>} {lockSetupFor && <LockSetupSheet email={profile.email} appLockEnabled={profile.app_lock_enabled} onClose={() => setLockSetupFor(null)} onSaved={() => { const target = lockSetupFor; setLockSetupFor(null); if (target) toggleOrgList("locked_thread_ids", target.id, true); }}/>} {updateInfo && <SheetFrame title="نیا ورژن دستیاب ہے!" eyebrow="Bolo Chat" onClose={() => setUpdateInfo(null)} compact><p className="help-body">Bolo Chat کا نیا ورژن <strong dir="ltr">v{updateInfo.version}</strong> آ گیا ہے۔ نیا ورژن ڈاؤن لوڈ کر کے انسٹال کریں تاکہ تازہ خصوصیات اور بہتریاں مل سکیں۔</p>{updateInfo.notes && <p className="help-body update-notes">{updateInfo.notes}</p>}<div className="sheet-actions">{updateInfo.downloadUrl && <button type="button" className="primary-button update-download" onClick={() => { const url = updateInfo.downloadUrl; if (url) void openExternalUrl(url); }}>ڈاؤن لوڈ کریں</button>}<button type="button" className="text-button" onClick={() => setUpdateInfo(null)}>بعد میں</button></div></SheetFrame>}</main></LocaleContext.Provider>;
}
