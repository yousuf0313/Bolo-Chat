import { Capacitor } from "@capacitor/core";
import { NativeBiometric } from "@capgo/capacitor-native-biometric";

/* Native biometric bridge (Capacitor).
 *
 * Inside the Android/iOS APK the app runs in a WebView, where the web
 * WebAuthn API cannot reach the phone's fingerprint/face sensor. When the
 * app runs on a native Capacitor platform we therefore use the device's
 * native biometric prompt (Android BiometricPrompt / iOS Face ID/Touch ID)
 * through the @capgo/capacitor-native-biometric plugin. On the hosted web
 * version none of these helpers engage and the existing WebAuthn flow in
 * App.tsx is used instead. */

export function isNativeApp(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/** True when the device has a fingerprint/face sensor with biometrics enrolled. */
export async function nativeBiometricAvailable(): Promise<boolean> {
  if (!isNativeApp()) return false;
  try {
    const result = await NativeBiometric.isAvailable({ useFallback: false });
    return result.isAvailable;
  } catch {
    return false;
  }
}

/**
 * Show the native biometric prompt. Resolves true only when the user
 * successfully authenticates with fingerprint/face; any failure, dismissal
 * or unavailability resolves false so callers can fall back to PIN/password.
 */
export async function nativeVerifyBiometric(title: string, description: string): Promise<boolean> {
  if (!isNativeApp()) return false;
  try {
    await NativeBiometric.verifyIdentity({
      title,
      description,
      useFallback: false,
    });
    return true;
  } catch {
    return false;
  }
}

/**
 * Enrollment proof used when the user turns the biometric lock on: the
 * sensor must exist and the user must pass one native prompt, so enabling
 * the lock can never succeed on a device where unlock would later fail.
 */
export async function nativeEnrollBiometric(title: string, description: string): Promise<boolean> {
  if (!(await nativeBiometricAvailable())) return false;
  return nativeVerifyBiometric(title, description);
}
