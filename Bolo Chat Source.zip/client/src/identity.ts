/* "Is this the same person?" — one identity matcher for the whole app.
 *
 * A Easy Chat user can be referenced by several identifier forms:
 *   - their account id, which is their lower-cased email;
 *   - an "@username" id (manual contacts and older data);
 *   - a "mobile:<digits>" id (contacts added by phone number only);
 *   - a "local:<name>" id (name-only manual contacts, never synced);
 *   - plus the email / username / mobile fields stored next to the id.
 *
 * The old self-chat checks compared only the raw id against the email,
 * so a chat the user had created with themself through a username,
 * mobile or name-only contact (the leftover voice-test chat) never
 * matched, was never purged and kept rendering forever. Every self-chat
 * check — creation guards, list filters and the purge — goes through
 * this matcher instead, so all identifier forms are covered. */

export type PersonIdentifiers = {
  id?: string | null;
  email?: string | null;
  username?: string | null;
  mobile?: string | null;
  name?: string | null;
};

function norm(value: string | null | undefined): string {
  return (value ?? "").trim().toLocaleLowerCase();
}

function mobileDigits(value: string | null | undefined): string {
  return (value ?? "").replace(/[^0-9]/g, "");
}

/** Strong identifier keys for one side: account ids, emails, usernames
 *  and mobile numbers. A "local:<name>" id deliberately contributes no
 *  key here — a bare name is not a strong identifier (two different
 *  people can share one) and is handled separately in isSamePerson. */
function identifierKeys(person: PersonIdentifiers): Set<string> {
  const keys = new Set<string>();
  const rawId = norm(person.id);
  if (rawId.startsWith("@")) {
    keys.add(`username:${rawId.slice(1)}`);
  } else if (rawId.startsWith("mobile:")) {
    const digits = mobileDigits(rawId.slice("mobile:".length));
    if (digits.length >= 7) keys.add(`mobile:${digits}`);
  } else if (rawId.startsWith("local:")) {
    /* name-only fallback id — no strong key */
  } else if (rawId) {
    keys.add(`id:${rawId}`);
    if (rawId.includes("@")) keys.add(`email:${rawId}`);
  }
  const email = norm(person.email);
  if (email) {
    keys.add(`email:${email}`);
    keys.add(`id:${email}`);
  }
  const username = norm(person.username).replace(/^@+/, "");
  if (username) keys.add(`username:${username}`);
  const digits = mobileDigits(person.mobile);
  if (digits.length >= 7) keys.add(`mobile:${digits}`);
  return keys;
}

/** The name embedded in a "local:<name>" fallback id, or null. */
function localFallbackName(person: PersonIdentifiers): string | null {
  const rawId = norm(person.id);
  return rawId.startsWith("local:") ? rawId.slice("local:".length) : null;
}

/** True when both identifier sets describe the same person, in any of
 *  the identifier forms the app has ever used. */
export function isSamePerson(a: PersonIdentifiers, b: PersonIdentifiers): boolean {
  const aKeys = identifierKeys(a);
  const bKeys = identifierKeys(b);
  for (const key of aKeys) if (bKeys.has(key)) return true;
  // A name-only "local:<name>" contact matches the side whose display
  // name it carries — that is exactly how the leftover self-test chat
  // was created (the user added themself by name before their profile
  // could be found). Only the side carrying the local: id contributes
  // the name, so two real people who merely share a name never match.
  const aLocal = localFallbackName(a);
  if (aLocal && norm(b.name) && aLocal === norm(b.name)) return true;
  const bLocal = localFallbackName(b);
  if (bLocal && norm(a.name) && bLocal === norm(a.name)) return true;
  return false;
}
