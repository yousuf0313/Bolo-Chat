import { getApp, getApps, initializeApp } from "firebase/app";
import {
Timestamp,
collection,
deleteDoc,
doc,
increment,
getDoc,
getDocs,
getFirestore,
onSnapshot,
orderBy,
query,
setDoc,
updateDoc,
where,
writeBatch,
type DocumentData,
type Firestore,
type UpdateData,
type QueryDocumentSnapshot,
type Unsubscribe,
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBYLf2pXzjyefhk2mC-Q71G6SFgheC6d2E",
  authDomain: "rabta-24267.firebaseapp.com",
  projectId: "rabta-24267",
  storageBucket: "rabta-24267.firebasestorage.app",
  messagingSenderId: "635724835065",
  appId: "1:635724835065:web:5fce3c5279bd1438fb1a28",
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const db = getFirestore(app);

export type FirebaseDeliveryStatus = "sent" | "delivered" | "read";
export type FirebaseMessageType = "text" | "audio" | "image";
export type FirebaseVoiceEffect = "original" | "soft" | "deep" | "bright" | "quick" | "slow" | "chipmunk" | "helium" | "robot" | "monster" | "echo" | "cave";
const FIREBASE_VOICE_EFFECTS: FirebaseVoiceEffect[] = ["original", "soft", "deep", "bright", "quick", "slow", "chipmunk", "helium", "robot", "monster", "echo", "cave"];

export type FirebaseContact = {
  id: string;
  name: string;
  email: string | null;
  username: string | null;
  mobile: string | null;
  photo: string | null;
};

export type FirebaseConversation = {
  id: string;
  contact_name: string;
  contact_email: string | null;
  contact_username: string | null;
  contact_mobile: string | null;
  contact_photo: string | null;
  target_user_id: string;
  last_message: string | null;
  last_message_type: FirebaseMessageType | null;
  last_sender_id: string | null;
  unread_count: number;
  updated_at: string;
  is_group?: boolean;
  group_id?: string;
  group_description?: string;
  group_members?: FirebaseContact[];
  group_admins?: string[];
  group_created_by?: string;
};

export type FirebaseMessage = {
  id: string;
  body: string;
  direction: "self" | "contact";
  sender_id: string;
  receiver_id: string;
  message_type: FirebaseMessageType;
  audio_url: string | null;
  image_url: string | null;
  delivery_status: FirebaseDeliveryStatus;
  audio_duration: number | null;
  voice_effect: FirebaseVoiceEffect;
  unlock_at: string | null;
  password_hash: string | null;
  password_salt: string | null;
  expires_at: string | null;
  created_at: string;
  sender_name?: string | null;
  sender_photo?: string | null;
};

export type FirebaseMessageInput = {
  id?: string;
  threadId: string;
  senderId: string;
  receiverId: string;
  body: string;
  type: FirebaseMessageType;
  dataUrl?: string;
  audioDuration?: number;
  voiceEffect?: FirebaseVoiceEffect;
  unlockAt?: number | null;
  passwordHash?: string | null;
  passwordSalt?: string | null;
  ttlSeconds?: number | null;
  createdAt?: number;
};

function normalizeId(value: string) {
  return value.trim().toLocaleLowerCase();
}

function safeDocPart(value: string) {
  return encodeURIComponent(normalizeId(value));
}

export function firebaseThreadId(firstUserId: string, secondUserId: string) {
  return [normalizeId(firstUserId), normalizeId(secondUserId)].sort((a, b) => a.localeCompare(b)).map(safeDocPart).join("--");
}

function dateIso(value: unknown) {
  if (value instanceof Timestamp) return value.toDate().toISOString();
  if (typeof value === "number") return new Date(value).toISOString();
  return new Date().toISOString();
}

function parseContact(value: unknown): FirebaseContact | null {
  if (!value || typeof value !== "object") return null;
  const item = value as Record<string, unknown>;
  if (typeof item.id !== "string" || typeof item.name !== "string") return null;
  return {
    id: normalizeId(item.id),
    name: item.name,
    email: typeof item.email === "string" ? item.email : null,
    username: typeof item.username === "string" ? item.username : null,
    mobile: typeof item.mobile === "string" && item.mobile ? item.mobile : null,
    photo: typeof item.photo === "string" && item.photo.startsWith("data:image/") ? item.photo : null,
  };
}

export async function ensureFirebaseProfile(profile: { id: string; name: string; email: string; username: string; mobile?: string | null; photo?: string | null }) {
  const id = normalizeId(profile.id);
  const username = profile.username.trim();
  await setDoc(doc(db, "profiles", safeDocPart(id)), {
    id,
    name: profile.name,
    email: profile.email.trim().toLocaleLowerCase(),
    username,
    usernameLower: username.toLocaleLowerCase(),
    mobile: profile.mobile ?? null,
    mobileDigits: profile.mobile ? profile.mobile.replace(/[^0-9]/g, "") : null,
    photo: profile.photo ?? null,
    updatedAt: Timestamp.now(),
  }, { merge: true });
}

export async function fetchFirebaseProfileByEmail(email: string): Promise<FirebaseContact | null> {
  const normalizedEmail = normalizeId(email);
  if (!normalizedEmail) return null;
  const candidateIds = [...new Set([safeDocPart(normalizedEmail), normalizedEmail])];
  for (const candidateId of candidateIds) {
    const snapshot = await getDoc(doc(db, "profiles", candidateId));
    if (snapshot.exists()) {
      const found = parseContact(snapshot.data());
      if (found) return found;
    }
  }
  return null;
}

export async function searchFirebaseProfilesByUsername(term: string): Promise<FirebaseContact[]> {
  const wanted = normalizeId(term).replace(/^@+/, "");
  if (wanted.length < 2) return [];
  const matches = new Map<string, FirebaseContact>();
  const addMatches = (docs: QueryDocumentSnapshot<DocumentData>[]) => {
    for (const item of docs) {
      const found = parseContact(item.data());
      if (found?.username && found.username.toLocaleLowerCase().startsWith(wanted)) matches.set(found.id, found);
    }
  };
  // New profiles carry a lowercase `usernameLower` search field so the
  // display username can keep its capital letters while search stays
  // case-insensitive; older profiles only have the lowercase `username`.
  for (const field of ["usernameLower", "username"] as const) {
    const prefix = await getDocs(query(collection(db, "profiles"), where(field, ">=", wanted), where(field, "<=", `${wanted}\uf8ff`)));
    addMatches(prefix.docs);
    const exact = await getDocs(query(collection(db, "profiles"), where(field, "==", wanted)));
    addMatches(exact.docs);
  }
  if (matches.size === 0) {
    // Last resort for any legacy document whose stored username kept mixed
    // case without a lowercase search field: compare case-insensitively
    // on the client so the user is still found.
    const all = await getDocs(collection(db, "profiles"));
    addMatches(all.docs);
  }
  return [...matches.values()].sort((a, b) => (a.username ?? "").localeCompare(b.username ?? "", undefined, { sensitivity: "base" })).slice(0, 20);
}

export async function lookupFirebaseProfile(identifier: string): Promise<FirebaseContact | null> {
  const id = normalizeId(identifier);
  if (!id) return null;
  const direct = await getDoc(doc(db, "profiles", safeDocPart(id)));
  if (direct.exists()) {
    const found = parseContact(direct.data());
    if (found) return found;
  }
  const wanted = id.startsWith("@") ? id.slice(1) : id;
  for (const field of ["usernameLower", "username"] as const) {
    const byUsername = await getDocs(query(collection(db, "profiles"), where(field, "==", wanted)));
    for (const item of byUsername.docs) {
      const found = parseContact(item.data());
      if (found?.username && found.username.toLocaleLowerCase() === wanted) return found;
    }
  }
  if (id.startsWith("@") || /[a-z]/i.test(wanted)) {
    const all = await getDocs(collection(db, "profiles"));
    for (const item of all.docs) {
      const found = parseContact(item.data());
      if (found?.username && found.username.toLocaleLowerCase() === wanted) return found;
    }
  }
  const digits = id.replace(/[^0-9]/g, "");
  if (digits.length >= 7) {
    const byMobile = await getDocs(query(collection(db, "profiles"), where("mobileDigits", "==", digits)));
    for (const item of byMobile.docs) {
      const found = parseContact(item.data());
      if (found) return found;
    }
  }
  return null;
}

export async function ensureFirebaseConversation(input: {
  current: FirebaseContact;
  target: FirebaseContact;
}) {
  const current = { ...input.current, id: normalizeId(input.current.id) };
  const target = { ...input.target, id: normalizeId(input.target.id) };
  const id = firebaseThreadId(current.id, target.id);
  await setDoc(doc(db, "conversations", id), {
    id,
    participants: [current.id, target.id].sort((a, b) => a.localeCompare(b)),
    participantProfiles: [current, target],
    updatedAt: Timestamp.now(),
  }, { merge: true });
  return id;
}

export function listenToFirebaseConversations(
  currentUserId: string,
  onData: (items: FirebaseConversation[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  const conversationsQuery = query(collection(db, "conversations"), where("participants", "array-contains", current));
  return onSnapshot(conversationsQuery, (snapshot) => {
    const items = snapshot.docs.map((snapshotDoc) => {
      const data = snapshotDoc.data();
      const participants = Array.isArray(data.participants) ? data.participants.filter((value): value is string => typeof value === "string") : [];
      const targetId = participants.find((id) => normalizeId(id) !== current) ?? current;
      const profiles = Array.isArray(data.participantProfiles) ? data.participantProfiles.map(parseContact).filter((value): value is FirebaseContact => value !== null) : [];
      const target = profiles.find((profile) => profile.id !== current);
      const unreadBy = data.unreadBy && typeof data.unreadBy === "object" ? data.unreadBy as Record<string, unknown> : {};
      const unreadKey = safeDocPart(current);
      const messageType = data.lastMessageType === "text" || data.lastMessageType === "audio" || data.lastMessageType === "image" ? data.lastMessageType : null;
      return {
        id: snapshotDoc.id,
        contact_name: target?.name ?? targetId,
        contact_email: target?.email ?? (targetId.includes("@") && !targetId.startsWith("@") ? targetId : null),
        contact_username: target?.username ?? (targetId.startsWith("@") ? targetId.slice(1) : null),
        contact_mobile: target?.mobile ?? null,
        contact_photo: target?.photo ?? null,
        target_user_id: targetId,
        last_message: typeof data.lastMessage === "string" ? data.lastMessage : null,
        last_message_type: messageType,
        last_sender_id: typeof data.lastSenderId === "string" ? data.lastSenderId : null,
        unread_count: typeof unreadBy[unreadKey] === "number" ? unreadBy[unreadKey] : 0,
        updated_at: dateIso(data.updatedAt),
      } satisfies FirebaseConversation;
    }).sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
    onData(items);
  }, (error) => onError(error));
}

async function loadChunkedDataUrl(threadId: string, messageId: string, mimeType: string, root: "conversations" | "groups" = "conversations") {
  const chunksSnapshot = await getDocs(query(collection(db, root, threadId, "messages", messageId, "mediaChunks"), orderBy("index", "asc")));
  const base64 = chunksSnapshot.docs.map((item) => {
    const data = item.data();
    return typeof data.data === "string" ? data.data : "";
  }).join("");
  return base64 ? `data:${mimeType};base64,${base64}` : null;
}

async function mapMessage(snapshotDoc: QueryDocumentSnapshot<DocumentData>, threadId: string, currentUserId: string, root: "conversations" | "groups" = "conversations"): Promise<FirebaseMessage> {
  const data = snapshotDoc.data();
  const senderId = typeof data.senderId === "string" ? normalizeId(data.senderId) : "";
  const receiverId = typeof data.receiverId === "string" ? normalizeId(data.receiverId) : "";
  const type: FirebaseMessageType = data.type === "audio" || data.type === "image" ? data.type : "text";
  const mimeType = typeof data.mimeType === "string" ? data.mimeType : type === "audio" ? "audio/webm" : "image/jpeg";
  let dataUrl = typeof data.dataUrl === "string" ? data.dataUrl : null;
  if (!dataUrl && data.hasChunks === true) dataUrl = await loadChunkedDataUrl(threadId, snapshotDoc.id, mimeType, root);
  const deliveryStatus: FirebaseDeliveryStatus = data.status === "read" || data.status === "delivered" ? data.status : "sent";
  const effect: FirebaseVoiceEffect = typeof data.voiceEffect === "string" && (FIREBASE_VOICE_EFFECTS as string[]).includes(data.voiceEffect) ? data.voiceEffect as FirebaseVoiceEffect : "original";
  return {
    id: snapshotDoc.id,
    body: typeof data.body === "string" ? data.body : "",
    direction: senderId === normalizeId(currentUserId) ? "self" : "contact",
    sender_id: senderId,
    receiver_id: receiverId,
    message_type: type,
    audio_url: type === "audio" ? dataUrl : null,
    image_url: type === "image" ? dataUrl : null,
    delivery_status: deliveryStatus,
    audio_duration: typeof data.audioDuration === "number" ? data.audioDuration : null,
    voice_effect: effect,
    unlock_at: data.unlockAt instanceof Timestamp ? data.unlockAt.toDate().toISOString() : null,
    password_hash: typeof data.passwordHash === "string" ? data.passwordHash : null,
    password_salt: typeof data.passwordSalt === "string" ? data.passwordSalt : null,
    expires_at: data.expiresAt instanceof Timestamp ? data.expiresAt.toDate().toISOString() : null,
    created_at: dateIso(data.createdAt),
    sender_name: typeof data.senderName === "string" ? data.senderName : null,
    sender_photo: typeof data.senderPhoto === "string" && data.senderPhoto.startsWith("data:image/") ? data.senderPhoto : null,
  };
}

function isExpired(message: FirebaseMessage) {
  return message.expires_at !== null && new Date(message.expires_at).getTime() <= Date.now();
}

export function listenToFirebaseMessages(
  threadId: string,
  currentUserId: string,
  onData: (items: FirebaseMessage[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const messagesQuery = query(collection(db, "conversations", threadId, "messages"), orderBy("createdAt", "asc"));
  return onSnapshot(messagesQuery, (snapshot) => {
    void Promise.all(snapshot.docs.map((item) => mapMessage(item, threadId, currentUserId))).then((items) => onData(items.filter((item) => !isExpired(item)))).catch((error: unknown) => onError(error instanceof Error ? error : new Error("Could not load messages")));
    const toDeliver = snapshot.docs.filter((item) => {
      const data = item.data();
      return normalizeId(typeof data.receiverId === "string" ? data.receiverId : "") === normalizeId(currentUserId) && data.status === "sent";
    });
    if (toDeliver.length > 0) {
      const batch = writeBatch(db);
      toDeliver.forEach((item) => batch.update(item.ref, { status: "delivered", deliveredAt: Timestamp.now() }));
      void batch.commit();
    }
  }, (error) => onError(error));
}

export async function markFirebaseMessagesRead(threadId: string, currentUserId: string) {
  const current = normalizeId(currentUserId);
  const incoming = await getDocs(query(collection(db, "conversations", threadId, "messages"), where("receiverId", "==", current)));
  const unread = incoming.docs.filter((item) => item.data().status !== "read");
  const batch = writeBatch(db);
  unread.forEach((item) => batch.update(item.ref, { status: "read", readAt: Timestamp.now() }));
  const threadRef = doc(db, "conversations", threadId);
  batch.set(threadRef, { unreadBy: { [safeDocPart(current)]: 0 } }, { merge: true });
  await batch.commit();
}

function splitDataUrl(dataUrl: string) {
  const match = /^data:([^;]+);base64,(.*)$/.exec(dataUrl);
  if (!match) return null;
  const mimeType = match[1] ?? "application/octet-stream";
  const data = match[2] ?? "";
  return { mimeType, data };
}

export async function sendFirebaseMessage(input: FirebaseMessageInput) {
  const createdAt = input.createdAt ?? Date.now();
  const messageRef = input.id ? doc(db, "conversations", input.threadId, "messages", input.id) : doc(collection(db, "conversations", input.threadId, "messages"));
  const parsedMedia = input.dataUrl ? splitDataUrl(input.dataUrl) : null;
  const chunks = parsedMedia && parsedMedia.data.length > 650_000 ? parsedMedia.data.match(/.{1,600000}/g) ?? [] : [];
  const batch = writeBatch(db);
  batch.set(messageRef, {
    id: messageRef.id,
    body: input.body,
    senderId: normalizeId(input.senderId),
    receiverId: normalizeId(input.receiverId),
    type: input.type,
    status: "sent",
    createdAt: Timestamp.fromMillis(createdAt),
    ...(parsedMedia ? { mimeType: parsedMedia.mimeType, ...(chunks.length === 0 ? { dataUrl: input.dataUrl } : { hasChunks: true }) } : {}),
    ...(input.audioDuration !== undefined ? { audioDuration: input.audioDuration } : {}),
    ...(input.voiceEffect ? { voiceEffect: input.voiceEffect } : {}),
    ...(input.unlockAt ? { unlockAt: Timestamp.fromMillis(input.unlockAt) } : {}),
    ...(input.passwordHash ? { passwordHash: input.passwordHash } : {}),
    ...(input.passwordSalt ? { passwordSalt: input.passwordSalt } : {}),
    ...(input.ttlSeconds && input.ttlSeconds > 0 ? { expiresAt: Timestamp.fromMillis(createdAt + input.ttlSeconds * 1000) } : {}),
  });
  chunks.forEach((chunk, index) => batch.set(doc(db, "conversations", input.threadId, "messages", messageRef.id, "mediaChunks", String(index).padStart(4, "0")), { index, data: chunk }));
  batch.set(doc(db, "conversations", input.threadId), {
    lastMessage: input.body,
    lastMessageType: input.type,
    lastSenderId: normalizeId(input.senderId),
    updatedAt: Timestamp.fromMillis(createdAt),
    unreadBy: { [safeDocPart(input.receiverId)]: 1 },
  }, { merge: true });
  await batch.commit();
  return { id: messageRef.id, createdAt };
}

export async function hashFirebaseVoicePassword(password: string, salt: string) {
  const bytes = new TextEncoder().encode(`${salt}:${password}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join("");
}

export async function imageFileToDataUrl(file: File) {
  const bitmap = await createImageBitmap(file);
  const maxDimension = 1440;
  const scale = Math.min(1, maxDimension / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Image canvas is unavailable");
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  let quality = .84;
  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  while (dataUrl.length > 700_000 && quality > .45) {
    quality -= .09;
    dataUrl = canvas.toDataURL("image/jpeg", quality);
  }
  if (dataUrl.length > 900_000) throw new Error("Image is too large");
  return dataUrl;
}

export async function profileImageFileToDataUrl(file: File) {
  const bitmap = await createImageBitmap(file);
  const target = 256;
  const canvas = document.createElement("canvas");
  canvas.width = target;
  canvas.height = target;
  const context = canvas.getContext("2d");
  if (!context) { bitmap.close(); throw new Error("Image canvas is unavailable"); }
  const side = Math.min(bitmap.width, bitmap.height);
  const sourceX = (bitmap.width - side) / 2;
  const sourceY = (bitmap.height - side) / 2;
  context.drawImage(bitmap, sourceX, sourceY, side, side, 0, 0, target, target);
  bitmap.close();
  let quality = .82;
  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  while (dataUrl.length > 700_000 && quality > .4) {
    quality -= .08;
    dataUrl = canvas.toDataURL("image/jpeg", quality);
  }
  if (dataUrl.length > 900_000) throw new Error("Image is too large");
  return dataUrl;
}

export type FirebaseStatusAccent = "teal" | "amber" | "blue" | "rose" | "violet" | "emerald" | "orange" | "crimson";

export type FirebaseStatus = {
  id: string;
  author_id: string;
  author_name: string;
  author_username: string | null;
  author_photo: string | null;
  status_type: "text" | "photo";
  body: string;
  accent: FirebaseStatusAccent;
  image_url: string | null;
  created_at: string;
  expires_at: string;
};

const statusAccents: FirebaseStatusAccent[] = ["teal", "amber", "blue", "rose", "violet", "emerald", "orange", "crimson"];

export async function publishFirebaseStatus(input: {
  author: FirebaseContact;
  statusType: "text" | "photo";
  body: string;
  accent: FirebaseStatusAccent;
  imageDataUrl?: string | null;
}) {
  const now = Date.now();
  const statusRef = doc(collection(db, "statuses"));
  const parsedMedia = input.imageDataUrl ? splitDataUrl(input.imageDataUrl) : null;
  const chunks = parsedMedia && parsedMedia.data.length > 650_000 ? parsedMedia.data.match(/.{1,600000}/g) ?? [] : [];
  const batch = writeBatch(db);
  batch.set(statusRef, {
    id: statusRef.id,
    authorId: normalizeId(input.author.id),
    authorName: input.author.name,
    authorUsername: input.author.username ?? null,
    authorPhoto: input.author.photo ?? null,
    statusType: input.statusType,
    body: input.body,
    accent: input.accent,
    createdAt: Timestamp.fromMillis(now),
    expiresAt: Timestamp.fromMillis(now + 24 * 60 * 60 * 1000),
    ...(parsedMedia ? { mimeType: parsedMedia.mimeType, ...(chunks.length === 0 ? { imageDataUrl: input.imageDataUrl } : { hasChunks: true }) } : {}),
  });
  chunks.forEach((chunk, index) => batch.set(doc(db, "statuses", statusRef.id, "mediaChunks", String(index).padStart(4, "0")), { index, data: chunk }));
  await batch.commit();
  return statusRef.id;
}

async function loadChunkedStatusImage(statusId: string, mimeType: string) {
  const chunksSnapshot = await getDocs(query(collection(db, "statuses", statusId, "mediaChunks"), orderBy("index", "asc")));
  const base64 = chunksSnapshot.docs.map((item) => {
    const data = item.data();
    return typeof data.data === "string" ? data.data : "";
  }).join("");
  return base64 ? `data:${mimeType};base64,${base64}` : null;
}

async function mapStatus(snapshotDoc: QueryDocumentSnapshot<DocumentData>): Promise<FirebaseStatus> {
  const data = snapshotDoc.data();
  const mimeType = typeof data.mimeType === "string" ? data.mimeType : "image/jpeg";
  let imageUrl = typeof data.imageDataUrl === "string" ? data.imageDataUrl : null;
  if (!imageUrl && data.hasChunks === true) imageUrl = await loadChunkedStatusImage(snapshotDoc.id, mimeType);
  const accent = statusAccents.includes(data.accent as FirebaseStatusAccent) ? data.accent as FirebaseStatusAccent : "teal";
  return {
    id: snapshotDoc.id,
    author_id: typeof data.authorId === "string" ? normalizeId(data.authorId) : "",
    author_name: typeof data.authorName === "string" ? data.authorName : "",
    author_username: typeof data.authorUsername === "string" ? data.authorUsername : null,
    author_photo: typeof data.authorPhoto === "string" && data.authorPhoto.startsWith("data:image/") ? data.authorPhoto : null,
    status_type: data.statusType === "photo" ? "photo" : "text",
    body: typeof data.body === "string" ? data.body : "",
    accent,
    image_url: imageUrl,
    created_at: dateIso(data.createdAt),
    expires_at: dateIso(data.expiresAt),
  };
}

export function listenToFirebaseStatuses(
  currentUserId: string,
  onData: (items: FirebaseStatus[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  const statusesQuery = query(collection(db, "statuses"), where("expiresAt", ">", Timestamp.now()), orderBy("expiresAt", "asc"), orderBy("createdAt", "desc"));
  return onSnapshot(statusesQuery, (snapshot) => {
    void Promise.all(snapshot.docs.map((item) => mapStatus(item)))
      .then((items) => onData(items.filter((item) => item.author_id && item.author_id !== current)))
      .catch((error: unknown) => onError(error instanceof Error ? error : new Error("Could not load statuses")));
  }, (error) => onError(error));
}

export async function statusImageFileToDataUrl(file: File) {
  const bitmap = await createImageBitmap(file);
  const maxDimension = 1080;
  const scale = Math.min(1, maxDimension / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext("2d");
  if (!context) { bitmap.close(); throw new Error("Image canvas is unavailable"); }
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  let quality = .8;
  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  while (dataUrl.length > 620_000 && quality > .4) {
    quality -= .08;
    dataUrl = canvas.toDataURL("image/jpeg", quality);
  }
  if (dataUrl.length > 900_000) throw new Error("Image is too large");
  return dataUrl;
}

export function listenToFirebaseDisappearing(
  threadId: string,
  currentUserId: string,
  onData: (seconds: number) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  const key = safeDocPart(current);
  return onSnapshot(doc(db, "conversations", threadId), (snapshot) => {
    const data = snapshot.data();
    const timers = data?.disappearingBy && typeof data.disappearingBy === "object" ? data.disappearingBy as Record<string, unknown> : {};
    const value = timers[key];
    onData(typeof value === "number" && value > 0 ? value : 0);
  }, () => onData(0));
}

export async function setFirebaseDisappearing(threadId: string, currentUserId: string, seconds: number) {
  const key = safeDocPart(normalizeId(currentUserId));
  await setDoc(doc(db, "conversations", threadId), { disappearingBy: { [key]: seconds } }, { merge: true });
}

export async function fetchFirebaseMessagesOnce(threadId: string, currentUserId: string): Promise<FirebaseMessage[]> {
  const snapshot = await getDocs(query(collection(db, "conversations", threadId, "messages"), orderBy("createdAt", "asc")));
  const items = await Promise.all(snapshot.docs.map((item) => mapMessage(item, threadId, currentUserId)));
  return items.filter((item) => !isExpired(item));
}

export type FirebaseUsage = { sent: number; received: number; photos: number; voice: number };

export async function fetchFirebaseUsage(currentUserId: string): Promise<FirebaseUsage> {
  const current = normalizeId(currentUserId);
  const conversationsSnapshot = await getDocs(query(collection(db, "conversations"), where("participants", "array-contains", current)));
  const usage: FirebaseUsage = { sent: 0, received: 0, photos: 0, voice: 0 };
  for (const conversationDoc of conversationsSnapshot.docs) {
    const messagesSnapshot = await getDocs(collection(db, "conversations", conversationDoc.id, "messages"));
    for (const messageDoc of messagesSnapshot.docs) {
      const data = messageDoc.data();
      const sender = normalizeId(typeof data.senderId === "string" ? data.senderId : "");
      if (sender === current) usage.sent += 1; else usage.received += 1;
      if (data.type === "image") usage.photos += 1;
      if (data.type === "audio") usage.voice += 1;
    }
  }
  return usage;
}

export function getFirebaseDbForDiagnostics(): Firestore {
  return db;
}

/* ===== Presence: online / last seen ===== */

export async function touchFirebasePresence(userId: string) {
  const id = normalizeId(userId);
  if (!id) return;
  await setDoc(doc(db, "profiles", safeDocPart(id)), { lastActiveAt: Timestamp.now(), online: true }, { merge: true });
}

export async function markFirebaseOffline(userId: string) {
  const id = normalizeId(userId);
  if (!id) return;
  await setDoc(doc(db, "profiles", safeDocPart(id)), { lastActiveAt: Timestamp.now(), online: false }, { merge: true });
}

export function listenToFirebasePresence(
  userId: string,
  onData: (presence: { online: boolean; last_active_at: string | null }) => void,
): Unsubscribe {
  const id = normalizeId(userId);
  return onSnapshot(doc(db, "profiles", safeDocPart(id)), (snapshot) => {
    const data = snapshot.data();
    const lastActive = data?.lastActiveAt instanceof Timestamp ? data.lastActiveAt.toDate().toISOString() : null;
    const fresh = lastActive !== null && Date.now() - new Date(lastActive).getTime() < 150_000;
    onData({ online: data?.online === true && fresh, last_active_at: lastActive });
  }, () => onData({ online: false, last_active_at: null }));
}

/* ===== Delete a single message (works for voice, image and text) ===== */

export async function deleteFirebaseMessage(collectionRoot: "conversations" | "groups", threadId: string, messageId: string) {
  const chunksSnapshot = await getDocs(collection(db, collectionRoot, threadId, "messages", messageId, "mediaChunks"));
  if (!chunksSnapshot.empty) {
    const batch = writeBatch(db);
    chunksSnapshot.docs.forEach((item) => batch.delete(item.ref));
    await batch.commit();
  }
  await deleteDoc(doc(db, collectionRoot, threadId, "messages", messageId));
}

/* ===== Groups (WhatsApp-style) ===== */

export type FirebaseGroup = {
  id: string;
  name: string;
  photo: string | null;
  description: string;
  created_by: string;
  admins: string[];
  members: FirebaseContact[];
  updated_at: string;
};

function parseGroupDoc(snapshotDoc: QueryDocumentSnapshot<DocumentData>): FirebaseGroup {
  const data = snapshotDoc.data();
  const members = Array.isArray(data.members) ? data.members.map(parseContact).filter((value): value is FirebaseContact => value !== null) : [];
  return {
    id: snapshotDoc.id,
    name: typeof data.name === "string" ? data.name : "",
    photo: typeof data.photo === "string" && data.photo.startsWith("data:image/") ? data.photo : null,
    description: typeof data.description === "string" ? data.description : "",
    created_by: typeof data.createdBy === "string" ? normalizeId(data.createdBy) : "",
    admins: Array.isArray(data.admins) ? data.admins.filter((value): value is string => typeof value === "string").map(normalizeId) : [],
    members,
    updated_at: dateIso(data.updatedAt),
  };
}

export function groupConversationId(groupId: string) {
  return `group:${groupId}`;
}

export async function createFirebaseGroup(input: { creator: FirebaseContact; name: string; photo: string | null; description: string; members: FirebaseContact[] }): Promise<string> {
  const creator = { ...input.creator, id: normalizeId(input.creator.id) };
  const membersById = new Map<string, FirebaseContact>();
  membersById.set(creator.id, creator);
  for (const member of input.members) membersById.set(normalizeId(member.id), { ...member, id: normalizeId(member.id) });
  const members = [...membersById.values()];
  const groupRef = doc(collection(db, "groups"));
  await setDoc(groupRef, {
    id: groupRef.id,
    name: input.name,
    photo: input.photo ?? null,
    description: input.description,
    createdBy: creator.id,
    admins: [creator.id],
    memberIds: members.map((member) => member.id),
    members,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  });
  return groupRef.id;
}

export function listenToFirebaseGroups(
  currentUserId: string,
  onData: (items: FirebaseConversation[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  const groupsQuery = query(collection(db, "groups"), where("memberIds", "array-contains", current));
  return onSnapshot(groupsQuery, (snapshot) => {
    const items = snapshot.docs.map((snapshotDoc) => {
      const data = snapshotDoc.data();
      const group = parseGroupDoc(snapshotDoc);
      const unreadBy = data.unreadBy && typeof data.unreadBy === "object" ? data.unreadBy as Record<string, unknown> : {};
      const unreadKey = safeDocPart(current);
      const messageType = data.lastMessageType === "text" || data.lastMessageType === "audio" || data.lastMessageType === "image" ? data.lastMessageType : null;
      return {
        id: groupConversationId(group.id),
        contact_name: group.name,
        contact_email: null,
        contact_username: null,
        contact_mobile: null,
        contact_photo: group.photo,
        target_user_id: group.id,
        last_message: typeof data.lastMessage === "string" ? data.lastMessage : null,
        last_message_type: messageType,
        last_sender_id: typeof data.lastSenderId === "string" ? data.lastSenderId : null,
        unread_count: typeof unreadBy[unreadKey] === "number" ? unreadBy[unreadKey] : 0,
        updated_at: group.updated_at,
        is_group: true,
        group_id: group.id,
        group_description: group.description,
        group_members: group.members,
        group_admins: group.admins,
        group_created_by: group.created_by,
      } satisfies FirebaseConversation;
    }).sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
    onData(items);
  }, (error) => onError(error));
}

export async function updateFirebaseGroup(groupId: string, next: { name?: string; photo?: string | null; description?: string }) {
  await updateDoc(doc(db, "groups", groupId), { ...next, updatedAt: Timestamp.now() });
}

export async function setFirebaseGroupMembers(groupId: string, members: FirebaseContact[], admins: string[]) {
  const normalizedMembers = members.map((member) => ({ ...member, id: normalizeId(member.id) }));
  const memberIds = normalizedMembers.map((member) => member.id);
  const normalizedAdmins = admins.map(normalizeId).filter((id) => memberIds.includes(id));
  await updateDoc(doc(db, "groups", groupId), { members: normalizedMembers, memberIds, admins: normalizedAdmins, updatedAt: Timestamp.now() });
}

export function listenToFirebaseGroupMessages(
  groupId: string,
  currentUserId: string,
  onData: (items: FirebaseMessage[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const messagesQuery = query(collection(db, "groups", groupId, "messages"), orderBy("createdAt", "asc"));
  return onSnapshot(messagesQuery, (snapshot) => {
    void Promise.all(snapshot.docs.map((item) => mapMessage(item, groupId, currentUserId, "groups"))).then((items) => onData(items.filter((item) => !isExpired(item)))).catch((error: unknown) => onError(error instanceof Error ? error : new Error("Could not load messages")));
    const toDeliver = snapshot.docs.filter((item) => {
      const data = item.data();
      const receivers = Array.isArray(data.receiverIds) ? data.receiverIds.filter((value): value is string => typeof value === "string").map(normalizeId) : [];
      return receivers.includes(normalizeId(currentUserId)) && data.status === "sent";
    });
    if (toDeliver.length > 0) {
      const batch = writeBatch(db);
      toDeliver.forEach((item) => batch.update(item.ref, { status: "delivered", deliveredAt: Timestamp.now() }));
      void batch.commit();
    }
  }, (error) => onError(error));
}

export async function sendFirebaseGroupMessage(input: FirebaseMessageInput & { memberIds: string[]; senderName: string; senderPhoto: string | null }) {
  const createdAt = input.createdAt ?? Date.now();
  const messageRef = input.id ? doc(db, "groups", input.threadId, "messages", input.id) : doc(collection(db, "groups", input.threadId, "messages"));
  const parsedMedia = input.dataUrl ? splitDataUrl(input.dataUrl) : null;
  const chunks = parsedMedia && parsedMedia.data.length > 650_000 ? parsedMedia.data.match(/.{1,600000}/g) ?? [] : [];
  const others = input.memberIds.map(normalizeId).filter((id) => id !== normalizeId(input.senderId));
  const batch = writeBatch(db);
  batch.set(messageRef, {
    id: messageRef.id,
    body: input.body,
    senderId: normalizeId(input.senderId),
    senderName: input.senderName,
    senderPhoto: input.senderPhoto,
    receiverId: others[0] ?? "",
    receiverIds: others,
    type: input.type,
    status: "sent",
    createdAt: Timestamp.fromMillis(createdAt),
    ...(parsedMedia ? { mimeType: parsedMedia.mimeType, ...(chunks.length === 0 ? { dataUrl: input.dataUrl } : { hasChunks: true }) } : {}),
    ...(input.audioDuration !== undefined ? { audioDuration: input.audioDuration } : {}),
    ...(input.voiceEffect ? { voiceEffect: input.voiceEffect } : {}),
    ...(input.unlockAt ? { unlockAt: Timestamp.fromMillis(input.unlockAt) } : {}),
    ...(input.passwordHash ? { passwordHash: input.passwordHash } : {}),
    ...(input.passwordSalt ? { passwordSalt: input.passwordSalt } : {}),
    ...(input.ttlSeconds && input.ttlSeconds > 0 ? { expiresAt: Timestamp.fromMillis(createdAt + input.ttlSeconds * 1000) } : {}),
  });
  chunks.forEach((chunk, index) => batch.set(doc(db, "groups", input.threadId, "messages", messageRef.id, "mediaChunks", String(index).padStart(4, "0")), { index, data: chunk }));
  const groupUpdate: Record<string, unknown> = {
    lastMessage: input.body,
    lastMessageType: input.type,
    lastSenderId: normalizeId(input.senderId),
    updatedAt: Timestamp.fromMillis(createdAt),
  };
  others.forEach((id) => { groupUpdate[`unreadBy.${safeDocPart(id)}`] = increment(1); });
  batch.update(doc(db, "groups", input.threadId), groupUpdate as UpdateData<DocumentData>);
  await batch.commit();
  return { id: messageRef.id, createdAt };
}

export async function markFirebaseGroupMessagesRead(groupId: string, currentUserId: string) {
  const current = normalizeId(currentUserId);
  const snapshot = await getDocs(collection(db, "groups", groupId, "messages"));
  const batch = writeBatch(db);
  let touched = false;
  snapshot.docs.forEach((item) => {
    const data = item.data();
    const receivers = Array.isArray(data.receiverIds) ? data.receiverIds.filter((value): value is string => typeof value === "string").map(normalizeId) : [];
    if (receivers.includes(current) && data.status !== "read") { batch.update(item.ref, { status: "read", readAt: Timestamp.now() }); touched = true; }
  });
  batch.update(doc(db, "groups", groupId), { [`unreadBy.${safeDocPart(current)}`]: 0 });
  void touched;
  await batch.commit();
}

export async function fetchFirebaseGroupMessagesOnce(groupId: string, currentUserId: string): Promise<FirebaseMessage[]> {
  const snapshot = await getDocs(query(collection(db, "groups", groupId, "messages"), orderBy("createdAt", "asc")));
  const items = await Promise.all(snapshot.docs.map((item) => mapMessage(item, groupId, currentUserId, "groups")));
  return items.filter((item) => !isExpired(item));
}
