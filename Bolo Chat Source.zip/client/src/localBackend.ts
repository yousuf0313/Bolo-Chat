// Local-mode fallback backend.
//
// The hosted artifact talks to its private server through the typed action
// client in `./api`. When the app runs somewhere with no private server at
// all — the Bolo Chat Android APK, which serves these same files locally
// through Capacitor — every action call fails, and the app used to stop at
// its fatal "could not open" screen. This module wraps the action client:
// each call tries the server first, and the moment the server proves
// unreachable the app switches (for the rest of the session) to a
// localStorage-backed store that mirrors the server's state shapes field
// for field. Profile, preferences, app lock, chat organisation, blocked
// contacts, lists, own statuses, the call log and conversation summaries
// all keep working on-device, and the profile stored here is the identity
// the Firebase layer already uses — so messaging, user search, statuses
// and groups keep working through Firestore exactly as before.
//
// When the server answers (the hosted artifact), nothing changes: calls go
// to the server and the local store is never touched.
//
// Native APK exception: inside the Capacitor APK there is no server at all,
// and "try the server first, fall back on failure" made every launch and
// every action wait on a doomed network attempt. So when the app runs as a
// native app the session starts in local mode and stays there — every call
// is served from localStorage immediately, with zero network waits.

import { api, type ApiRequest, type ApiResponse } from "./api";
import { isNativeApp } from "./nativeBiometric";

export type AppState = ApiResponse<typeof api, "getAppState">;
type Profile = NonNullable<AppState["profile"]>;
type ConversationSummary = AppState["conversations"][number];
type StatusItem = AppState["statuses"][number];
type CallItem = AppState["calls"][number];

const LOCAL_STATE_KEY = "bolo-local-state-v1";
const SERVER_TIMEOUT_MS = 8_000;

type LocalState = {
  profile: Profile | null;
  conversations: ConversationSummary[];
  statuses: StatusItem[];
  calls: CallItem[];
  blocked_contacts: AppState["blocked_contacts"];
  chat_lists: AppState["chat_lists"];
  feedback: string[];
  next_id: number;
};

function emptyLocalState(): LocalState {
  return { profile: null, conversations: [], statuses: [], calls: [], blocked_contacts: [], chat_lists: [], feedback: [], next_id: 1 };
}

function loadLocalState(): LocalState {
  try {
    const raw = window.localStorage.getItem(LOCAL_STATE_KEY);
    if (!raw) return emptyLocalState();
    const parsed = JSON.parse(raw) as Partial<LocalState>;
    // Profiles saved by older builds lack the newer fields — fill defaults.
    if (parsed.profile) {
      if (!Array.isArray(parsed.profile.pinned_thread_ids)) parsed.profile.pinned_thread_ids = [];
      if (typeof parsed.profile.media_visibility_enabled !== "boolean") parsed.profile.media_visibility_enabled = true;
    }
    return {
      profile: parsed.profile ?? null,
      conversations: Array.isArray(parsed.conversations) ? parsed.conversations : [],
      statuses: Array.isArray(parsed.statuses) ? parsed.statuses : [],
      calls: Array.isArray(parsed.calls) ? parsed.calls : [],
      blocked_contacts: Array.isArray(parsed.blocked_contacts) ? parsed.blocked_contacts : [],
      chat_lists: Array.isArray(parsed.chat_lists) ? parsed.chat_lists : [],
      feedback: Array.isArray(parsed.feedback) ? parsed.feedback : [],
      next_id: typeof parsed.next_id === "number" && parsed.next_id > 0 ? parsed.next_id : 1,
    };
  } catch { return emptyLocalState(); }
}

let localState: LocalState | null = null;
function state(): LocalState {
  if (!localState) localState = loadLocalState();
  return localState;
}
function persist() {
  try { window.localStorage.setItem(LOCAL_STATE_KEY, JSON.stringify(state())); } catch { /* storage full/unavailable — the in-memory copy still serves this session */ }
}
function nextId(): number {
  const id = state().next_id;
  state().next_id = id + 1;
  return id;
}

/** The local store presented in the exact shape `getAppState` returns. */
function localAppState(): AppState {
  const current = state();
  // Self-conversations (a chat with your own address) are leftover voice-test
  // data: drop them from the on-device store so they can never be listed or
  // re-created in Firebase again.
  if (current.profile) {
    const self = current.profile.email.trim().toLocaleLowerCase();
    const kept = current.conversations.filter((item) => item.target_user_id.trim().toLocaleLowerCase() !== self);
    if (kept.length !== current.conversations.length) {
      current.conversations = kept;
      persist();
    }
  }
  const now = Date.now();
  const view: AppState = {
    profile: current.profile,
    conversations: [...current.conversations].sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()),
    statuses: current.statuses.filter((item) => new Date(item.expires_at).getTime() > now),
    calls: [...current.calls].slice(0, 50),
    blocked_contacts: current.blocked_contacts,
    chat_lists: current.chat_lists,
  };
  // Hand react-query a fresh snapshot so in-place local writes are seen as
  // new data on the next refetch instead of being structural-shared away.
  return JSON.parse(JSON.stringify(view)) as AppState;
}

function requireProfile(): Profile {
  const profile = state().profile;
  if (!profile) throw new Error("Profile not found");
  return profile;
}

/* ------------------------------------------------------------------ */
/* Local implementations, one per server action the client uses.       */
/* ------------------------------------------------------------------ */

type SaveProfileArgs = ApiRequest<typeof api, "saveProfile">;
function localSaveProfile(args: SaveProfileArgs): { ok: true } {
  const current = state();
  const email = args.email.trim().toLocaleLowerCase();
  const mobile = args.mobile_number === undefined ? undefined : (args.mobile_number ?? "").trim() || null;
  if (current.profile) {
    current.profile = {
      ...current.profile,
      display_name: args.display_name,
      email,
      ...(args.username !== undefined ? { username: args.username } : {}),
      ...(mobile !== undefined ? { mobile_number: mobile } : {}),
      ...(args.about !== undefined ? { about: args.about } : {}),
    };
  } else {
    current.profile = {
      display_name: args.display_name,
      username: args.username ?? "",
      email,
      mobile_number: mobile ?? null,
      avatar_url: null,
      about: args.about || "دستیاب ہوں",
      notifications_enabled: true,
      read_receipts_enabled: true,
      language: "ur",
      theme_mode: "system",
      wallpaper: "doodle",
      message_tone: "saba",
      call_tone: "noor",
      security_notifications_enabled: true,
      auto_download_photos: true,
      auto_download_voice: true,
      conversation_tones_enabled: true,
      default_voice_effect: "original",
      app_lock_enabled: false,
      app_lock_method: "none",
      app_lock_hash: null,
      app_lock_salt: null,
      pinned_thread_ids: [],
      media_visibility_enabled: true,
      archived_thread_ids: [],
      locked_thread_ids: [],
      muted_thread_ids: [],
      deleted_thread_ids: [],
      thread_wallpapers: {},
    };
  }
  persist();
  return { ok: true };
}

type SaveProfilePhotoArgs = ApiRequest<typeof api, "saveProfilePhoto">;
function localSaveProfilePhoto(args: SaveProfilePhotoArgs): { avatar_url: string | null } {
  const profile = requireProfile();
  if (args.data_base64 === null) {
    profile.avatar_url = null;
    persist();
    return { avatar_url: null };
  }
  // On-device the photo itself is the stored value (a data URL) instead of
  // a server blob URL; the app renders both the same way.
  const avatarUrl = `data:${args.mime_type ?? "image/jpeg"};base64,${args.data_base64}`;
  profile.avatar_url = avatarUrl;
  persist();
  return { avatar_url: avatarUrl };
}

type SavePreferencesArgs = ApiRequest<typeof api, "savePreferences">;
function localSavePreferences(args: SavePreferencesArgs): { ok: true } {
  const profile = state().profile;
  if (profile) {
    profile.language = args.language;
    profile.theme_mode = args.theme_mode;
    profile.wallpaper = args.wallpaper;
    profile.message_tone = args.message_tone;
    if (args.call_tone !== undefined) profile.call_tone = args.call_tone;
    if (args.security_notifications_enabled !== undefined) profile.security_notifications_enabled = args.security_notifications_enabled;
    if (args.auto_download_photos !== undefined) profile.auto_download_photos = args.auto_download_photos;
    if (args.auto_download_voice !== undefined) profile.auto_download_voice = args.auto_download_voice;
    if (args.media_visibility_enabled !== undefined) profile.media_visibility_enabled = args.media_visibility_enabled;
    if (args.default_voice_effect !== undefined) profile.default_voice_effect = args.default_voice_effect;
    profile.conversation_tones_enabled = args.conversation_tones_enabled;
    persist();
  }
  return { ok: true };
}

type SaveSettingsArgs = ApiRequest<typeof api, "saveSettings">;
function localSaveSettings(args: SaveSettingsArgs): { ok: true } {
  const profile = state().profile;
  if (profile) {
    profile.notifications_enabled = args.notifications_enabled;
    profile.read_receipts_enabled = args.read_receipts_enabled;
    persist();
  }
  return { ok: true };
}

type SaveAppLockArgs = ApiRequest<typeof api, "saveAppLock">;
function localSaveAppLock(args: SaveAppLockArgs): { ok: true } {
  const profile = state().profile;
  if (profile) {
    profile.app_lock_enabled = args.enabled;
    profile.app_lock_method = args.method;
    if (args.secret_hash !== undefined) profile.app_lock_hash = args.secret_hash;
    if (args.secret_salt !== undefined) profile.app_lock_salt = args.secret_salt;
    persist();
  }
  return { ok: true };
}

type SaveChatOrganizationArgs = ApiRequest<typeof api, "saveChatOrganization">;
function localSaveChatOrganization(args: SaveChatOrganizationArgs): { ok: true } {
  const profile = state().profile;
  if (profile) {
    if (args.pinned_thread_ids !== undefined) profile.pinned_thread_ids = args.pinned_thread_ids;
    profile.archived_thread_ids = args.archived_thread_ids;
    profile.locked_thread_ids = args.locked_thread_ids;
    profile.muted_thread_ids = args.muted_thread_ids;
    profile.deleted_thread_ids = args.deleted_thread_ids;
    profile.thread_wallpapers = args.thread_wallpapers;
    persist();
  }
  return { ok: true };
}

type BlockContactArgs = ApiRequest<typeof api, "blockContact">;
function localBlockContact(args: BlockContactArgs): { ok: true } {
  const target = args.target_user_id.trim().toLocaleLowerCase();
  const current = state();
  if (!current.blocked_contacts.some((item) => item.target_user_id === target)) {
    current.blocked_contacts.unshift({
      target_user_id: target,
      contact_name: args.contact_name,
      contact_email: args.contact_email || null,
      contact_username: args.contact_username || null,
    });
    persist();
  }
  return { ok: true };
}

function localUnblockContact(args: ApiRequest<typeof api, "unblockContact">): { ok: true } {
  const target = args.target_user_id.trim().toLocaleLowerCase();
  const current = state();
  current.blocked_contacts = current.blocked_contacts.filter((item) => item.target_user_id !== target);
  persist();
  return { ok: true };
}

function localCreateChatList(args: ApiRequest<typeof api, "createChatList">): { id: number } {
  const id = nextId();
  state().chat_lists.push({ id, name: args.name, members: [] });
  persist();
  return { id };
}

function localDeleteChatList(args: ApiRequest<typeof api, "deleteChatList">): { ok: true } {
  const current = state();
  current.chat_lists = current.chat_lists.filter((list) => list.id !== args.id);
  persist();
  return { ok: true };
}

type AddChatListMemberArgs = ApiRequest<typeof api, "addChatListMember">;
function localAddChatListMember(args: AddChatListMemberArgs): { ok: true } {
  const list = state().chat_lists.find((item) => item.id === args.list_id);
  if (list) {
    const target = args.target_user_id.trim().toLocaleLowerCase();
    if (!list.members.some((member) => member.target_user_id === target)) {
      list.members.push({
        target_user_id: target,
        contact_name: args.contact_name,
        contact_email: args.contact_email || null,
        contact_username: args.contact_username || null,
      });
      persist();
    }
  }
  return { ok: true };
}

function localRemoveChatListMember(args: ApiRequest<typeof api, "removeChatListMember">): { ok: true } {
  const list = state().chat_lists.find((item) => item.id === args.list_id);
  if (list) {
    const target = args.target_user_id.trim().toLocaleLowerCase();
    list.members = list.members.filter((member) => member.target_user_id !== target);
    persist();
  }
  return { ok: true };
}

function localSaveFeedback(args: ApiRequest<typeof api, "saveFeedback">): { ok: true } {
  state().feedback.push(args.body);
  persist();
  return { ok: true };
}

function localCreateStatus(args: ApiRequest<typeof api, "createStatus">): { id: number } {
  const id = nextId();
  const now = new Date();
  state().statuses.unshift({
    id, body: args.body, accent: args.accent, status_type: "text", image_url: null,
    created_at: now.toISOString(), expires_at: new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString(),
  });
  persist();
  return { id };
}

function localCreatePhotoStatus(args: ApiRequest<typeof api, "createPhotoStatus">): { id: number } {
  const id = nextId();
  const now = new Date();
  state().statuses.unshift({
    id, body: args.caption ?? "", accent: "teal", status_type: "photo",
    image_url: `data:${args.mime_type};base64,${args.data_base64}`,
    created_at: now.toISOString(), expires_at: new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString(),
  });
  persist();
  return { id };
}

function localDeleteStatus(args: ApiRequest<typeof api, "deleteStatus">): { ok: true } {
  const current = state();
  current.statuses = current.statuses.filter((item) => item.id !== args.id);
  persist();
  return { ok: true };
}

function localStartCall(args: ApiRequest<typeof api, "startCall">): { id: number } {
  const id = nextId();
  state().calls.unshift({
    id, contact_name: args.contact_name, contact_email: args.contact_email,
    call_type: args.call_type, started_at: new Date().toISOString(),
  });
  persist();
  return { id };
}

type GetOrCreateConversationIdArgs = ApiRequest<typeof api, "getOrCreateConversationId">;
function localGetOrCreateConversationId(args: GetOrCreateConversationIdArgs): { id: number } {
  const profile = requireProfile();
  const targetUserId = args.target_user_id.trim().toLocaleLowerCase();
  if (targetUserId === profile.email.trim().toLocaleLowerCase()) throw new Error("Cannot create a conversation with yourself");
  const current = state();
  const existing = current.conversations.find((item) => item.target_user_id === targetUserId);
  if (existing) {
    if (args.contact_photo_url !== undefined && args.contact_photo_url !== existing.contact_photo_url) {
      existing.contact_photo_url = args.contact_photo_url;
      persist();
    }
    return { id: existing.id };
  }
  const id = nextId();
  current.conversations.push({
    id,
    contact_name: args.contact_name,
    contact_email: args.contact_email,
    contact_username: targetUserId.startsWith("@") ? targetUserId.slice(1) : null,
    contact_photo_url: args.contact_photo_url ?? null,
    target_user_id: targetUserId,
    last_message: null,
    last_message_type: null,
    last_sender_id: null,
    unread_count: 0,
    updated_at: new Date().toISOString(),
  });
  persist();
  return { id };
}

function localCacheConversationPhotos(args: ApiRequest<typeof api, "cacheConversationPhotos">): { ok: true } {
  const current = state();
  let changed = false;
  for (const item of args.items) {
    const target = item.target_user_id.trim().toLocaleLowerCase();
    const row = current.conversations.find((entry) => entry.target_user_id === target);
    if (row && row.contact_photo_url !== item.contact_photo_url) {
      row.contact_photo_url = item.contact_photo_url;
      changed = true;
    }
  }
  if (changed) persist();
  return { ok: true };
}

function localDeleteAllData(): { ok: true } {
  localState = emptyLocalState();
  try { window.localStorage.removeItem(LOCAL_STATE_KEY); } catch { /* storage unavailable */ }
  persist();
  return { ok: true };
}

function localDeleteConversation(args: ApiRequest<typeof api, "deleteConversation">): { ok: true } {
  const target = args.target_user_id.trim().toLocaleLowerCase();
  const current = state();
  current.conversations = current.conversations.filter((item) => item.target_user_id !== target);
  for (const list of current.chat_lists) {
    list.members = list.members.filter((member) => member.target_user_id !== target);
  }
  persist();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Server-first dispatch. `serverAvailable` starts unknown; the boot   */
/* `getAppState` call decides it. Any failure flips the session to     */
/* local mode and the call is served from the local store instead, so  */
/* the UI never sees an error just because there is no server.        */
/* In the native APK the session starts already in local mode: the    */
/* server is never attempted, not even once.                          */
/* ------------------------------------------------------------------ */

const NATIVE_APP = isNativeApp();
let serverAvailable: boolean | null = NATIVE_APP ? false : null;

async function dispatch<R>(remote: () => Promise<R>, applyLocal: () => R): Promise<R> {
  if (NATIVE_APP) return applyLocal();
  if (serverAvailable !== false) {
    try {
      const result = await remote();
      serverAvailable = true;
      return result;
    } catch {
      serverAvailable = false;
    }
  }
  return applyLocal();
}

async function fetchServerAppState(): Promise<AppState> {
  let timer: number | undefined;
  const timeout = new Promise<never>((_resolve, reject) => {
    timer = window.setTimeout(() => reject(new Error("server-timeout")), SERVER_TIMEOUT_MS);
  });
  try {
    return await Promise.race([api.getAppState({}), timeout]);
  } finally {
    if (timer !== undefined) window.clearTimeout(timer);
  }
}

export const backend = {
  async getAppState(): Promise<AppState> {
    if (NATIVE_APP) return localAppState();
    if (serverAvailable !== false) {
      try {
        const result = await fetchServerAppState();
        serverAvailable = true;
        return result;
      } catch {
        serverAvailable = false;
      }
    }
    return localAppState();
  },
  saveProfile: (args: SaveProfileArgs) => dispatch(() => api.saveProfile(args), () => localSaveProfile(args)),
  saveProfilePhoto: (args: SaveProfilePhotoArgs) => dispatch(() => api.saveProfilePhoto(args), () => localSaveProfilePhoto(args)),
  savePreferences: (args: SavePreferencesArgs) => dispatch(() => api.savePreferences(args), () => localSavePreferences(args)),
  saveSettings: (args: SaveSettingsArgs) => dispatch(() => api.saveSettings(args), () => localSaveSettings(args)),
  saveAppLock: (args: SaveAppLockArgs) => dispatch(() => api.saveAppLock(args), () => localSaveAppLock(args)),
  saveChatOrganization: (args: SaveChatOrganizationArgs) => dispatch(() => api.saveChatOrganization(args), () => localSaveChatOrganization(args)),
  blockContact: (args: BlockContactArgs) => dispatch(() => api.blockContact(args), () => localBlockContact(args)),
  unblockContact: (args: ApiRequest<typeof api, "unblockContact">) => dispatch(() => api.unblockContact(args), () => localUnblockContact(args)),
  createChatList: (args: ApiRequest<typeof api, "createChatList">) => dispatch(() => api.createChatList(args), () => localCreateChatList(args)),
  deleteChatList: (args: ApiRequest<typeof api, "deleteChatList">) => dispatch(() => api.deleteChatList(args), () => localDeleteChatList(args)),
  addChatListMember: (args: AddChatListMemberArgs) => dispatch(() => api.addChatListMember(args), () => localAddChatListMember(args)),
  removeChatListMember: (args: ApiRequest<typeof api, "removeChatListMember">) => dispatch(() => api.removeChatListMember(args), () => localRemoveChatListMember(args)),
  saveFeedback: (args: ApiRequest<typeof api, "saveFeedback">) => dispatch(() => api.saveFeedback(args), () => localSaveFeedback(args)),
  createStatus: (args: ApiRequest<typeof api, "createStatus">) => dispatch(() => api.createStatus(args), () => localCreateStatus(args)),
  createPhotoStatus: (args: ApiRequest<typeof api, "createPhotoStatus">) => dispatch(() => api.createPhotoStatus(args), () => localCreatePhotoStatus(args)),
  deleteStatus: (args: ApiRequest<typeof api, "deleteStatus">) => dispatch(() => api.deleteStatus(args), () => localDeleteStatus(args)),
  startCall: (args: ApiRequest<typeof api, "startCall">) => dispatch(() => api.startCall(args), () => localStartCall(args)),
  getOrCreateConversationId: (args: GetOrCreateConversationIdArgs) => dispatch(() => api.getOrCreateConversationId(args), () => localGetOrCreateConversationId(args)),
  cacheConversationPhotos: (args: ApiRequest<typeof api, "cacheConversationPhotos">) => dispatch(() => api.cacheConversationPhotos(args), () => localCacheConversationPhotos(args)),
  deleteConversation: (args: ApiRequest<typeof api, "deleteConversation">) => dispatch(() => api.deleteConversation(args), () => localDeleteConversation(args)),
  deleteAllData: () => dispatch(() => api.deleteAllData({}), () => localDeleteAllData()),
};
