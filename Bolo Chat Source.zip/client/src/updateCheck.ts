/* In-app update check.
 *
 * On launch the app asks GitHub for the latest published release of the
 * Easy Chat repo. If that release's version is newer than APP_VERSION,
 * the app shows a dismissible dialog with the release notes and a
 * download button pointing at the release's APK asset. The check is fully
 * silent: offline, a slow network, a missing release or any malformed
 * response simply means "no update to show" — it never blocks the app
 * and never throws. */

import { APP_VERSION } from "./appVersion";

const LATEST_RELEASE_URL = "https://api.github.com/repos/yousuf0313/Bolo-Chat/releases/latest";
const CHECK_TIMEOUT_MS = 10_000;

export type UpdateInfo = {
  /** Latest release version without the leading "v", e.g. "1.0.123". */
  version: string;
  /** Release notes (the GitHub release body), possibly empty. */
  notes: string;
  /** APK asset download URL, falling back to the release page itself.
   *  The update dialog downloads this file inside the app (see
   *  ./apkDownload) so progress and completion are shown in-app and the
   *  saved file can be opened for install. */
  downloadUrl: string | null;
  /** File name to save the download under, from the release asset. */
  fileName: string;
};

/** Parse "v1.0.123" / "1.0.123" into numeric parts; null when unreadable. */
function parseVersion(raw: string): number[] | null {
  const cleaned = raw.trim().replace(/^v/i, "");
  if (!cleaned) return null;
  const parts = cleaned.split(".").map((part) => Number.parseInt(part, 10));
  if (parts.some((part) => Number.isNaN(part) || part < 0)) return null;
  return parts;
}

/** True when `candidate` is a strictly newer version than `current`. */
export function isNewerVersion(candidate: string, current: string): boolean {
  const next = parseVersion(candidate);
  const installed = parseVersion(current);
  if (!next || !installed) return false;
  const length = Math.max(next.length, installed.length);
  for (let index = 0; index < length; index += 1) {
    const a = next[index] ?? 0;
    const b = installed[index] ?? 0;
    if (a !== b) return a > b;
  }
  return false;
}

type GitHubRelease = {
  tag_name?: unknown;
  body?: unknown;
  html_url?: unknown;
  assets?: unknown;
};

/**
 * Resolve with the newer release's info, or null when the app is up to
 * date or the check could not be completed for any reason.
 */
export async function checkForUpdate(): Promise<UpdateInfo | null> {
  try {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), CHECK_TIMEOUT_MS);
    let response: Response;
    try {
      response = await fetch(LATEST_RELEASE_URL, {
        signal: controller.signal,
        headers: { Accept: "application/vnd.github+json" },
      });
    } finally {
      window.clearTimeout(timer);
    }
    if (!response.ok) return null;
    const release = (await response.json()) as GitHubRelease;
    const tag = typeof release.tag_name === "string" ? release.tag_name : "";
    if (!tag || !isNewerVersion(tag, APP_VERSION)) return null;
    let downloadUrl: string | null = typeof release.html_url === "string" && release.html_url ? release.html_url : null;
    let fileName = `EasyChat-${tag.replace(/^v/i, "")}.apk`;
    if (Array.isArray(release.assets)) {
      // Pick the APK asset specifically — blindly taking the first asset
      // can hand the user a non-installable file (a zip, an .aab, release
      // metadata) whose "download" then never opens or installs.
      const assets = release.assets as { name?: unknown; browser_download_url?: unknown }[];
      const usable = assets.filter((asset) => typeof asset.browser_download_url === "string" && asset.browser_download_url);
      const apk = usable.find((asset) => typeof asset.name === "string" && asset.name.toLowerCase().endsWith(".apk")) ?? usable[0];
      if (apk && typeof apk.browser_download_url === "string") {
        downloadUrl = apk.browser_download_url;
        if (typeof apk.name === "string" && apk.name) fileName = apk.name;
      }
    }
    return {
      version: tag.replace(/^v/i, ""),
      notes: typeof release.body === "string" ? release.body.trim() : "",
      downloadUrl,
      fileName,
    };
  } catch {
    return null;
  }
}
