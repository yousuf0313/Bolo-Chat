import { Browser } from "@capacitor/browser";
import { isNativeApp } from "./nativeBiometric";

/* Open a URL OUTSIDE the app's WebView.
 *
 * Inside the Android APK a plain link or `window.open` stays trapped in
 * the WebView, which cannot download files — the tap would go nowhere.
 * Capacitor's Browser plugin instead hands the URL to the device's
 * browser (Chrome Custom Tab / system browser), so an APK download URL
 * is picked up by Android's own download manager: the user sees progress
 * in the notification shade and taps the finished download to install it.
 * On the hosted web version a normal new tab is opened. A plugin failure
 * falls back to `window.open` so the tap never silently dies. */
export async function openExternalUrl(url: string): Promise<void> {
  if (isNativeApp()) {
    try {
      await Browser.open({ url });
      return;
    } catch {
      /* plugin unavailable in this build — fall through to window.open */
    }
  }
  window.open(url, "_blank", "noopener,noreferrer");
}
