ALTER TABLE `profiles` ADD COLUMN `app_font` text DEFAULT 'default' NOT NULL;
--> statement-breakpoint
ALTER TABLE `statuses` ADD COLUMN `font` text;
