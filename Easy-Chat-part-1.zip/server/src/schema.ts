import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const profiles = sqliteTable("profiles", {
  id: integer("id").primaryKey(),
  displayName: text("display_name").notNull(),
  username: text("username").notNull().default(""),
  email: text("email").notNull(),
  mobileNumber: text("mobile_number"),
  avatarBlobKey: text("avatar_blob_key"),
  about: text("about").notNull().default("دستیاب ہوں"),
  notificationsEnabled: integer("notifications_enabled", { mode: "boolean" }).notNull().default(true),
  readReceiptsEnabled: integer("read_receipts_enabled", { mode: "boolean" }).notNull().default(true),
  language: text("language", { enum: ["ur", "en", "hi", "ar", "fa", "ps", "tr", "es", "fr", "de", "pt", "ru", "bn", "id", "ms", "zh", "ja", "ko", "it", "nl", "th", "vi", "sw", "uk", "pl"] }).notNull().default("ur"),
  useDeviceLanguage: integer("use_device_language", { mode: "boolean" }).notNull().default(false),
  themeMode: text("theme_mode", { enum: ["system", "light", "dark", "glass"] }).notNull().default("system"),
  wallpaper: text("wallpaper", { enum: ["doodle", "grid", "plain", "garden", "midnight", "sunset", "ocean", "linen", "terrazzo", "constellation", "waves", "blossom", "forest", "jungle", "meadow", "pinewood", "bamboo", "autumn", "leaves", "waterfall", "lake", "desert", "canyon", "savanna", "skyline", "towers", "citynight", "oldtown", "suburb", "village", "harbor", "bridge", "street", "rooftops", "aurora", "ember", "lagoon", "orchid", "honey", "mist", "coral", "mint", "herringbone", "chevron", "dots", "diamonds", "arcs", "mosaic", "prism", "tiles", "balloons", "seasunset", "desertroad", "beachsunset", "pastelbeach", "flowerbeach", "meadowsunset", "hillsunrise", "greenvalley", "poppysunset"] }).notNull().default("doodle"),
  messageTone: text("message_tone", { enum: ["saba", "noor", "raqs", "aabshar", "sukoon", "none"] }).notNull().default("saba"),
  callTone: text("call_tone", { enum: ["saba", "noor", "raqs", "aabshar", "sukoon", "none"] }).notNull().default("noor"),
  securityNotificationsEnabled: integer("security_notifications_enabled", { mode: "boolean" }).notNull().default(true),
  autoDownloadPhotos: integer("auto_download_photos", { mode: "boolean" }).notNull().default(true),
  autoDownloadVoice: integer("auto_download_voice", { mode: "boolean" }).notNull().default(true),
  conversationTonesEnabled: integer("conversation_tones_enabled", { mode: "boolean" }).notNull().default(true),
  defaultVoiceEffect: text("default_voice_effect", { enum: ["original", "soft", "deep", "bright", "quick", "slow", "chipmunk", "helium", "robot", "monster", "echo", "cave"] }).notNull().default("original"),
  appFont: text("app_font").notNull().default("default"),
  appLockEnabled: integer("app_lock_enabled", { mode: "boolean" }).notNull().default(false),
  appLockMethod: text("app_lock_method", { enum: ["none", "pin", "password", "biometric"] }).notNull().default("none"),
  appLockHash: text("app_lock_hash"),
  appLockSalt: text("app_lock_salt"),
  pinnedThreadIds: text("pinned_thread_ids").notNull().default("[]"),
  mediaVisibilityEnabled: integer("media_visibility_enabled", { mode: "boolean" }).notNull().default(true),
  archivedThreadIds: text("archived_thread_ids").notNull().default("[]"),
  lockedThreadIds: text("locked_thread_ids").notNull().default("[]"),
  mutedThreadIds: text("muted_thread_ids").notNull().default("[]"),
  deletedThreadIds: text("deleted_thread_ids").notNull().default("[]"),
  threadWallpapers: text("thread_wallpapers").notNull().default("{}"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const conversations = sqliteTable("conversations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  contactName: text("contact_name").notNull(),
  contactEmail: text("contact_email"),
  contactUsername: text("contact_username"),
  contactPhotoUrl: text("contact_photo_url"),
  currentUserId: text("current_user_id").notNull(),
  targetUserId: text("target_user_id").notNull(),
  lastMessage: text("last_message"),
  lastMessageType: text("last_message_type", { enum: ["text", "audio", "image"] }),
  lastSenderId: text("last_sender_id"),
  unreadCount: integer("unread_count").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const messages = sqliteTable("messages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  direction: text("direction", { enum: ["self", "contact"] }).notNull(),
  senderId: text("sender_id").notNull(),
  receiverId: text("receiver_id").notNull(),
  messageType: text("message_type", { enum: ["text", "audio", "image"] }).notNull().default("text"),
  audioBlobKey: text("audio_blob_key"),
  audioDuration: integer("audio_duration"),
  voiceEffect: text("voice_effect", { enum: ["original", "soft", "deep", "bright", "quick", "slow", "chipmunk", "helium", "robot", "monster", "echo", "cave"] }).notNull().default("original"),
  unlockAt: integer("unlock_at", { mode: "timestamp_ms" }),
  passwordHash: text("password_hash"),
  passwordSalt: text("password_salt"),
  unlockedAt: integer("unlocked_at", { mode: "timestamp_ms" }),
  mediaBlobKey: text("media_blob_key"),
  deliveryStatus: text("delivery_status", { enum: ["sent", "delivered", "read"] }).notNull().default("sent"),
  readAt: integer("read_at", { mode: "timestamp_ms" }),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const statuses = sqliteTable("statuses", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  body: text("body").notNull(),
  accent: text("accent", { enum: ["teal", "amber", "blue", "rose", "violet", "emerald", "orange", "crimson"] }).notNull(),
  statusType: text("status_type", { enum: ["text", "photo", "video"] }).notNull().default("text"),
  font: text("font"),
  imageBlobKey: text("image_blob_key"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
});

export const blockedContacts = sqliteTable("blocked_contacts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  targetUserId: text("target_user_id").notNull().unique(),
  contactName: text("contact_name").notNull(),
  contactEmail: text("contact_email"),
  contactUsername: text("contact_username"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const chatLists = sqliteTable("chat_lists", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const chatListMembers = sqliteTable("chat_list_members", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  listId: integer("list_id").notNull().references(() => chatLists.id, { onDelete: "cascade" }),
  targetUserId: text("target_user_id").notNull(),
  contactName: text("contact_name").notNull(),
  contactEmail: text("contact_email"),
  contactUsername: text("contact_username"),
});

export const feedback = sqliteTable("feedback", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  body: text("body").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const calls = sqliteTable("calls", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  contactName: text("contact_name").notNull(),
  contactEmail: text("contact_email"),
  callType: text("call_type", { enum: ["audio", "video"] }).notNull(),
  startedAt: integer("started_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});
