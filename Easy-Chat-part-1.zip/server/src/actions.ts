import { defineAction, z, type ActionsModule, type Ctx } from "@hatch/space-sdk";
import { and, asc, desc, eq } from "drizzle-orm";
import * as schema from "./schema";

const profileSchema = z.object({
  display_name: z.string(),
  username: z.string(),
  email: z.string(),
  mobile_number: z.string().nullable(),
  avatar_url: z.string().nullable(),
  about: z.string(),
  notifications_enabled: z.boolean(),
  read_receipts_enabled: z.boolean(),
  language: z.enum(["ur", "en", "hi", "ar", "fa", "ps", "tr", "es", "fr", "de", "pt", "ru", "bn", "id", "ms", "zh", "ja", "ko", "it", "nl", "th", "vi", "sw", "uk", "pl"]),
  use_device_language: z.boolean(),
  theme_mode: z.enum(["system", "light", "dark", "glass"]),
  wallpaper: z.enum(["glass", "doodle", "grid", "plain", "garden", "midnight", "sunset", "ocean", "linen", "terrazzo", "constellation", "waves", "blossom", "forest", "jungle", "meadow", "pinewood", "bamboo", "autumn", "leaves", "waterfall", "lake", "desert", "canyon", "savanna", "skyline", "towers", "citynight", "oldtown", "suburb", "village", "harbor", "bridge", "street", "rooftops", "aurora", "ember", "lagoon", "orchid", "honey", "mist", "coral", "mint", "herringbone", "chevron", "dots", "diamonds", "arcs", "mosaic", "prism", "tiles", "balloons", "seasunset", "desertroad", "beachsunset", "pastelbeach", "flowerbeach", "meadowsunset", "hillsunrise", "greenvalley", "poppysunset"]),
  message_tone: z.enum(["saba", "noor", "raqs", "aabshar", "sukoon", "none"]),
  call_tone: z.enum(["saba", "noor", "raqs", "aabshar", "sukoon", "none"]),
  security_notifications_enabled: z.boolean(),
  auto_download_photos: z.boolean(),
  auto_download_voice: z.boolean(),
  conversation_tones_enabled: z.boolean(),
  default_voice_effect: z.enum(["original", "soft", "deep", "bright", "quick", "slow", "chipmunk", "helium", "robot", "monster", "echo", "cave"]),
  app_font: z.string(),
  app_lock_enabled: z.boolean(),
  app_lock_method: z.enum(["none", "pin", "password", "biometric"]),
  app_lock_hash: z.string().nullable(),
  app_lock_salt: z.string().nullable(),
  pinned_thread_ids: z.array(z.string()),
  media_visibility_enabled: z.boolean(),
  archived_thread_ids: z.array(z.string()),
  locked_thread_ids: z.array(z.string()),
  muted_thread_ids: z.array(z.string()),
  deleted_thread_ids: z.array(z.string()),
  thread_wallpapers: z.record(z.string(), z.string()),
});

const toneSchema = z.enum(["saba", "noor", "raqs", "aabshar", "sukoon", "none"]);

const blockedContactSchema = z.object({
  target_user_id: z.string(), contact_name: z.string(),
  contact_email: z.string().nullable(), contact_username: z.string().nullable(),
});

const chatListSchema = z.object({
  id: z.number(), name: z.string(),
  members: z.array(z.object({
    target_user_id: z.string(), contact_name: z.string(),
    contact_email: z.string().nullable(), contact_username: z.string().nullable(),
  })),
});

const conversationSummarySchema = z.object({
  id: z.number(), contact_name: z.string(), contact_email: z.string().nullable(), contact_username: z.string().nullable(),
  contact_photo_url: z.string().nullable(),
  target_user_id: z.string(),
  last_message: z.string().nullable(), last_message_type: z.enum(["text", "audio", "image"]).nullable(),
  last_sender_id: z.string().nullable(), unread_count: z.number(), updated_at: z.string(),
});

const messageSchema = z.object({
  id: z.number(), body: z.string(), direction: z.enum(["self", "contact"]),
  sender_id: z.string(), receiver_id: z.string(),
  message_type: z.enum(["text", "audio", "image"]), audio_url: z.string().nullable(),
  image_url: z.string().nullable(), delivery_status: z.enum(["sent", "delivered", "read"]),
  audio_duration: z.number().nullable(), voice_effect: z.enum(["original", "soft", "deep", "bright", "quick", "slow", "chipmunk", "helium", "robot", "monster", "echo", "cave"]),
  unlock_at: z.string().nullable(), is_locked: z.boolean(), is_unlocked: z.boolean(), created_at: z.string(),
});

const statusAccentSchema = z.enum(["teal", "amber", "blue", "rose", "violet", "emerald", "orange", "crimson"]);

const statusSchema = z.object({
  id: z.number(), body: z.string(), accent: statusAccentSchema,
  status_type: z.enum(["text", "photo", "video"]), image_url: z.string().nullable(),
  font: z.string().nullable(),
  created_at: z.string(), expires_at: z.string(),
});

const callSchema = z.object({
  id: z.number(), contact_name: z.string(), contact_email: z.string().nullable(),
  call_type: z.enum(["audio", "video"]), started_at: z.string(),
});

const usernameSchema = z.string().trim().regex(/^[A-Za-z0-9_.]{3,30}$/);

function parseIdList(value: string): string[] {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
  } catch { return []; }
}

function parseWallpaperMap(value: string): Record<string, string> {
  try {
    const parsed: unknown = JSON.parse(value);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    return Object.fromEntries(Object.entries(parsed as Record<string, unknown>).filter((entry): entry is [string, string] => typeof entry[1] === "string"));
  } catch { return {}; }
}

async function hashVoicePassword(password: string, salt: string) {
  const bytes = new TextEncoder().encode(`${salt}:${password}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join("");
}

async function getConversationRoute(ctx: Ctx, conversationId: number) {
  const rows = await ctx.db<typeof schema>().select().from(schema.conversations)
    .where(eq(schema.conversations.id, conversationId)).limit(1);
  const conversation = rows[0];
  if (!conversation) throw new Error("Conversation not found");
  return conversation;
}

/* GIPHY responses for the GIF picker. The API key lives only here, on
 * the server: the client asks the searchGifs action and receives just
 * the GIF entries, so the key never ships in the client bundle and
 * never appears in a URL the browser sends, logs or leaks via a
 * referrer. */
const GIPHY_API_KEY = "PDqEB0cQTV0rRzt9CNCHnr7YZjdRwK5Z";
const gifSearchResponse = z.object({
  ok: z.boolean(),
  items: z.array(z.object({ id: z.string(), preview: z.string(), full: z.string(), title: z.string() })),
});

export const Actions = {
  getAppState: defineAction({
    request: z.object({}),
    response: z.object({
      profile: profileSchema.nullable(), conversations: z.array(conversationSummarySchema),
      statuses: z.array(statusSchema), calls: z.array(callSchema),
      blocked_contacts: z.array(blockedContactSchema), chat_lists: z.array(chatListSchema),
    }),
    async handler(ctx) {
      const db = ctx.db<typeof schema>();
      const [profileRows, allConversationRows, statusRows, callRows, blockedRows, listRows, memberRows] = await Promise.all([
        db.select().from(schema.profiles).limit(1),
        db.select().from(schema.conversations).orderBy(desc(schema.conversations.updatedAt)),
        db.select().from(schema.statuses).orderBy(desc(schema.statuses.createdAt)),
        db.select().from(schema.calls).orderBy(desc(schema.calls.startedAt)).limit(50),
        db.select().from(schema.blockedContacts).orderBy(desc(schema.blockedContacts.createdAt)),
        db.select().from(schema.chatLists).orderBy(asc(schema.chatLists.createdAt)),
        db.select().from(schema.chatListMembers),
      ]);
      // Data isolation + self-chat purge. Only rows owned by the current
      // profile are ever returned — another account's rows are invisible
      // here, never inherited. Self-conversations (a chat with yourself)
      // are leftover voice-test data: delete them and their messages for
      // good, so the test chat can never be listed or brought back. The
      // self match covers every identifier form the app has used: the
      // email itself, an "@username" id, and a "local:<name>" id.
      let conversationRows = allConversationRows;
      const ownerProfile = profileRows[0];
      if (ownerProfile) {
        const self = ownerProfile.email.trim().toLocaleLowerCase();
        const selfTargets = new Set([self]);
        if (ownerProfile.username.trim()) selfTargets.add(`@${ownerProfile.username.trim().toLocaleLowerCase()}`);
        if (ownerProfile.displayName.trim()) selfTargets.add(`local:${ownerProfile.displayName.trim().toLocaleLowerCase()}`);
        const ownedRows = allConversationRows.filter((item) => item.currentUserId.trim().toLocaleLowerCase() === self);
        const selfRows = ownedRows.filter((item) => selfTargets.has(item.targetUserId.trim().toLocaleLowerCase()));
        for (const row of selfRows) {
          await db.delete(schema.messages).where(eq(schema.messages.conversationId, row.id));
          await db.delete(schema.conversations).where(eq(schema.conversations.id, row.id));
        }
        conversationRows = ownedRows.filter((item) => !selfRows.includes(item));
      }
      const summaries = conversationRows.map((conversation) => ({
        id: conversation.id,
        contact_name: conversation.contactName,
        contact_email: conversation.contactEmail,
        contact_username: conversation.contactUsername,
        contact_photo_url: conversation.contactPhotoUrl,
        target_user_id: conversation.targetUserId,
        last_message: conversation.lastMessage,
        last_message_type: conversation.lastMessageType,
        last_sender_id: conversation.lastSenderId,
        unread_count: conversation.unreadCount,
        updated_at: conversation.updatedAt.toISOString(),
      }));
      const profile = profileRows[0];
      const now = Date.now();
      return {
        profile: profile ? {
          display_name: profile.displayName, username: profile.username, email: profile.email,
          mobile_number: profile.mobileNumber,
          avatar_url: profile.avatarBlobKey ? await ctx.blobs.getUrl(profile.avatarBlobKey) : null,
          about: profile.about,
          notifications_enabled: profile.notificationsEnabled, read_receipts_enabled: profile.readReceiptsEnabled,
          language: profile.language, use_device_language: profile.useDeviceLanguage, theme_mode: profile.themeMode, wallpaper: profile.wallpaper, message_tone: profile.messageTone,
          call_tone: profile.callTone, security_notifications_enabled: profile.securityNotificationsEnabled,
          auto_download_photos: profile.autoDownloadPhotos, auto_download_voice: profile.autoDownloadVoice,
          conversation_tones_enabled: profile.conversationTonesEnabled, default_voice_effect: profile.defaultVoiceEffect,
          app_font: profile.appFont,
          app_lock_enabled: profile.appLockEnabled, app_lock_method: profile.appLockMethod,
          app_lock_hash: profile.appLockHash, app_lock_salt: profile.appLockSalt,
          pinned_thread_ids: parseIdList(profile.pinnedThreadIds),
          media_visibility_enabled: profile.mediaVisibilityEnabled,
          archived_thread_ids: parseIdList(profile.archivedThreadIds),
          locked_thread_ids: parseIdList(profile.lockedThreadIds),
          muted_thread_ids: parseIdList(profile.mutedThreadIds),
          deleted_thread_ids: parseIdList(profile.deletedThreadIds),
          thread_wallpapers: parseWallpaperMap(profile.threadWallpapers),
        } : null,
        conversations: summaries,
        statuses: await Promise.all(statusRows.filter((item) => item.expiresAt.getTime() > now).map(async (item) => ({
          id: item.id, body: item.body, accent: item.accent,
          status_type: item.statusType,
          image_url: item.imageBlobKey ? await ctx.blobs.getUrl(item.imageBlobKey) : null,
          font: item.font ?? null,
          created_at: item.createdAt.toISOString(), expires_at: item.expiresAt.toISOString(),
        }))),
        calls: callRows.map((item) => ({
          id: item.id, contact_name: item.contactName, contact_email: item.contactEmail,
          call_type: item.callType, started_at: item.startedAt.toISOString(),
        })),
        blocked_contacts: blockedRows.map((item) => ({
          target_user_id: item.targetUserId, contact_name: item.contactName,
          contact_email: item.contactEmail, contact_username: item.contactUsername,
        })),
        chat_lists: listRows.map((list) => ({
          id: list.id, name: list.name,
          members: memberRows.filter((member) => member.listId === list.id).map((member) => ({
            target_user_id: member.targetUserId, contact_name: member.contactName,
            contact_email: member.contactEmail, contact_username: member.contactUsername,
          })),
        })),
      };
    },
  }),

  saveProfile: defineAction({
    request: z.object({ display_name: z.string().trim().min(2).max(60), username: usernameSchema.optional(), email: z.string().trim().email().max(180), mobile_number: z.string().trim().max(24).regex(/^[+0-9][0-9\s-]*$/).optional().or(z.literal("")).or(z.null()), about: z.string().trim().max(120).optional() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const existing = await db.select().from(schema.profiles).limit(1);
      const normalizedEmail = args.email.trim().toLocaleLowerCase();
      const mobileNumber = args.mobile_number === undefined ? undefined : (args.mobile_number ?? "").trim() || null;
      if (existing[0]) {
        await db.update(schema.profiles).set({ displayName: args.display_name, email: normalizedEmail, ...(args.username !== undefined ? { username: args.username } : {}), ...(mobileNumber !== undefined ? { mobileNumber } : {}), ...(args.about !== undefined ? { about: args.about } : {}), updatedAt: new Date() }).where(eq(schema.profiles.id, 1));
        if (existing[0].email.toLocaleLowerCase() !== normalizedEmail) {
          // A different account is being set up: the previous account's
          // data must NEVER be re-owned or shown to it (that silent
          // transfer was the cross-account data leak). The new account
          // starts completely empty — delete the old account's rows and
          // their stored media instead of re-attributing them.
          const [messageRows, statusRows] = await Promise.all([
            db.select().from(schema.messages),
            db.select().from(schema.statuses),
          ]);
          const blobKeys = new Set<string>();
          for (const message of messageRows) {
            if (message.audioBlobKey) blobKeys.add(message.audioBlobKey);
            if (message.mediaBlobKey) blobKeys.add(message.mediaBlobKey);
          }
          for (const status of statusRows) if (status.imageBlobKey) blobKeys.add(status.imageBlobKey);
          for (const key of blobKeys) {
            try { await ctx.blobs.delete(key); } catch { /* blob already gone */ }
          }
          await db.batch([
            db.delete(schema.messages),
            db.delete(schema.conversations),
            db.delete(schema.statuses),
            db.delete(schema.blockedContacts),
            db.delete(schema.chatListMembers),
            db.delete(schema.chatLists),
            db.delete(schema.calls),
            db.delete(schema.feedback),
          ]);
        }
      } else {
        await db.insert(schema.profiles).values({ id: 1, displayName: args.display_name, username: args.username ?? "", email: normalizedEmail, mobileNumber: mobileNumber ?? null, about: args.about || "دستیاب ہوں" });
      }
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  saveProfilePhoto: defineAction({
    request: z.object({
      data_base64: z.string().min(1).max(1_200_000).nullable(),
      mime_type: z.enum(["image/jpeg", "image/png", "image/webp"]).optional(),
    }),
    response: z.object({ avatar_url: z.string().nullable() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const existing = await db.select().from(schema.profiles).limit(1);
      const profile = existing[0];
      if (!profile) throw new Error("Profile not found");
      const oldKey = profile.avatarBlobKey;
      if (args.data_base64 === null) {
        await db.update(schema.profiles).set({ avatarBlobKey: null, updatedAt: new Date() }).where(eq(schema.profiles.id, 1));
        if (oldKey) await ctx.blobs.delete(oldKey);
        ctx.invalidateQueries();
        return { avatar_url: null };
      }
      const binary = atob(args.data_base64);
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      const mimeType = args.mime_type ?? "image/jpeg";
      const ext = mimeType === "image/png" ? "png" : mimeType === "image/webp" ? "webp" : "jpg";
      const key = `avatars/${crypto.randomUUID()}.${ext}`;
      await ctx.blobs.put(key, bytes, { contentType: mimeType });
      await db.update(schema.profiles).set({ avatarBlobKey: key, updatedAt: new Date() }).where(eq(schema.profiles.id, 1));
      if (oldKey) await ctx.blobs.delete(oldKey);
      ctx.invalidateQueries();
      return { avatar_url: await ctx.blobs.getUrl(key) };
    },
  }),

  cacheConversationPhotos: defineAction({
    request: z.object({
      items: z.array(z.object({
        target_user_id: z.string().trim().min(1).max(180),
        contact_photo_url: z.string().max(950_000).nullable(),
      })).max(100),
    }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const profileRows = await db.select().from(schema.profiles).limit(1);
      const profile = profileRows[0];
      if (!profile) return { ok: true };
      const currentUserId = profile.email.trim().toLocaleLowerCase();
      for (const item of args.items) {
        const targetUserId = item.target_user_id.trim().toLocaleLowerCase();
        const rows = await db.select().from(schema.conversations).where(and(
          eq(schema.conversations.currentUserId, currentUserId),
          eq(schema.conversations.targetUserId, targetUserId),
        )).limit(1);
        const row = rows[0];
        if (row && row.contactPhotoUrl !== item.contact_photo_url) {
          await db.update(schema.conversations).set({ contactPhotoUrl: item.contact_photo_url }).where(eq(schema.conversations.id, row.id));
        }
      }
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  saveSettings: defineAction({
    request: z.object({ notifications_enabled: z.boolean(), read_receipts_enabled: z.boolean() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      await db.update(schema.profiles).set({ notificationsEnabled: args.notifications_enabled, readReceiptsEnabled: args.read_receipts_enabled, updatedAt: new Date() }).where(eq(schema.profiles.id, 1));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  savePreferences: defineAction({
    request: z.object({
      language: z.enum(["ur", "en", "hi", "ar", "fa", "ps", "tr", "es", "fr", "de", "pt", "ru", "bn", "id", "ms", "zh", "ja", "ko", "it", "nl", "th", "vi", "sw", "uk", "pl"]),
      use_device_language: z.boolean().optional(),
      theme_mode: z.enum(["system", "light", "dark", "glass"]),
      wallpaper: z.enum(["glass", "doodle", "grid", "plain", "garden", "midnight", "sunset", "ocean", "linen", "terrazzo", "constellation", "waves", "blossom", "forest", "jungle", "meadow", "pinewood", "bamboo", "autumn", "leaves", "waterfall", "lake", "desert", "canyon", "savanna", "skyline", "towers", "citynight", "oldtown", "suburb", "village", "harbor", "bridge", "street", "rooftops", "aurora", "ember", "lagoon", "orchid", "honey", "mist", "coral", "mint", "herringbone", "chevron", "dots", "diamonds", "arcs", "mosaic", "prism", "tiles", "balloons", "seasunset", "desertroad", "beachsunset", "pastelbeach", "flowerbeach", "meadowsunset", "hillsunrise", "greenvalley", "poppysunset"]),
      message_tone: toneSchema,
      call_tone: toneSchema.optional(),
      security_notifications_enabled: z.boolean().optional(),
      auto_download_photos: z.boolean().optional(),
      auto_download_voice: z.boolean().optional(),
      media_visibility_enabled: z.boolean().optional(),
      app_font: z.string().trim().min(1).max(60).optional(),
      default_voice_effect: z.enum(["original", "soft", "deep", "bright", "quick", "slow", "chipmunk", "helium", "robot", "monster", "echo", "cave"]).optional(),
      conversation_tones_enabled: z.boolean(),
    }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      await ctx.db<typeof schema>().update(schema.profiles).set({
        language: args.language,
        ...(args.use_device_language !== undefined ? { useDeviceLanguage: args.use_device_language } : {}),
        themeMode: args.theme_mode,
        wallpaper: args.wallpaper,
        messageTone: args.message_tone,
        ...(args.call_tone !== undefined ? { callTone: args.call_tone } : {}),
        ...(args.security_notifications_enabled !== undefined ? { securityNotificationsEnabled: args.security_notifications_enabled } : {}),
        ...(args.auto_download_photos !== undefined ? { autoDownloadPhotos: args.auto_download_photos } : {}),
        ...(args.auto_download_voice !== undefined ? { autoDownloadVoice: args.auto_download_voice } : {}),
        ...(args.media_visibility_enabled !== undefined ? { mediaVisibilityEnabled: args.media_visibility_enabled } : {}),
        ...(args.app_font !== undefined ? { appFont: args.app_font } : {}),
        ...(args.default_voice_effect !== undefined ? { defaultVoiceEffect: args.default_voice_effect } : {}),
        conversationTonesEnabled: args.conversation_tones_enabled,
        updatedAt: new Date(),
      }).where(eq(schema.profiles.id, 1));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  blockContact: defineAction({
    request: z.object({ target_user_id: z.string().trim().min(1).max(180), contact_name: z.string().trim().min(1).max(80), contact_email: z.string().trim().max(180).nullable(), contact_username: z.string().trim().max(40).nullable() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const target = args.target_user_id.trim().toLocaleLowerCase();
      const existing = await db.select().from(schema.blockedContacts).where(eq(schema.blockedContacts.targetUserId, target)).limit(1);
      if (!existing[0]) {
        await db.insert(schema.blockedContacts).values({ targetUserId: target, contactName: args.contact_name, contactEmail: args.contact_email || null, contactUsername: args.contact_username || null });
      }
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  unblockContact: defineAction({
    request: z.object({ target_user_id: z.string().trim().min(1).max(180) }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      await ctx.db<typeof schema>().delete(schema.blockedContacts).where(eq(schema.blockedContacts.targetUserId, args.target_user_id.trim().toLocaleLowerCase()));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  createChatList: defineAction({
    request: z.object({ name: z.string().trim().min(1).max(40) }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const inserted = await ctx.db<typeof schema>().insert(schema.chatLists).values({ name: args.name }).returning({ id: schema.chatLists.id });
      const row = inserted[0];
      if (!row) throw new Error("List could not be created");
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  deleteChatList: defineAction({
    request: z.object({ id: z.number().int().positive() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      await db.delete(schema.chatListMembers).where(eq(schema.chatListMembers.listId, args.id));
      await db.delete(schema.chatLists).where(eq(schema.chatLists.id, args.id));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  addChatListMember: defineAction({
    request: z.object({ list_id: z.number().int().positive(), target_user_id: z.string().trim().min(1).max(180), contact_name: z.string().trim().min(1).max(80), contact_email: z.string().trim().max(180).nullable(), contact_username: z.string().trim().max(40).nullable() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const target = args.target_user_id.trim().toLocaleLowerCase();
      const existing = await db.select().from(schema.chatListMembers).where(and(eq(schema.chatListMembers.listId, args.list_id), eq(schema.chatListMembers.targetUserId, target))).limit(1);
      if (!existing[0]) {
        await db.insert(schema.chatListMembers).values({ listId: args.list_id, targetUserId: target, contactName: args.contact_name, contactEmail: args.contact_email || null, contactUsername: args.contact_username || null });
      }
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  removeChatListMember: defineAction({
    request: z.object({ list_id: z.number().int().positive(), target_user_id: z.string().trim().min(1).max(180) }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      await ctx.db<typeof schema>().delete(schema.chatListMembers).where(and(eq(schema.chatListMembers.listId, args.list_id), eq(schema.chatListMembers.targetUserId, args.target_user_id.trim().toLocaleLowerCase())));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  saveFeedback: defineAction({
    request: z.object({ body: z.string().trim().min(2).max(2000) }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      await ctx.db<typeof schema>().insert(schema.feedback).values({ body: args.body });
      return { ok: true };
    },
  }),

  createConversation: defineAction({
    request: z.object({ contact_name: z.string().trim().min(2).max(80), contact_username: usernameSchema.optional().or(z.literal("")), contact_email: z.string().trim().email().max(180).optional().or(z.literal("")), contact_photo_url: z.string().max(950_000).nullable().optional() }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const profileRows = await db.select().from(schema.profiles).limit(1);
      const profile = profileRows[0];
      if (!profile) throw new Error("Profile not found");
      const contactEmail = (args.contact_email ?? "").trim().toLocaleLowerCase();
      const contactUsername = (args.contact_username ?? "").trim();
      const currentUserId = profile.email.trim().toLocaleLowerCase();
      const targetUserId = contactUsername ? `@${contactUsername.toLocaleLowerCase()}` : contactEmail || `local:${args.contact_name.trim().toLocaleLowerCase()}`;
      // A conversation with yourself can never be created, in any
      // identifier form (own email, own @username, own name-only entry).
      if (targetUserId === currentUserId
        || (profile.username.trim() && targetUserId === `@${profile.username.trim().toLocaleLowerCase()}`)
        || (targetUserId.startsWith("local:") && targetUserId.slice("local:".length) === profile.displayName.trim().toLocaleLowerCase())) {
        throw new Error("Cannot create a conversation with yourself");
      }
      const existingRows = await db.select().from(schema.conversations).where(and(
        eq(schema.conversations.currentUserId, currentUserId),
        eq(schema.conversations.targetUserId, targetUserId),
      )).limit(1);
      const existing = existingRows[0];
      if (existing) {
        if (args.contact_photo_url !== undefined && args.contact_photo_url !== existing.contactPhotoUrl) {
          await db.update(schema.conversations).set({ contactPhotoUrl: args.contact_photo_url }).where(eq(schema.conversations.id, existing.id));
        }
        return { id: existing.id };
      }
      const inserted = await db.insert(schema.conversations).values({
        contactName: args.contact_name,
        contactEmail: contactEmail || null,
        contactUsername: contactUsername || null,
        contactPhotoUrl: args.contact_photo_url ?? null,
        currentUserId,
        targetUserId,
        unreadCount: 0,
      }).returning({ id: schema.conversations.id });
      const row = inserted[0];
      if (!row) throw new Error("Conversation could not be created");
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  getOrCreateConversationId: defineAction({
    request: z.object({
      current_user_id: z.string().trim().min(1).max(180),
      target_user_id: z.string().trim().min(1).max(180),
      contact_name: z.string().trim().min(2).max(80),
      contact_email: z.string().trim().email().max(180).nullable(),
      contact_photo_url: z.string().max(950_000).nullable().optional(),
    }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const profileRows = await db.select().from(schema.profiles).limit(1);
      const profile = profileRows[0];
      if (!profile) throw new Error("Profile not found");
      const currentUserId = profile.email.trim().toLocaleLowerCase();
      const requestedCurrentUserId = args.current_user_id.trim().toLocaleLowerCase();
      if (requestedCurrentUserId !== currentUserId) throw new Error("Current user does not match the saved profile");
      const targetUserId = args.target_user_id.trim().toLocaleLowerCase();
      // Self-chat guard, every identifier form: own email, own
      // @username, or a name-only "local:" entry carrying the profile's
      // own display name.
      if (targetUserId === currentUserId
        || (profile.username.trim() && targetUserId === `@${profile.username.trim().toLocaleLowerCase()}`)
        || (targetUserId.startsWith("local:") && targetUserId.slice("local:".length) === profile.displayName.trim().toLocaleLowerCase())
        || (args.contact_email && args.contact_email.trim().toLocaleLowerCase() === currentUserId)) {
        throw new Error("Cannot create a conversation with yourself");
      }
      const existingRows = await db.select().from(schema.conversations).where(and(
        eq(schema.conversations.currentUserId, currentUserId),
        eq(schema.conversations.targetUserId, targetUserId),
      )).limit(1);
      const existing = existingRows[0];
      if (existing) {
        if (args.contact_photo_url !== undefined && args.contact_photo_url !== existing.contactPhotoUrl) {
          await db.update(schema.conversations).set({ contactPhotoUrl: args.contact_photo_url }).where(eq(schema.conversations.id, existing.id));
        }
        return { id: existing.id };
      }
      const inserted = await db.insert(schema.conversations).values({
        contactName: args.contact_name,
        contactEmail: args.contact_email,
        contactUsername: targetUserId.startsWith("@") ? targetUserId.slice(1) : null,
        contactPhotoUrl: args.contact_photo_url ?? null,
        currentUserId,
        targetUserId,
        unreadCount: 0,
      }).returning({ id: schema.conversations.id });
      const row = inserted[0];
      if (!row) throw new Error("Conversation could not be created");
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  getConversation: defineAction({
    request: z.object({ id: z.number().int().positive() }),
    response: z.object({ conversation: z.object({ id: z.number(), contact_name: z.string(), contact_email: z.string().nullable(), contact_username: z.string().nullable() }).nullable(), messages: z.array(messageSchema) }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const conversationRows = await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.id)).limit(1);
      const conversation = conversationRows[0];
      if (!conversation) return { conversation: null, messages: [] };
      const messageRows = await db.select().from(schema.messages).where(eq(schema.messages.conversationId, args.id)).orderBy(asc(schema.messages.createdAt), asc(schema.messages.id));
      const mapped = await Promise.all(messageRows.map(async (message) => {
        const hasLock = Boolean(message.unlockAt && message.passwordHash);
        const unlocked = !hasLock || Boolean(message.unlockedAt);
        const audioAvailable = message.audioBlobKey && unlocked;
        return {
          id: message.id, body: message.body, direction: message.direction,
          sender_id: message.senderId, receiver_id: message.receiverId, message_type: message.messageType,
          audio_url: audioAvailable ? await ctx.blobs.getUrl(message.audioBlobKey as string) : null,
          image_url: message.mediaBlobKey ? await ctx.blobs.getUrl(message.mediaBlobKey) : null,
          delivery_status: message.deliveryStatus,
          audio_duration: message.audioDuration, voice_effect: message.voiceEffect,
          unlock_at: message.unlockAt?.toISOString() ?? null,
          is_locked: hasLock && !unlocked,
          is_unlocked: unlocked,
          created_at: message.createdAt.toISOString(),
        };
      }));
      return { conversation: { id: conversation.id, contact_name: conversation.contactName, contact_email: conversation.contactEmail, contact_username: conversation.contactUsername }, messages: mapped };
    },
  }),

  markConversationRead: defineAction({
    request: z.object({ conversation_id: z.number().int().positive() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const profileRows = await db.select().from(schema.profiles).limit(1);
      const showReadReceipts = profileRows[0]?.readReceiptsEnabled ?? true;
      await db.update(schema.messages).set({
        readAt: new Date(),
        ...(showReadReceipts ? { deliveryStatus: "read" as const } : {}),
      }).where(and(eq(schema.messages.conversationId, args.conversation_id), eq(schema.messages.direction, "contact")));
      await db.update(schema.conversations).set({ unreadCount: 0 }).where(eq(schema.conversations.id, args.conversation_id));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  sendMessage: defineAction({
    request: z.object({ conversation_id: z.number().int().positive(), body: z.string().trim().min(1).max(4000), direction: z.enum(["self", "contact"]).default("self") }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const now = new Date();
      const conversation = await getConversationRoute(ctx, args.conversation_id);
      const senderId = args.direction === "self" ? conversation.currentUserId : conversation.targetUserId;
      const receiverId = args.direction === "self" ? conversation.targetUserId : conversation.currentUserId;
      const inserted = await db.insert(schema.messages).values({
        conversationId: args.conversation_id,
        body: args.body,
        direction: args.direction,
        senderId,
        receiverId,
        messageType: "text",
        deliveryStatus: args.direction === "self" ? "delivered" : "sent",
        readAt: args.direction === "self" ? now : null,
        createdAt: now,
      }).returning({ id: schema.messages.id });
      const row = inserted[0];
      if (!row) throw new Error("Message could not be saved");
      await db.update(schema.conversations).set({
        lastMessage: args.body,
        lastMessageType: "text",
        lastSenderId: senderId,
        unreadCount: args.direction === "contact" ? conversation.unreadCount + 1 : conversation.unreadCount,
        updatedAt: now,
      }).where(eq(schema.conversations.id, args.conversation_id));
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  sendVoiceMessage: defineAction({
    request: z.object({
      conversation_id: z.number().int().positive(),
      data_base64: z.string().min(1).max(8_000_000),
      mime_type: z.enum(["audio/webm", "audio/mp4", "audio/ogg"]),
      duration: z.number().int().min(1).max(1800),
      voice_effect: z.enum(["original", "soft", "deep", "bright", "quick", "slow", "chipmunk", "helium", "robot", "monster", "echo", "cave"]).default("original"),
      unlock_delay_seconds: z.number().int().min(0).max(604800).default(0),
      password: z.string().min(4).max(40).optional(),
    }).refine((value) => value.unlock_delay_seconds === 0 || Boolean(value.password), { message: "Password is required for a timed voice message", path: ["password"] }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const now = new Date();
      const conversation = await getConversationRoute(ctx, args.conversation_id);
      const binary = atob(args.data_base64);
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      const ext = args.mime_type === "audio/mp4" ? "m4a" : args.mime_type === "audio/ogg" ? "ogg" : "webm";
      const key = `voice/${crypto.randomUUID()}.${ext}`;
      await ctx.blobs.put(key, bytes, { contentType: args.mime_type });
      const unlockAt = args.unlock_delay_seconds > 0 ? new Date(now.getTime() + args.unlock_delay_seconds * 1000) : null;
      const passwordSalt = unlockAt ? crypto.randomUUID() : null;
      const passwordHash = unlockAt && passwordSalt && args.password ? await hashVoicePassword(args.password, passwordSalt) : null;
      const inserted = await db.insert(schema.messages).values({
        conversationId: args.conversation_id,
        body: "صوتی پیغام",
        direction: "self",
        senderId: conversation.currentUserId,
        receiverId: conversation.targetUserId,
        messageType: "audio",
        audioBlobKey: key,
        audioDuration: args.duration,
        voiceEffect: args.voice_effect,
        unlockAt,
        passwordHash,
        passwordSalt,
        deliveryStatus: unlockAt ? "sent" : "delivered",
        readAt: now,
        createdAt: now,
      }).returning({ id: schema.messages.id });
      const row = inserted[0];
      if (!row) throw new Error("Voice message could not be saved");
      await db.update(schema.conversations).set({
        lastMessage: "صوتی پیغام",
        lastMessageType: "audio",
        lastSenderId: conversation.currentUserId,
        updatedAt: now,
      }).where(eq(schema.conversations.id, args.conversation_id));
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  unlockVoiceMessage: defineAction({
    request: z.object({ message_id: z.number().int().positive(), password: z.string().min(1).max(40) }),
    response: z.object({ status: z.enum(["unlocked", "too_early", "wrong_password"]), unlock_at: z.string().nullable() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.messages).where(eq(schema.messages.id, args.message_id)).limit(1);
      const message = rows[0];
      if (!message || message.messageType !== "audio" || !message.unlockAt || !message.passwordHash || !message.passwordSalt) {
        return { status: "wrong_password" as const, unlock_at: null };
      }
      if (Date.now() < message.unlockAt.getTime()) {
        return { status: "too_early" as const, unlock_at: message.unlockAt.toISOString() };
      }
      const candidate = await hashVoicePassword(args.password, message.passwordSalt);
      if (candidate !== message.passwordHash) {
        return { status: "wrong_password" as const, unlock_at: message.unlockAt.toISOString() };
      }
      await db.update(schema.messages).set({ unlockedAt: new Date(), deliveryStatus: "delivered" }).where(eq(schema.messages.id, args.message_id));
      ctx.invalidateQueries();
      return { status: "unlocked" as const, unlock_at: message.unlockAt.toISOString() };
    },
  }),

  sendImageMessage: defineAction({
    request: z.object({
      conversation_id: z.number().int().positive(),
      data_base64: z.string().min(1).max(12_000_000),
      mime_type: z.enum(["image/jpeg", "image/png", "image/webp"]),
      caption: z.string().trim().max(1000).optional(),
    }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const now = new Date();
      const conversation = await getConversationRoute(ctx, args.conversation_id);
      const binary = atob(args.data_base64);
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      const ext = args.mime_type === "image/png" ? "png" : args.mime_type === "image/webp" ? "webp" : "jpg";
      const key = `images/${crypto.randomUUID()}.${ext}`;
      await ctx.blobs.put(key, bytes, { contentType: args.mime_type });
      const inserted = await db.insert(schema.messages).values({
        conversationId: args.conversation_id,
        body: args.caption || "تصویر",
        direction: "self",
        senderId: conversation.currentUserId,
        receiverId: conversation.targetUserId,
        messageType: "image",
        mediaBlobKey: key,
        deliveryStatus: "delivered",
        readAt: now,
        createdAt: now,
      }).returning({ id: schema.messages.id });
      const row = inserted[0];
      if (!row) throw new Error("Image message could not be saved");
      await db.update(schema.conversations).set({
        lastMessage: args.caption || "تصویر",
        lastMessageType: "image",
        lastSenderId: conversation.currentUserId,
        updatedAt: now,
      }).where(eq(schema.conversations.id, args.conversation_id));
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  createStatus: defineAction({
    request: z.object({ body: z.string().trim().min(1).max(240), accent: statusAccentSchema, font: z.string().trim().min(1).max(60).optional() }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const now = new Date();
      const inserted = await db.insert(schema.statuses).values({ body: args.body, accent: args.accent, statusType: "text", font: args.font ?? null, createdAt: now, expiresAt: new Date(now.getTime() + 24 * 60 * 60 * 1000) }).returning({ id: schema.statuses.id });
      const row = inserted[0];
      if (!row) throw new Error("Status could not be created");
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  createPhotoStatus: defineAction({
    request: z.object({
      data_base64: z.string().min(1).max(12_000_000),
      mime_type: z.enum(["image/jpeg", "image/png", "image/webp"]),
      caption: z.string().trim().max(240).optional(),
    }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const now = new Date();
      const binary = atob(args.data_base64);
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      const ext = args.mime_type === "image/png" ? "png" : args.mime_type === "image/webp" ? "webp" : "jpg";
      const key = `statuses/${crypto.randomUUID()}.${ext}`;
      await ctx.blobs.put(key, bytes, { contentType: args.mime_type });
      const inserted = await db.insert(schema.statuses).values({ body: args.caption ?? "", accent: "teal", statusType: "photo", imageBlobKey: key, createdAt: now, expiresAt: new Date(now.getTime() + 24 * 60 * 60 * 1000) }).returning({ id: schema.statuses.id });
      const row = inserted[0];
      if (!row) throw new Error("Status could not be created");
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  createVideoStatus: defineAction({
    request: z.object({
      data_base64: z.string().min(1).max(16_000_000),
      mime_type: z.enum(["video/mp4", "video/webm", "video/quicktime", "video/3gpp"]),
      caption: z.string().trim().max(240).optional(),
    }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const now = new Date();
      const binary = atob(args.data_base64);
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      const ext = args.mime_type === "video/webm" ? "webm" : args.mime_type === "video/quicktime" ? "mov" : args.mime_type === "video/3gpp" ? "3gp" : "mp4";
      const key = `statuses/${crypto.randomUUID()}.${ext}`;
      await ctx.blobs.put(key, bytes, { contentType: args.mime_type });
      const inserted = await db.insert(schema.statuses).values({ body: args.caption ?? "", accent: "teal", statusType: "video", imageBlobKey: key, createdAt: now, expiresAt: new Date(now.getTime() + 24 * 60 * 60 * 1000) }).returning({ id: schema.statuses.id });
      const row = inserted[0];
      if (!row) throw new Error("Status could not be created");
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  deleteStatus: defineAction({
    request: z.object({ id: z.number().int().positive() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.statuses).where(eq(schema.statuses.id, args.id)).limit(1);
      const row = rows[0];
      await db.delete(schema.statuses).where(eq(schema.statuses.id, args.id));
      if (row?.imageBlobKey) await ctx.blobs.delete(row.imageBlobKey);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  saveAppLock: defineAction({
    request: z.object({
      enabled: z.boolean(),
      method: z.enum(["none", "pin", "password", "biometric"]),
      secret_hash: z.string().trim().max(200).nullable().optional(),
      secret_salt: z.string().trim().max(200).nullable().optional(),
    }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      await db.update(schema.profiles).set({
        appLockEnabled: args.enabled,
        appLockMethod: args.method,
        ...(args.secret_hash !== undefined ? { appLockHash: args.secret_hash } : {}),
        ...(args.secret_salt !== undefined ? { appLockSalt: args.secret_salt } : {}),
        updatedAt: new Date(),
      }).where(eq(schema.profiles.id, 1));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  saveChatOrganization: defineAction({
    request: z.object({
      pinned_thread_ids: z.array(z.string().trim().min(1).max(400)).max(500).optional(),
      archived_thread_ids: z.array(z.string().trim().min(1).max(400)).max(500),
      locked_thread_ids: z.array(z.string().trim().min(1).max(400)).max(500),
      muted_thread_ids: z.array(z.string().trim().min(1).max(400)).max(500),
      deleted_thread_ids: z.array(z.string().trim().min(1).max(400)).max(500),
      thread_wallpapers: z.record(z.string().trim().min(1).max(400), z.string().trim().min(1).max(60)),
    }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      await ctx.db<typeof schema>().update(schema.profiles).set({
        ...(args.pinned_thread_ids !== undefined ? { pinnedThreadIds: JSON.stringify(args.pinned_thread_ids) } : {}),
        archivedThreadIds: JSON.stringify(args.archived_thread_ids),
        lockedThreadIds: JSON.stringify(args.locked_thread_ids),
        mutedThreadIds: JSON.stringify(args.muted_thread_ids),
        deletedThreadIds: JSON.stringify(args.deleted_thread_ids),
        threadWallpapers: JSON.stringify(args.thread_wallpapers),
        updatedAt: new Date(),
      }).where(eq(schema.profiles.id, 1));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  deleteConversation: defineAction({
    request: z.object({ target_user_id: z.string().trim().min(1).max(180) }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const target = args.target_user_id.trim().toLocaleLowerCase();
      const rows = await db.select().from(schema.conversations).where(eq(schema.conversations.targetUserId, target));
      for (const row of rows) {
        await db.delete(schema.messages).where(eq(schema.messages.conversationId, row.id));
        await db.delete(schema.conversations).where(eq(schema.conversations.id, row.id));
      }
      await db.delete(schema.chatListMembers).where(eq(schema.chatListMembers.targetUserId, target));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  deleteAllData: defineAction({
    request: z.object({}),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      // Remove stored media first so no orphan blobs survive the wipe.
      const [profileRows, messageRows, statusRows] = await Promise.all([
        db.select().from(schema.profiles),
        db.select().from(schema.messages),
        db.select().from(schema.statuses),
      ]);
      const blobKeys = new Set<string>();
      for (const profile of profileRows) if (profile.avatarBlobKey) blobKeys.add(profile.avatarBlobKey);
      for (const message of messageRows) {
        if (message.audioBlobKey) blobKeys.add(message.audioBlobKey);
        if (message.mediaBlobKey) blobKeys.add(message.mediaBlobKey);
      }
      for (const status of statusRows) if (status.imageBlobKey) blobKeys.add(status.imageBlobKey);
      for (const key of blobKeys) {
        try { await ctx.blobs.delete(key); } catch { /* blob already gone */ }
      }
      await db.batch([
        db.delete(schema.messages),
        db.delete(schema.conversations),
        db.delete(schema.statuses),
        db.delete(schema.blockedContacts),
        db.delete(schema.chatListMembers),
        db.delete(schema.chatLists),
        db.delete(schema.calls),
        db.delete(schema.feedback),
        db.delete(schema.profiles),
      ]);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  startCall: defineAction({
    request: z.object({ contact_name: z.string().trim().min(1).max(80), contact_email: z.string().trim().email().nullable(), call_type: z.enum(["audio", "video"]) }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const inserted = await db.insert(schema.calls).values({ contactName: args.contact_name, contactEmail: args.contact_email, callType: args.call_type }).returning({ id: schema.calls.id });
      const row = inserted[0];
      if (!row) throw new Error("Call could not be recorded");
      ctx.invalidateQueries();
      return { id: row.id };
    },
  }),

  /* Translate one chat message into the reader's own language. Runs the
   * managed model through ctx.inference — the only model channel a web
   * artifact may use. Stateless: nothing is stored. */
  translateText: defineAction({
    request: z.object({ text: z.string().trim().min(1).max(2000), target_language: z.string().trim().min(2).max(60) }),
    response: z.object({ translated: z.string() }),
    async handler(ctx, args) {
      const result = await ctx.inference.complete(
        `Translate the following chat message into ${args.target_language}. Keep the tone, warmth and meaning of everyday messaging; translate only the message itself.\n\n${args.text}`,
        { schema: z.object({ translated: z.string() }) },
      );
      return { translated: result.translated };
    },
  }),

  /* Voice transcription. The managed inference channel accepts text and
   * images only — this app has no speech-to-text model available to it —
   * so the action honestly reports the feature as unavailable instead of
   * inventing a transcript. The client shows that note under the voice
   * message. When a speech model becomes available to the runtime, this
   * handler is the single place that starts returning real transcripts. */
  transcribeVoice: defineAction({
    request: z.object({ mime_type: z.string().trim().min(1).max(80), language: z.string().trim().min(2).max(60) }),
    response: z.object({ status: z.enum(["ok", "unavailable"]), transcript: z.string() }),
    async handler(): Promise<{ status: "ok" | "unavailable"; transcript: string }> {
      return { status: "unavailable", transcript: "" };
    },
  }),

  /* GIF trending/search for the emoji panel's GIF tab, proxied through
   * the server so the GIPHY API key stays server-side (see the note on
   * gifSearchResponse above). Stateless: nothing is stored; failures
   * report ok:false and the panel shows its usual "couldn't load"
   * note. The media files themselves still load straight from
   * media.giphy.com in the client — those URLs carry no key. */
  searchGifs: defineAction({
    request: z.object({ mode: z.enum(["trending", "search"]), query: z.string().trim().max(120) }),
    response: gifSearchResponse,
    async handler(_ctx, args): Promise<z.infer<typeof gifSearchResponse>> {
      const endpoint = args.mode === "trending" ? "https://api.giphy.com/v1/gifs/trending" : "https://api.giphy.com/v1/gifs/search";
      const params = new URLSearchParams({ api_key: GIPHY_API_KEY, rating: "g", limit: "30", ...(args.mode === "search" ? { q: args.query } : {}) });
      try {
        const response = await fetch(`${endpoint}?${params.toString()}`);
        if (!response.ok) return { ok: false, items: [] };
        const payload = await response.json() as { data?: { id?: unknown; title?: unknown; images?: { fixed_height?: { url?: unknown }; original?: { url?: unknown } } }[] };
        const items: z.infer<typeof gifSearchResponse>["items"] = [];
        for (const entry of payload.data ?? []) {
          const preview = typeof entry.images?.fixed_height?.url === "string" ? entry.images.fixed_height.url : null;
          const full = typeof entry.images?.original?.url === "string" ? entry.images.original.url : preview;
          if (preview && full) items.push({ id: typeof entry.id === "string" ? entry.id : preview, preview, full, title: typeof entry.title === "string" ? entry.title : "GIF" });
        }
        return { ok: true, items };
      } catch {
        return { ok: false, items: [] };
      }
    },
  }),
} satisfies ActionsModule;
