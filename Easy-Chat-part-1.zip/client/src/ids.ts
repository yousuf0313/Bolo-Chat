/* Random id generation that works on EVERY WebView this app ships to.
 *
 * `crypto.randomUUID()` only exists in Chrome 92+ (and other browsers of
 * the same era). A large share of the low-end Android phones Easy Chat
 * runs on carry an Android System WebView that was never updated past
 * the Chrome 60s–80s, where `crypto.randomUUID` is `undefined` — calling
 * it throws a TypeError. Because message ids were minted with it on
 * every single send path, those phones could not send ANY message at
 * all ("the app just doesn't work on my phone"), while newer phones
 * were completely fine.
 *
 * randomId() prefers the native implementation, falls back to
 * `crypto.getRandomValues` (available since Chrome 11) formatted as a
 * v4 UUID, and finally to a time+Math.random id — the shape stays a
 * unique string in every case, which is all the callers rely on. */
export function randomId(): string {
  const cryptoObj = globalThis.crypto;
  if (cryptoObj && typeof cryptoObj.randomUUID === "function") {
    try {
      return cryptoObj.randomUUID();
    } catch {
      /* fall through to the manual generators */
    }
  }
  if (cryptoObj && typeof cryptoObj.getRandomValues === "function") {
    try {
      const bytes = new Uint8Array(16);
      cryptoObj.getRandomValues(bytes);
      bytes[6] = ((bytes[6] ?? 0) & 0x0f) | 0x40; // version 4
      bytes[8] = ((bytes[8] ?? 0) & 0x3f) | 0x80; // variant 10xx
      const hex = Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
      return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
    } catch {
      /* fall through to the last-resort generator */
    }
  }
  // Last resort (no WebCrypto at all): time + random hex. Still unique
  // enough for message ids and one-time salts on a single device.
  const randomPart = () => Math.floor(Math.random() * 0x1_0000_0000).toString(16).padStart(8, "0");
  return `${randomPart()}-${randomPart().slice(0, 4)}-4${randomPart().slice(0, 3)}-${randomPart().slice(0, 4)}-${randomPart()}${randomPart().slice(0, 4)}`;
}
