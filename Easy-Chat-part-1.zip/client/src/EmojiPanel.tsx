import { useEffect, useRef, useState } from "react";
import { fileToBase64 } from "@hatch/space-sdk/client";
import { EMOJI_CATEGORIES, loadEmojiRecents, pushEmojiRecent, searchEmojis } from "./emojiData";
import { BUILTIN_PACKS, loadFavouriteIds, loadMyStickers, loadRecentIds, pushRecentId, saveMySticker, stickerById, stickerSrc, toggleFavouriteId, type StickerDef } from "./stickers";

/* ------------------------------------------------------------------ */
/* GIPHY — GIF search & trending for the GIF tab.                     */
/* Put the GIPHY API key here (one place only):                       */
/* ------------------------------------------------------------------ */
export const GIPHY_API_KEY = "PDqEB0cQTV0rRzt9CNCHnr7YZjdRwK5Z";

export type PanelLabels = {
  searchPlaceholder: string;
  emojiTab: string;
  gifTab: string;
  stickersTab: string;
  keyboard: string;
  recents: string;
  favourites: string;
  myStickers: string;
  createSticker: string;
  gifSetup: string;
  gifFailed: string;
  noResults: string;
  loading: string;
  cropTitle: string;
  backspace: string;
  zoom: string;
  saveSticker: string;
  cancel: string;
  stickerSaveError: string;
  categoryLabels: Record<string, string>;
};

type GifItem = { id: string; preview: string; full: string; title: string };
const GIF_CATEGORIES: { label: string; query: string }[] = [
  { label: "👋 سلام", query: "hi hello wave" },
  { label: "😂 ہاہا", query: "haha funny laugh" },
  { label: "❤️ محبت", query: "love hearts" },
  { label: "😢 اداس", query: "sad crying" },
  { label: "👍 ہاں", query: "yes ok thumbs up" },
  { label: "👎 نہیں", query: "no nope" },
  { label: "😮 واہ", query: "wow amazing shocked" },
  { label: "🙏 شکریہ", query: "thank you thanks" },
  { label: "🎉 مبارک", query: "congratulations celebration" },
  { label: "😡 غصہ", query: "angry mad" },
];

/* The key is a free beta key (100 calls/hour), so trending results
 * are cached for the whole session — reopening the GIF tab must not
 * refetch. Search results are cached per query for the session too. */
const gifSessionCache = new Map<string, GifItem[]>();

async function fetchGifs(mode: "trending" | "search", query: string): Promise<GifItem[]> {
  const cacheKey = `${mode}:${query.trim().toLocaleLowerCase()}`;
  const cached = gifSessionCache.get(cacheKey);
  if (cached) return cached;
  const endpoint = mode === "trending" ? "https://api.giphy.com/v1/gifs/trending" : "https://api.giphy.com/v1/gifs/search";
  const params = new URLSearchParams({ api_key: GIPHY_API_KEY, rating: "g", limit: "30", ...(mode === "search" ? { q: query } : {}) });
  const response = await fetch(`${endpoint}?${params.toString()}`);
  if (!response.ok) throw new Error("giphy");
  const payload = await response.json() as { data?: { id?: unknown; title?: unknown; images?: { fixed_height?: { url?: unknown }; original?: { url?: unknown } } }[] };
  const items: GifItem[] = [];
  for (const entry of payload.data ?? []) {
    const preview = typeof entry.images?.fixed_height?.url === "string" ? entry.images.fixed_height.url : null;
    const full = typeof entry.images?.original?.url === "string" ? entry.images.original.url : preview;
    if (preview && full) items.push({ id: typeof entry.id === "string" ? entry.id : preview, preview, full, title: typeof entry.title === "string" ? entry.title : "GIF" });
  }
  gifSessionCache.set(cacheKey, items);
  return items;
}

/** Square cropper for "Create sticker": drag to position, slider to
 *  zoom, confirm renders a 512×512 transparent-frame PNG (no
 *  background removal). */
function StickerCropper({ source, labels, onDone, onCancel }: { source: string; labels: PanelLabels; onDone: (dataUrl: string) => void; onCancel: () => void }) {
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const drag = useRef<{ startX: number; startY: number; baseX: number; baseY: number } | null>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const FRAME = 264;
  const confirm = () => {
    const image = imageRef.current;
    if (!image || !image.naturalWidth) return;
    const size = 512;
    const canvas = document.createElement("canvas");
    canvas.width = size; canvas.height = size;
    const context = canvas.getContext("2d");
    if (!context) return;
    const baseScale = Math.max(size / image.naturalWidth, size / image.naturalHeight);
    const scale = baseScale * zoom;
    const width = image.naturalWidth * scale;
    const height = image.naturalHeight * scale;
    const ratio = size / FRAME;
    context.drawImage(image, (size - width) / 2 + offset.x * ratio, (size - height) / 2 + offset.y * ratio, width, height);
    onDone(canvas.toDataURL("image/png"));
  };
  return <div className="sticker-cropper">
    <h3>{labels.cropTitle}</h3>
    <div className="crop-frame" style={{ width: FRAME, height: FRAME }}
      onPointerDown={(event) => { drag.current = { startX: event.clientX, startY: event.clientY, baseX: offset.x, baseY: offset.y }; (event.target as HTMLElement).setPointerCapture(event.pointerId); }}
      onPointerMove={(event) => { if (drag.current) setOffset({ x: drag.current.baseX + event.clientX - drag.current.startX, y: drag.current.baseY + event.clientY - drag.current.startY }); }}
      onPointerUp={() => { drag.current = null; }}
      onPointerCancel={() => { drag.current = null; }}>
      <img ref={imageRef} src={source} alt="" draggable={false} style={{ transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})` }}/>
    </div>
    <label className="crop-zoom"><span>{labels.zoom}</span><input type="range" min={1} max={3} step={0.05} value={zoom} onChange={(event) => setZoom(Number(event.target.value))} aria-label={labels.zoom}/></label>
    <div className="sheet-actions"><button type="button" className="text-button" onClick={onCancel}>{labels.cancel}</button><button type="button" className="primary-button" onClick={confirm}>{labels.saveSticker}</button></div>
  </div>;
}

export function EmojiPanel({ labels, onInsertEmoji, onSendGif, onSendSticker, onKeyboard, onBackspace, onNotice }: {
  labels: PanelLabels;
  onInsertEmoji: (emoji: string) => void;
  onSendGif: (dataUrl: string) => void;
  onSendSticker: (sticker: StickerDef) => void;
  onKeyboard: () => void;
  onBackspace: () => void;
  onNotice: (message: string) => void;
}) {
  const [tab, setTabState] = useState<"emoji" | "gif" | "stickers">("emoji");
  const [query, setQuery] = useState("");
  const [recents, setRecents] = useState<string[]>(() => loadEmojiRecents());
  const scrollRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const sectionRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const [gifs, setGifs] = useState<GifItem[]>([]);
  const [gifState, setGifState] = useState<"idle" | "loading" | "error">("idle");
  const [gifBusyId, setGifBusyId] = useState<string | null>(null);
  const gifKeyReady = GIPHY_API_KEY.trim().length > 0;

  const [myStickers, setMyStickers] = useState<StickerDef[]>(() => loadMyStickers());
  const [favouriteIds, setFavouriteIds] = useState<string[]>(() => loadFavouriteIds());
  const [stickerRecentIds, setStickerRecentIds] = useState<string[]>(() => loadRecentIds());
  const [activePack, setActivePack] = useState<string>("calligraphy");
  const [cropSource, setCropSource] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const pressTimer = useRef<number | null>(null);
  const longPressed = useRef(false);

  const loadGifs = (mode: "trending" | "search", term: string) => {
    if (!gifKeyReady) return;
    setGifState("loading");
    void fetchGifs(mode, term).then((items) => { setGifs(items); setGifState("idle"); }).catch(() => setGifState("error"));
  };
  useEffect(() => { if (tab === "gif") loadGifs("trending", ""); }, [tab]);
  useEffect(() => {
    if (tab !== "gif" || !gifKeyReady) return;
    const term = query.trim();
    const timer = window.setTimeout(() => loadGifs(term ? "search" : "trending", term), 450);
    return () => window.clearTimeout(timer);
  }, [query, tab]);

  const pickGif = async (gif: GifItem) => {
    if (gifBusyId) return;
    setGifBusyId(gif.id);
    try {
      const response = await fetch(gif.full);
      if (!response.ok) throw new Error("gif");
      const blob = await response.blob();
      const encoded = await fileToBase64(blob);
      onSendGif(`data:${blob.type || encoded.mimeType || "image/gif"};base64,${encoded.dataBase64}`);
    } catch { onNotice(labels.gifFailed); }
    finally { setGifBusyId(null); }
  };

  const sendSticker = (sticker: StickerDef) => {
    setStickerRecentIds(pushRecentId(sticker.id));
    onSendSticker(sticker);
  };
  const stickerPressStart = (sticker: StickerDef) => {
    longPressed.current = false;
    pressTimer.current = window.setTimeout(() => {
      longPressed.current = true;
      setFavouriteIds(toggleFavouriteId(sticker.id));
    }, 550);
  };
  const stickerPressEnd = (sticker: StickerDef) => {
    if (pressTimer.current !== null) { window.clearTimeout(pressTimer.current); pressTimer.current = null; }
    if (!longPressed.current) sendSticker(sticker);
    longPressed.current = false;
  };
  const stickerButton = (sticker: StickerDef) => <button type="button" key={sticker.id} className="sticker-cell"
    onPointerDown={() => stickerPressStart(sticker)} onPointerUp={() => stickerPressEnd(sticker)} onPointerLeave={() => { if (pressTimer.current !== null) { window.clearTimeout(pressTimer.current); pressTimer.current = null; } }} onContextMenu={(event) => event.preventDefault()}
    aria-label={sticker.label}><img src={stickerSrc(sticker)} alt={sticker.label} draggable={false}/>{favouriteIds.includes(sticker.id) && <span className="sticker-fav" aria-hidden="true">★</span>}</button>;

  const jumpToCategory = (id: string) => {
    const container = scrollRef.current;
    const section = sectionRefs.current[id];
    if (container && section) container.scrollTo({ top: section.offsetTop - container.offsetTop, behavior: "smooth" });
  };

  const emojiGroups = searchEmojis(query);
  const favouriteStickers = favouriteIds.map((id) => stickerById(id, myStickers)).filter((item): item is StickerDef => item !== null);
  const recentStickers = stickerRecentIds.map((id) => stickerById(id, myStickers)).filter((item): item is StickerDef => item !== null);
  const stickerQuery = query.trim().toLocaleLowerCase();
  const packList = [...BUILTIN_PACKS, ...(myStickers.length > 0 ? [{ id: "my", name: labels.myStickers, icon: "⭐", stickers: myStickers }] : [])];
  const visiblePack = packList.find((pack) => pack.id === activePack) ?? packList[0];

  return <div className="emoji-panel">
    <div className="emoji-switcher-row">
      <button type="button" className="emoji-switcher-side" onClick={() => searchInputRef.current?.focus()} aria-label={labels.searchPlaceholder}><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m20.5 20.5-4.8-4.8"/></svg></button>
      <div className="emoji-switcher" role="tablist" aria-label={labels.emojiTab}>
        <button type="button" role="tab" aria-selected={tab === "emoji"} aria-label={labels.emojiTab} className={tab === "emoji" ? "selected" : ""} onClick={() => setTabState("emoji")}><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round"><circle cx="12" cy="12" r="9"/><path d="M8.3 14.2c.9 1.2 2.2 1.9 3.7 1.9s2.8-.7 3.7-1.9"/><path d="M9 9.4h.01M15 9.4h.01" strokeWidth="2.7"/></svg></button>
        <button type="button" role="tab" aria-selected={tab === "gif"} aria-label={labels.gifTab} className={tab === "gif" ? "selected" : ""} onClick={() => setTabState("gif")}><span className="emoji-switcher-gif">GIF</span></button>
        <button type="button" role="tab" aria-selected={tab === "stickers"} aria-label={labels.stickersTab} className={tab === "stickers" ? "selected" : ""} onClick={() => setTabState("stickers")}><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M7.5 3h6L21 10.5V20a1.5 1.5 0 0 1-1.5 1.5H7.5A4.5 4.5 0 0 1 3 17V7.5A4.5 4.5 0 0 1 7.5 3Z"/><path d="M21 10.5h-5A2.5 2.5 0 0 1 13.5 8V3"/></svg></button>
      </div>
      <button type="button" className="emoji-switcher-side" onClick={onBackspace} aria-label={labels.backspace}><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M9.5 4.5H20a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H9.5L3 12l6.5-7.5Z"/><path d="m12 9 5 6M17 9l-5 6"/></svg></button>
    </div>
    <div className="emoji-panel-head">
      <label className="emoji-search"><span className="sr-only">{labels.searchPlaceholder}</span><input ref={searchInputRef} value={query} onChange={(event) => setQuery(event.target.value)} placeholder={labels.searchPlaceholder} aria-label={labels.searchPlaceholder}/></label>
      <button type="button" className="icon-button emoji-keyboard-button" onClick={onKeyboard} aria-label={labels.keyboard}><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><rect x="2.5" y="6" width="19" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M6 14h.01M18 14h.01M9 14h6"/></svg></button>
    </div>

    {tab === "emoji" && <>
      <div className="emoji-scroll" ref={scrollRef}>
        {query.trim() === "" && recents.length > 0 && <div className="emoji-section"><h4>{labels.recents}</h4><div className="emoji-grid-panel">{recents.map((emoji) => <button type="button" key={`recent-${emoji}`} onClick={() => { setRecents(pushEmojiRecent(emoji)); onInsertEmoji(emoji); }} aria-label={emoji}>{emoji}</button>)}</div></div>}
        {emojiGroups.length === 0 && <p className="picker-empty">{labels.noResults}</p>}
        {emojiGroups.map(({ category, emojis }) => <div className="emoji-section" key={category.id} ref={(element) => { sectionRefs.current[category.id] = element; }}><h4>{labels.categoryLabels[category.id] ?? category.label}</h4><div className="emoji-grid-panel">{emojis.map((emoji) => <button type="button" key={`${category.id}-${emoji}`} onClick={() => { setRecents(pushEmojiRecent(emoji)); onInsertEmoji(emoji); }} aria-label={emoji}>{emoji}</button>)}</div></div>)}
      </div>
      <div className="emoji-category-bar">{EMOJI_CATEGORIES.map((category) => <button type="button" key={category.id} onClick={() => jumpToCategory(category.id)} aria-label={labels.categoryLabels[category.id] ?? category.label}>{category.icon}</button>)}</div>
    </>}

    {tab === "gif" && <div className="gif-wrap">
      <div className="gif-chips">{GIF_CATEGORIES.map((chip) => <button type="button" key={chip.query} onClick={() => { setQuery(""); loadGifs("search", chip.query); }}>{chip.label}</button>)}</div>
      {!gifKeyReady ? <div className="gif-setup"><p>{labels.gifSetup}</p><p className="powered-by">Powered by GIPHY</p></div>
        : gifState === "loading" ? <p className="picker-empty">{labels.loading}</p>
        : gifState === "error" ? <p className="picker-empty">{labels.gifFailed}</p>
        : gifs.length === 0 ? <p className="picker-empty">{labels.noResults}</p>
        : <><div className="gif-grid">{gifs.map((gif) => <button type="button" key={gif.id} className="gif-cell" onClick={() => void pickGif(gif)} disabled={gifBusyId !== null} aria-label={gif.title}><img src={gif.preview} alt={gif.title} loading="lazy"/>{gifBusyId === gif.id && <span className="gif-busy">{labels.loading}</span>}</button>)}</div><p className="powered-by">Powered by GIPHY</p></>}
    </div>}

    {tab === "stickers" && <div className="stickers-wrap">
      {cropSource ? <StickerCropper source={cropSource} labels={labels} onCancel={() => setCropSource(null)} onDone={(dataUrl) => {
        const saved = saveMySticker(dataUrl);
        if (saved) { setMyStickers(saved); setActivePack("my"); setCropSource(null); }
        else onNotice(labels.stickerSaveError);
      }}/>
      : <>
        <div className="stickers-scroll">
          <div className="emoji-section"><h4>{labels.createSticker}</h4><div className="sticker-grid"><button type="button" className="sticker-create-tile" onClick={() => fileRef.current?.click()} aria-label={labels.createSticker}><span aria-hidden="true">＋</span><small>{labels.createSticker}</small></button>
          {visiblePack && (stickerQuery ? visiblePack.stickers.filter((sticker) => sticker.label.toLocaleLowerCase().includes(stickerQuery)) : visiblePack.stickers).map(stickerButton)}</div></div>
          {stickerQuery === "" && favouriteStickers.length > 0 && <div className="emoji-section"><h4>{labels.favourites}</h4><div className="sticker-grid">{favouriteStickers.map(stickerButton)}</div></div>}
          {stickerQuery === "" && recentStickers.length > 0 && <div className="emoji-section"><h4>{labels.recents}</h4><div className="sticker-grid">{recentStickers.map(stickerButton)}</div></div>}
        </div>
        <div className="sticker-pack-strip">{packList.map((pack) => <button type="button" key={pack.id} className={visiblePack?.id === pack.id ? "selected" : ""} onClick={() => setActivePack(pack.id)} aria-label={pack.name} aria-pressed={visiblePack?.id === pack.id}><span aria-hidden="true">{pack.icon}</span><small>{pack.name}</small></button>)}</div>
      </>}
      <input ref={fileRef} className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => { const file = event.target.files?.[0]; event.currentTarget.value = ""; if (!file) return; const reader = new FileReader(); reader.onload = () => setCropSource(String(reader.result)); reader.readAsDataURL(file); }}/>
    </div>}
  </div>;
}
