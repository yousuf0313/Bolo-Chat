/* Categorized emoji catalogue for the composer's emoji panel.
 * Emojis are stored as space-separated strings per category and split
 * at runtime. The name map gives the common emojis searchable English
 * keywords (search also matches the emoji itself and category names). */

export type EmojiCategory = { id: string; label: string; icon: string; emojis: string[] };

function split(value: string): string[] {
  return value.split(/\s+/).filter(Boolean);
}

export const EMOJI_CATEGORIES: EmojiCategory[] = [
  {
    id: "smileys", label: "Smileys & People", icon: "😀",
    emojis: split("😀 😁 😂 🤣 😃 😄 😅 😆 😉 😊 😋 😎 😍 😘 🥰 😗 😙 😚 🙂 🤗 🤩 🤔 🤨 😐 😑 😶 🙄 😏 😣 😥 😮 🤐 😯 😪 😫 🥱 😴 😌 😛 😜 😝 🤪 😒 😓 😔 😕 🙃 😉 😲 ☹️ 🙁 😖 😞 😟 😤 😢 😭 😦 😧 😨 😩 🤯 😬 😰 😱 🥵 🥶 😳 🤪 😵 😡 😠 🤬 😷 🤒 🤕 🤢 🤮 🤧 😇 🥳 🥺 🤠 🤡 🤥 🤫 🤭 🧐 🤓 😈 👿 💀 ☠️ 👻 👽 🤖 💩 😺 😸 😹 😻 😼 😽 🙀 😿 😾 👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 👍 👎 ✊ 👊 👏 🙌 👐 🤲 🤝 🤲 🙏 💪 🦶 👂 👃 🧠 🦷 👀 👁️ 💋 💘 💝"),
  },
  {
    id: "animals", label: "Animals & Nature", icon: "🐶",
    emojis: split("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🪱 🦋 🐌 🐞 🐜 🦟 🪰 🕷️ 🦂 🐢 🐍 🦎 🐙 🦑 🦐 🦞 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🦧 🐘 🦛 🦏 🐪 🐫 🦒 🦘 🦬 🐃 🐄 🐎 🐖 🐏 🐑 🦙 🐐 🦌 🐕 🐩 🦮 🐈 🐓 🦃 🦚 🦜 🦢 🦩 🕊️ 🐇 🦝 🦨 🦡 🦦 🦥 🐁 🐀 🐿️ 🦔 🌸 🌼 🌻 🌹 🌷 🌺 🌴 🌲 🌳 🍀 🍁 🍂 🍃 🌵 🌾 🌿 ☘️ 🪴"),
  },
  {
    id: "food", label: "Food & Drink", icon: "🍔",
    emojis: split("🍇 🍉 🍊 🍋 🍌 🍍 🥭 🍎 🍏 🍐 🍑 🍒 🍓 🫐 🥝 🍅 🫒 🥥 🥑 🍆 🥔 🥕 🌽 🌶️ 🫑 🥒 🥬 🥦 🧄 🧅 🍄 🥜 🌰 🍞 🥐 🥖 🫓 🥨 🥯 🥞 🧇 🧀 🍖 🍗 🥩 🥓 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🫔 🥙 🧆 🥚 🍳 🥘 🍲 🫕 🥣 🥗 🍿 🧈 🧂 🥫 🍱 🍘 🍙 🍚 🍛 🍜 🍝 🍠 🍢 🍣 🍤 🍥 🥮 🍡 🥟 🥠 🥡 🍦 🍧 🍨 🍩 🍪 🎂 🍰 🧁 🥧 🍫 🍬 🍭 🍮 🍯 🍼 🥛 ☕ 🫖 🍵 🍶 🍾 🍷 🍸 🍹 🍺 🍻 🥂 🥃 🫗 🥤 🧋 🧃 🧉 🍽️ 🍴 🥄 🔪"),
  },
  {
    id: "activity", label: "Activity", icon: "⚽",
    emojis: split("⚽ 🏀 🏈 ⚾ 🥎 🎾 🏐 🏉 🥏 🎱 🪀 🏓 🏸 🏒 🏑 🥍 🏏 🪃 🥅 ⛳ ⛹️ 🏋️ 🚴 🤸 🤽 🤾 🧘 🏄 🚣 🏊 🧗 🚵 🎽 👟 🥊 🥋 🎯 🎮 🕹️ 🎲 🧩 🃏 🎴 🎨 🎭 🎤 🎧 🎼 🎹 🎸 🎻 🎺 🎷 🥁 🪘 🎬 🏆 🥇 🥈 🥉 🏅 🎖️ 🏵️ 🎗️ 🎫 🎟️"),
  },
  {
    id: "travel", label: "Travel & Places", icon: "🚗",
    emojis: split("🚗 🚕 🚙 🚌 🚎 🏎️ 🚓 🚑 🚒 🚐 🛻 🚚 🚛 🚜 🦽 🦼 🛴 🚲 🛵 🏍️ 🛺 🚨 🚔 🚍 🚘 🚖 🚡 🚠 🚟 🚃 🚋 🚞 🚝 🚄 🚅 🚈 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🪂 💺 🚁 🛸 🚀 🛰️ 🛎️ 🧳 ⌛ ⏰ ⌚ 🗺️ 🧭 🏠 🏡 🏢 🏣 🏤 🏥 🏦 🏨 🏪 🏫 🏬 🏭 🏯 🏰 💒 🗼 🗽 ⛪ 🕌 🛕 🕍 ⛩️ 🕋 ⛲ ⛺ 🌁 ⛺ 🌃 🌄 🌅 🌆 🌇 🌉 ♨️ 🎠 🎡 🎢 🚂 🌋 🗻 ⛺ 🏕️ 🏖️ 🏜️ 🏝️ 🏞️ 🏟️ ⛷️ 🏂 🪁"),
  },
  {
    id: "objects", label: "Objects", icon: "💡",
    emojis: split("⌚ 📱 📲 💻 ⌨️ 🖥️ 🖨️ 🖱️ 🖲️ 🕹️ 🗜️ 💽 💾 💿 📀 📷 📸 📹 🎥 📽️ 🎞️ 📞 ☎️ 📟 📠 🔋 🔌 💡 🔦 🕯️ 🪔 🧯 🛢️ 💸 💵 💴 💶 💷 💰 💳 💎 ⚖️ 🧰 🔧 🔨 ⚒️ 🛠️ ⛏️ 🔩 ⚙️ 🧲 🔫 💣 🔪 🗡️ ⚔️ 🛡️ 🚬 ⚰️ ⚱️ 🏺 🔮 📿 🧿 💈 ⚗️ 🔭 🔬 🕳️ 🩹 🩺 💊 💉 🩸 🧬 🦠 🧫 🧪 🌡️ 🧹 🧺 🧻 🚽 🚰 🚿 🛁 🛀 🧼 🪥 🪒 🧽 🧴 🛎️ 🔑 🗝️ 🚪 🪑 🛋️ 🛏️ 🛌 🧸 🖼️ 🛍️ 🛒 🎁 🎈 🎏 🎀 🪄 🪅 🎊 🎉 🎎 🏮 🎐 🧧 ✉️ 📩 📨 📧 💌 📥 📤 📦 🏷️ 📪 📫 📬 📭 📫 📮 🗳️ ✏️ ✒️ 🖋️ 🖊️ 🖌️ 🖍️ 📝 ✂️ 📌 📍 📎 🖇️ 📏 📐 🗂️ 🗃️ 🗄️ 🗑️ 🔒 🔓 🔏 🔐 🔑 🛡️"),
  },
  {
    id: "symbols", label: "Symbols", icon: "❤️",
    emojis: split("❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ☮️ ✝️ ☪️ 🕉️ ✡️ 🔯 🕎 ☯️ ☦️ 🛐 ♈ ♉ ♊ ♋ ♌ ♍ ♎ ♏ ♐ ♑ ♒ ♓ ⛎ 🔀 🔁 🔂 ▶️ ⏩ ⏭️ ⏯️ ⏮️ ⏸️ ⏹️ ⏺️ ⏏️ 🎦 🔅 🔆 📶 📳 📴 ♀️ ♂️ ⚧ ⚕️ ♾️ ♻️ ⚜️ 🔱 📛 🔰 ⭕ ✅ ☑️ ✔️ ❌ ❎ ➕ ➖ ➗ ➰ ➿ 〽️ ✳️ ✴️ ❇️ ‼️ ⁉️ ❓ ❔ ❕ ❗ 〰️ ⚠️ 🚸 🔞 📵 🚯 🚱 🚳 🚷 🔕 🔔 🔇 🔊 🔉 🔈 💤 💢 💬 💭 🗯️ ♠️ ♣️ ♥️ ♦️ 🃏 🎴 🕐 🕑 🕒 🕓 🕔 🕕 🕖 🕗 🕘 🕙 🕚 🕛 ✨ ⭐ 🌟 💫 ✅ 💯"),
  },
  {
    id: "flags", label: "Flags", icon: "🏳️",
    emojis: split("🏳️ 🏴 🏁 🚩 🏳️‍🌈 🏳️‍⚧️ 🏴‍☠️ 🇵🇰 🇮🇳 🇧🇩 🇦🇫 🇮🇷 🇮🇶 🇸🇦 🇦🇪 🇶🇦 🇰🇼 🇴🇲 🇹🇷 🇪🇬 🇵🇸 🇯🇴 🇱🇧 🇸🇾 🇾🇪 🇧🇭 🇱🇾 🇸🇩 🇲🇦 🇩🇿 🇹🇳 🇲🇾 🇮🇩 🇧🇳 🇲🇻 🇬🇧 🇺🇸 🇨🇦 🇦🇺 🇩🇪 🇫🇷 🇮🇹 🇪🇸 🇵🇹 🇳🇱 🇧🇪 🇨🇭 🇦🇹 🇸🇪 🇳🇴 🇩🇰 🇫🇮 🇵🇱 🇷🇺 🇺🇦 🇨🇳 🇯🇵 🇰🇷 🇹🇭 🇻🇳 🇵🇭 🇸🇬 🇲🇲 🇱🇰 🇳🇵 🇧🇹 🇦🇿 🇰🇿 🇺🇿 🇹🇲 🇰🇬 🇹🇯 🇬🇪 🇦🇲"),
  },
];

/** Search keywords for the most common emojis. */
export const EMOJI_NAMES: Record<string, string> = {
  "😀": "grinning face smile happy", "😁": "beaming smile teeth", "😂": "joy laugh tears funny haha", "🤣": "rofl laughing rolling", "😃": "smiley happy open mouth", "😄": "smile happy eyes", "😅": "sweat smile nervous", "😆": "laughing squint", "😉": "wink flirt", "😊": "blush smile happy", "😋": "yum tasty food delicious", "😎": "cool sunglasses", "😍": "heart eyes love crush", "😘": "kiss love blow", "🥰": "hearts love smiling", "😗": "kiss whistling", "🙂": "slight smile ok", "🤗": "hug hugging", "🤩": "star struck wow excited", "🤔": "thinking hmm", "🤨": "raised eyebrow sceptical", "😐": "neutral straight face", "😑": "expressionless blank", "😶": "no mouth speechless", "🙄": "eye roll annoyed", "😏": "smirk smug", "😣": "persevere struggle", "😥": "sad relieved disappointed", "😮": "surprised open mouth wow", "🤐": "zipper mouth quiet secret", "😯": "hushed surprised", "😪": "sleepy tired", "😫": "tired exhausted", "🥱": "yawn tired bored", "😴": "sleep sleeping zzz", "😌": "relieved content", "😛": "tongue out cheeky", "😜": "wink tongue silly", "😝": "tongue squint playful", "🤪": "zany crazy silly", "😒": "unamused annoyed", "😓": "sweat sad downcast", "😔": "pensive sad thoughtful", "😕": "confused unsure", "🙃": "upside down silly", "😲": "astonished shocked", "☹️": "frown sad", "🙁": "slight frown sad", "😖": "confounded frustrated", "😞": "disappointed sad", "😟": "worried anxious", "😤": "triumph proud steam", "😢": "cry sad tear", "😭": "loud cry sob sad", "😦": "frown open mouth", "😧": "anguished", "😨": "fear scared", "😩": "weary tired fed up", "🤯": "exploding head mind blown", "😬": "grimace awkward", "😰": "anxious sweat worried", "😱": "scream fear shocked", "🥵": "hot face heat", "🥶": "cold freezing", "😳": "flushed embarrassed", "😵": "dizzy dead", "😡": "rage angry red", "😠": "angry mad", "🤬": "swearing cursing angry", "😷": "mask sick doctor", "🤒": "thermometer sick ill", "🤕": "bandage hurt injured", "🤢": "nauseated sick green", "🤮": "vomit sick throw up", "🤧": "sneeze sick tissue", "😇": "angel halo innocent", "🥳": "party celebrate birthday", "🥺": "pleading puppy eyes please", "🤠": "cowboy hat", "🤡": "clown funny", "🤥": "lying pinocchio", "🤫": "shush quiet secret", "🤭": "giggle oops hand mouth", "🧐": "monocle curious", "🤓": "nerd glasses geek", "😈": "devil purple evil", "👿": "imp angry devil", "💀": "skull death dead", "☠️": "skull crossbones poison", "👻": "ghost halloween boo", "👽": "alien ufo", "🤖": "robot machine", "💩": "poop funny",
  "👋": "wave hand hello hi bye", "🤚": "raised hand stop", "✋": "hand stop high five", "🖖": "vulcan salute spock", "👌": "ok hand perfect", "✌️": "peace victory", "🤞": "crossed fingers luck hope", "🤟": "love you gesture", "🤘": "rock metal horns", "👈": "point left", "👉": "point right", "👆": "point up", "👇": "point down", "👍": "thumbs up yes like good approve", "👎": "thumbs down no dislike", "✊": "fist power", "👊": "fist bump punch", "👏": "clap applause bravo", "🙌": "raised hands praise celebrate", "👐": "open hands hug", "🤲": "palms up prayer dua", "🤝": "handshake deal agreement", "🙏": "pray please thanks namaste dua", "💪": "muscle strong bicep gym",
  "❤️": "red heart love", "🧡": "orange heart love", "💛": "yellow heart love", "💚": "green heart love", "💙": "blue heart love", "💜": "purple heart love", "🖤": "black heart", "🤍": "white heart pure", "🤎": "brown heart", "💔": "broken heart sad", "💕": "two hearts love", "💞": "revolving hearts love", "💓": "beating heart love", "💗": "growing heart love", "💖": "sparkling heart love", "💘": "heart arrow cupid love", "💝": "heart ribbon gift love", "💟": "heart decoration love", "☮️": "peace symbol", "✝️": "cross christian", "☪️": "star crescent islam muslim", "🕉️": "om hindu", "☯️": "yin yang balance", "🕌": "mosque masjid islam", "🕋": "kaaba makkah islam hajj",
  "🔥": "fire hot lit flame", "✨": "sparkles shiny new magic", "⭐": "star favourite", "🌟": "glowing star", "💫": "dizzy star", "💯": "hundred points score perfect", "💢": "anger symbol mad", "💤": "zzz sleep", "🎉": "party popper celebrate tada", "🎊": "confetti ball celebrate party", "🎁": "gift present birthday", "🏆": "trophy winner champion", "🥇": "gold medal first winner", "⚽": "football soccer sport ball", "🏏": "cricket sport bat ball", "🏀": "basketball sport", "🎾": "tennis sport", "🚗": "car automobile drive", "✈️": "airplane flight travel plane", "🏠": "house home", "📱": "mobile phone smartphone", "💰": "money bag rich dollars", "📚": "books study read", "☕": "coffee tea hot drink", "🍕": "pizza food", "🌹": "rose flower love", "💐": "bouquet flowers", "🌙": "crescent moon night ramadan", "☀️": "sun sunny day", "🌧️": "rain cloud weather", "❄️": "snowflake cold winter", "✅": "check mark done yes tick", "❌": "cross mark no wrong", "❓": "question mark help", "👀": "eyes looking watch", "🦁": "lion animal king", "🐱": "cat animal kitty", "🐶": "dog animal puppy", "🐴": "horse animal", "🦄": "unicorn magic", "🦋": "butterfly insect", "🌸": "cherry blossom flower spring", "🌴": "palm tree tropical", "🍎": "apple fruit red", "🍌": "banana fruit", "🍇": "grapes fruit", "🍓": "strawberry fruit berry", "🥭": "mango fruit", "🍔": "burger hamburger fast food", "🍟": "fries fast food", "🌙 ": "moon night",
};

const RECENTS_KEY = "easy-chat-emoji-recents-v1";
export function loadEmojiRecents(): string[] {
  try {
    const parsed: unknown = JSON.parse(window.localStorage.getItem(RECENTS_KEY) ?? "[]");
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string").slice(0, 32) : [];
  } catch { return []; }
}
export function pushEmojiRecent(emoji: string): string[] {
  const next = [emoji, ...loadEmojiRecents().filter((item) => item !== emoji)].slice(0, 32);
  try { window.localStorage.setItem(RECENTS_KEY, JSON.stringify(next)); } catch { /* storage full/unavailable */ }
  return next;
}

/** Search across names, the emoji characters themselves and categories. */
export function searchEmojis(query: string): { category: EmojiCategory; emojis: string[] }[] {
  const term = query.trim().toLocaleLowerCase();
  if (!term) return EMOJI_CATEGORIES.map((category) => ({ category, emojis: category.emojis }));
  return EMOJI_CATEGORIES.map((category) => {
    const inCategory = category.label.toLocaleLowerCase().includes(term);
    const emojis = category.emojis.filter((emoji) => inCategory || emoji.includes(term) || (EMOJI_NAMES[emoji] ?? "").includes(term));
    return { category, emojis };
  }).filter((group) => group.emojis.length > 0);
}
