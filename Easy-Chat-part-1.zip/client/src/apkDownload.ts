import { Directory, Filesystem } from "@capacitor/filesystem";
import { FileTransfer, type FileTransferError } from "@capacitor/file-transfer";
import { FileOpener } from "@capawesome-team/capacitor-file-opener";
import { isNativeApp } from "./nativeBiometric";

/* In-app APK download for the update dialog.
 *
 * Diagnosis of the "download could not be completed" failure (phone
 * screenshot, v1.0.55 trying to fetch v1.0.56 on working 4G):
 *
 *  1. The dialog threw away the real error. `startDownload` caught
 *     every rejection with a bare `catch {}` and showed the single
 *     generic line ("Check your internet connection…") for DNS
 *     failures, HTTP errors, timeouts and disk problems alike. The
 *     user's internet was fine — the message was simply wrong.
 *  2. The mechanism itself was the deprecated one. Downloads ran
 *     through `Filesystem.downloadFile`, which @capacitor/filesystem
 *     v8 marks `@Deprecated("Use @capacitor/file-transfer plugin
 *     instead")`. Its Android implementation is a legacy
 *     HttpURLConnection copy loop that reads `connection.inputStream`
 *     without ever checking the HTTP response code, copies through a
 *     1 KB buffer, sets no connect/read timeouts of its own, and
 *     rejects with nothing but "Error downloading file: <message>".
 *     The update URL is GitHub's `browser_download_url`, which answers
 *     with a 302 redirect to a signed CDN URL — exactly the kind of
 *     chain this legacy path handles worst and reports worst.
 *
 * The download now goes through @capacitor/file-transfer (the plugin
 * Capacitor itself points to): on native it streams the response
 * straight to a file on disk (redirects followed by the native HTTP
 * stack, no blob held in memory or pushed over the bridge), reports
 * throttled progress events, enforces explicit connect/read timeouts,
 * checks the HTTP status, and rejects with a structured
 * FileTransferError (`error.data`: code, httpStatus, exception). The
 * saved file is verified with `stat` before success is declared, so a
 * truncated body or an error page can never pose as a finished APK.
 *
 * Every failure is classified into an `ApkDownloadError` kind, and the
 * dialog shows the matching plain-language reason (see App.tsx) with
 * the Download button still in place for an immediate retry. */

export type DownloadedApk = {
  /** Native file URI of the saved APK (native only). */
  uri: string | null;
  /** Object URL of the downloaded Blob (web only). */
  blobUrl: string | null;
  fileName: string;
};

/** Why a download failed, in terms the dialog can explain plainly. */
export type ApkDownloadErrorKind = "offline" | "timeout" | "http" | "storage" | "bad-file" | "unknown";

export class ApkDownloadError extends Error {
  readonly kind: ApkDownloadErrorKind;
  readonly httpStatus: number | null;
  /** Short technical detail (native exception / plugin code) kept for
   * support; the dialog shows the kind's plain-language message. */
  readonly detail: string | null;
  constructor(kind: ApkDownloadErrorKind, options?: { httpStatus?: number | null; detail?: string | null }) {
    super(`APK download failed (${kind})`);
    this.name = "ApkDownloadError";
    this.kind = kind;
    this.httpStatus = options?.httpStatus ?? null;
    this.detail = options?.detail ?? null;
  }
}

/** Smallest plausible size for the real APK (~12 MB today). Anything
 * at or below this is an error page or a truncated body, not an APK. */
const MIN_APK_BYTES = 100_000;
const CONNECT_TIMEOUT_MS = 30_000;
/** Read timeout is an idle timeout — it resets whenever data arrives,
 * so a slow-but-alive 4G download is never killed mid-stream. */
const READ_TIMEOUT_MS = 60_000;

type RawTransferError = { message?: unknown; code?: unknown; data?: unknown };

/** Classify a rejected transfer into a dialog-explainable kind. The
 * native plugin reports HTTP failures through `error.data.httpStatus`
 * and everything else through a plugin code + exception string. */
function classifyDownloadError(error: unknown): ApkDownloadError {
  if (error instanceof ApkDownloadError) return error;
  const raw = (typeof error === "object" && error !== null ? error : {}) as RawTransferError;
  const data = (typeof raw.data === "object" && raw.data !== null ? raw.data : {}) as Partial<FileTransferError>;
  const httpStatus = typeof data.httpStatus === "number" ? data.httpStatus : null;
  if (httpStatus !== null) {
    return new ApkDownloadError("http", { httpStatus, detail: data.exception ?? data.message ?? null });
  }
  const haystack = [raw.message, raw.code, data.code, data.message, data.exception]
    .filter((part): part is string => typeof part === "string")
    .join(" ");
  if (/timed?\s?out|timeout|ETIMEDOUT|aborted/i.test(haystack)) {
    return new ApkDownloadError("timeout", { detail: haystack || null });
  }
  if (/no space|enospc|permission|denied|security|read-only|cannot create|can not create/i.test(haystack)) {
    return new ApkDownloadError("storage", { detail: haystack || null });
  }
  if (/unable to resolve host|unknownhost|no address associated|failed to connect|connection|network|unreachable|ssl|handshake|certificate|certpath|econn|enotfound|internet/i.test(haystack)) {
    return new ApkDownloadError("offline", { detail: haystack || null });
  }
  return new ApkDownloadError("unknown", { detail: haystack || null });
}

/**
 * Download `url` as `fileName`, reporting progress (0–100, or null when
 * the total size is unknown) through `onProgress`. Resolves once the
 * file is fully saved AND verified on disk; rejects with an
 * `ApkDownloadError` carrying the real reason so the dialog can show
 * it instead of a generic internet warning.
 */
export async function downloadApk(url: string, fileName: string, onProgress: (percent: number | null) => void): Promise<DownloadedApk> {
  const listener = await FileTransfer.addListener("progress", (status) => {
    if (status.type !== "download" || status.url !== url) return;
    if (status.lengthComputable && status.contentLength > 0) {
      onProgress(Math.min(100, Math.floor((status.bytes / status.contentLength) * 100)));
    } else {
      onProgress(null);
    }
  });
  try {
    if (isNativeApp()) {
      /* FileTransfer wants the full target path; Filesystem.getUri is
       * the documented way to get it for the app's private storage —
       * the same Directory.Data location the installer step stats and
       * opens, so the hand-off to openDownloadedApk is unchanged. */
      let targetUri: string;
      try {
        const resolved = await Filesystem.getUri({ path: fileName, directory: Directory.Data });
        targetUri = resolved.uri;
      } catch (error) {
        throw new ApkDownloadError("storage", { detail: error instanceof Error ? error.message : String(error) });
      }
      /* A leftover partial file from an earlier failed attempt must
       * never be mistaken for this download — remove it first. */
      await Filesystem.deleteFile({ path: fileName, directory: Directory.Data }).catch(() => undefined);
      let resultPath: string | null = null;
      try {
        const result = await FileTransfer.downloadFile({
          url,
          path: targetUri,
          progress: true,
          connectTimeout: CONNECT_TIMEOUT_MS,
          readTimeout: READ_TIMEOUT_MS,
        });
        resultPath = result.path ?? null;
      } catch (error) {
        throw classifyDownloadError(error);
      }
      /* Verify what actually landed: an HTTP error page saved as
       * ".apk" or a body cut short by a dropped connection must fail
       * here with a clear reason, not at install time. */
      try {
        const stat = await Filesystem.stat({ path: fileName, directory: Directory.Data });
        if (!stat || stat.size <= MIN_APK_BYTES) {
          throw new ApkDownloadError("bad-file", { detail: `saved size ${stat?.size ?? 0}` });
        }
      } catch (error) {
        if (error instanceof ApkDownloadError) throw error;
        throw new ApkDownloadError("bad-file", { detail: error instanceof Error ? error.message : String(error) });
      }
      onProgress(100);
      return { uri: resultPath ?? targetUri, blobUrl: null, fileName };
    }
    /* Web: the plugin fetches the file and hands back a Blob; save it
     * through the browser's own download mechanism, as before. */
    let blob: Blob | undefined;
    try {
      const result = await FileTransfer.downloadFile({
        url,
        path: fileName,
        progress: true,
        connectTimeout: CONNECT_TIMEOUT_MS,
      });
      blob = result.blob;
    } catch (error) {
      throw classifyDownloadError(error);
    }
    if (!blob) throw new ApkDownloadError("bad-file", { detail: "web download produced no file" });
    if (blob.size <= MIN_APK_BYTES) throw new ApkDownloadError("bad-file", { detail: `web download size ${blob.size}` });
    onProgress(100);
    const blobUrl = URL.createObjectURL(blob);
    triggerBrowserSave(blobUrl, fileName);
    return { uri: null, blobUrl, fileName };
  } finally {
    await listener.remove().catch(() => undefined);
  }
}

/** Save a blob URL through the browser's own download mechanism (web). */
function triggerBrowserSave(blobUrl: string, fileName: string): void {
  const anchor = document.createElement("a");
  anchor.href = blobUrl;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
}

/** Outcome of an Install tap: either the system installer was opened, or
 * a specific failure the dialog can explain to the user. */
export type OpenApkResult =
  | { opened: true }
  | { opened: false; error: "not-found" | "cannot-open" | "install-permission" };

/**
 * Open the saved APK so the Android package installer starts.
 *
 * The previous flow handed the saved file's `file://` URI to the Browser
 * plugin (a Chrome Custom Tab). A Custom Tab cannot read the app's
 * private storage and cannot install packages, so the Install tap
 * silently died — the download completed but nothing ever installed.
 *
 * Now, on native, the FileOpener plugin opens the file the way Android
 * requires: it builds a `content://` URI for the file through
 * FileProvider, then starts an ACTION_VIEW intent with MIME type
 * `application/vnd.android.package-archive` and
 * FLAG_GRANT_READ_URI_PERMISSION, so the system installer can read and
 * install the downloaded APK. The saved file is verified with `stat`
 * first: a missing or empty file returns `not-found` so the dialog can
 * show a clear error and offer a fresh download instead of a dead tap.
 * If the native opener fails, `cannot-open` is returned so the dialog
 * can explain and offer its explicit "Open in browser" button — this
 * function never opens a browser on its own (that silent hand-off was
 * the old bug: one tap downloaded in-app, the next dumped the user on
 * GitHub). The `fallbackUrl` parameter is accepted for signature
 * compatibility and deliberately not used here.
 *
 * Web: the downloaded blob is saved again through the browser.
 */
export async function openDownloadedApk(downloaded: DownloadedApk, fallbackUrl: string | null): Promise<OpenApkResult> {
  void fallbackUrl;
  if (downloaded.blobUrl) {
    triggerBrowserSave(downloaded.blobUrl, downloaded.fileName);
    return { opened: true };
  }
  if (isNativeApp() && downloaded.uri) {
    try {
      const stat = await Filesystem.stat({ path: downloaded.fileName, directory: Directory.Data });
      if (!stat || stat.size <= 0) return { opened: false, error: "not-found" };
    } catch {
      return { opened: false, error: "not-found" };
    }
    try {
      await FileOpener.openFile({ path: downloaded.uri, mimeType: "application/vnd.android.package-archive" });
      return { opened: true };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (/does not exist/i.test(message)) return { opened: false, error: "not-found" };
      /* Android refused because "install unknown apps" is not yet
       * allowed for Easy Chat (the REQUEST_INSTALL_PACKAGES flow):
       * reported distinctly so the dialog can explain the Settings
       * path instead of failing silently. Retrying the install opens
       * the system installer, whose own screen routes the user to
       * that permission when it is missing — Android mandates its
       * confirmation screen either way; nothing here can (or may)
       * bypass it. */
      if (/permission|unknown app|install.*denied|not allowed/i.test(message)) return { opened: false, error: "install-permission" };
      return { opened: false, error: "cannot-open" };
    }
  }
  return { opened: false, error: downloaded.uri ? "cannot-open" : "not-found" };
}
