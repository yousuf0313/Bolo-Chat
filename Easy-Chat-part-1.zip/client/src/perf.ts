/* Lightweight internal performance timings.
 *
 * The recurring "the app is still slow" reports arrived without a
 * single number attached, so every diagnosis started from guesswork.
 * This module keeps two honest measurements on the device itself:
 *  - cold start: module load → the first chat-list paint;
 *  - thread open: chat tap → the thread's first painted snapshot.
 * Only the last cold-start value and a running average for thread
 * opens are kept (plus sample counts), in localStorage under one small
 * key. Settings → Storage & data shows them, so the next slowness
 * report can quote real numbers from the phone that felt slow.
 * Nothing here ever leaves the device and nothing blocks rendering:
 * every function swallows storage failures. */

const PERF_KEY = "easy-chat-perf-v1";

type PerfStore = {
  coldStartMs?: number;
  coldSamples?: number;
  threadTotalMs?: number;
  threadSamples?: number;
};

function readStore(): PerfStore {
  try {
    const raw = window.localStorage.getItem(PERF_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as PerfStore;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function writeStore(store: PerfStore): void {
  try {
    window.localStorage.setItem(PERF_KEY, JSON.stringify(store));
  } catch {
    /* storage unavailable/full — timings are diagnostic only */
  }
}

/** Record one cold-start measurement (ms from launch to first paint). */
export function recordColdStart(ms: number): void {
  if (!Number.isFinite(ms) || ms <= 0 || ms > 180_000) return;
  const store = readStore();
  store.coldStartMs = Math.round(ms);
  store.coldSamples = (store.coldSamples ?? 0) + 1;
  writeStore(store);
}

/** Record one thread-open measurement (ms from tap to first paint). */
export function recordThreadOpen(ms: number): void {
  if (!Number.isFinite(ms) || ms <= 0 || ms > 120_000) return;
  const store = readStore();
  store.threadTotalMs = (store.threadTotalMs ?? 0) + Math.round(ms);
  store.threadSamples = (store.threadSamples ?? 0) + 1;
  writeStore(store);
}

export type PerfTimings = {
  coldStartMs: number | null;
  coldSamples: number;
  threadOpenAvgMs: number | null;
  threadSamples: number;
};

export function readPerfTimings(): PerfTimings {
  const store = readStore();
  const threadSamples = store.threadSamples ?? 0;
  return {
    coldStartMs: typeof store.coldStartMs === "number" ? store.coldStartMs : null,
    coldSamples: store.coldSamples ?? 0,
    threadOpenAvgMs: threadSamples > 0 && typeof store.threadTotalMs === "number" ? Math.round(store.threadTotalMs / threadSamples) : null,
    threadSamples,
  };
}
