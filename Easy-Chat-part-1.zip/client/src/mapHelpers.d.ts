/* Typed surface for the bundled map helpers in ./mapHelpers.mjs
   (copied verbatim from the platform map recipes). Only the URL builders
   are used by the chat UI: static map images for location messages and
   Google Maps navigation links. */

export type PlaceRef = {
  label: string;
  venue?: string;
  address?: string;
  locality?: string;
  region?: string;
  country?: string;
  lat?: number;
  lng?: number;
  source?: string;
};

export type StaticMapOptions = {
  center: [number, number];
  zoom: number;
  width?: number;
  height?: number;
  scale?: number;
  format?: string;
  theme?: string;
  language?: string;
  region?: string;
  markers?: { position: [number, number]; scale?: 1 | 2 | 3 }[];
};

export declare function buildStaticMapUrl(opts: StaticMapOptions): string;
export declare function mapsSearchUrl(place: PlaceRef): string | null;
export declare function mapsDirectionsUrl(
  destination: PlaceRef,
  options?: { origin?: { lat: number; lng: number }; travelmode?: "driving" | "walking" | "bicycling" | "transit" },
): string | null;
