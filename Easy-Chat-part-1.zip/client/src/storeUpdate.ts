import { AppLauncher } from "@capacitor/app-launcher";
import { openExternalUrl } from "./externalBrowser";
import { isNativeApp } from "./nativeBiometric";

/* Update route: YS Store, not the browser.
 *
 * Updates no longer download the Easy Chat APK in the system browser.
 * The update button hands the user to YS Store (com.ysstore.app), which
 * opens directly on Easy Chat's page via its deep link; the user taps
 * UPDATE there and the store downloads and installs the new version.
 *
 * Most Easy Chat users will NOT have YS Store yet, so when the deep
 * link cannot be opened (store not installed, or the open fails) the
 * one remaining browser step is the one-time YS Store install: the
 * store's own APK downloads in the system browser, the user installs
 * it once, and from then on every Easy Chat update happens inside
 * the store.
 *
 * The deep link only resolves on Android 11+ because the APK's
 * AndroidManifest declares the ysstore scheme in a <queries> block
 * (injected by the build workflow) — without that declaration
 * canOpenUrl would always answer false. */
export const YS_STORE_DEEP_LINK = "ysstore://app/easychat";
export const YS_STORE_INSTALL_URL =
  "https://github.com/yousuf0313/YS-Store/releases/download/v1.0.2/YS-Store.apk";

/**
 * The update action behind the update dialog (launch prompt and the
 * Settings "Check for updates" result alike). Opens YS Store on Easy
 * Chat's page when the store is installed; otherwise falls back to
 * the one-time YS Store APK download in the system browser.
 */
export async function openYsStoreForUpdate(): Promise<void> {
  if (isNativeApp()) {
    try {
      const { value: canOpen } = await AppLauncher.canOpenUrl({ url: YS_STORE_DEEP_LINK });
      if (canOpen) {
        await AppLauncher.openUrl({ url: YS_STORE_DEEP_LINK });
        return;
      }
    } catch {
      /* Store not installed or the launcher failed — fall through to
       * the one-time store install below. */
    }
  }
  await openExternalUrl(YS_STORE_INSTALL_URL);
}
