import { AppLauncher } from "@capacitor/app-launcher";
import { openExternalUrl } from "./externalBrowser";
import { isNativeApp } from "./nativeBiometric";

/* Update route: YS Store, not the browser.
 *
 * Updates no longer download the Easy Chat APK in the system browser.
 * The update button hands the user to YS Store (com.ysstore.app), which
 * opens directly on Easy Chat's page via its deep link; the user taps
 * UPDATE there and the store downloads and installs the new version.
 *
 * Most Easy Chat users will NOT have YS Store yet, so when the deep
 * link cannot be opened (store not installed, or the open fails) the
 * fallback is the YS Store WEB page: it reads the live catalog, shows
 * Easy Chat with its full logo, version and a big UPDATE button, and
 * the user updates from there — no GitHub page, no raw APK link.
 *
 * The deep link only resolves on Android 11+ because the APK's
 * AndroidManifest declares the ysstore scheme in a <queries> block
 * (injected by the build workflow) — without that declaration
 * canOpenUrl would always answer false. */
export const YS_STORE_DEEP_LINK = "ysstore://app/easychat";
export const YS_STORE_WEB_URL = "https://yousuf0313.github.io/YS-Store/";

/**
 * The update action behind the update dialog (launch prompt and the
 * Settings "Check for updates" result alike). Opens YS Store on Easy
 * Chat's page when the store is installed; otherwise falls back to
 * the YS Store web page in the system browser.
 */
export async function openYsStoreForUpdate(): Promise<void> {
  if (isNativeApp()) {
    try {
      const { value: canOpen } = await AppLauncher.canOpenUrl({ url: YS_STORE_DEEP_LINK });
      if (canOpen) {
        await AppLauncher.openUrl({ url: YS_STORE_DEEP_LINK });
        return;
      }
    } catch {
      /* Store not installed or the launcher failed — fall through to
       * the store's web page below. */
    }
  }
  await openExternalUrl(YS_STORE_WEB_URL);
}
