import { spaceQueryClient } from "@hatch/space-sdk/client";
import { QueryClientProvider } from "@tanstack/react-query";
import { Component, StrictMode, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App";
import "./theme.css";

const rootEl = document.querySelector<HTMLElement>("[data-generated-space-root]");
if (!rootEl) {
  throw new Error("missing generated space root element");
}

/* Boot watchdog counterpart (see the inline script in index.html): the
 * app bundle has loaded and is about to render, so the "still loading"
 * fallback must never fire. */
(window as unknown as { __easyChatBooted?: boolean }).__easyChatBooted = true;

/* Last-resort error boundary. Without it, ANY render-time exception —
 * including the ones old WebViews throw on APIs newer phones take for
 * granted — unmounted the whole tree and left a dead white screen with
 * no explanation and no way out ("the app doesn't open on my phone").
 * Now a crash lands on a small recovery screen: reopening usually
 * clears a transient failure, and the reset option clears the saved
 * on-device caches (localStorage) that a corrupt snapshot could poison
 * — chat data itself lives in Firestore/IndexedDB and is untouched. */
class AppErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  override state = { failed: false };

  static getDerivedStateFromError(): { failed: boolean } {
    return { failed: true };
  }

  override componentDidCatch(): void {
    /* Rendering must never depend on logging succeeding. */
    try {
      console.error("Easy Chat hit a fatal rendering error");
    } catch {
      /* ignore */
    }
  }

  private resetSavedData = (): void => {
    try {
      window.localStorage.clear();
    } catch {
      /* ignore */
    }
    window.location.reload();
  };

  override render(): ReactNode {
    if (!this.state.failed) return this.props.children;
    return (
      <main className="full-state">
        <h1>Easy Chat رک گیا ہے · Easy Chat stopped</h1>
        <p>ایپ کھولتے ہوئے کوئی خرابی آ گئی۔ دوبارہ کھول کر دیکھیں — آپ کی چیٹس محفوظ ہیں۔</p>
        <p>Something went wrong while opening the app. Please reopen it — your chats are safe.</p>
        <button className="primary-button narrow" onClick={() => window.location.reload()}>
          دوبارہ کھولیں · Reopen
        </button>
        <button className="text-button" onClick={this.resetSavedData}>
          محفوظ ڈیٹا صاف کر کے کھولیں · Reset saved data &amp; reopen
        </button>
      </main>
    );
  }
}

// If you edit this file: keep `<QueryClientProvider client={spaceQueryClient}>`
// wrapping the app (every space shares the SDK's QueryClient), and keep
// BOTH the `hatch-space-root` class AND the `data-hatch-space-root`
// attribute on the outer div. The SDK styles select on
// `.hatch-space-root[data-hatch-space-root]` to apply mobile safe-area
// insets (notches, gesture bars, etc.), correct viewport sizing, and the
// hosting header/chrome offsets — dropping either breaks layout silently.
createRoot(rootEl).render(
  <StrictMode>
    <QueryClientProvider client={spaceQueryClient}>
      <div className="hatch-space-root" data-hatch-space-root>
        <AppErrorBoundary>
          <App />
        </AppErrorBoundary>
      </div>
    </QueryClientProvider>
  </StrictMode>,
);
