/* Sticker packs for Easy Chat.
 *
 * Every built-in sticker is an ORIGINAL text-art design rendered at
 * runtime from fonts on a transparent canvas — no artwork is copied
 * from any existing sticker pack. Rendering is lazy (first time a
 * pack is opened) and cached in memory for the session. Favourites,
 * recents and the user's own "My stickers" pack persist on-device in
 * localStorage. */

export type StickerDef = {
  /** Stable identity used for favourites/recents. */
  id: string;
  /** Searchable label. */
  label: string;
  /** The data URL to send/render. Generated text-art resolves lazily. */
  src: string | null;
  /** For generated stickers: the text and design to render. */
  art?: { text: string; font: string; fill: string; stroke?: string; emoji?: boolean };
};

export type StickerPack = { id: string; name: string; icon: string; stickers: StickerDef[] };

const NASTALIQ = `"Noto Nastaliq Urdu", "Noto Naskh Arabic", serif`;
const NASKH = `"Noto Naskh Arabic", serif`;

function artSticker(pack: string, index: number, text: string, label: string, font: string, fill: string, stroke?: string): StickerDef {
  return { id: `${pack}:${index}`, label, src: null, art: { text, font, fill, ...(stroke ? { stroke } : {}) } };
}
function emojiSticker(pack: string, index: number, glyph: string, label: string): StickerDef {
  return { id: `${pack}:${index}`, label, src: null, art: { text: glyph, font: "sans-serif", fill: "#ffffff", emoji: true } };
}

const CALLIGRAPHY_ITEMS: [string, string, string][] = [
  ["السلام علیکم", "Assalamu Alaikum salaam greeting", "#0b6b57"],
  ["ماشاءاللہ", "Masha Allah", "#b8860b"],
  ["جزاک اللہ", "Jazak Allah thanks", "#0b6b57"],
  ["الحمدللہ", "Alhamdulillah praise", "#7c3aed"],
  ["سبحان اللہ", "Subhan Allah glory", "#0e7490"],
  ["اللہ اکبر", "Allahu Akbar", "#b91c1c"],
  ["ان شاءاللہ", "Insha Allah", "#0b6b57"],
  ["بارک اللہ فیک", "Barak Allah feek blessings", "#b8860b"],
  ["رمضان مبارک", "Ramadan Mubarak", "#0e7490"],
  ["عید مبارک", "Eid Mubarak", "#db2777"],
  ["جمعہ مبارک", "Jummah Mubarak friday", "#0b6b57"],
  ["آمین", "Ameen dua prayer", "#7c3aed"],
];
const PHRASE_ITEMS: [string, string, string][] = [
  ["شکریہ", "Shukriya thanks", "#0b6b57"],
  ["مبارک ہو", "Mubarak ho congrats", "#db2777"],
  ["خدا حافظ", "Khuda Hafiz goodbye Allah Hafiz", "#0e7490"],
  ["شب بخیر", "Shab bakhair good night", "#4338ca"],
  ["صبح بخیر", "Subah bakhair good morning", "#d97706"],
  ["واہ!", "Wah wow amazing", "#b91c1c"],
  ["بہت خوب", "Bohat khoob very good", "#0b6b57"],
  ["زندہ باد", "Zindabad long live", "#15803d"],
  ["جی بالکل", "Ji bilkul yes of course", "#0e7490"],
  ["نہیں بھائی", "Nahi bhai no brother", "#b45309"],
  ["ہاہاہا", "Hahaha laugh funny", "#db2777"],
  ["اوہ!", "Oh surprise", "#7c3aed"],
];
const FACE_ITEMS: [string, string][] = [
  ["😂", "laugh cry funny haha"], ["🥰", "love hearts smile"], ["😍", "heart eyes love"], ["🤲", "dua prayer hands"],
  ["👍", "thumbs up yes good"], ["👏", "clap bravo"], ["🙏", "please thanks pray"], ["😎", "cool sunglasses"],
  ["🥺", "pleading please sad"], ["😴", "sleepy tired night"], ["🤔", "thinking hmm"], ["😮", "wow surprised"],
  ["❤️", "red heart love"], ["🌹", "rose flower"], ["🌙", "moon night ramadan"], ["⭐", "star"],
];

export const BUILTIN_PACKS: StickerPack[] = [
  { id: "calligraphy", name: "خطاطی", icon: "🕌", stickers: CALLIGRAPHY_ITEMS.map(([text, label, fill], index) => artSticker("calligraphy", index, text, label, NASTALIQ, fill, "#ffffff")) },
  { id: "phrases", name: "اردو جملے", icon: "💬", stickers: PHRASE_ITEMS.map(([text, label, fill], index) => artSticker("phrases", index, text, label, index % 2 === 0 ? NASTALIQ : NASKH, fill, "#ffffff")) },
  { id: "faces", name: "چہرے", icon: "😀", stickers: FACE_ITEMS.map(([glyph, label], index) => emojiSticker("faces", index, glyph, label)) },
];

/* ------------------------------------------------------------------ */
/* Rendering: transparent 512×512 canvas, text fitted to the frame.   */
/* ------------------------------------------------------------------ */

const renderCache = new Map<string, string>();

export function stickerSrc(sticker: StickerDef): string {
  if (sticker.src) return sticker.src;
  const cached = renderCache.get(sticker.id);
  if (cached) return cached;
  const art = sticker.art;
  if (!art) return "";
  const size = 512;
  const canvas = document.createElement("canvas");
  canvas.width = size; canvas.height = size;
  const context = canvas.getContext("2d");
  if (!context) return "";
  context.clearRect(0, 0, size, size);
  context.textAlign = "center";
  context.textBaseline = "middle";
  let fontSize = art.emoji ? 340 : 120;
  const setFont = () => { context.font = `${fontSize}px ${art.font}`; };
  setFont();
  const maxWidth = size - 48;
  while (context.measureText(art.text).width > maxWidth && fontSize > 28) { fontSize -= 8; setFont(); }
  const x = size / 2; const y = size / 2 + (art.emoji ? 0 : fontSize * 0.08);
  if (!art.emoji) {
    context.shadowColor = "rgba(0,0,0,0.28)";
    context.shadowBlur = 10;
    context.shadowOffsetY = 4;
    if (art.stroke) { context.lineWidth = Math.max(6, fontSize / 9); context.strokeStyle = art.stroke; context.lineJoin = "round"; context.strokeText(art.text, x, y); }
    context.fillStyle = art.fill;
    context.fillText(art.text, x, y);
  } else {
    context.fillText(art.text, x, y);
  }
  const url = canvas.toDataURL("image/png");
  renderCache.set(sticker.id, url);
  return url;
}

/* ------------------------------------------------------------------ */
/* On-device stores: my stickers, favourites, recents.                */
/* ------------------------------------------------------------------ */

const MY_KEY = "easy-chat-my-stickers-v1";
const FAV_KEY = "easy-chat-sticker-favourites-v1";
const RECENT_KEY = "easy-chat-sticker-recents-v1";

function readList(key: string): string[] {
  try {
    const parsed: unknown = JSON.parse(window.localStorage.getItem(key) ?? "[]");
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
  } catch { return []; }
}
function writeList(key: string, values: string[]) {
  try { window.localStorage.setItem(key, JSON.stringify(values)); } catch { /* storage full/unavailable */ }
}

export function loadMyStickers(): StickerDef[] {
  try {
    const parsed: unknown = JSON.parse(window.localStorage.getItem(MY_KEY) ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is { id: string; src: string } => Boolean(item) && typeof item === "object" && typeof (item as { id?: unknown }).id === "string" && typeof (item as { src?: unknown }).src === "string")
      .map((item) => ({ id: item.id, label: "My sticker", src: item.src }));
  } catch { return []; }
}
/** Save a user-created sticker; returns the updated pack or null when
 *  the device storage refused it (quota). */
export function saveMySticker(dataUrl: string): StickerDef[] | null {
  const next: StickerDef = { id: `my:${Date.now()}`, label: "My sticker", src: dataUrl };
  const items = [next, ...loadMyStickers()].slice(0, 30);
  try {
    window.localStorage.setItem(MY_KEY, JSON.stringify(items.map((item) => ({ id: item.id, src: item.src }))));
    return items;
  } catch { return null; }
}

export function loadFavouriteIds(): string[] { return readList(FAV_KEY); }
export function toggleFavouriteId(id: string): string[] {
  const current = readList(FAV_KEY);
  const next = current.includes(id) ? current.filter((item) => item !== id) : [id, ...current].slice(0, 60);
  writeList(FAV_KEY, next);
  return next;
}
export function loadRecentIds(): string[] { return readList(RECENT_KEY); }
export function pushRecentId(id: string): string[] {
  const next = [id, ...readList(RECENT_KEY).filter((item) => item !== id)].slice(0, 24);
  writeList(RECENT_KEY, next);
  return next;
}

/** Resolve a stored id back to a sticker definition. */
export function stickerById(id: string, myStickers: StickerDef[]): StickerDef | null {
  if (id.startsWith("my:")) return myStickers.find((item) => item.id === id) ?? null;
  for (const pack of BUILTIN_PACKS) {
    const found = pack.stickers.find((item) => item.id === id);
    if (found) return found;
  }
  return null;
}
