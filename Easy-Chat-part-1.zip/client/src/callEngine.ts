/* WebRTC peer engine for Easy Chat's real 1-to-1 calls.
 *
 * Signaling (SDP offer/answer + ICE candidates) travels over Firestore
 * through the helpers in ./firebase; this module owns only the media
 * side: getUserMedia, the RTCPeerConnection, ICE restart recovery and
 * the in-call track controls. It is deliberately UI-free — the call
 * screens in App.tsx drive it through callbacks.
 *
 * ICE: two public STUN servers plus the free public Open Relay TURN
 * service by Metered, so calls still connect when both sides sit
 * behind strict NATs / carrier-grade NAT where STUN alone fails. The
 * TURN relay is offered over UDP *and* TCP *and* TLS: many carrier
 * networks throttle or block UDP outright, and a `turn:` URL without
 * an explicit transport is only ever tried over UDP — without the
 * `?transport=tcp` and `turns:` (TLS/TCP) variants a call on such a
 * network has no relay path at all and dies the moment the direct
 * path stumbles, which is exactly what users on weaker connections
 * reported. (The relay itself is Metered's shared public service —
 * free, but shared and rate-limited; it is a fallback path, not the
 * primary one.) */

export const CALL_ICE_SERVERS: RTCIceServer[] = [
  { urls: "stun:stun.l.google.com:19302" },
  { urls: "stun:stun.cloudflare.com:3478" },
  { urls: "turn:staticauth.openrelay.metered.ca:80", username: "openrelayproject", credential: "openrelayprojectsecret" },
  { urls: "turn:staticauth.openrelay.metered.ca:80?transport=tcp", username: "openrelayproject", credential: "openrelayprojectsecret" },
  { urls: "turn:staticauth.openrelay.metered.ca:443", username: "openrelayproject", credential: "openrelayprojectsecret" },
  { urls: "turn:staticauth.openrelay.metered.ca:443?transport=tcp", username: "openrelayproject", credential: "openrelayprojectsecret" },
  { urls: "turns:staticauth.openrelay.metered.ca:443", username: "openrelayproject", credential: "openrelayprojectsecret" },
];

/** How long a call may ring before it is finalized as missed. */
export const CALL_RING_TIMEOUT_MS = 45_000;

export type CallPhase =
  | "setup"        // acquiring media / creating the peer connection
  | "ringing"      // outgoing: offer sent, waiting for the callee
  | "connecting"   // answer exchanged, ICE still negotiating
  | "ongoing"      // media flowing
  | "reconnecting" // ICE disrupted; restart in progress
  | "failed";      // ICE gave up after restarts

export type CallEngineEvents = {
  onLocalStream: (stream: MediaStream | null) => void;
  onRemoteStream: (stream: MediaStream | null) => void;
  onPhase: (phase: CallPhase) => void;
  onLocalCandidate: (candidate: RTCIceCandidateInit) => void;
  /** A fresh local description (initial offer/answer, or an ICE-restart
   *  offer) that must be published through the signaling channel. */
  onLocalDescription: (description: RTCSessionDescriptionInit) => void;
  /** The link degraded so far that video sending was switched off to
   *  keep the call alive as audio-only (see the stats monitor). */
  onAudioOnly?: () => void;
  onEnded: () => void;
};

/** How long one continuous ICE disruption may last before the call is
 *  declared failed. Carrier 4G disruptions — a cell handover, a brief
 *  signal dip, a NAT rebinding — commonly run 20–45 seconds; the old
 *  20-second budget declared those calls dead while they were still
 *  perfectly recoverable. */
const ICE_GRACE_MS = 60_000;
/** Delay before the first ICE restart once a disruption is seen. */
const ICE_FIRST_RESTART_MS = 1_500;
/** Cadence of further ICE restarts inside the grace window. */
const ICE_RESTART_EVERY_MS = 6_000;
/** Outgoing video caps: a phone camera's default (720p/1080p at
 *  30 fps) demands far more uplink than a weak connection has, and
 *  the resulting packet loss is what pushed ICE into "disconnected"
 *  in the first place. 640×360 at 15–20 fps stays watchable and
 *  fits an ordinary 4G uplink with room to spare. */
const VIDEO_MAX_BITRATE = 500_000;
const VIDEO_DEGRADED_BITRATE = 180_000;

export class CallEngine {
  private pc: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private remoteStream: MediaStream | null = null;
  private readonly events: CallEngineEvents;
  private readonly isCaller: boolean;
  private facingMode: "user" | "environment" = "user";
  private callKind: "audio" | "video" = "audio";
  private restartAttempts = 0;
  private recoveryTimer: number | null = null;
  private disruptionStartedAt: number | null = null;
  private statsTimer: number | null = null;
  private degradeLevel = 0;
  private badStreak = 0;
  private goodStreak = 0;
  private lastStats: { sent: number; lost: number } | null = null;
  private closed = false;
  private remoteDescriptionSet = false;
  private pendingCandidates: RTCIceCandidateInit[] = [];

  constructor(events: CallEngineEvents, isCaller: boolean) {
    this.events = events;
    this.isCaller = isCaller;
  }

  get stream(): MediaStream | null {
    return this.localStream;
  }

  /** Acquire mic/camera and build the peer connection. Throws the
   *  original getUserMedia error (NotAllowedError etc.) so the UI can
   *  show the permission guidance — never swallows it. */
  async start(kind: "audio" | "video"): Promise<void> {
    if (!navigator.mediaDevices?.getUserMedia || typeof RTCPeerConnection === "undefined") {
      throw new Error("webrtc-unavailable");
    }
    this.callKind = kind;
    const stream = await navigator.mediaDevices.getUserMedia({
      // Explicit processing constraints: on some Android WebViews a
      // bare `audio: true` negotiates with echo cancellation OFF,
      // and the far side then hears their own voice echoed back —
      // reported as "the call connects but the voice is wrong".
      // Naming the three processors keeps behaviour identical on
      // every WebView.
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      // Capped on purpose — see VIDEO_MAX_BITRATE above: an uncapped
      // camera track is the single biggest cause of weak-link calls
      // collapsing under their own video bitrate.
      video: kind === "video" ? {
        facingMode: this.facingMode,
        width: { ideal: 640, max: 640 },
        height: { ideal: 360, max: 480 },
        frameRate: { ideal: 15, max: 20 },
      } : false,
    });
    if (this.closed) {
      stream.getTracks().forEach((track) => track.stop());
      return;
    }
    this.localStream = stream;
    this.events.onLocalStream(stream);
    const pc = new RTCPeerConnection({ iceServers: CALL_ICE_SERVERS });
    this.pc = pc;
    stream.getTracks().forEach((track) => pc.addTrack(track, stream));
    pc.ontrack = (event) => {
      if (this.closed) return;
      // Prefer the stream the browser grouped the track into: a
      // hand-assembled MediaStream built track-by-track can leave a
      // media element bound BEFORE the audio track was added in a
      // state where it never starts rendering the later track (the
      // call shows "connected" but no voice is heard). The grouped
      // stream is the one the browser keeps in sync with the
      // transceivers, and re-emitting it on every track event lets
      // the UI re-bind + re-play whenever a track (re)appears —
      // including the fresh tracks an ICE restart delivers.
      const grouped = event.streams?.[0] ?? null;
      if (grouped) {
        this.remoteStream = grouped;
      } else {
        if (!this.remoteStream) this.remoteStream = new MediaStream();
        if (!this.remoteStream.getTracks().some((track) => track.id === event.track.id)) this.remoteStream.addTrack(event.track);
      }
      this.events.onRemoteStream(this.remoteStream);
    };
    pc.onicecandidate = (event) => {
      if (event.candidate) this.events.onLocalCandidate(event.candidate.toJSON());
    };
    pc.oniceconnectionstatechange = () => this.handleIceState();
    pc.onconnectionstatechange = () => {
      if (this.closed || !this.pc) return;
      if (this.pc.connectionState === "connected") this.markConnected();
      if (this.pc.connectionState === "failed") this.handleIceState();
    };
    this.applySenderCaps();
    this.startStatsMonitor();
    if (this.isCaller) {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      if (pc.localDescription) this.events.onLocalDescription({ type: pc.localDescription.type, sdp: pc.localDescription.sdp });
    }
  }

  /** Apply the other side's description. For the callee this produces
   *  the answer (published through onLocalDescription). A description
   *  arriving mid-call with a different SDP is an ICE-restart
   *  renegotiation and is answered the same way. */
  async applyRemoteDescription(description: RTCSessionDescriptionInit): Promise<void> {
    const pc = this.pc;
    if (!pc || this.closed) return;
    await pc.setRemoteDescription(new RTCSessionDescription(description));
    this.remoteDescriptionSet = true;
    const queued = this.pendingCandidates;
    this.pendingCandidates = [];
    for (const candidate of queued) {
      try { await pc.addIceCandidate(new RTCIceCandidate(candidate)); } catch { /* stale candidate */ }
    }
    if (description.type === "offer") {
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      if (pc.localDescription) this.events.onLocalDescription({ type: pc.localDescription.type, sdp: pc.localDescription.sdp });
    }
  }

  async addRemoteCandidate(candidate: RTCIceCandidateInit): Promise<void> {
    const pc = this.pc;
    if (!pc || this.closed) return;
    if (!this.remoteDescriptionSet) {
      this.pendingCandidates.push(candidate);
      return;
    }
    try { await pc.addIceCandidate(new RTCIceCandidate(candidate)); } catch { /* stale candidate */ }
  }

  private markConnected() {
    if (this.closed) return;
    this.restartAttempts = 0;
    this.disruptionStartedAt = null;
    if (this.recoveryTimer !== null) { window.clearTimeout(this.recoveryTimer); this.recoveryTimer = null; }
    this.events.onPhase("ongoing");
  }

  private handleIceState() {
    const pc = this.pc;
    if (!pc || this.closed) return;
    const state = pc.iceConnectionState;
    if (state === "connected" || state === "completed") {
      this.markConnected();
      return;
    }
    if (state === "disconnected" || state === "failed") {
      this.events.onPhase("reconnecting");
      if (this.disruptionStartedAt === null) this.disruptionStartedAt = Date.now();
      this.scheduleRecovery(ICE_FIRST_RESTART_MS);
    }
  }

  /* Recovery is a self-perpetuating chain, NOT a pair of one-shot
   * timers armed from the state-change handler. The previous design
   * armed one restart timer and one 20s fail timer when ICE first
   * reported "disconnected"; when the restart timer fired, nothing
   * re-armed it — a still-disconnected peer connection raises no new
   * state-change event (its state never changed), so no second
   * restart was ever scheduled and the fail timer killed the call
   * 20 seconds in, even when the network came back at second 25.
   * This chain instead re-checks every few seconds for the whole
   * grace window: the caller re-offers with iceRestart (each restart
   * re-gathers candidates, so a phone that moved to a new IP / NAT
   * mapping gets fresh paths), the callee waits for that offer (its
   * own restart offer would collide with the caller's), and only a
   * disruption that outlasts ICE_GRACE_MS fails the call. */
  private scheduleRecovery(delayMs: number) {
    if (this.recoveryTimer !== null || this.closed) return;
    this.recoveryTimer = window.setTimeout(() => {
      this.recoveryTimer = null;
      if (this.closed || !this.pc) return;
      const ice = this.pc.iceConnectionState;
      if (ice === "connected" || ice === "completed") {
        this.markConnected();
        return;
      }
      const startedAt = this.disruptionStartedAt ?? Date.now();
      if (Date.now() - startedAt >= ICE_GRACE_MS) {
        this.events.onPhase("failed");
        return;
      }
      this.restartAttempts += 1;
      if (this.isCaller) void this.restartIce();
      this.scheduleRecovery(ICE_RESTART_EVERY_MS);
    }, delayMs);
  }

  private async restartIce(): Promise<void> {
    const pc = this.pc;
    if (!pc || this.closed) return;
    try {
      const offer = await pc.createOffer({ iceRestart: true });
      await pc.setLocalDescription(offer);
      if (pc.localDescription) this.events.onLocalDescription({ type: pc.localDescription.type, sdp: pc.localDescription.sdp });
    } catch { /* the recovery chain will try again, then settle the call */ }
  }

  /* ===== Adaptive media quality =====
   * Every 3 seconds the engine samples the live stats: outgoing
   * packet loss (from the peer's reception reports) and round-trip
   * time. Sustained bad samples walk a video call down a ladder —
   * first cheaper video (lower bitrate, half resolution), then
   * video sending OFF entirely so the call survives as audio-only
   * instead of dying — while sustained good samples walk it back up
   * one step (never back into video on their own: once video has
   * been dropped the user re-enables it with the camera toggle,
   * which resets the ladder). Audio-only calls are not monitored:
   * Opus audio already fits any link that can carry a call at all. */

  private startStatsMonitor() {
    if (this.callKind !== "video") return;
    if (this.statsTimer !== null) window.clearInterval(this.statsTimer);
    this.statsTimer = window.setInterval(() => { void this.sampleStats(); }, 3000);
  }

  private async sampleStats(): Promise<void> {
    const pc = this.pc;
    if (!pc || this.closed) return;
    // Samples taken mid-disruption measure the outage, not the link
    // quality — the recovery chain owns those periods.
    if (pc.iceConnectionState !== "connected" && pc.iceConnectionState !== "completed") return;
    let stats: RTCStatsReport;
    try {
      stats = await pc.getStats();
    } catch {
      return;
    }
    let sent = 0;
    let lost = 0;
    let rtt = 0;
    stats.forEach((report) => {
      const item = report as { type?: string; packetsSent?: number; packetsLost?: number; currentRoundTripTime?: number; state?: string };
      if (item.type === "remote-inbound-rtp") {
        if (typeof item.packetsLost === "number") lost += item.packetsLost;
        if (typeof item.currentRoundTripTime === "number") rtt = Math.max(rtt, item.currentRoundTripTime);
      }
      if (item.type === "outbound-rtp" && typeof item.packetsSent === "number") sent += item.packetsSent;
      if (item.type === "candidate-pair" && item.state === "succeeded" && typeof item.currentRoundTripTime === "number") {
        rtt = Math.max(rtt, item.currentRoundTripTime);
      }
    });
    const previous = this.lastStats;
    this.lastStats = { sent, lost };
    if (!previous) return;
    const sentDelta = sent - previous.sent;
    const lostDelta = Math.max(0, lost - previous.lost);
    if (sentDelta <= 0) return;
    const lossRatio = lostDelta / (sentDelta + lostDelta);
    const bad = lossRatio > 0.08 || rtt > 0.7;
    const good = lossRatio < 0.02 && (rtt === 0 || rtt < 0.35);
    if (bad) {
      this.badStreak += 1;
      this.goodStreak = 0;
    } else if (good) {
      this.goodStreak += 1;
      this.badStreak = 0;
    } else {
      this.badStreak = 0;
      this.goodStreak = 0;
    }
    if (this.badStreak >= 2 && this.degradeLevel < 2) {
      this.degradeLevel += 1;
      this.badStreak = 0;
      this.applySenderCaps();
      if (this.degradeLevel >= 2) this.events.onAudioOnly?.();
    } else if (this.goodStreak >= 4 && this.degradeLevel === 1) {
      this.degradeLevel = 0;
      this.goodStreak = 0;
      this.applySenderCaps();
    }
  }

  /** Push the current degradation level into the video sender's
   *  encoding parameters. Level 0: the standard caps. Level 1: a
   *  much cheaper picture. Level 2: video encoding inactive — no
   *  video RTP is sent at all (the local preview, which reads the
   *  camera stream directly, is unaffected), so the call needs only
   *  an audio-sized link. */
  private applySenderCaps() {
    const pc = this.pc;
    if (!pc) return;
    for (const sender of pc.getSenders()) {
      const track = sender.track;
      if (!track || track.kind !== "video") continue;
      try {
        const params = sender.getParameters();
        if (!params.encodings || params.encodings.length === 0) params.encodings = [{}];
        const encoding = params.encodings[0];
        if (!encoding) continue;
        if (this.degradeLevel >= 2) {
          encoding.active = false;
        } else if (this.degradeLevel === 1) {
          encoding.active = true;
          encoding.maxBitrate = VIDEO_DEGRADED_BITRATE;
          encoding.maxFramerate = 15;
          encoding.scaleResolutionDownBy = 2;
        } else {
          encoding.active = true;
          encoding.maxBitrate = VIDEO_MAX_BITRATE;
          encoding.maxFramerate = 20;
          encoding.scaleResolutionDownBy = 1;
        }
        void sender.setParameters(params).catch(() => undefined);
      } catch { /* sender parameters unsupported on this WebView */ }
    }
  }

  setMuted(muted: boolean) {
    this.localStream?.getAudioTracks().forEach((track) => { track.enabled = !muted; });
  }

  setCameraOff(off: boolean) {
    this.localStream?.getVideoTracks().forEach((track) => { track.enabled = !off; });
    if (!off) {
      // The user explicitly wants video back: forget the degradation
      // ladder and restore the standard sender caps — if the link is
      // still bad, the stats monitor will walk the ladder down again.
      this.degradeLevel = 0;
      this.badStreak = 0;
      this.goodStreak = 0;
      this.applySenderCaps();
    }
  }

  /** Switch between the front and back cameras: re-acquire the video
   *  track facing the other way and swap it into the live sender, so
   *  the call itself never drops. */
  async switchCamera(): Promise<void> {
    const pc = this.pc;
    if (!pc || this.closed || !navigator.mediaDevices?.getUserMedia) return;
    this.facingMode = this.facingMode === "user" ? "environment" : "user";
    let fresh: MediaStream;
    try {
      fresh = await navigator.mediaDevices.getUserMedia({ video: { facingMode: this.facingMode, width: { ideal: 640, max: 640 }, height: { ideal: 360, max: 480 }, frameRate: { ideal: 15, max: 20 } }, audio: false });
    } catch {
      this.facingMode = this.facingMode === "user" ? "environment" : "user";
      return;
    }
    const newTrack = fresh.getVideoTracks()[0];
    if (!newTrack) return;
    const sender = pc.getSenders().find((item) => item.track?.kind === "video");
    if (sender) {
      try { await sender.replaceTrack(newTrack); } catch { newTrack.stop(); return; }
    }
    if (this.localStream) {
      this.localStream.getVideoTracks().forEach((track) => { track.stop(); this.localStream?.removeTrack(track); });
      this.localStream.addTrack(newTrack);
      this.events.onLocalStream(this.localStream);
    }
    this.applySenderCaps();
  }

  /** Best-effort speaker routing for the WebView: Chromium's
   *  setSinkId with the well-known "speaker" device id where the
   *  platform exposes one; the visible toggle state is kept either
   *  way, and failures are silent by design. */
  static applySpeaker(element: HTMLMediaElement | null, speaker: boolean) {
    if (!element) return;
    const withSink = element as HTMLMediaElement & { setSinkId?: (id: string) => Promise<void> };
    if (typeof withSink.setSinkId !== "function") return;
    void withSink.setSinkId(speaker ? "speaker" : "").catch(() => undefined);
  }

  /** Stop every track, close the peer connection, and go silent. */
  close() {
    if (this.closed) return;
    this.closed = true;
    if (this.recoveryTimer !== null) { window.clearTimeout(this.recoveryTimer); this.recoveryTimer = null; }
    if (this.statsTimer !== null) { window.clearInterval(this.statsTimer); this.statsTimer = null; }
    try { this.pc?.close(); } catch { /* already closed */ }
    this.pc = null;
    this.localStream?.getTracks().forEach((track) => track.stop());
    this.localStream = null;
    this.remoteStream = null;
  }
}

/* ===== Ringtone =====
 * A classic dual-tone ring generated with WebAudio (no audio asset to
 * ship): one second of ring, two seconds of silence, looping, plus a
 * matching vibration pattern on devices that support it. Returns the
 * stop function. */

export function startRingtone(): () => void {
  let stopped = false;
  let context: AudioContext | null = null;
  let interval: number | null = null;
  try {
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (Ctor) {
      context = new Ctor();
      // An AudioContext created outside a user gesture (an incoming
      // call arrives asynchronously) starts SUSPENDED under the
      // autoplay policy and then produces no ring at all — resume it
      // explicitly, and again inside ringOnce until it runs.
      void context.resume().catch(() => undefined);
      const ringOnce = () => {
        if (context && context.state === "suspended") void context.resume().catch(() => undefined);
        if (stopped || !context) return;
        const now = context.currentTime;
        const gain = context.createGain();
        gain.gain.setValueAtTime(0.0001, now);
        gain.connect(context.destination);
        for (const frequency of [440, 480]) {
          const osc = context.createOscillator();
          osc.type = "sine";
          osc.frequency.value = frequency;
          osc.connect(gain);
          osc.start(now);
          osc.stop(now + 1);
        }
        gain.gain.exponentialRampToValueAtTime(0.12, now + 0.05);
        gain.gain.setValueAtTime(0.12, now + 0.9);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 1);
      };
      ringOnce();
      interval = window.setInterval(ringOnce, 3000);
    }
  } catch { /* ringtone is best-effort */ }
  try {
    navigator.vibrate?.([600, 400, 600]);
    var vibrateTimer = window.setInterval(() => { if (!stopped) navigator.vibrate?.([600, 400, 600]); }, 3400);
  } catch { /* vibration is best-effort */ }
  return () => {
    stopped = true;
    if (interval !== null) window.clearInterval(interval);
    try { window.clearInterval(vibrateTimer); } catch { /* never started */ }
    try { navigator.vibrate?.(0); } catch { /* ignore */ }
    void context?.close().catch(() => undefined);
  };
}
