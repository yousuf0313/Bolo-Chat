/* In-app update check.
 *
 * On launch the app asks GitHub for the latest published release of the
 * Easy Chat repo. If that release's version is newer than APP_VERSION,
 * the app shows a dismissible dialog with the release notes and a
 * download button pointing at the release's APK asset.
 *
 * Throttle discipline (fixed): the successful-check launch throttle
 * (3 hours) is written ONLY after a successful fetch + parse (HTTP 200
 * with a readable release). A failed check — offline, slow network,
 * HTTP error, malformed JSON — must never burn that window; otherwise
 * one bad launch hides every later update for hours and every further
 * failure pushes the window out again. Failures instead record a
 * separate timestamp with a short 30-minute retry window. The success
 * window is deliberately short (3 hours, down from 24) so a release
 * published today surfaces inside the app the same day.
 *
 * The manual check (Settings → "Check for updates") bypasses every
 * throttle and never writes any throttle key; it always reports a
 * visible result: update found, up to date, or the failure reason. */

import { APP_VERSION } from "./appVersion";

const LATEST_RELEASE_URL = "https://api.github.com/repos/yousuf0313/Easy-Chat/releases/latest";
const LAST_CHECK_KEY = "easy_chat_last_update_check";
const FAILURE_KEY = "easy_chat_update_last_failure";
const BACKOFF_KEY = "easy_chat_update_backoff_until";
const CHECK_THROTTLE_MS = 3 * 60 * 60 * 1000;
const FAILURE_RETRY_MS = 30 * 60 * 1000;
const FORBIDDEN_BACKOFF_MS = 60 * 60 * 1000;
const CHECK_TIMEOUT_MS = 10_000;

export type UpdateInfo = {
  /** Latest release version without the leading "v", e.g. "1.0.123". */
  version: string;
  /** Release notes (the GitHub release body), possibly empty. */
  notes: string;
  /** APK asset download URL, falling back to the release page itself.
   *  The update dialog downloads this file inside the app (see
   *  ./apkDownload) so progress and completion are shown in-app and the
   *  saved file can be opened for install. */
  downloadUrl: string | null;
  /** File name to save the download under, from the release asset. */
  fileName: string;
  /** True when release notes contain a [critical] marker — bypasses dialog suppression. */
  critical: boolean;
};

export type UpdateCheckResult =
  | { status: "update"; info: UpdateInfo }
  | { status: "up-to-date"; latestVersion: string }
  | { status: "error"; reason: string };

/** Parse "v1.0.123" / "1.0.123" into numeric parts; null when unreadable. */
function parseVersion(raw: string): number[] | null {
  const cleaned = raw.trim().replace(/^v/i, "");
  if (!cleaned) return null;
  const parts = cleaned.split(".").map((part) => Number.parseInt(part, 10));
  if (parts.some((part) => Number.isNaN(part) || part < 0)) return null;
  return parts;
}

/** True when `candidate` is a strictly newer version than `current`. */
export function isNewerVersion(candidate: string, current: string): boolean {
  const next = parseVersion(candidate);
  const installed = parseVersion(current);
  if (!next || !installed) return false;
  const length = Math.max(next.length, installed.length);
  for (let index = 0; index < length; index += 1) {
    const a = next[index] ?? 0;
    const b = installed[index] ?? 0;
    if (a !== b) return a > b;
  }
  return false;
}

type GitHubRelease = {
  tag_name?: unknown;
  body?: unknown;
  html_url?: unknown;
  assets?: unknown;
};

type FetchOutcome =
  | { ok: true; info: UpdateInfo | null; latestVersion: string }
  | { ok: false; reason: string; forbidden?: boolean };

function readTimestamp(key: string): number {
  try {
    const value = Number(window.localStorage.getItem(key) ?? "0");
    return Number.isFinite(value) ? value : 0;
  } catch {
    return 0;
  }
}

function writeTimestamp(key: string, value: number): void {
  try { window.localStorage.setItem(key, String(value)); } catch { /* ignore */ }
}

function clearKey(key: string): void {
  try { window.localStorage.removeItem(key); } catch { /* ignore */ }
}

/**
 * Fetch and parse the latest release exactly once. This helper itself
 * never writes the success/failure throttle keys — the caller decides
 * what a success or failure means for its own path. When
 * `recordBackoff` is set, a 403 records the 1-hour GitHub backoff
 * (launch path behaviour, preserved).
 */
async function fetchLatestRelease(options: { recordBackoff: boolean }): Promise<FetchOutcome> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), CHECK_TIMEOUT_MS);
  let response: Response;
  try {
    response = await fetch(LATEST_RELEASE_URL, {
      signal: controller.signal,
      headers: { Accept: "application/vnd.github+json" },
    });
  } catch (error) {
    const aborted = error instanceof DOMException && error.name === "AbortError";
    return { ok: false, reason: aborted ? "The check timed out — the network is too slow." : "No internet connection." };
  } finally {
    window.clearTimeout(timer);
  }
  if (response.status === 403) {
    if (options.recordBackoff) writeTimestamp(BACKOFF_KEY, Date.now() + FORBIDDEN_BACKOFF_MS);
    return { ok: false, reason: "GitHub rate limit (403) — please try again later.", forbidden: true };
  }
  if (!response.ok) {
    return { ok: false, reason: `GitHub returned HTTP ${response.status}.` };
  }
  let release: GitHubRelease;
  try {
    release = (await response.json()) as GitHubRelease;
  } catch {
    return { ok: false, reason: "The release information could not be read." };
  }
  const tag = typeof release.tag_name === "string" ? release.tag_name : "";
  if (!tag || !parseVersion(tag)) {
    return { ok: false, reason: "The latest release has no readable version." };
  }
  const latestVersion = tag.replace(/^v/i, "");
  if (!isNewerVersion(tag, APP_VERSION)) {
    return { ok: true, info: null, latestVersion };
  }
  let downloadUrl: string | null = typeof release.html_url === "string" && release.html_url ? release.html_url : null;
  let fileName = `EasyChat-${latestVersion}.apk`;
  if (Array.isArray(release.assets)) {
    const assets = release.assets as { name?: unknown; browser_download_url?: unknown }[];
    const usable = assets.filter((asset) => typeof asset.browser_download_url === "string" && asset.browser_download_url);
    const apk = usable.find((asset) => typeof asset.name === "string" && asset.name.toLowerCase().endsWith(".apk")) ?? usable[0];
    if (apk && typeof apk.browser_download_url === "string") {
      downloadUrl = apk.browser_download_url;
      if (typeof apk.name === "string" && apk.name) fileName = apk.name;
    }
  }
  const notes = typeof release.body === "string" ? release.body.trim() : "";
  const critical = /\[critical\]|critical\s*[:=]\s*true/i.test(notes);
  return {
    ok: true,
    info: { version: latestVersion, notes, downloadUrl, fileName, critical },
    latestVersion,
  };
}

/**
 * Launch-path check. Resolves with the newer release's info, or null
 * when the app is up to date, throttled, in backoff, or the check
 * failed. Only a successful fetch + parse writes the 3-hour throttle;
 * a failure writes the separate 30-minute failure key instead.
 */
export async function checkForUpdate(): Promise<UpdateInfo | null> {
  try {
    const now = Date.now();
    const backoffUntil = readTimestamp(BACKOFF_KEY);
    if (backoffUntil > now) return null;
    const last = readTimestamp(LAST_CHECK_KEY);
    if (last > 0 && now - last < CHECK_THROTTLE_MS) return null;
    const lastFailure = readTimestamp(FAILURE_KEY);
    if (lastFailure > 0 && now - lastFailure < FAILURE_RETRY_MS) return null;
  } catch { /* storage unavailable — proceed with check */ }
  let outcome: FetchOutcome;
  try {
    outcome = await fetchLatestRelease({ recordBackoff: true });
  } catch {
    writeTimestamp(FAILURE_KEY, Date.now());
    return null;
  }
  if (!outcome.ok) {
    // Failure: do NOT touch the successful-check throttle.
    writeTimestamp(FAILURE_KEY, Date.now());
    return null;
  }
  writeTimestamp(LAST_CHECK_KEY, Date.now());
  clearKey(FAILURE_KEY);
  return outcome.info;
}

/**
 * Manual check for the Settings button. Bypasses the success throttle,
 * the failure window and the backoff entirely, and never writes any
 * throttle key — tapping the button always performs a real fetch and
 * always produces a visible result.
 */
export async function checkForUpdateNow(): Promise<UpdateCheckResult> {
  let outcome: FetchOutcome;
  try {
    outcome = await fetchLatestRelease({ recordBackoff: false });
  } catch {
    return { status: "error", reason: "No internet connection." };
  }
  if (!outcome.ok) return { status: "error", reason: outcome.reason };
  if (outcome.info) return { status: "update", info: outcome.info };
  return { status: "up-to-date", latestVersion: outcome.latestVersion };
}
