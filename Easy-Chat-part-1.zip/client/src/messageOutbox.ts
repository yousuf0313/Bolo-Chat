import {
sendFirebaseGroupMessage,
sendFirebaseMessage,
type FirebaseMessageInput,
} from "./firebase";
import { markThreadKnown } from "./threadKnown";
import { randomId } from "./ids";

/* ===== Durable pending-message outbox =====
 * The bug this fixes: a message that never reached the server lived
 * only in a React state array (the optimistic bubble). Closing the app
 * destroyed that state, so on the next launch the message was simply
 * gone — never sent, never shown, no trace.
 *
 * The contract now: EVERY outgoing message is written to this outbox
 * (localStorage, on the device) BEFORE the network send is attempted,
 * and an entry leaves the outbox only when
 *   - the send's commit resolves — a Firestore commit resolves only
 *     when the server acknowledges the write, or
 *   - the message echoes back in a server snapshot with no pending
 *     local writes (confirmPendingMessages), or
 *   - the user explicitly deletes the bubble.
 * Anything still in the outbox when the app (re)opens is shown in its
 * chat again and re-sent automatically — on launch, when a chat is
 * opened, when the device comes back online, and when the app returns
 * to the foreground. Re-sends are safe: the message id and every field
 * are fixed at queue time, and the send functions write absolute
 * values under that same id, so a retry after a lost acknowledgement
 * rewrites identical data and can never produce a duplicate.
 * Scope: the composer/scheduled sends (text, photo, voice, video,
 * file, contact card, location, forwards — everything that goes
 * through the thread's send path). */

export type PendingGroupContext = {
  memberIds: string[];
  senderName: string;
  senderPhoto: string | null;
};

export type PendingMessage = {
  input: FirebaseMessageInput & { id: string };
  group: PendingGroupContext | null;
  attempts: number;
  /** Epoch ms when the entry was first queued — drives the >30s pending hint. */
  queuedAt: number;
  /** Session-only: the most recent delivery attempt failed, so the
   *  bubble shows its failed/retry state instead of the clock. */
  failed: boolean;
};

const OUTBOX_KEY = "easy-chat-outbox-v1";
const MAX_PERSISTED_ENTRIES = 300;

type StoredPendingMessage = {
  input: FirebaseMessageInput & { id: string };
  group: PendingGroupContext | null;
  attempts: number;
  queuedAt?: number;
};

let entries: PendingMessage[] | null = null;
const listeners = new Set<() => void>();
const inFlight = new Set<string>();
let flushing = false;
let autoFlushInstalled = false;

function isStoredEntry(value: unknown): value is StoredPendingMessage {
  if (!value || typeof value !== "object") return false;
  const entry = value as { input?: unknown; attempts?: unknown };
  if (!entry.input || typeof entry.input !== "object") return false;
  const input = entry.input as { id?: unknown; threadId?: unknown; senderId?: unknown; body?: unknown; type?: unknown };
  return typeof input.id === "string" && typeof input.threadId === "string"
    && typeof input.senderId === "string" && typeof input.body === "string"
    && typeof input.type === "string" && typeof entry.attempts === "number";
}

function loadEntries(): PendingMessage[] {
  if (entries) return entries;
  entries = [];
  try {
    const raw = window.localStorage.getItem(OUTBOX_KEY);
    if (raw) {
      const parsed: unknown = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        entries = parsed.filter(isStoredEntry).map((stored) => ({
          input: stored.input,
          group: stored.group ?? null,
          attempts: stored.attempts,
          queuedAt: typeof stored.queuedAt === "number" ? stored.queuedAt : (stored.input.createdAt ?? Date.now()),
          failed: false,
        }));
      }
    }
  } catch { /* storage unavailable/corrupt — start empty rather than crash */ }
  return entries;
}

function persist() {
  if (!entries) return;
  const stored: StoredPendingMessage[] = entries
    .slice(-MAX_PERSISTED_ENTRIES)
    .map((entry) => ({ input: entry.input, group: entry.group, attempts: entry.attempts, queuedAt: entry.queuedAt }));
  // localStorage is small and media messages carry their bytes inline:
  // if the full queue does not fit, drop the oldest entries from the
  // PERSISTED copy only (the in-memory queue still drives this
  // session) so the newest unsent messages always survive a restart.
  let candidate = stored;
  for (;;) {
    try {
      window.localStorage.setItem(OUTBOX_KEY, JSON.stringify(candidate));
      return;
    } catch {
      if (candidate.length === 0) return;
      candidate = candidate.slice(1);
    }
  }
}

function notify() {
  listeners.forEach((listener) => listener());
}

function removeEntry(id: string) {
  if (!entries) return;
  const next = entries.filter((entry) => entry.input.id !== id);
  if (next.length === entries.length) return;
  entries = next;
  persist();
  notify();
}

/** Current queue snapshot for useSyncExternalStore. The internal array
 *  is treated as immutable — every mutation replaces it — so the
 *  identity changes exactly when the queue does, which is what
 *  re-renders subscribers (and keeps React's snapshot cache happy). */
export function getPendingMessages(): PendingMessage[] {
  return loadEntries();
}

export function subscribePendingMessages(listener: () => void): () => void {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

/** Persist a message in the outbox BEFORE it is sent. Idempotent per
 *  message id: re-queueing (a manual retry) refreshes the stored
 *  input and clears the failed flag. Returns the stored entry. */
export function queuePendingMessage(
  input: FirebaseMessageInput,
  group: PendingGroupContext | null,
): PendingMessage {
  const list = loadEntries();
  const withId: FirebaseMessageInput & { id: string } = { ...input, id: input.id ?? randomId() };
  const existing = list.find((entry) => entry.input.id === withId.id);
  if (existing) {
    const refreshed: PendingMessage = { ...existing, input: withId, group, failed: false };
    entries = list.map((entry) => (entry.input.id === withId.id ? refreshed : entry));
    persist();
    notify();
    return refreshed;
  }
  const entry: PendingMessage = { input: withId, group, attempts: 0, queuedAt: Date.now(), failed: false };
  entries = [...list, entry];
  // A queued message proves its thread exists: record that protection
  // NOW, durably, so neither a restart nor the startup flush can ever
  // leave this thread looking "not found" before its first snapshot.
  markThreadKnown(withId.threadId, true);
  persist();
  notify();
  return entry;
}

/** The user deleted a pending/failed bubble: drop it for good. */
export function discardPendingMessage(id: string) {
  removeEntry(id);
}

/** Server confirmation: ids the live snapshot echoed back with no
 *  pending local writes are acknowledged by the server, so their
 *  outbox entries have done their job. */
export function confirmPendingMessages(ids: Iterable<string>) {
  if (!entries || entries.length === 0) return;
  const confirmed = new Set(ids);
  if (!entries.some((entry) => confirmed.has(entry.input.id))) return;
  entries = entries.filter((entry) => !confirmed.has(entry.input.id));
  persist();
  notify();
}

/** Attempt delivery of one queued message now. Resolves once the
 *  server has acknowledged the write (the entry is then removed);
 *  rejects after marking the entry failed, keeping it queued. */
export async function deliverPendingMessage(id: string): Promise<void> {
  const entry = loadEntries().find((item) => item.input.id === id);
  if (!entry || inFlight.has(id)) return;
  inFlight.add(id);
  try {
    if (entry.group) {
      await sendFirebaseGroupMessage({ ...entry.input, ...entry.group });
    } else {
      await sendFirebaseMessage(entry.input);
    }
    // The server just acknowledged a message in this thread: refresh the
    // thread's existence record BEFORE the entry leaves the outbox, so
    // the flush can never strip the thread's protection in between.
    markThreadKnown(entry.input.threadId, true);
    removeEntry(id);
  } catch (error) {
    if (entries) {
      entries = entries.map((item) => (item.input.id === id ? { ...item, attempts: item.attempts + 1, failed: true } : item));
    }
    persist();
    notify();
    throw error;
  } finally {
    inFlight.delete(id);
  }
}

/** Re-send everything still queued, oldest first. Stops at the first
 *  failure — the connection is presumed down, the remaining entries
 *  stay queued, and the next trigger (relaunch, reconnect, chat open)
 *  tries again. When a sender id is given, only that user's entries
 *  are attempted: a queue left behind by a previous account on this
 *  device is never sent under someone else's sign-in. */
export async function flushPendingMessages(senderId?: string): Promise<void> {
  if (flushing) return;
  flushing = true;
  try {
    const only = senderId?.trim().toLocaleLowerCase();
    const queued = [...loadEntries()]
      .filter((entry) => !only || entry.input.senderId.trim().toLocaleLowerCase() === only)
      .sort((a, b) => (a.input.createdAt ?? 0) - (b.input.createdAt ?? 0));
    for (const entry of queued) {
      if (!loadEntries().some((item) => item.input.id === entry.input.id)) continue;
      try {
        await deliverPendingMessage(entry.input.id);
      } catch {
        return;
      }
    }
  } finally {
    flushing = false;
  }
}

/** Retry the queue whenever delivery becomes plausible again: the
 *  device reconnects, or the app returns to the foreground. Installed
 *  once; safe to call repeatedly. */
export function installPendingAutoFlush() {
  if (autoFlushInstalled || typeof window === "undefined") return;
  autoFlushInstalled = true;
  window.addEventListener("online", () => { void flushPendingMessages(); });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") void flushPendingMessages();
  });
}


/** True while this message id is still waiting in the outbox (not yet
 *  server-acknowledged). Used by the thread to render the clock state. */
export function isPendingOutbox(id: string): boolean {
  return loadEntries().some((entry) => entry.input.id === id);
}

/** When a queued entry was first queued (epoch ms), or null. */
export function pendingQueuedAt(id: string): number | null {
  const entry = loadEntries().find((item) => item.input.id === id);
  return entry ? entry.queuedAt : null;
}

const retryInFlight = new Set<string>();

/** Manual resend of one pending/failed message — the ONLY retry path.
 *  Reuses the original message id (never mints a new one) and goes
 *  through deliverPendingMessage, whose writes are merge-based and
 *  never touch status/read_at. Guarded per-id so a manual tap can
 *  never collide with the automatic flush. */
export async function resendMessage(id: string): Promise<void> {
  if (retryInFlight.has(id)) return;
  retryInFlight.add(id);
  try {
    await deliverPendingMessage(id);
  } finally {
    retryInFlight.delete(id);
  }
}

export function isRetryInFlight(id: string): boolean {
  return retryInFlight.has(id);
}
