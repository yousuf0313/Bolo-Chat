import { useSyncExternalStore } from "react";

/* Starred messages: a per-account, on-device index (localStorage).
 * Each entry snapshots everything the Starred screen needs — chat,
 * sender, a preview and the message's own timestamp — so the screen
 * renders instantly without opening every thread. Tapping an entry
 * opens its chat and asks the thread to scroll to that message. */

export type StarredItem = {
  key: string;
  conversation_id: string;
  thread_id: string;
  message_id: string;
  body: string;
  message_type: string;
  sender_name: string;
  contact_name: string;
  created_at: string;
  starred_at: number;
};

const STORE_PREFIX = "easy-chat-starred-v1:";
let version = 0;
const listeners = new Set<() => void>();
function notify() { version += 1; listeners.forEach((listener) => listener()); }
function subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; }
function snapshot() { return version; }
/** Re-render hook for components reading the starred store. */
export function useStarredVersion(): number {
  return useSyncExternalStore(subscribe, snapshot, snapshot);
}

function storeKey(userId: string) { return `${STORE_PREFIX}${userId.trim().toLocaleLowerCase()}`; }

export function loadStarred(userId: string): StarredItem[] {
  try {
    const parsed: unknown = JSON.parse(window.localStorage.getItem(storeKey(userId)) ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is StarredItem => Boolean(item) && typeof item === "object"
      && typeof (item as StarredItem).key === "string" && typeof (item as StarredItem).message_id === "string" && typeof (item as StarredItem).conversation_id === "string")
      .sort((a, b) => b.starred_at - a.starred_at);
  } catch { return []; }
}

function saveStarred(userId: string, items: StarredItem[]) {
  try { window.localStorage.setItem(storeKey(userId), JSON.stringify(items.slice(0, 500))); } catch { /* storage full/unavailable */ }
  notify();
}

export function starKey(threadId: string, messageId: string) { return `${threadId}:${messageId}`; }

export function isStarred(userId: string, threadId: string, messageId: string): boolean {
  const key = starKey(threadId, messageId);
  return loadStarred(userId).some((item) => item.key === key);
}

/** Toggle a message's star; returns the new starred state. */
export function toggleStarred(userId: string, item: Omit<StarredItem, "key" | "starred_at">): boolean {
  const key = starKey(item.thread_id, item.message_id);
  const items = loadStarred(userId);
  if (items.some((entry) => entry.key === key)) {
    saveStarred(userId, items.filter((entry) => entry.key !== key));
    return false;
  }
  saveStarred(userId, [{ ...item, key, starred_at: Date.now() }, ...items]);
  return true;
}
