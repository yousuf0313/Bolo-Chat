/* Quiet hours (Do Not Disturb) for message notifications.
 *
 * Quiet hours are a property of this device — they decide whether THIS
 * phone rings for a new message — so they live in localStorage next to
 * the other on-device state rather than in the synced profile. The
 * window may wrap past midnight (e.g. 22:00 → 07:00). */

export type QuietHours = { enabled: boolean; from: string; to: string };

const QUIET_HOURS_KEY = "easy-chat-quiet-hours-v1";
const TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d$/;

export function loadQuietHours(): QuietHours {
  try {
    const raw = window.localStorage.getItem(QUIET_HOURS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<QuietHours>;
      if (typeof parsed.enabled === "boolean" && typeof parsed.from === "string" && TIME_PATTERN.test(parsed.from) && typeof parsed.to === "string" && TIME_PATTERN.test(parsed.to)) {
        return { enabled: parsed.enabled, from: parsed.from, to: parsed.to };
      }
    }
  } catch { /* storage unavailable — fall through to defaults */ }
  return { enabled: false, from: "22:00", to: "07:00" };
}

export function saveQuietHours(value: QuietHours) {
  try { window.localStorage.setItem(QUIET_HOURS_KEY, JSON.stringify(value)); } catch { /* storage unavailable */ }
}

function minutesOfDay(value: string): number {
  const [hours = 0, minutes = 0] = value.split(":").map(Number);
  return hours * 60 + minutes;
}

/** True when `at` falls inside the quiet window (start inclusive, end
 *  exclusive). A window whose start equals its end means "always quiet"
 *  while enabled. */
export function isQuietNow(settings: QuietHours, at: Date = new Date()): boolean {
  if (!settings.enabled) return false;
  const start = minutesOfDay(settings.from);
  const end = minutesOfDay(settings.to);
  const now = at.getHours() * 60 + at.getMinutes();
  if (start === end) return true;
  if (start < end) return now >= start && now < end;
  return now >= start || now < end;
}
