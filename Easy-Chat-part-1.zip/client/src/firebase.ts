import { getApp, getApps, initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, getRedirectResult, onAuthStateChanged, signInAnonymously, signInWithCredential, signInWithPopup, signInWithRedirect, type Auth, type User } from "firebase/auth";
import { FirebaseAuthentication } from "@capacitor-firebase/authentication";
import { isNativeApp } from "./nativeBiometric";
import { isSamePerson } from "./identity";
import { markThreadKnown } from "./threadKnown";
import {
Timestamp,
collection,
deleteDoc,
disableNetwork,
doc,
enableNetwork,
getDoc,
getDocs,
getDocsFromCache,
getFirestore,
increment,
initializeFirestore,
limit,
memoryLocalCache,
onSnapshot,
orderBy,
persistentLocalCache,
persistentMultipleTabManager,
query,
setDoc,
startAfter,
updateDoc,
where,
writeBatch,
type DocumentData,
type DocumentSnapshot,
type Firestore,
type QuerySnapshot,
type UpdateData,
type QueryDocumentSnapshot,
type Unsubscribe,
type WriteBatch,
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBYLf2pXzjyefhk2mC-Q71G6SFgheC6d2E",
  authDomain: "rabta-24267.firebaseapp.com",
  projectId: "rabta-24267",
  storageBucket: "rabta-24267.firebasestorage.app",
  messagingSenderId: "635724835065",
  appId: "1:635724835065:web:5fce3c5279bd1438fb1a28",
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

/* Firestore is deliberately NOT created with the plain defaults. The
 * default streaming transport silently stalls inside the Android
 * WebView this app ships in: the connection looks open, no error is
 * raised, and no data flows — the first message after launch goes
 * through on the fresh stream and everything after it stops, in both
 * directions, which is exactly the bug users kept reporting.
 * Auto-detected long polling was tried and is NOT enough: its probe
 * can pass on a healthy first connection, after which the chosen
 * streaming transport still wedges mid-session without any error.
 * Long polling is therefore FORCED: every poll is a discrete HTTP
 * request that either returns data or fails observably, so a dead
 * connection is detected and replaced instead of silently swallowing
 * messages. The persistent local cache additionally lets listeners
 * show everything already on the phone instantly and keeps pending
 * writes safe across restarts.
 *
 * RE-EVALUATED when chat opening was measured at ~1 minute on a
 * flagship phone: the transport was a suspect, but the evidence does
 * not convict it. A long-poll cycle costs one HTTP round trip, and
 * listeners emit the persistent-cache snapshot first regardless; the
 * minute went to snapshot MAPPING blocking on chunked-media
 * downloads (see handleMessageSnapshot's two-phase delivery) — with
 * that fixed, long polling's remaining cost is seconds at worst on a
 * bad link, while switching back to streaming would re-introduce a
 * silent total data stop. Correctness beats the smaller latency:
 * forced long polling stays. */
function createFirestore(): Firestore {
  try {
    return initializeFirestore(app, {
      experimentalForceLongPolling: true,
      localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    });
  } catch {
    try {
      return initializeFirestore(app, {
        experimentalForceLongPolling: true,
        localCache: memoryLocalCache(),
      });
    } catch {
      return getFirestore(app);
    }
  }
}

const db = createFirestore();

/* ===== Firebase Authentication bootstrap (anonymous sign-in) =====
 * ROOT CAUSE of the "message stuck on the clock + chat flips to
 * 'This chat could not be found'" failure: this client NEVER signed in
 * to Firebase Authentication, so every Firestore request went out with
 * request.auth == null. While the project's security rules were open
 * (test mode) that worked fine, which hid the problem completely. The
 * moment the rules were tightened to authenticated-only
 * (allow read, write: if request.auth != null) the server started
 * rejecting EVERYTHING this app does:
 *   - message/conversation listeners failed with permission-denied,
 *     and the thread screen treated that listener error as "chat not
 *     found" and replaced the whole conversation with it;
 *   - message writes were rejected by the server, so a sent message
 *     never got its server acknowledgement and sat on the pending
 *     clock forever (its outbox retries were rejected too).
 * Messages from before the rules change displayed normally because
 * they were already in the on-device cache — only new reads/writes
 * were blocked.
 *
 * THE FIX: the app now signs in anonymously with Firebase Auth as
 * soon as this module loads, and every write commit waits for that
 * sign-in (see commitWithRecovery below). Read listeners attach
 * immediately without waiting for auth — under the open rules they
 * work either way, and under authenticated-only rules a too-early
 * listener lands in the supervisor's classified retry path, which
 * force-refreshes the token and resubscribes once sign-in lands.
 * Anonymous sign-in needs no action from the user — no password, no
 * code, nothing to tap — and it makes request.auth != null true for
 * all app traffic, so the authenticated-only rules can stay on
 * permanently.
 * DEPLOY REQUIREMENT: "Anonymous" must be enabled as a sign-in
 * provider in the Firebase console (Authentication → Sign-in method)
 * for project rabta-24267. If it is not enabled yet, sign-in fails:
 * ensureFirebaseAuth then REJECTS (writes surface the failure through
 * their retry paths and read listeners land in the supervisor's
 * classified reconnecting state) instead of silently falling through
 * to an unauthenticated subscription; the supervisor keeps retrying
 * sign-in in the background, and once the provider is enabled the app
 * heals itself with no update needed. */
const auth: Auth = getAuth(app);
let authReadyPromise: Promise<void> | null = null;
let authWatchInstalled = false;

function installAuthWatch() {
  if (authWatchInstalled) return;
  authWatchInstalled = true;
  onAuthStateChanged(auth, (user) => {
    // A lost/expired anonymous session is replaced silently — the user
    // never sees a sign-in screen in this app.
    if (!user) {
      authReadyPromise = null;
      void signInAnonymously(auth).catch(() => undefined);
    }
  });
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

/** One anonymous sign-in attempt with a REAL timeout: the SDK promise
 *  can hang indefinitely on a wedged WebView network stack, so it is
 *  raced against a timer. A sign-in that lands after the race is lost
 *  still leaves auth.currentUser set, which later calls pick up. */
async function signInAttempt(timeoutMs: number): Promise<boolean> {
  if (auth.currentUser) return true;
  try {
    await Promise.race([
      signInAnonymously(auth),
      delay(timeoutMs).then(() => { throw new Error("auth-signin-timeout"); }),
    ]);
  } catch { /* fall through to the currentUser check */ }
  return auth.currentUser !== null;
}

/** Resolves once a Firebase Auth session exists; rejects when sign-in
 *  could not be established. SINGLE-FLIGHT: concurrent callers share
 *  one in-flight attempt, so a cold start never fires parallel duplicate
 *  sign-ins. The attempt first awaits authStateReady() so a persisted
 *  session restored from disk is not raced by a fresh anonymous
 *  sign-in, then signs in with a ~4s timeout and one backoff retry.
 *  Callers that cannot proceed without auth (writes) await this and
 *  surface the failure through their normal retry paths; read listeners
 *  do NOT wait for it (see resilientSnapshot). */
export function ensureFirebaseAuth(): Promise<void> {
  installAuthWatch();
  if (auth.currentUser) return Promise.resolve();
  if (authReadyPromise) return authReadyPromise;
  const attempt = (async () => {
    // Wait (bounded) for Firebase Auth to finish restoring any session
    // persisted on the device before deciding a sign-in is needed.
    try {
      await Promise.race([auth.authStateReady(), delay(3000)]);
    } catch { /* proceed to sign-in */ }
    if (auth.currentUser) return;
    if (await signInAttempt(4000)) return;
    // One retry after a short pause covers a cold-start network race.
    await delay(1200);
    if (await signInAttempt(5000)) return;
    throw new Error("firebase-auth-unavailable");
  })();
  authReadyPromise = attempt;
  void attempt.then(
    () => { if (authReadyPromise === attempt && !auth.currentUser) authReadyPromise = null; },
    () => { if (authReadyPromise === attempt) authReadyPromise = null; },
  );
  return attempt;
}

/** Force a fresh ID token after an auth-class listener error: the
 *  cached token may be stale or the session silently dropped, and
 *  resubscribing with the same token would fail identically forever.
 *  Falls back to a full (single-flight) sign-in when there is no user. */
async function refreshAuthAfterError(): Promise<void> {
  const user = auth.currentUser;
  if (user) {
    try { await user.getIdToken(true); return; } catch { /* session unusable — sign in again below */ }
  }
  await ensureFirebaseAuth().catch(() => undefined);
}

// Start signing in immediately at module load so the session is
// normally already established before the first screen subscribes.
void ensureFirebaseAuth().catch(() => undefined);

/* ===== Google sign-in (account page "With Google") =====
 * Real Google sign-in through this project's Firebase Authentication
 * (Google provider). The popup opens Google's own account chooser with
 * the device's Gmail accounts; choosing one replaces the anonymous
 * session with the Google session, which Firebase Auth persists like
 * any other sign-in. The Easy Chat identity stays the account's email
 * address — the caller feeds the returned email/name/photo through the
 * exact same profile bootstrap as the Gmail and phone-OTP routes
 * (restore the existing `profiles` document, or create it), so no
 * second identity system appears.
 * DEPLOY REQUIREMENT: "Google" must be enabled as a sign-in provider
 * in the Firebase console (Authentication → Sign-in method) for
 * project rabta-24267, and the origin serving the app must be in the
 * project's authorised domains, or the popup fails with a visible
 * error the login screen surfaces.
 * NATIVE (Android APK): the sign-in runs through the
 * @capacitor-firebase/authentication plugin's native Google flow and
 * the returned credential is signed into this same Auth instance —
 * see signInWithGoogle below. The native project must carry the
 * project's google-services.json and the Android app's SHA-1
 * fingerprint must be registered in the Firebase console, or the
 * native chooser fails with a visible error. */
export type GoogleAccount = { email: string; name: string; photo: string | null };

function googleAccountFromUser(user: User): GoogleAccount | null {
  const email = (user.email ?? "").trim().toLocaleLowerCase();
  if (!email) return null;
  return { email, name: (user.displayName ?? "").trim() || email.split("@")[0] || email, photo: user.photoURL ?? null };
}

/** Marker thrown when sign-in continues through a full-page redirect:
 *  the browser is leaving for Google, and the result is picked up by
 *  consumeGoogleRedirectResult() when the page comes back. */
export const GOOGLE_REDIRECT_PENDING = "google-redirect-pending";

export async function signInWithGoogle(): Promise<GoogleAccount> {
  installAuthWatch();
  const provider = new GoogleAuthProvider();
  // Always show the account chooser, even when one account is already
  // signed in to Google — the owner asked for the Gmail list to appear.
  provider.setCustomParameters({ prompt: "select_account" });
  if (isNativeApp()) {
    /* Native Android: Google's OAuth flow cannot run inside the app's
     * WebView (Google blocks it), so the account chooser is the native
     * one from the @capacitor-firebase/authentication plugin. The
     * plugin returns the Google credential; its ID token is signed
     * into THIS Firebase Auth instance with signInWithCredential, so
     * the rest of the app sees exactly the same kind of session as the
     * web popup flow produces, and the caller runs the same profile
     * bootstrap either way. */
    const result = await FirebaseAuthentication.signInWithGoogle();
    const idToken = result.credential?.idToken ?? null;
    if (!idToken) throw new Error("google-no-credential");
    const signedIn = await signInWithCredential(auth, GoogleAuthProvider.credential(idToken));
    const account = googleAccountFromUser(signedIn.user);
    if (!account) throw new Error("google-no-email");
    return account;
  }
  try {
    const result = await signInWithPopup(auth, provider);
    const account = googleAccountFromUser(result.user);
    if (!account) throw new Error("google-no-email");
    return account;
  } catch (error) {
    const code = (error as { code?: string } | null)?.code ?? "";
    // A blocked popup (or an environment where popups cannot work)
    // falls back to the redirect flow; every other failure — the user
    // closing the chooser (auth/popup-closed-by-user), a domain that
    // is not authorised, no network — surfaces to the caller as-is.
    if (code === "auth/popup-blocked" || code === "auth/operation-not-supported-in-this-environment") {
      await signInWithRedirect(auth, provider);
      throw new Error(GOOGLE_REDIRECT_PENDING);
    }
    throw error;
  }
}

/** The Google account a redirect sign-in returned with, or null when
 *  this page load is not a redirect return (or it failed). Called once
 *  by the account screen on mount. */
export async function consumeGoogleRedirectResult(): Promise<GoogleAccount | null> {
  try {
    const result = await getRedirectResult(auth);
    return result ? googleAccountFromUser(result.user) : null;
  } catch { return null; }
}

/* ===== Realtime listener supervisor =====
 * A bare onSnapshot listener dies permanently on its first stream error
 * (network drop, phone sleep, Wi-Fi ↔ mobile switch): Firestore never
 * revives it, and previously nothing here re-subscribed, so new
 * messages only appeared when some screen happened to remount and a
 * fresh listener connected — often hours later. Every listener in this
 * file is therefore created through this supervisor, which:
 *  - attaches IMMEDIATELY: reads are never serialized behind the auth
 *    bootstrap (the auth gate applies to writes only, via
 *    commitWithRecovery / ensureFirebaseAuth at the write sites);
 *  - CLASSIFIES errors by error.code: auth-class failures
 *    (permission-denied, unauthenticated, auth/*) force a fresh ID
 *    token (getIdToken(true)) before resubscribing, so a stale token
 *    cannot fail identically forever; transient failures simply retry;
 *  - applies HYSTERESIS before surfacing anything: an error reaches
 *    the caller's onError only after the listener has been failing
 *    continuously for ~12 seconds. A brief cold-start or network blip
 *    therefore never flashes an error screen — the listener just heals;
 *  - retries with exponential backoff plus jitter, staggered so a
 *    fleet of listeners recovering at once does not stampede;
 *  - recovers GENTLY on foreground/online: only unhealthy listeners
 *    restart (a visibility change must not tear down every healthy
 *    stream — each restart costs a fresh snapshot round-trip, which
 *    on a slow link is exactly the multi-second stall users saw);
 *  - runs a PER-LISTENER silence watchdog: a wedged stream raises NO
 *    error, so a listener that was healthy but has delivered nothing
 *    for over 90 seconds while the app is on screen is restarted on
 *    its own; healthy active listeners are never disturbed, and a
 *    listener already in its retry loop is left to it;
 *  - nudges Firestore's network layer back on during recovery.
 * Delivery stays pure realtime push (onSnapshot) — the retries only
 * repair broken streams; nothing polls for messages. */

type ListenerRecovery = { restart: () => void; isHealthy: () => boolean; lastSnapshotAt: () => number; needsRecovery: () => boolean };

const activeListeners = new Set<ListenerRecovery>();
let recoveryHooksInstalled = false;

/** How long a listener must fail continuously before its error is
 *  surfaced to the UI layer at all. */
const ERROR_SURFACE_DELAY_MS = 12_000;
/** A healthy listener silent for longer than this is presumed wedged. */
const LISTENER_SILENCE_LIMIT_MS = 90_000;

function installRecoveryHooks() {
  if (recoveryHooksInstalled || typeof window === "undefined") return;
  recoveryHooksInstalled = true;
  const recover = () => {
    void enableNetwork(db).catch(() => undefined);
    activeListeners.forEach((listener) => {
      if (listener.needsRecovery()) listener.restart();
    });
  };
  window.addEventListener("online", recover);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") recover();
  });
  window.setInterval(() => {
    if (document.visibilityState !== "visible") return;
    const now = Date.now();
    activeListeners.forEach((listener) => {
      // Per-listener silence watchdog: only a listener that believes
      // itself healthy yet has been silent past the limit is wedged.
      if (listener.isHealthy() && listener.lastSnapshotAt() > 0 && now - listener.lastSnapshotAt() > LISTENER_SILENCE_LIMIT_MS) {
        listener.restart();
      }
    });
  }, 25_000);
}

type ListenerErrorClass = "auth" | "transient";

function classifyListenerError(error: Error): ListenerErrorClass {
  const code = (error as { code?: unknown }).code;
  if (code === "permission-denied" || code === "unauthenticated") return "auth";
  if (typeof code === "string" && code.startsWith("auth/")) return "auth";
  return "transient";
}

function resilientSnapshot<TSnapshot>(
  subscribe: (onNext: (snapshot: TSnapshot) => void, onError: (error: Error) => void) => Unsubscribe,
  onNext: (snapshot: TSnapshot) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  installRecoveryHooks();
  let inner: Unsubscribe | null = null;
  let stopped = false;
  let healthy = false;
  let errorReported = false;
  let retryDelayMs = 1000;
  let retryTimer: number | null = null;
  let surfaceTimer: number | null = null;
  let generation = 0;
  // Set at supervisor creation and updated ONLY when a snapshot actually
  // arrives — deliberately never reset by (re)starts, so the silence
  // watchdog measures real data flow, not subscription churn.
  let lastSnapshot = Date.now();
  let firstFailureAt: number | null = null;
  let lastError: Error | null = null;

  const clearRetry = () => {
    if (retryTimer !== null) { window.clearTimeout(retryTimer); retryTimer = null; }
  };
  const clearSurface = () => {
    if (surfaceTimer !== null) { window.clearTimeout(surfaceTimer); surfaceTimer = null; }
  };
  const teardownInner = () => {
    if (inner) { try { inner(); } catch { /* listener already gone */ } inner = null; }
  };
  const scheduleSurface = (gen: number) => {
    if (errorReported || surfaceTimer !== null || firstFailureAt === null) return;
    const wait = Math.max(0, firstFailureAt + ERROR_SURFACE_DELAY_MS - Date.now());
    surfaceTimer = window.setTimeout(() => {
      surfaceTimer = null;
      if (stopped || gen !== generation || healthy || errorReported) return;
      errorReported = true;
      if (lastError) onError(lastError);
    }, wait);
  };
  const handleFailure = (gen: number, error: Error) => {
    if (stopped || gen !== generation) return;
    healthy = false;
    lastError = error;
    if (firstFailureAt === null) firstFailureAt = Date.now();
    scheduleSurface(gen);
    // Auth-class failures must refresh the token before resubscribing —
    // retrying with the same stale token fails identically forever.
    if (classifyListenerError(error) === "auth") void refreshAuthAfterError();
    clearRetry();
    const jitter = Math.floor(Math.random() * 750);
    const delay = retryDelayMs + jitter;
    retryDelayMs = Math.min(retryDelayMs * 2, 30_000);
    retryTimer = window.setTimeout(() => {
      retryTimer = null;
      if (stopped) return;
      teardownInner();
      start();
    }, delay);
  };
  const start = () => {
    if (stopped) return;
    const gen = ++generation;
    startSubscription(gen);
  };
  const startSubscription = (gen: number) => {
    if (stopped || gen !== generation) return;
    try {
      inner = subscribe(
        (snapshot) => {
          if (stopped || gen !== generation) return;
          healthy = true;
          errorReported = false;
          firstFailureAt = null;
          lastError = null;
          retryDelayMs = 1000;
          lastSnapshot = Date.now();
          clearRetry();
          clearSurface();
          onNext(snapshot);
        },
        (error) => handleFailure(gen, error),
      );
    } catch (error) {
      handleFailure(gen, error instanceof Error ? error : new Error("Listener failed to start"));
    }
  };

  const recovery: ListenerRecovery = {
    restart: () => {
      if (stopped) return;
      clearRetry();
      retryDelayMs = 1000;
      teardownInner();
      // Stagger simultaneous restarts so a recovery sweep does not
      // re-subscribe every listener in the same tick.
      const gen = ++generation;
      window.setTimeout(() => { if (!stopped && gen === generation) startSubscription(gen); }, Math.floor(Math.random() * 600));
    },
    isHealthy: () => healthy,
    lastSnapshotAt: () => lastSnapshot,
    needsRecovery: () => !healthy && retryTimer === null,
  };
  activeListeners.add(recovery);
  start();

  return () => {
    stopped = true;
    activeListeners.delete(recovery);
    clearRetry();
    clearSurface();
    teardownInner();
  };
}

let connectionCycle: Promise<void> | null = null;

/** Force a full Firestore connection cycle: drop the (possibly wedged)
 * transport, reconnect, and restart every live listener. Used when a
 * write's commit never comes back — the signature of a silently dead
 * stream — so a stuck send heals itself in seconds instead of the
 * message sitting on the clock icon until the app is restarted.
 * Concurrent callers share one cycle. */
export function recoverFirestoreConnection(): Promise<void> {
  if (connectionCycle) return connectionCycle;
  connectionCycle = (async () => {
    try {
      await disableNetwork(db).catch(() => undefined);
      await enableNetwork(db).catch(() => undefined);
      activeListeners.forEach((listener) => listener.restart());
    } finally {
      connectionCycle = null;
    }
  })();
  return connectionCycle;
}

const COMMIT_TIMEOUT_MS = 15_000;

/** Commit a write batch, healing a wedged connection if the commit is
 * not acknowledged in time. A Firestore commit promise resolves only
 * when the server acknowledges the write; on a silently dead WebView
 * stream it can hang forever, which is how a "sent" message used to
 * never actually leave the phone. The batch is REBUILT for the retry
 * (a batch cannot be committed twice) from the same fixed document ids
 * and values the caller captured, so a retry after a lost
 * acknowledgement rewrites identical data and can never duplicate a
 * message. */
async function commitWithRecovery(buildBatch: (isRetry: boolean) => WriteBatch): Promise<void> {
  // A commit attempted before the anonymous Auth session exists is
  // rejected by authenticated-only rules and the message would stay
  // on its pending clock — wait for sign-in before every attempt
  // (including the recovery retry, whose session may have been lost).
  await ensureFirebaseAuth();
  const attempt = async (isRetry: boolean): Promise<void> => {
    if (isRetry) await ensureFirebaseAuth();
    const commitPromise = buildBatch(isRetry).commit();
    // If the race below times out, this promise may still settle later;
    // swallow that late outcome so it never surfaces as an unhandled
    // rejection — its writes carry the same ids and values as the retry.
    void commitPromise.catch(() => undefined);
    let timer: number | null = null;
    try {
      await Promise.race([
        commitPromise,
        new Promise<never>((_resolve, reject) => {
          timer = window.setTimeout(() => reject(new Error("firestore-commit-timeout")), COMMIT_TIMEOUT_MS);
        }),
      ]);
    } finally {
      if (timer !== null) window.clearTimeout(timer);
    }
  };
  try {
    await attempt(false);
  } catch {
    await recoverFirestoreConnection();
    await attempt(true);
  }
}

export type FirebaseDeliveryStatus = "sent" | "delivered" | "read";
export type FirebaseMessageType = "text" | "audio" | "image" | "video" | "file" | "contact" | "location" | "poll" | "sticker" | "call";
const FIREBASE_MESSAGE_TYPES: FirebaseMessageType[] = ["text", "audio", "image", "video", "file", "contact", "location", "poll", "sticker", "call"];

function parseMessageType(value: unknown): FirebaseMessageType {
  return typeof value === "string" && (FIREBASE_MESSAGE_TYPES as string[]).includes(value) ? value as FirebaseMessageType : "text";
}

export type FirebaseFileMeta = { name: string; size: number; mime_type: string };
export type FirebaseContactCard = { name: string; phone: string | null; email: string | null; username: string | null };
export type FirebaseLocationData = { lat: number; lng: number; live: boolean; updated_at: string | null };
export type FirebasePollData = { question: string; options: { id: string; text: string }[]; votes: Record<string, string[]> };
export type FirebaseGroupReminder = { text: string; set_by: string; set_by_name: string; created_at: string | null };
export type FirebaseVoiceEffect = "original" | "soft" | "deep" | "bright" | "quick" | "slow" | "chipmunk" | "helium" | "robot" | "monster" | "echo" | "cave";
const FIREBASE_VOICE_EFFECTS: FirebaseVoiceEffect[] = ["original", "soft", "deep", "bright", "quick", "slow", "chipmunk", "helium", "robot", "monster", "echo", "cave"];

export type FirebaseContact = {
  id: string;
  name: string;
  email: string | null;
  username: string | null;
  mobile: string | null;
  photo: string | null;
  about?: string | null;
};

export type FirebaseConversation = {
  id: string;
  contact_name: string;
  contact_email: string | null;
  contact_username: string | null;
  contact_mobile: string | null;
  contact_photo: string | null;
  target_user_id: string;
  last_message: string | null;
  last_message_type: FirebaseMessageType | null;
  last_sender_id: string | null;
  unread_count: number;
  updated_at: string;
  is_group?: boolean;
  group_id?: string;
  group_description?: string;
  group_members?: FirebaseContact[];
  group_admins?: string[];
  group_created_by?: string;
};

export type FirebaseMessage = {
  id: string;
  body: string;
  direction: "self" | "contact";
  sender_id: string;
  receiver_id: string;
  message_type: FirebaseMessageType;
  audio_url: string | null;
  image_url: string | null;
  /** True when this message's media lives in the mediaChunks
   *  subcollection and has NOT been downloaded yet — the thread
   *  paints without it and the media is filled in by the follow-up
   *  delivery (see handleMessageSnapshot). media_mime is the type
   *  the eventual data URL must carry. Mirrors FirebaseStatus. */
  media_pending?: boolean;
  media_mime?: string | null;
  sticker_url: string | null;
  video_url: string | null;
  file_url: string | null;
  file_meta: FirebaseFileMeta | null;
  contact_card: FirebaseContactCard | null;
  location: FirebaseLocationData | null;
  poll: FirebasePollData | null;
  scheduled_for: string | null;
  delivery_status: FirebaseDeliveryStatus;
  audio_duration: number | null;
  waveform: number[] | null;
  voice_effect: FirebaseVoiceEffect;
  unlock_at: string | null;
  password_hash: string | null;
  password_salt: string | null;
  expires_at: string | null;
  created_at: string;
  call_kind: "audio" | "video" | null;
  call_status: string | null;
  call_duration_sec: number | null;
  reactions: Record<string, string[]>;
  reply_to: { id: string; body: string; sender_name: string } | null;
  forwarded: boolean;
  sender_name?: string | null;
  sender_photo?: string | null;
};

export type FirebaseMessageInput = {
  id?: string;
  threadId: string;
  senderId: string;
  receiverId: string;
  body: string;
  type: FirebaseMessageType;
  dataUrl?: string;
  fileMeta?: FirebaseFileMeta;
  contactCard?: FirebaseContactCard;
  location?: { lat: number; lng: number; live: boolean };
  poll?: { question: string; options: { id: string; text: string }[] };
  scheduledFor?: number | null;
  audioDuration?: number;
  waveform?: number[];
  voiceEffect?: FirebaseVoiceEffect;
  unlockAt?: number | null;
  passwordHash?: string | null;
  passwordSalt?: string | null;
  ttlSeconds?: number | null;
  replyTo?: { id: string; body: string; senderName: string } | null;
  forwarded?: boolean;
  createdAt?: number;
};

function normalizeId(value: string) {
  return value.trim().toLocaleLowerCase();
}

function safeDocPart(value: string) {
  return encodeURIComponent(normalizeId(value));
}

export function firebaseThreadId(firstUserId: string, secondUserId: string) {
  return [normalizeId(firstUserId), normalizeId(secondUserId)].sort((a, b) => a.localeCompare(b)).map(safeDocPart).join("--");
}

function dateIso(value: unknown): string {
  if (value instanceof Timestamp) return value.toDate().toISOString();
  if (typeof value === "number" && Number.isFinite(value)) return new Date(value).toISOString();
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) return new Date(parsed).toISOString();
    return new Date(0).toISOString();
  }
  if (value && typeof value === "object") {
    const rec = value as { seconds?: unknown; nanoseconds?: unknown; nanos?: unknown };
    const seconds = typeof rec.seconds === "number" ? rec.seconds : null;
    if (seconds !== null) {
      const nanosRaw = typeof rec.nanoseconds === "number" ? rec.nanoseconds : typeof rec.nanos === "number" ? rec.nanos : 0;
      return new Date(seconds * 1000 + Math.floor(nanosRaw / 1_000_000)).toISOString();
    }
  }
  return new Date(0).toISOString();
}

function parseWaveform(value: unknown): number[] | null {
  if (!Array.isArray(value)) return null;
  const nums = value.filter((v): v is number => typeof v === "number" && Number.isFinite(v)).slice(0, 40).map((v) => Math.round(Math.min(1, Math.max(0, v)) * 100) / 100);
  return nums.length > 0 ? nums : null;
}

function parseContact(value: unknown): FirebaseContact | null {
  if (!value || typeof value !== "object") return null;
  const item = value as Record<string, unknown>;
  if (typeof item.id !== "string" || typeof item.name !== "string") return null;
  return {
    id: normalizeId(item.id),
    name: item.name,
    email: typeof item.email === "string" ? item.email : null,
    username: typeof item.username === "string" ? item.username : null,
    mobile: typeof item.mobile === "string" && item.mobile ? item.mobile : null,
    photo: typeof item.photo === "string" && item.photo.startsWith("data:image/") ? item.photo : null,
  };
}

/* Conversation and group documents are read by every participant on
 * every snapshot, so they must stay small: a full-size base64 profile
 * photo embedded in participantProfiles / members made each document
 * hundreds of KB and every snapshot re-downloaded all of them. What
 * those documents carry instead is a small thumbnail (the profile
 * document keeps the full photo — it is the actual source). */
const STORED_PHOTO_MAX_CHARS = 16_000;

async function thumbnailPhoto(photo: string | null): Promise<string | null> {
  if (!photo) return null;
  if (photo.length <= STORED_PHOTO_MAX_CHARS) return photo;
  try {
    const image = new Image();
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error("photo-decode"));
      image.src = photo;
    });
    const size = 64;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext("2d");
    if (!context) return null;
    const side = Math.min(image.naturalWidth, image.naturalHeight);
    if (side === 0) return null;
    context.drawImage(image, (image.naturalWidth - side) / 2, (image.naturalHeight - side) / 2, side, side, 0, 0, size, size);
    const thumb = canvas.toDataURL("image/jpeg", 0.72);
    return thumb.length <= 40_000 ? thumb : null;
  } catch {
    return null;
  }
}

/** A contact as stored inside conversation/group documents: same shape,
 *  but the photo is reduced to a thumbnail first. */
async function contactForStorage(contact: FirebaseContact): Promise<FirebaseContact> {
  return { ...contact, photo: await thumbnailPhoto(contact.photo) };
}

/** Subscribe with a bounded query, transparently falling back to the
 *  unbounded form if Firestore rejects the bounded one with
 *  failed-precondition (a composite index that has not been created
 *  yet). The fallback is silent and sticky for the life of this
 *  subscription closure, so a missing index degrades to the old
 *  behaviour instead of breaking the listener. */
function subscribeWithIndexFallback<TSnapshot>(
  boundedSubscribe: (onNext: (snapshot: TSnapshot) => void, onError: (error: Error) => void) => Unsubscribe,
  fallbackSubscribe: (onNext: (snapshot: TSnapshot) => void, onError: (error: Error) => void) => Unsubscribe,
  onNext: (snapshot: TSnapshot) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  let inner: Unsubscribe | null = null;
  let usingFallback = false;
  let stopped = false;
  const attach = () => {
    if (stopped) return;
    const impl = usingFallback ? fallbackSubscribe : boundedSubscribe;
    inner = impl(onNext, (error) => {
      const code = (error as { code?: unknown }).code;
      if (!usingFallback && code === "failed-precondition") {
        usingFallback = true;
        if (inner) { try { inner(); } catch { /* already gone */ } inner = null; }
        attach();
        return;
      }
      onError(error);
    });
  };
  attach();
  return () => {
    stopped = true;
    if (inner) { try { inner(); } catch { /* already gone */ } inner = null; }
  };
}

export async function ensureFirebaseProfile(profile: { id: string; name: string; email: string; username: string; mobile?: string | null; photo?: string | null }) {
  await ensureFirebaseAuth();
  const id = normalizeId(profile.id);
  const username = profile.username.trim();
  const profileRef = doc(db, "profiles", safeDocPart(id));
  /* Photo stability: at cold start the caller's own photo loads
   * asynchronously, so the first sync of a session runs with
   * photo === null. Writing that null through erased the cloud
   * profile photo until the second sync restored it — anyone reading
   * the profile in between (search, contact cards, a new chat) saw
   * "no picture", and repeated launches made pictures appear and
   * vanish. A null incoming photo therefore NEVER overwrites a photo
   * already stored; only an explicit non-null photo replaces it. */
  let photo = profile.photo ?? null;
  if (!photo) {
    try {
      const existing = await getDoc(profileRef);
      const stored = existing.data()?.photo;
      if (typeof stored === "string" && stored) photo = stored;
    } catch { /* keep null — the write below still lands the rest */ }
  }
  await setDoc(profileRef, {
    id,
    name: profile.name,
    email: profile.email.trim().toLocaleLowerCase(),
    username,
    usernameLower: username.toLocaleLowerCase(),
    mobile: profile.mobile ?? null,
    mobileDigits: profile.mobile ? profile.mobile.replace(/[^0-9]/g, "") : null,
    photo,
    updatedAt: Timestamp.now(),
  }, { merge: true });
}

/* The profiles document above is the ONLY thing username discovery,
 * email/phone login-restore and contact cards read — a user whose
 * document was never written exists locally and can chat (conversation
 * documents are written separately), but NOBODY can find them by
 * username and they can never restore their account on another
 * device. The write used to happen exactly once per profile change,
 * fire-and-forget, from a background effect: on a brand-new
 * registration that single attempt races the first-launch anonymous
 * sign-in and the cold-start network, and when it lost the race the
 * error was swallowed and never retried, so the new account stayed
 * permanently invisible to search while everything else looked fine.
 * (Older users were unaffected: their document already existed from
 * an earlier successful write and every launch refreshes it.)
 * syncFirebaseProfile is the registration-grade version: it retries
 * the write with backoff until it lands, and reports whether it did,
 * so callers at signup time and the background sync both stop the
 * moment the document is confirmed written. */
export async function syncFirebaseProfile(profile: { id: string; name: string; email: string; username: string; mobile?: string | null; photo?: string | null }): Promise<boolean> {
  const backoffMs = [0, 1500, 4000, 9000];
  for (const wait of backoffMs) {
    if (wait > 0) await delay(wait);
    try {
      await ensureFirebaseProfile(profile);
      return true;
    } catch { /* retry with backoff — see the note above */ }
  }
  return false;
}

export async function fetchFirebaseProfileByEmail(email: string): Promise<FirebaseContact | null> {
  await ensureFirebaseAuth();
  const normalizedEmail = normalizeId(email);
  if (!normalizedEmail) return null;
  const candidateIds = [...new Set([safeDocPart(normalizedEmail), normalizedEmail])];
  for (const candidateId of candidateIds) {
    const snapshot = await getDoc(doc(db, "profiles", candidateId));
    if (snapshot.exists()) {
      const found = parseContact(snapshot.data());
      if (found) return found;
    }
  }
  return null;
}

/* Fallback profile scan for username matching. The range queries in
 * searchFirebaseProfilesByUsername / lookupFirebaseProfile compare raw
 * Firestore strings BYTE-wise: a profile written before the lowercase
 * `usernameLower` search field existed may carry only a case-preserved
 * `username` (e.g. "Saqi_786"), and such a value sorts BEFORE the whole
 * lowercase "saqi…" range, so the prefix/exact queries never return
 * the document at all — the search then reports "no user found" for a
 * person who exists. This scan reads a bounded page of profiles and
 * matches the normalised username on the client, which finds every
 * profile shape the app has ever written. It runs only when the range
 * queries found nothing, so the common path stays a cheap indexed
 * lookup. */
async function scanProfilesByUsername(wanted: string, exact: boolean): Promise<FirebaseContact[]> {
  const found: FirebaseContact[] = [];
  try {
    const snapshot = await getDocs(query(collection(db, "profiles"), limit(1000)));
    for (const item of snapshot.docs) {
      const contact = parseContact(item.data());
      if (!contact?.username) continue;
      const candidate = contact.username.trim().toLocaleLowerCase().replace(/^@+/, "");
      if (exact ? candidate === wanted : candidate.startsWith(wanted)) found.push(contact);
    }
  } catch { /* the caller already has the range-query results (or none) */ }
  return found;
}

export async function searchFirebaseProfilesByUsername(term: string): Promise<FirebaseContact[]> {
  // A read: like the listeners, it does not hard-fail when the
  // anonymous session is still being established — the queries below
  // are individually fault-isolated and simply return what they can.
  await ensureFirebaseAuth().catch(() => undefined);
  const wanted = normalizeId(term).replace(/^@+/, "");
  if (wanted.length < 2) return [];
  const matches = new Map<string, FirebaseContact>();
  const addMatches = (docs: QueryDocumentSnapshot<DocumentData>[]) => {
    for (const item of docs) {
      const found = parseContact(item.data());
      if (found?.username && found.username.toLocaleLowerCase().startsWith(wanted)) matches.set(found.id, found);
    }
  };
  // New profiles carry a lowercase `usernameLower` search field so the
  // display username can keep its capital letters while search stays
  // case-insensitive; older profiles only have the display `username`.
  // Each query is isolated: one failing query must not sink the whole
  // search (the sheet renders any rejection as "no user found").
  for (const field of ["usernameLower", "username"] as const) {
    try {
      const prefix = await getDocs(query(collection(db, "profiles"), where(field, ">=", wanted), where(field, "<=", `${wanted}\uf8ff`)));
      addMatches(prefix.docs);
    } catch { /* try the next field / the fallback scan below */ }
    try {
      const exact = await getDocs(query(collection(db, "profiles"), where(field, "==", wanted)));
      addMatches(exact.docs);
    } catch { /* try the next field / the fallback scan below */ }
  }
  // Profiles whose stored username shape the byte-wise range queries
  // cannot reach (case-preserved legacy `username`, no `usernameLower`)
  // are found by the normalised client-side scan instead.
  if (matches.size === 0) {
    for (const found of await scanProfilesByUsername(wanted, false)) matches.set(found.id, found);
  }
  return [...matches.values()].sort((a, b) => (a.username ?? "").localeCompare(b.username ?? "", undefined, { sensitivity: "base" })).slice(0, 20);
}

export async function lookupFirebaseProfile(identifier: string): Promise<FirebaseContact | null> {
  await ensureFirebaseAuth();
  const id = normalizeId(identifier);
  if (!id) return null;
  const direct = await getDoc(doc(db, "profiles", safeDocPart(id)));
  if (direct.exists()) {
    const found = parseContact(direct.data());
    if (found) return found;
  }
  const wanted = id.startsWith("@") ? id.slice(1) : id;
  for (const field of ["usernameLower", "username"] as const) {
    try {
      const byUsername = await getDocs(query(collection(db, "profiles"), where(field, "==", wanted)));
      for (const item of byUsername.docs) {
        const found = parseContact(item.data());
        if (found?.username && found.username.toLocaleLowerCase() === wanted) return found;
      }
    } catch { /* fall through to the scan / mobile lookup below */ }
  }
  // Same legacy-shape gap as username search: a case-preserved username
  // stored without `usernameLower` never equals the lowercase query
  // value byte-wise, so resolve it with the normalised scan. Only an
  // "@username" identifier reaches this branch — email identifiers are
  // resolved by the document read above and mobile numbers below.
  if (id.startsWith("@") && wanted) {
    const scanned = await scanProfilesByUsername(wanted, true);
    if (scanned[0]) return scanned[0];
  }
  const digits = id.replace(/[^0-9]/g, "");
  if (digits.length >= 7) {
    const byMobile = await getDocs(query(collection(db, "profiles"), where("mobileDigits", "==", digits)));
    for (const item of byMobile.docs) {
      const found = parseContact(item.data());
      if (found) return found;
    }
  }
  return null;
}

export async function ensureFirebaseConversation(input: {
  current: FirebaseContact;
  target: FirebaseContact;
}) {
  await ensureFirebaseAuth();
  const current = { ...input.current, id: normalizeId(input.current.id) };
  const target = { ...input.target, id: normalizeId(input.target.id) };
  // A conversation with yourself must never be created — in any
  // identifier form (email, @username, mobile or name-only contact).
  if (isSamePerson(current, target)) throw new Error("Cannot create a conversation with yourself");
  const id = firebaseThreadId(current.id, target.id);
  const conversationRef = doc(db, "conversations", id);
  /* Photo stability (the blinking-avatar bug): this ensure used to
   * rewrite participantProfiles UNCONDITIONALLY on every chat open,
   * with each side's client supplying the OTHER person's photo from
   * its own local cache — which is null or stale until that device's
   * photo sync lands, and is re-thumbnailed through a canvas on every
   * pass. The two clients therefore kept overwriting the conversation
   * document with alternating null / thumbnail / differently-encoded
   * photo values, every write fired a fresh conversations snapshot,
   * and the chat list + thread header avatar visibly flickered,
   * vanished, or re-appeared. Now: an already-stored photo is never
   * replaced by a null/stale incoming one, and when the merged result
   * equals what is stored the write is skipped entirely, so opening a
   * chat is read-only for the conversation document. */
  let existingProfiles: FirebaseContact[] = [];
  let existingParticipants: string[] = [];
  try {
    const existing = await getDoc(conversationRef);
    if (existing.exists()) {
      const data = existing.data();
      if (Array.isArray(data.participantProfiles)) existingProfiles = data.participantProfiles.map(parseContact).filter((value): value is FirebaseContact => value !== null);
      if (Array.isArray(data.participants)) existingParticipants = data.participants.filter((value): value is string => typeof value === "string");
    }
  } catch { /* a failed read falls back to the plain write below */ }
  const preservePhoto = async (contact: FirebaseContact): Promise<FirebaseContact> => {
    if (contact.photo) return contactForStorage(contact);
    const stored = existingProfiles.find((profile) => profile.id === contact.id);
    return { ...contact, photo: stored?.photo ?? null };
  };
  const storedProfiles = await Promise.all([preservePhoto(current), preservePhoto(target)]);
  const participants = [current.id, target.id].sort((a, b) => a.localeCompare(b));
  const unchanged = existingParticipants.length > 0
    && JSON.stringify([...existingParticipants].sort((a, b) => a.localeCompare(b))) === JSON.stringify(participants)
    && JSON.stringify(existingProfiles.map((profile) => [profile.id, profile.name, profile.photo])) === JSON.stringify(storedProfiles.map((profile) => [profile.id, profile.name, profile.photo]));
  if (!unchanged) {
    await setDoc(conversationRef, {
      id,
      participants,
      participantProfiles: storedProfiles,
      updatedAt: Timestamp.now(),
    }, { merge: true });
  }
  return id;
}

function mapConversationDoc(snapshotDoc: QueryDocumentSnapshot<DocumentData>, current: string): FirebaseConversation {
  const data = snapshotDoc.data();
  const participants = Array.isArray(data.participants) ? data.participants.filter((value): value is string => typeof value === "string") : [];
  const targetId = participants.find((id) => normalizeId(id) !== current) ?? current;
  const profiles = Array.isArray(data.participantProfiles) ? data.participantProfiles.map(parseContact).filter((value): value is FirebaseContact => value !== null) : [];
  const target = profiles.find((profile) => profile.id !== current);
  const unreadBy = data.unreadBy && typeof data.unreadBy === "object" ? data.unreadBy as Record<string, unknown> : {};
  const unreadKey = safeDocPart(current);
  const messageType = typeof data.lastMessageType === "string" && (FIREBASE_MESSAGE_TYPES as string[]).includes(data.lastMessageType) ? data.lastMessageType as FirebaseMessageType : null;
  return {
    id: snapshotDoc.id,
    contact_name: target?.name ?? targetId,
    contact_email: target?.email ?? (targetId.includes("@") && !targetId.startsWith("@") ? targetId : null),
    contact_username: target?.username ?? (targetId.startsWith("@") ? targetId.slice(1) : null),
    contact_mobile: target?.mobile ?? null,
    contact_photo: target?.photo ?? null,
    target_user_id: targetId,
    last_message: typeof data.lastMessage === "string" ? data.lastMessage : null,
    last_message_type: messageType,
    last_sender_id: typeof data.lastSenderId === "string" ? data.lastSenderId : null,
    unread_count: typeof unreadBy[unreadKey] === "number" ? unreadBy[unreadKey] : 0,
    updated_at: dateIso(data.updatedAt),
  } satisfies FirebaseConversation;
}

function sortConversations(items: FirebaseConversation[]): FirebaseConversation[] {
  return items.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
}

const CONVERSATION_PAGE_SIZE = 100;

function conversationsQueryFor(current: string, bounded: boolean) {
  const base = query(collection(db, "conversations"), where("participants", "array-contains", current));
  return bounded ? query(base, orderBy("updatedAt", "desc"), limit(CONVERSATION_PAGE_SIZE)) : base;
}

export function listenToFirebaseConversations(
  currentUserId: string,
  onData: (items: FirebaseConversation[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  return resilientSnapshot<QuerySnapshot<DocumentData>>((next, error) => subscribeWithIndexFallback<QuerySnapshot<DocumentData>>(
    (n, e) => onSnapshot(conversationsQueryFor(current, true), n, e),
    (n, e) => onSnapshot(conversationsQueryFor(current, false), n, e),
    next,
    error,
  ), (snapshot) => {
    const items = sortConversations(snapshot.docs.map((snapshotDoc) => mapConversationDoc(snapshotDoc, current)));
    // A listed conversation provably exists — record it before the data
    // goes any further, so its thread can never be declared missing.
    for (const item of items) markThreadKnown(item.id, item.last_message !== null);
    onData(items);
  }, onError);
}

/** Cache-first paint: read the conversations already in the on-device
 *  Firestore cache without touching the network, so the chat list can
 *  render instantly on a cold start while the live listener catches up.
 *  Resolves with an empty list when the cache has nothing yet. */
export async function fetchConversationsFromCache(currentUserId: string): Promise<FirebaseConversation[]> {
  const current = normalizeId(currentUserId);
  try {
    const snapshot = await getDocsFromCache(conversationsQueryFor(current, false));
    return sortConversations(snapshot.docs.map((snapshotDoc) => mapConversationDoc(snapshotDoc, current)));
  } catch {
    return [];
  }
}

/** The ONLY legitimate source of a "chat not found" verdict: an explicit
 *  document check. Returns true when the thread document exists, false
 *  when it provably does not, and null when the check itself could not
 *  be completed (offline, auth still settling) — null must never be
 *  treated as "not found". */
export async function verifyThreadExists(threadId: string, root: "conversations" | "groups"): Promise<boolean | null> {
  try {
    const snapshot = await getDoc(doc(db, root, threadId));
    return snapshot.exists();
  } catch {
    return null;
  }
}

/* Resolved chunked-media data URLs, keyed per message. A message's
 * chunks are immutable once written, so a data URL resolved once
 * stays valid for the life of the app session. Without this cache,
 * EVERY message snapshot re-downloaded EVERY chunked voice note and
 * photo in the page from the server — the snapshot mapping awaited
 * all of them before delivering anything, which is where most of
 * the ~1-minute chat opening went on a slow connection. Bounded:
 * least-recently-used entries drop out past the cap. */
const chunkedMediaCache = new Map<string, string>();
const CHUNKED_MEDIA_CACHE_LIMIT = 40;
/* The cache is capped by total BYTES, not just entry count: forty
 * entries can mean forty voice notes (~100 KB each) or forty video
 * files (~8 MB each) — the count-only cap let the second case hold
 * hundreds of MB of base64 in RAM until the WebView was killed. The
 * byte cap keeps the working set near 24 MB; the count cap stays as a
 * backstop for pathological numbers of tiny entries. */
const CHUNKED_MEDIA_CACHE_MAX_BYTES = 24 * 1024 * 1024;
let chunkedMediaCacheBytes = 0;

function chunkedMediaCacheKey(root: "conversations" | "groups", threadId: string, messageId: string): string {
  return `${root}/${threadId}/${messageId}`;
}

function rememberChunkedMedia(key: string, url: string) {
  const previous = chunkedMediaCache.get(key);
  if (previous) chunkedMediaCacheBytes -= previous.length;
  chunkedMediaCache.delete(key);
  chunkedMediaCache.set(key, url);
  chunkedMediaCacheBytes += url.length;
  while (chunkedMediaCache.size > 1 && (chunkedMediaCache.size > CHUNKED_MEDIA_CACHE_LIMIT || chunkedMediaCacheBytes > CHUNKED_MEDIA_CACHE_MAX_BYTES)) {
    const oldest = chunkedMediaCache.keys().next().value;
    if (oldest === undefined) break;
    const evicted = chunkedMediaCache.get(oldest);
    if (evicted) chunkedMediaCacheBytes -= evicted.length;
    chunkedMediaCache.delete(oldest);
  }
}

async function loadChunkedDataUrl(threadId: string, messageId: string, mimeType: string, root: "conversations" | "groups" = "conversations"): Promise<string | null> {
  // A failed chunk read degrades THIS message's media only — it must
  // never throw into the snapshot mapping and fail the whole thread.
  const key = chunkedMediaCacheKey(root, threadId, messageId);
  const cached = chunkedMediaCache.get(key);
  if (cached) {
    rememberChunkedMedia(key, cached);
    return cached;
  }
  try {
    const chunksQuery = query(collection(db, root, threadId, "messages", messageId, "mediaChunks"), orderBy("index", "asc"));
    // Cache first: chunks already on the phone resolve instantly and
    // cost no network; only a genuine cache miss goes to the server.
    let chunksSnapshot: QuerySnapshot<DocumentData> | null = null;
    try {
      const fromCache = await getDocsFromCache(chunksQuery);
      if (!fromCache.empty) chunksSnapshot = fromCache;
    } catch { /* not cached — fall through to the network read */ }
    if (!chunksSnapshot) chunksSnapshot = await getDocs(chunksQuery);
    const base64 = chunksSnapshot.docs.map((item) => {
      const data = item.data();
      return typeof data.data === "string" ? data.data : "";
    }).join("");
    const url = base64 ? `data:${mimeType};base64,${base64}` : null;
    if (url) rememberChunkedMedia(key, url);
    return url;
  } catch {
    return null;
  }
}

async function mapMessage(snapshotDoc: QueryDocumentSnapshot<DocumentData>, threadId: string, currentUserId: string, root: "conversations" | "groups" = "conversations", options?: { deferChunks?: boolean }): Promise<FirebaseMessage> {
  const data = snapshotDoc.data();
  const senderId = typeof data.senderId === "string" ? normalizeId(data.senderId) : "";
  const receiverId = typeof data.receiverId === "string" ? normalizeId(data.receiverId) : "";
  const type: FirebaseMessageType = parseMessageType(data.type);
  const mimeType = typeof data.mimeType === "string" ? data.mimeType : type === "audio" ? "audio/webm" : "image/jpeg";
  const fileMeta: FirebaseFileMeta | null = (type === "video" || type === "file") && typeof data.fileName === "string"
    ? { name: data.fileName, size: typeof data.fileSize === "number" ? data.fileSize : 0, mime_type: mimeType }
    : null;
  const contactCard: FirebaseContactCard | null = type === "contact" && data.contactCard && typeof data.contactCard === "object" && !Array.isArray(data.contactCard) && typeof (data.contactCard as Record<string, unknown>).name === "string"
    ? (() => { const raw = data.contactCard as Record<string, unknown>; return { name: raw.name as string, phone: typeof raw.phone === "string" && raw.phone ? raw.phone : null, email: typeof raw.email === "string" && raw.email ? raw.email : null, username: typeof raw.username === "string" && raw.username ? raw.username : null }; })()
    : null;
  const location: FirebaseLocationData | null = type === "location" && typeof data.locationLat === "number" && typeof data.locationLng === "number"
    ? { lat: data.locationLat, lng: data.locationLng, live: data.locationLive === true, updated_at: data.locationUpdatedAt instanceof Timestamp ? data.locationUpdatedAt.toDate().toISOString() : null }
    : null;
  const poll: FirebasePollData | null = type === "poll" && typeof data.pollQuestion === "string" && Array.isArray(data.pollOptions)
    ? (() => {
        const options = (data.pollOptions as unknown[]).filter((item): item is { id: string; text: string } => Boolean(item) && typeof item === "object" && typeof (item as { id?: unknown }).id === "string" && typeof (item as { text?: unknown }).text === "string").map((item) => ({ id: item.id, text: item.text }));
        const votes: Record<string, string[]> = {};
        if (data.pollVotes && typeof data.pollVotes === "object" && !Array.isArray(data.pollVotes)) {
          for (const [optionId, users] of Object.entries(data.pollVotes as Record<string, unknown>)) {
            if (Array.isArray(users)) {
              const ids = users.filter((value): value is string => typeof value === "string").map(normalizeId);
              if (ids.length > 0) votes[optionId] = ids;
            }
          }
        }
        return options.length >= 2 ? { question: data.pollQuestion as string, options, votes } : null;
      })()
    : null;
  let dataUrl = typeof data.dataUrl === "string" ? data.dataUrl : null;
  let mediaPending = false;
  let mediaMime: string | null = null;
  if (!dataUrl && data.hasChunks === true) {
    const cachedMedia = chunkedMediaCache.get(chunkedMediaCacheKey(root, threadId, snapshotDoc.id));
    if (cachedMedia) {
      dataUrl = cachedMedia;
    } else if (options?.deferChunks) {
      // Two-phase delivery: this snapshot's text must paint NOW, not
      // after megabytes of base64 have crossed a slow link. The
      // message is delivered media-pending; handleMessageSnapshot
      // fetches the chunks in the background and delivers the page
      // again with the media attached.
      mediaPending = true;
      mediaMime = mimeType;
    } else {
      dataUrl = await loadChunkedDataUrl(threadId, snapshotDoc.id, mimeType, root);
    }
  }
  const reactions: Record<string, string[]> = {};
  if (data.reactions && typeof data.reactions === "object" && !Array.isArray(data.reactions)) {
    for (const [emoji, users] of Object.entries(data.reactions as Record<string, unknown>)) {
      if (Array.isArray(users)) {
        const ids = users.filter((value): value is string => typeof value === "string").map(normalizeId);
        if (ids.length > 0) reactions[emoji] = ids;
      }
    }
  }
  const replyTo = data.replyTo && typeof data.replyTo === "object" && !Array.isArray(data.replyTo)
    ? (() => { const raw = data.replyTo as Record<string, unknown>; return typeof raw.id === "string" && typeof raw.body === "string" ? { id: raw.id, body: raw.body, sender_name: typeof raw.senderName === "string" ? raw.senderName : "" } : null; })()
    : null;
  const deliveryStatus: FirebaseDeliveryStatus = data.status === "read" || data.status === "delivered" ? data.status : "sent";
  const effect: FirebaseVoiceEffect = typeof data.voiceEffect === "string" && (FIREBASE_VOICE_EFFECTS as string[]).includes(data.voiceEffect) ? data.voiceEffect as FirebaseVoiceEffect : "original";
  return {
    id: snapshotDoc.id,
    body: typeof data.body === "string" ? data.body : "",
    direction: senderId === normalizeId(currentUserId) ? "self" : "contact",
    sender_id: senderId,
    receiver_id: receiverId,
    message_type: type,
    audio_url: type === "audio" ? dataUrl : null,
    image_url: type === "image" ? dataUrl : null,
    media_pending: mediaPending,
    media_mime: mediaMime,
    sticker_url: type === "sticker" ? dataUrl : null,
    video_url: type === "video" ? dataUrl : null,
    file_url: type === "file" ? dataUrl : null,
    file_meta: fileMeta,
    contact_card: contactCard,
    location,
    poll,
    scheduled_for: data.scheduledFor instanceof Timestamp ? data.scheduledFor.toDate().toISOString() : null,
    delivery_status: deliveryStatus,
    audio_duration: typeof data.audioDuration === "number" ? data.audioDuration : null,
    waveform: parseWaveform(data.waveform),
    voice_effect: effect,
    unlock_at: data.unlockAt instanceof Timestamp ? data.unlockAt.toDate().toISOString() : null,
    password_hash: typeof data.passwordHash === "string" ? data.passwordHash : null,
    password_salt: typeof data.passwordSalt === "string" ? data.passwordSalt : null,
    expires_at: data.expiresAt instanceof Timestamp ? data.expiresAt.toDate().toISOString() : null,
    call_kind: type === "call" ? (data.callKind === "video" ? "video" : "audio") : null,
    call_status: type === "call" && typeof data.callStatus === "string" ? data.callStatus : null,
    call_duration_sec: type === "call" && typeof data.callDurationSec === "number" ? data.callDurationSec : null,
    reactions,
    reply_to: replyTo,
    forwarded: data.forwarded === true,
    created_at: dateIso(data.createdAt),
    sender_name: typeof data.senderName === "string" ? data.senderName : null,
    sender_photo: typeof data.senderPhoto === "string" && data.senderPhoto.startsWith("data:image/") ? data.senderPhoto : null,
  };
}

function isExpired(message: FirebaseMessage) {
  return message.expires_at !== null && new Date(message.expires_at).getTime() <= Date.now();
}

/** Ids in a snapshot the SERVER has acknowledged: a document still
 *  carrying a local, unacknowledged write (metadata.hasPendingWrites)
 *  is only on this phone so far and does not count as confirmed. The
 *  pending-message outbox uses these ids to retire delivered entries. */
function serverConfirmedIds(snapshot: QuerySnapshot<DocumentData>): string[] {
  return snapshot.docs.filter((item) => !item.metadata.hasPendingWrites).map((item) => item.id);
}

export const MESSAGE_PAGE_SIZE = 50;

/** Map a page of message documents with Promise.allSettled: one
 *  message whose media chunks cannot be read degrades to a message
 *  without its media — it never fails the whole thread. Genuine
 *  mapping failures (a document that cannot be parsed at all) are
 *  collected and rethrown so the caller routes them through the
 *  listener retry supervisor instead of an error screen. */
async function mapMessagesSettled(
  docs: QueryDocumentSnapshot<DocumentData>[],
  threadId: string,
  currentUserId: string,
  root: "conversations" | "groups",
  options?: { deferChunks?: boolean },
): Promise<FirebaseMessage[]> {
  const settled = await Promise.allSettled(docs.map((item) => mapMessage(item, threadId, currentUserId, root, options)));
  const items: FirebaseMessage[] = [];
  let firstError: unknown = null;
  for (const result of settled) {
    if (result.status === "fulfilled") items.push(result.value);
    else if (firstError === null) firstError = result.reason;
  }
  if (firstError !== null && items.length === 0) throw firstError;
  return items.filter((item) => !isExpired(item));
}

/** Mark incoming messages in a page as delivered — a write triggered
 *  by the listener itself, batched and fire-and-forget. */
function markDeliveredInSnapshot(snapshot: QuerySnapshot<DocumentData>, currentUserId: string, isGroup: boolean) {
  const current = normalizeId(currentUserId);
  const toDeliver = snapshot.docs.filter((item) => {
    const data = item.data();
    if (data.status !== "sent") return false;
    if (isGroup) {
      const receivers = Array.isArray(data.receiverIds) ? data.receiverIds.filter((value): value is string => typeof value === "string").map(normalizeId) : [];
      return receivers.includes(current);
    }
    return normalizeId(typeof data.receiverId === "string" ? data.receiverId : "") === current;
  });
  if (toDeliver.length === 0) return;
  const batch = writeBatch(db);
  toDeliver.forEach((item) => batch.update(item.ref, { status: "delivered", deliveredAt: Timestamp.now() }));
  void batch.commit().catch(() => undefined);
}

/** Shared snapshot handling for the direct and group message listeners:
 *  thread protection is recorded at RAW snapshot receipt — before any
 *  async mapping — so nothing that happens later (a slow chunk read, a
 *  mapping error, an outbox flush) can make this thread look missing.
 *
 *  Delivery is TWO-PHASE, the same pattern the statuses listener
 *  adopted: phase 1 maps the page WITHOUT downloading chunked media
 *  and delivers immediately, so the thread's text paints from the
 *  local cache the moment the snapshot lands; phase 2 downloads the
 *  pending chunks in the background and delivers the same page again
 *  with media attached. Before this, mapping awaited every chunked
 *  voice note and photo in the page — each a separate server query
 *  over a slow carrier link — before a single message could render,
 *  which is how opening a chat reached ~1 minute on a flagship phone
 *  whose CPU was never the bottleneck. Phase 2 is discarded when a
 *  newer snapshot has superseded this one (isCurrent), so a slow
 *  background fill can never overwrite fresher state. */
function handleMessageSnapshot(
  snapshot: QuerySnapshot<DocumentData>,
  threadId: string,
  knownId: string,
  currentUserId: string,
  root: "conversations" | "groups",
  onData: (items: FirebaseMessage[]) => void,
  onError: (error: Error) => void,
  onConfirmed?: (ids: string[]) => void,
  isCurrent: () => boolean = () => true,
) {
  markThreadKnown(knownId, snapshot.docs.length > 0);
  if (onConfirmed) onConfirmed(serverConfirmedIds(snapshot));
  markDeliveredInSnapshot(snapshot, currentUserId, root === "groups");
  // The query is newest-first with a page limit; mapping preserves that
  // order and the thread renders oldest-first, so reverse after mapping.
  void mapMessagesSettled([...snapshot.docs].reverse(), threadId, currentUserId, root, { deferChunks: true })
    .then(async (items) => {
      onData(items);
      const pending = items.filter((item) => item.media_pending);
      if (pending.length === 0 || !isCurrent()) return;
      const filled = await Promise.all(pending.map(async (item) => ({
        id: item.id,
        url: await loadChunkedDataUrl(threadId, item.id, item.media_mime ?? "application/octet-stream", root),
      })));
      if (!isCurrent()) return;
      const byId = new Map<string, string>();
      for (const entry of filled) if (entry.url) byId.set(entry.id, entry.url);
      if (byId.size === 0) return;
      onData(items.map((item) => {
        const url = byId.get(item.id);
        if (!url) return item;
        return {
          ...item,
          media_pending: false,
          media_mime: null,
          audio_url: item.message_type === "audio" ? url : item.audio_url,
          image_url: item.message_type === "image" ? url : item.image_url,
          sticker_url: item.message_type === "sticker" ? url : item.sticker_url,
          video_url: item.message_type === "video" ? url : item.video_url,
          file_url: item.message_type === "file" ? url : item.file_url,
        };
      }));
    })
    .catch((error: unknown) => onError(error instanceof Error ? error : new Error("Could not load messages")));
}

export function listenToFirebaseMessages(
  threadId: string,
  currentUserId: string,
  onData: (items: FirebaseMessage[]) => void,
  onError: (error: Error) => void,
  onConfirmed?: (ids: string[]) => void,
): Unsubscribe {
  const messagesQuery = query(collection(db, "conversations", threadId, "messages"), orderBy("createdAt", "desc"), limit(MESSAGE_PAGE_SIZE));
  // Snapshot sequence for this subscription: lets a snapshot's
  // background media fill recognise when it has been superseded.
  const deliverySeq = { latest: 0 };
  /* No includeMetadataChanges: a metadata-only change (a pending
   * write being acknowledged, a delivered/read flag settling in the
   * cache) used to re-deliver the snapshot and re-map the whole
   * 50-message page — parse, chunk lookups and all — several times
   * per send. Data changes still deliver snapshots (with metadata
   * attached, so serverConfirmedIds keeps working); metadata churn
   * alone no longer re-maps the page. */
  return resilientSnapshot<QuerySnapshot<DocumentData>>((next, error) => onSnapshot(messagesQuery, next, error), (snapshot) => {
    const seq = ++deliverySeq.latest;
    handleMessageSnapshot(snapshot, threadId, threadId, currentUserId, "conversations", onData, onError, onConfirmed, () => seq === deliverySeq.latest);
  }, onError);
}

/** Load the next older page of messages (for the thread's "load older"
 *  control): everything strictly before `beforeIso`, newest page first
 *  on the wire, returned oldest-first like the listener delivers. */
export async function fetchOlderFirebaseMessages(
  threadId: string,
  currentUserId: string,
  beforeIso: string,
  root: "conversations" | "groups" = "conversations",
): Promise<FirebaseMessage[]> {
  await ensureFirebaseAuth();
  const beforeMs = new Date(beforeIso).getTime();
  if (!Number.isFinite(beforeMs)) return [];
  const snapshot = await getDocs(query(
    collection(db, root, threadId, "messages"),
    orderBy("createdAt", "desc"),
    startAfter(Timestamp.fromMillis(beforeMs)),
    limit(MESSAGE_PAGE_SIZE),
  ));
  return mapMessagesSettled([...snapshot.docs].reverse(), threadId, currentUserId, root);
}

export async function markFirebaseMessagesRead(threadId: string, currentUserId: string) {
  await ensureFirebaseAuth();
  const current = normalizeId(currentUserId);
  // Targeted query: only this user's not-yet-read incoming messages —
  // never a scan of the whole thread.
  const incoming = await getDocs(query(
    collection(db, "conversations", threadId, "messages"),
    where("receiverId", "==", current),
    where("status", "in", ["sent", "delivered"]),
  ));
  const batch = writeBatch(db);
  incoming.docs.forEach((item) => batch.update(item.ref, { status: "read", readAt: Timestamp.now() }));
  const threadRef = doc(db, "conversations", threadId);
  batch.set(threadRef, { unreadBy: { [safeDocPart(current)]: 0 } }, { merge: true });
  await batch.commit();
}

/* Media larger than this travels through the mediaChunks
 * subcollection (fetched on demand / in the background two-phase
 * delivery) instead of inline base64 inside the message document.
 * The old 650 KB inline threshold kept whole voice notes and photos
 * inside every message document, so every snapshot of a media-heavy
 * thread re-downloaded and re-parsed megabytes of base64. Old
 * messages written with inline media still render — mapMessage reads
 * `dataUrl` exactly as before; only NEW writes chunk earlier. */
const INLINE_MEDIA_MAX_CHARS = 120_000;
const MEDIA_CHUNK_CHARS = 600_000;

function splitDataUrl(dataUrl: string) {
  const match = /^data:([^;]+);base64,(.*)$/.exec(dataUrl);
  if (!match) return null;
  const mimeType = match[1] ?? "application/octet-stream";
  const data = match[2] ?? "";
  return { mimeType, data };
}

/** Extra Firestore fields for the attachment message types (video, file,
 *  contact card, location) shared by one-to-one and group sends. */
function attachmentWriteFields(input: FirebaseMessageInput, createdAt: number): Record<string, unknown> {
  return {
    ...(input.fileMeta ? { fileName: input.fileMeta.name, fileSize: input.fileMeta.size } : {}),
    ...(input.contactCard ? { contactCard: input.contactCard } : {}),
    ...(input.location ? { locationLat: input.location.lat, locationLng: input.location.lng, locationLive: input.location.live, locationUpdatedAt: Timestamp.fromMillis(createdAt) } : {}),
    ...(input.poll ? { pollQuestion: input.poll.question, pollOptions: input.poll.options, pollVotes: {} } : {}),
    ...(input.scheduledFor ? { scheduledFor: Timestamp.fromMillis(input.scheduledFor) } : {}),
  };
}

/** True while a message is still waiting for its scheduled send time —
 *  such messages stay out of the conversation summary until they land. */
function isFutureScheduled(input: FirebaseMessageInput, createdAt: number): boolean {
  return typeof input.scheduledFor === "number" && input.scheduledFor > createdAt;
}

/** Move an already-sent live-location message to the sender's current
 *  position; receivers see the new pin through their message listener. */
export async function updateFirebaseLiveLocation(root: "conversations" | "groups", threadId: string, messageId: string, lat: number, lng: number) {
  await ensureFirebaseAuth();
  await updateDoc(doc(db, root, threadId, "messages", messageId), { locationLat: lat, locationLng: lng, locationUpdatedAt: Timestamp.now() });
}

/** End a live-location share: the message stays in the chat as a static
 *  location at its last known position. */
export async function stopFirebaseLiveLocation(root: "conversations" | "groups", threadId: string, messageId: string) {
  await ensureFirebaseAuth();
  await updateDoc(doc(db, root, threadId, "messages", messageId), { locationLive: false, locationUpdatedAt: Timestamp.now() });
}

export async function sendFirebaseMessage(input: FirebaseMessageInput) {
  const createdAt = input.createdAt ?? Date.now();
  const messageRef = input.id ? doc(db, "conversations", input.threadId, "messages", input.id) : doc(collection(db, "conversations", input.threadId, "messages"));
  const parsedMedia = input.dataUrl ? splitDataUrl(input.dataUrl) : null;
  const chunks = parsedMedia && parsedMedia.data.length > INLINE_MEDIA_MAX_CHARS ? parsedMedia.data.match(new RegExp(`.{1,${MEDIA_CHUNK_CHARS}}`, "g")) ?? [] : [];
  // Every value written below is fixed before the first attempt (same
  // message id, same createdAt, absolute summary fields), so rebuilding
  // the batch for commitWithRecovery's retry is idempotent.
  const buildBatch = (isRetry = false): WriteBatch => {
    const batch = writeBatch(db);
    batch.set(messageRef, {
      id: messageRef.id,
      body: input.body,
      senderId: normalizeId(input.senderId),
      receiverId: normalizeId(input.receiverId),
      type: input.type,
      // Retry writes must never wipe a receiver's delivered/read mark:
      // status is written only on the first attempt.
      ...(isRetry ? {} : { status: "sent" as const }),
      createdAt: Timestamp.fromMillis(createdAt),
      ...(parsedMedia ? { mimeType: parsedMedia.mimeType, ...(chunks.length === 0 ? { dataUrl: input.dataUrl } : { hasChunks: true }) } : {}),
      ...attachmentWriteFields(input, createdAt),
      ...(input.audioDuration !== undefined ? { audioDuration: input.audioDuration } : {}),
      ...(input.waveform && input.waveform.length > 0 && !input.passwordHash ? { waveform: input.waveform.slice(0, 40) } : {}),
      ...(input.voiceEffect ? { voiceEffect: input.voiceEffect } : {}),
      ...(input.unlockAt ? { unlockAt: Timestamp.fromMillis(input.unlockAt) } : {}),
      ...(input.passwordHash ? { passwordHash: input.passwordHash } : {}),
      ...(input.passwordSalt ? { passwordSalt: input.passwordSalt } : {}),
      ...(input.ttlSeconds && input.ttlSeconds > 0 ? { expiresAt: Timestamp.fromMillis(createdAt + input.ttlSeconds * 1000) } : {}),
      ...(input.replyTo ? { replyTo: input.replyTo } : {}),
      ...(input.forwarded ? { forwarded: true } : {}),
    }, { merge: true });
    chunks.forEach((chunk, index) => batch.set(doc(db, "conversations", input.threadId, "messages", messageRef.id, "mediaChunks", String(index).padStart(4, "0")), { index, data: chunk }));
    if (!isFutureScheduled(input, createdAt)) {
      batch.set(doc(db, "conversations", input.threadId), {
        lastMessage: input.body,
        lastMessageType: input.type,
        lastSenderId: normalizeId(input.senderId),
        updatedAt: Timestamp.fromMillis(createdAt),
        unreadBy: { [safeDocPart(input.receiverId)]: 1 },
      }, { merge: true });
    }
    return batch;
  };
  await commitWithRecovery(buildBatch);
  return { id: messageRef.id, createdAt };
}

/** When a scheduled message's time arrives, publish it into the
 *  conversation summary (chat-list preview + unread) — the send itself
 *  deliberately skipped the summary while the message was still waiting. */
export async function publishScheduledMessageSummary(root: "conversations" | "groups", message: FirebaseMessage) {
  await ensureFirebaseAuth();
  if (root === "conversations") {
    await setDoc(doc(db, "conversations", messageThreadIdFromMessage(message)), {
      lastMessage: message.body,
      lastMessageType: message.message_type,
      lastSenderId: normalizeId(message.sender_id),
      updatedAt: Timestamp.now(),
      unreadBy: { [safeDocPart(message.receiver_id)]: 1 },
    }, { merge: true });
    return;
  }
  await updateDoc(doc(db, "groups", messageThreadIdFromMessage(message)), {
    lastMessage: message.body,
    lastMessageType: message.message_type,
    lastSenderId: normalizeId(message.sender_id),
    updatedAt: Timestamp.now(),
  });
}

/* The summary publisher needs the thread a message belongs to; message
 * objects don't carry it, so callers pass it through this companion. */
let scheduledSummaryThreadId = "";
export function setScheduledSummaryThread(threadId: string) { scheduledSummaryThreadId = threadId; }
function messageThreadIdFromMessage(_message: FirebaseMessage): string { return scheduledSummaryThreadId; }

export async function hashFirebaseVoicePassword(password: string, salt: string) {
  const input = `${salt}:${password}`;
  // crypto.subtle only exists in secure contexts on WebViews new enough
  // to expose WebCrypto's subtle interface; on older WebViews (and any
  // non-secure origin) it is undefined and digest() throws — which used
  // to break BOTH the timed-voice password gate and the phone-OTP code
  // hash on exactly the phones that already struggle. Fall back to a
  // deterministic FNV-1a expansion with the same 64-hex-char shape so
  // those flows keep working there; devices with subtle keep SHA-256.
  const subtle = globalThis.crypto?.subtle;
  if (subtle && typeof subtle.digest === "function") {
    const bytes = new TextEncoder().encode(input);
    const digest = await subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join("");
  }
  let hex = "";
  let state = 0x811c9dc5;
  for (let round = 0; round < 8; round += 1) {
    for (let i = 0; i < input.length; i += 1) {
      state ^= (input.charCodeAt(i) + round * 131) & 0xff;
      state = Math.imul(state, 0x01000193) >>> 0;
    }
    state = (Math.imul(state ^ (state >>> 13), 0x5bd1e995) >>> 0);
    hex += state.toString(16).padStart(8, "0");
  }
  return hex;
}

/* Decode a picked image file for the canvas resize pipeline below.
 * createImageBitmap is the fast path, but it is missing on some older
 * WebViews and rejects formats others accept; without a fallback every
 * photo send / profile photo / status photo failed outright on those
 * phones. The fallback decodes through an <img> element on an object
 * URL — slower, but universally supported. */
type DecodedImage = { source: CanvasImageSource; width: number; height: number; dispose: () => void };
async function decodeImageSource(file: File): Promise<DecodedImage> {
  if (typeof createImageBitmap === "function") {
    try {
      const bitmap = await createImageBitmap(file);
      return { source: bitmap, width: bitmap.width, height: bitmap.height, dispose: () => bitmap.close() };
    } catch {
      /* fall through to the <img> decode */
    }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const element = new Image();
      element.onload = () => resolve(element);
      element.onerror = () => reject(new Error("Image could not be decoded"));
      element.src = url;
    });
    return { source: img, width: img.naturalWidth || img.width, height: img.naturalHeight || img.height, dispose: () => URL.revokeObjectURL(url) };
  } catch (error) {
    URL.revokeObjectURL(url);
    throw error;
  }
}

export async function imageFileToDataUrl(file: File) {
  const decoded = await decodeImageSource(file);
  const maxDimension = 1440;
  const scale = Math.min(1, maxDimension / Math.max(decoded.width, decoded.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(decoded.width * scale));
  canvas.height = Math.max(1, Math.round(decoded.height * scale));
  const context = canvas.getContext("2d");
  if (!context) { decoded.dispose(); throw new Error("Image canvas is unavailable"); }
  context.drawImage(decoded.source, 0, 0, canvas.width, canvas.height);
  decoded.dispose();
  let quality = .84;
  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  while (dataUrl.length > 700_000 && quality > .45) {
    quality -= .09;
    dataUrl = canvas.toDataURL("image/jpeg", quality);
  }
  if (dataUrl.length > 900_000) throw new Error("Image is too large");
  return dataUrl;
}

export async function profileImageFileToDataUrl(file: File) {
  const decoded = await decodeImageSource(file);
  const target = 256;
  const canvas = document.createElement("canvas");
  canvas.width = target;
  canvas.height = target;
  const context = canvas.getContext("2d");
  if (!context) { decoded.dispose(); throw new Error("Image canvas is unavailable"); }
  const side = Math.min(decoded.width, decoded.height);
  const sourceX = (decoded.width - side) / 2;
  const sourceY = (decoded.height - side) / 2;
  context.drawImage(decoded.source, sourceX, sourceY, side, side, 0, 0, target, target);
  decoded.dispose();
  let quality = .82;
  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  while (dataUrl.length > 700_000 && quality > .4) {
    quality -= .08;
    dataUrl = canvas.toDataURL("image/jpeg", quality);
  }
  if (dataUrl.length > 900_000) throw new Error("Image is too large");
  return dataUrl;
}

export type FirebaseStatusAccent = "teal" | "amber" | "blue" | "rose" | "violet" | "emerald" | "orange" | "crimson";

export type FirebaseStatus = {
  id: string;
  author_id: string;
  author_name: string;
  author_username: string | null;
  author_photo: string | null;
  status_type: "text" | "photo" | "video";
  body: string;
  accent: FirebaseStatusAccent;
  font: string | null;
  image_url: string | null;
  video_url: string | null;
  /** True when the media lives in the mediaChunks subcollection and
   *  has NOT been downloaded yet — fetch it on demand with
   *  loadFirebaseStatusMedia() when the viewer actually opens it. */
  media_pending: boolean;
  media_mime: string | null;
  created_at: string;
  expires_at: string;
};

const statusAccents: FirebaseStatusAccent[] = ["teal", "amber", "blue", "rose", "violet", "emerald", "orange", "crimson"];

export async function publishFirebaseStatus(input: {
  author: FirebaseContact;
  statusType: "text" | "photo" | "video";
  body: string;
  accent: FirebaseStatusAccent;
  font?: string | null;
  imageDataUrl?: string | null;
  mediaDataUrl?: string | null;
}) {
  const now = Date.now();
  const statusRef = doc(collection(db, "statuses"));
  const mediaDataUrl = input.mediaDataUrl ?? input.imageDataUrl ?? null;
  const parsedMedia = mediaDataUrl ? splitDataUrl(mediaDataUrl) : null;
  const chunks = parsedMedia && parsedMedia.data.length > INLINE_MEDIA_MAX_CHARS ? parsedMedia.data.match(new RegExp(`.{1,${MEDIA_CHUNK_CHARS}}`, "g")) ?? [] : [];
  const buildBatch = (): WriteBatch => {
    const batch = writeBatch(db);
    batch.set(statusRef, {
      id: statusRef.id,
      authorId: normalizeId(input.author.id),
      authorName: input.author.name,
      authorUsername: input.author.username ?? null,
      authorPhoto: input.author.photo ?? null,
      statusType: input.statusType,
      body: input.body,
      accent: input.accent,
      ...(input.font ? { font: input.font } : {}),
      createdAt: Timestamp.fromMillis(now),
      expiresAt: Timestamp.fromMillis(now + 24 * 60 * 60 * 1000),
      ...(parsedMedia ? { mimeType: parsedMedia.mimeType, ...(chunks.length === 0 ? { imageDataUrl: mediaDataUrl } : { hasChunks: true }) } : {}),
    });
    chunks.forEach((chunk, index) => batch.set(doc(db, "statuses", statusRef.id, "mediaChunks", String(index).padStart(4, "0")), { index, data: chunk }));
    return batch;
  };
  await commitWithRecovery(buildBatch);
  return statusRef.id;
}

async function loadChunkedStatusImage(statusId: string, mimeType: string) {
  try {
    const chunksSnapshot = await getDocs(query(collection(db, "statuses", statusId, "mediaChunks"), orderBy("index", "asc")));
    const base64 = chunksSnapshot.docs.map((item) => {
      const data = item.data();
      return typeof data.data === "string" ? data.data : "";
    }).join("");
    return base64 ? `data:${mimeType};base64,${base64}` : null;
  } catch {
    return null;
  }
}

/** On-demand fetch of one status's chunked media (photo or video).
 *  Chunked media is deliberately NOT downloaded by the statuses
 *  listener anymore: a single video status is up to ~8 MB of base64,
 *  and the listener used to pull EVERY contact's chunked photo/video
 *  into memory on every launch — megabytes of downloads and huge
 *  strings held in RAM before the user ever opened the Updates tab,
 *  a direct cause of the multi-second cold start and of the WebView
 *  being killed for memory on low-RAM phones. The viewer calls this
 *  only for the status actually being watched. */
export async function loadFirebaseStatusMedia(statusId: string, mimeType: string): Promise<string | null> {
  await ensureFirebaseAuth();
  return loadChunkedStatusImage(statusId, mimeType);
}

function mapStatus(snapshotDoc: QueryDocumentSnapshot<DocumentData>): FirebaseStatus {
  const data = snapshotDoc.data();
  const statusType: FirebaseStatus["status_type"] = data.statusType === "photo" ? "photo" : data.statusType === "video" ? "video" : "text";
  const mimeType = typeof data.mimeType === "string" ? data.mimeType : statusType === "video" ? "video/mp4" : "image/jpeg";
  const mediaUrl = typeof data.imageDataUrl === "string" ? data.imageDataUrl : null;
  const mediaPending = !mediaUrl && data.hasChunks === true;
  const accent = statusAccents.includes(data.accent as FirebaseStatusAccent) ? data.accent as FirebaseStatusAccent : "teal";
  return {
    id: snapshotDoc.id,
    author_id: typeof data.authorId === "string" ? normalizeId(data.authorId) : "",
    author_name: typeof data.authorName === "string" ? data.authorName : "",
    author_username: typeof data.authorUsername === "string" ? data.authorUsername : null,
    author_photo: typeof data.authorPhoto === "string" && data.authorPhoto.startsWith("data:image/") ? data.authorPhoto : null,
    status_type: statusType,
    body: typeof data.body === "string" ? data.body : "",
    accent,
    font: typeof data.font === "string" && data.font ? data.font : null,
    image_url: statusType === "photo" ? mediaUrl : null,
    video_url: statusType === "video" ? mediaUrl : null,
    media_pending: mediaPending,
    media_mime: mediaPending ? mimeType : null,
    created_at: dateIso(data.createdAt),
    expires_at: dateIso(data.expiresAt),
  };
}

export function listenToFirebaseStatuses(
  currentUserId: string,
  onData: (items: FirebaseStatus[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  const statusesQuery = query(collection(db, "statuses"), where("expiresAt", ">", Timestamp.now()), orderBy("expiresAt", "asc"), orderBy("createdAt", "desc"), limit(100));
  return resilientSnapshot<QuerySnapshot<DocumentData>>((next, error) => onSnapshot(statusesQuery, next, error), (snapshot) => {
    try {
      onData(snapshot.docs.map((item) => mapStatus(item)).filter((item) => item.author_id && item.author_id !== current));
    } catch (error: unknown) {
      onError(error instanceof Error ? error : new Error("Could not load statuses"));
    }
  }, onError);
}

export async function statusImageFileToDataUrl(file: File) {
  const decoded = await decodeImageSource(file);
  const maxDimension = 1080;
  const scale = Math.min(1, maxDimension / Math.max(decoded.width, decoded.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(decoded.width * scale));
  canvas.height = Math.max(1, Math.round(decoded.height * scale));
  const context = canvas.getContext("2d");
  if (!context) { decoded.dispose(); throw new Error("Image canvas is unavailable"); }
  context.drawImage(decoded.source, 0, 0, canvas.width, canvas.height);
  decoded.dispose();
  let quality = .8;
  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  while (dataUrl.length > 620_000 && quality > .4) {
    quality -= .08;
    dataUrl = canvas.toDataURL("image/jpeg", quality);
  }
  if (dataUrl.length > 900_000) throw new Error("Image is too large");
  return dataUrl;
}

export function listenToFirebaseDisappearing(
  threadId: string,
  currentUserId: string,
  onData: (seconds: number) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  const key = safeDocPart(current);
  const threadRef = doc(db, "conversations", threadId);
  return resilientSnapshot<DocumentSnapshot<DocumentData>>((next, error) => onSnapshot(threadRef, next, error), (snapshot) => {
    const data = snapshot.data();
    const timers = data?.disappearingBy && typeof data.disappearingBy === "object" ? data.disappearingBy as Record<string, unknown> : {};
    const value = timers[key];
    onData(typeof value === "number" && value > 0 ? value : 0);
  }, () => onData(0));
}

export async function setFirebaseDisappearing(threadId: string, currentUserId: string, seconds: number) {
  await ensureFirebaseAuth();
  const key = safeDocPart(normalizeId(currentUserId));
  await setDoc(doc(db, "conversations", threadId), { disappearingBy: { [key]: seconds } }, { merge: true });
}

export async function fetchFirebaseMessagesOnce(threadId: string, currentUserId: string): Promise<FirebaseMessage[]> {
  await ensureFirebaseAuth();
  const snapshot = await getDocs(query(collection(db, "conversations", threadId, "messages"), orderBy("createdAt", "asc")));
  const items = await Promise.all(snapshot.docs.map((item) => mapMessage(item, threadId, currentUserId)));
  return items.filter((item) => !isExpired(item));
}

export type FirebaseUsage = { sent: number; received: number; photos: number; voice: number };

export async function fetchFirebaseUsage(currentUserId: string): Promise<FirebaseUsage> {
  await ensureFirebaseAuth();
  const current = normalizeId(currentUserId);
  const conversationsSnapshot = await getDocs(query(collection(db, "conversations"), where("participants", "array-contains", current)));
  const usage: FirebaseUsage = { sent: 0, received: 0, photos: 0, voice: 0 };
  for (const conversationDoc of conversationsSnapshot.docs) {
    const messagesSnapshot = await getDocs(collection(db, "conversations", conversationDoc.id, "messages"));
    for (const messageDoc of messagesSnapshot.docs) {
      const data = messageDoc.data();
      const sender = normalizeId(typeof data.senderId === "string" ? data.senderId : "");
      if (sender === current) usage.sent += 1; else usage.received += 1;
      if (data.type === "image") usage.photos += 1;
      if (data.type === "audio") usage.voice += 1;
    }
  }
  return usage;
}

export function getFirebaseDbForDiagnostics(): Firestore {
  return db;
}

/* ===== App reviews (Settings → "Rate the app") =====
 * Every signed-in user can post one review per submission: a star rating
 * plus an optional comment, stored in the `appReviews` collection with
 * the author's identity. Reviews are read back ONLY by the admin
 * account's in-app admin section (the UI never subscribes for anyone
 * else, and firestore.rules restricts reads to the admin email). */

export type AppReview = {
  id: string;
  author_id: string;
  author_name: string;
  author_email: string | null;
  author_username: string | null;
  rating: number;
  comment: string;
  created_at: string;
};

export async function submitAppReview(input: { author: FirebaseContact; rating: number; comment: string }): Promise<string> {
  await ensureFirebaseAuth();
  const rating = Math.min(5, Math.max(1, Math.round(input.rating)));
  const reviewRef = doc(collection(db, "appReviews"));
  await setDoc(reviewRef, {
    id: reviewRef.id,
    authorId: normalizeId(input.author.id),
    authorName: input.author.name,
    authorEmail: input.author.email ? normalizeId(input.author.email) : null,
    authorUsername: input.author.username ?? null,
    rating,
    comment: input.comment.trim().slice(0, 1000),
    createdAt: Timestamp.now(),
  });
  return reviewRef.id;
}

export function listenToAppReviews(
  onData: (items: AppReview[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const reviewsQuery = query(collection(db, "appReviews"), orderBy("createdAt", "desc"), limit(100));
  return resilientSnapshot<QuerySnapshot<DocumentData>>((next, error) => onSnapshot(reviewsQuery, next, error), (snapshot) => {
    const items = snapshot.docs.map((snapshotDoc) => {
      const data = snapshotDoc.data();
      return {
        id: snapshotDoc.id,
        author_id: typeof data.authorId === "string" ? normalizeId(data.authorId) : "",
        author_name: typeof data.authorName === "string" ? data.authorName : "",
        author_email: typeof data.authorEmail === "string" ? data.authorEmail : null,
        author_username: typeof data.authorUsername === "string" ? data.authorUsername : null,
        rating: typeof data.rating === "number" ? Math.min(5, Math.max(1, Math.round(data.rating))) : 0,
        comment: typeof data.comment === "string" ? data.comment : "",
        created_at: dateIso(data.createdAt),
      } satisfies AppReview;
    });
    onData(items);
  }, onError);
}

/* ===== Presence: online / last seen =====
 *
 * Presence is a `profiles` document with `online` + `lastActiveAt`,
 * refreshed by a 45-second heartbeat (touchFirebasePresence) while
 * the app is in the foreground. Firestore has no server-side
 * onDisconnect, so two defences decide what readers show:
 *  1. the writer marks itself offline the moment the app hides,
 *     pauses, or closes (App.tsx registers visibilitychange, pagehide
 *     and Capacitor's appStateChange idempotently);
 *  2. readers treat a heartbeat older than PRESENCE_FRESH_MS as
 *     offline and show `lastActiveAt` — the peer's actual last
 *     activity — as the last-seen time, so even a hard-killed app
 *     (no chance to write anything) stops showing "online" within
 *     ~90 seconds instead of the several minutes the old 150-second
 *     threshold plus snapshot-only evaluation allowed. Readers must
 *     RE-evaluate freshness on a timer, not only when a snapshot
 *     arrives: after a kill no further snapshot ever comes. */

/** A heartbeat older than this reads as offline. Kept above the 45s
 *  heartbeat interval so a single missed beat never flickers a live
 *  user offline. */
export const PRESENCE_FRESH_MS = 90_000;

export async function touchFirebasePresence(userId: string) {
  await ensureFirebaseAuth();
  const id = normalizeId(userId);
  if (!id) return;
  await setDoc(doc(db, "profiles", safeDocPart(id)), { lastActiveAt: Timestamp.now(), online: true }, { merge: true });
}

export async function markFirebaseOffline(userId: string) {
  await ensureFirebaseAuth();
  const id = normalizeId(userId);
  if (!id) return;
  await setDoc(doc(db, "profiles", safeDocPart(id)), { lastActiveAt: Timestamp.now(), online: false }, { merge: true });
}

export function listenToFirebasePresence(
  userId: string,
  onData: (presence: { online: boolean; last_active_at: string | null }) => void,
): Unsubscribe {
  const id = normalizeId(userId);
  const profileRef = doc(db, "profiles", safeDocPart(id));
  return resilientSnapshot<DocumentSnapshot<DocumentData>>((next, error) => onSnapshot(profileRef, next, error), (snapshot) => {
    const data = snapshot.data();
    const lastActive = data?.lastActiveAt instanceof Timestamp ? data.lastActiveAt.toDate().toISOString() : null;
    const fresh = lastActive !== null && Date.now() - new Date(lastActive).getTime() < PRESENCE_FRESH_MS;
    onData({ online: data?.online === true && fresh, last_active_at: lastActive });
  }, () => onData({ online: false, last_active_at: null }));
}

/* ===== Delete a single message (works for voice, image and text) ===== */

export async function deleteFirebaseMessage(collectionRoot: "conversations" | "groups", threadId: string, messageId: string) {
  await ensureFirebaseAuth();
  const chunksSnapshot = await getDocs(collection(db, collectionRoot, threadId, "messages", messageId, "mediaChunks"));
  if (!chunksSnapshot.empty) {
    const batch = writeBatch(db);
    chunksSnapshot.docs.forEach((item) => batch.delete(item.ref));
    await batch.commit();
  }
  await deleteDoc(doc(db, collectionRoot, threadId, "messages", messageId));
}

/* ===== Delete a whole direct chat: every message, its media chunks and the
 * conversation document itself, so a deleted chat can never reappear from
 * the conversations listener. ===== */

export async function deleteFirebaseConversation(threadId: string) {
  await ensureFirebaseAuth();
  const messagesSnapshot = await getDocs(collection(db, "conversations", threadId, "messages"));
  for (const messageDoc of messagesSnapshot.docs) {
    await deleteFirebaseMessage("conversations", threadId, messageDoc.id);
  }
  await deleteDoc(doc(db, "conversations", threadId));
}

/* ===== Emoji reactions: one reaction per user per message, tap again to remove ===== */

export async function toggleFirebaseMessageReaction(collectionRoot: "conversations" | "groups", threadId: string, messageId: string, userId: string, emoji: string) {
  await ensureFirebaseAuth();
  const current = normalizeId(userId);
  const ref = doc(db, collectionRoot, threadId, "messages", messageId);
  const snapshot = await getDoc(ref);
  if (!snapshot.exists()) return;
  const data = snapshot.data();
  const next: Record<string, string[]> = {};
  if (data.reactions && typeof data.reactions === "object" && !Array.isArray(data.reactions)) {
    for (const [key, users] of Object.entries(data.reactions as Record<string, unknown>)) {
      if (Array.isArray(users)) {
        const ids = users.filter((value): value is string => typeof value === "string").map(normalizeId).filter((id) => id !== current);
        if (ids.length > 0) next[key] = ids;
      }
    }
  }
  const already = Array.isArray((data.reactions as Record<string, unknown> | undefined)?.[emoji])
    && ((data.reactions as Record<string, unknown>)[emoji] as unknown[]).some((value) => typeof value === "string" && normalizeId(value) === current);
  if (!already) next[emoji] = [...(next[emoji] ?? []), current];
  await updateDoc(ref, { reactions: next });
}

/* ===== Poll votes: one vote per user; tapping another option moves the
 * vote, tapping the same option again withdraws it ===== */

export async function toggleFirebasePollVote(collectionRoot: "conversations" | "groups", threadId: string, messageId: string, userId: string, optionId: string) {
  await ensureFirebaseAuth();
  const current = normalizeId(userId);
  const ref = doc(db, collectionRoot, threadId, "messages", messageId);
  const snapshot = await getDoc(ref);
  if (!snapshot.exists()) return;
  const data = snapshot.data();
  const next: Record<string, string[]> = {};
  if (data.pollVotes && typeof data.pollVotes === "object" && !Array.isArray(data.pollVotes)) {
    for (const [key, users] of Object.entries(data.pollVotes as Record<string, unknown>)) {
      if (Array.isArray(users)) {
        const ids = users.filter((value): value is string => typeof value === "string").map(normalizeId).filter((id) => id !== current);
        if (ids.length > 0) next[key] = ids;
      }
    }
  }
  const already = Array.isArray((data.pollVotes as Record<string, unknown> | undefined)?.[optionId])
    && ((data.pollVotes as Record<string, unknown>)[optionId] as unknown[]).some((value) => typeof value === "string" && normalizeId(value) === current);
  if (!already) next[optionId] = [...(next[optionId] ?? []), current];
  await updateDoc(ref, { pollVotes: next });
}

/* ===== Disappearing messages: actually delete expired message documents ===== */

export async function purgeExpiredFirebaseMessages(collectionRoot: "conversations" | "groups", threadId: string): Promise<number> {
  await ensureFirebaseAuth();
  // Targeted: only documents that carry an expiry at or before now —
  // messages without an expiresAt field never match this query, so the
  // purge no longer reads the whole thread on every pass.
  const snapshot = await getDocs(query(collection(db, collectionRoot, threadId, "messages"), where("expiresAt", "<=", Timestamp.now())));
  for (const item of snapshot.docs) {
    await deleteFirebaseMessage(collectionRoot, threadId, item.id);
  }
  return snapshot.docs.length;
}

/* ===== Mark a chat as unread (chat-list long-press menu) ===== */

export async function setFirebaseConversationUnread(threadId: string, currentUserId: string) {
  await ensureFirebaseAuth();
  const key = safeDocPart(normalizeId(currentUserId));
  await setDoc(doc(db, "conversations", threadId), { unreadBy: { [key]: 1 } }, { merge: true });
}

export async function setFirebaseGroupUnread(groupId: string, currentUserId: string) {
  await ensureFirebaseAuth();
  const key = safeDocPart(normalizeId(currentUserId));
  await updateDoc(doc(db, "groups", groupId), { [`unreadBy.${key}`]: 1 });
}

/* ===== Delete ALL of this user's data from Firebase (Settings → delete my data) =====
 * Direct chats are removed completely (messages, media chunks and the
 * conversation document). In groups only this user's own messages are
 * removed — the group and other members' messages belong to everyone.
 * Own statuses and the own profile/presence document are deleted too. */

export async function deleteAllFirebaseUserData(currentUserId: string): Promise<void> {
  await ensureFirebaseAuth();
  const current = normalizeId(currentUserId);

  const conversationsSnapshot = await getDocs(query(collection(db, "conversations"), where("participants", "array-contains", current)));
  for (const conversationDoc of conversationsSnapshot.docs) {
    const messagesSnapshot = await getDocs(collection(db, "conversations", conversationDoc.id, "messages"));
    for (const messageDoc of messagesSnapshot.docs) {
      await deleteFirebaseMessage("conversations", conversationDoc.id, messageDoc.id);
    }
    await deleteDoc(conversationDoc.ref);
  }

  const groupsSnapshot = await getDocs(query(collection(db, "groups"), where("memberIds", "array-contains", current)));
  for (const groupDoc of groupsSnapshot.docs) {
    const messagesSnapshot = await getDocs(collection(db, "groups", groupDoc.id, "messages"));
    for (const messageDoc of messagesSnapshot.docs) {
      const sender = typeof messageDoc.data().senderId === "string" ? normalizeId(messageDoc.data().senderId as string) : "";
      if (sender === current) await deleteFirebaseMessage("groups", groupDoc.id, messageDoc.id);
    }
  }

  const statusesSnapshot = await getDocs(query(collection(db, "statuses"), where("authorId", "==", current)));
  for (const statusDoc of statusesSnapshot.docs) {
    const chunksSnapshot = await getDocs(collection(db, "statuses", statusDoc.id, "mediaChunks"));
    if (!chunksSnapshot.empty) {
      const batch = writeBatch(db);
      chunksSnapshot.docs.forEach((item) => batch.delete(item.ref));
      await batch.commit();
    }
    await deleteDoc(statusDoc.ref);
  }

  await deleteDoc(doc(db, "profiles", safeDocPart(current)));
}

/* ===== Groups (WhatsApp-style) ===== */

export type FirebaseGroup = {
  id: string;
  name: string;
  photo: string | null;
  description: string;
  created_by: string;
  admins: string[];
  members: FirebaseContact[];
  updated_at: string;
};

function parseGroupDoc(snapshotDoc: QueryDocumentSnapshot<DocumentData>): FirebaseGroup {
  const data = snapshotDoc.data();
  const members = Array.isArray(data.members) ? data.members.map(parseContact).filter((value): value is FirebaseContact => value !== null) : [];
  return {
    id: snapshotDoc.id,
    name: typeof data.name === "string" ? data.name : "",
    photo: typeof data.photo === "string" && data.photo.startsWith("data:image/") ? data.photo : null,
    description: typeof data.description === "string" ? data.description : "",
    created_by: typeof data.createdBy === "string" ? normalizeId(data.createdBy) : "",
    admins: Array.isArray(data.admins) ? data.admins.filter((value): value is string => typeof value === "string").map(normalizeId) : [],
    members,
    updated_at: dateIso(data.updatedAt),
  };
}

export function groupConversationId(groupId: string) {
  return `group:${groupId}`;
}

export async function createFirebaseGroup(input: { creator: FirebaseContact; name: string; photo: string | null; description: string; members: FirebaseContact[] }): Promise<string> {
  await ensureFirebaseAuth();
  const creator = { ...input.creator, id: normalizeId(input.creator.id) };
  const membersById = new Map<string, FirebaseContact>();
  membersById.set(creator.id, creator);
  for (const member of input.members) membersById.set(normalizeId(member.id), { ...member, id: normalizeId(member.id) });
  // Member photos are thumbnails in the group document (see
  // contactForStorage) so the document stays small for every member's
  // snapshots.
  const members = await Promise.all([...membersById.values()].map(contactForStorage));
  const groupRef = doc(collection(db, "groups"));
  await setDoc(groupRef, {
    id: groupRef.id,
    name: input.name,
    photo: await thumbnailPhoto(input.photo ?? null),
    description: input.description,
    createdBy: creator.id,
    admins: [creator.id],
    memberIds: members.map((member) => member.id),
    members,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  });
  return groupRef.id;
}

function mapGroupConversationDoc(snapshotDoc: QueryDocumentSnapshot<DocumentData>, current: string): FirebaseConversation {
  const data = snapshotDoc.data();
  const group = parseGroupDoc(snapshotDoc);
  const unreadBy = data.unreadBy && typeof data.unreadBy === "object" ? data.unreadBy as Record<string, unknown> : {};
  const unreadKey = safeDocPart(current);
  const messageType = typeof data.lastMessageType === "string" && (FIREBASE_MESSAGE_TYPES as string[]).includes(data.lastMessageType) ? data.lastMessageType as FirebaseMessageType : null;
  return {
    id: groupConversationId(group.id),
    contact_name: group.name,
    contact_email: null,
    contact_username: null,
    contact_mobile: null,
    contact_photo: group.photo,
    target_user_id: group.id,
    last_message: typeof data.lastMessage === "string" ? data.lastMessage : null,
    last_message_type: messageType,
    last_sender_id: typeof data.lastSenderId === "string" ? data.lastSenderId : null,
    unread_count: typeof unreadBy[unreadKey] === "number" ? unreadBy[unreadKey] : 0,
    updated_at: group.updated_at,
    is_group: true,
    group_id: group.id,
    group_description: group.description,
    group_members: group.members,
    group_admins: group.admins,
    group_created_by: group.created_by,
  } satisfies FirebaseConversation;
}

const GROUP_PAGE_SIZE = 100;

function groupsQueryFor(current: string, bounded: boolean) {
  const base = query(collection(db, "groups"), where("memberIds", "array-contains", current));
  return bounded ? query(base, orderBy("updatedAt", "desc"), limit(GROUP_PAGE_SIZE)) : base;
}

export function listenToFirebaseGroups(
  currentUserId: string,
  onData: (items: FirebaseConversation[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  return resilientSnapshot<QuerySnapshot<DocumentData>>((next, error) => subscribeWithIndexFallback<QuerySnapshot<DocumentData>>(
    (n, e) => onSnapshot(groupsQueryFor(current, true), n, e),
    (n, e) => onSnapshot(groupsQueryFor(current, false), n, e),
    next,
    error,
  ), (snapshot) => {
    const items = sortConversations(snapshot.docs.map((snapshotDoc) => mapGroupConversationDoc(snapshotDoc, current)));
    for (const item of items) markThreadKnown(item.group_id ?? item.id, item.last_message !== null);
    onData(items);
  }, onError);
}

/** Cache-first companion to listenToFirebaseGroups — see
 *  fetchConversationsFromCache. */
export async function fetchGroupsFromCache(currentUserId: string): Promise<FirebaseConversation[]> {
  const current = normalizeId(currentUserId);
  try {
    const snapshot = await getDocsFromCache(groupsQueryFor(current, false));
    return sortConversations(snapshot.docs.map((snapshotDoc) => mapGroupConversationDoc(snapshotDoc, current)));
  } catch {
    return [];
  }
}

export async function updateFirebaseGroup(groupId: string, next: { name?: string; photo?: string | null; description?: string }) {
  await ensureFirebaseAuth();
  const update: { name?: string; photo?: string | null; description?: string } = { ...next };
  if ("photo" in next) update.photo = await thumbnailPhoto(next.photo ?? null);
  await updateDoc(doc(db, "groups", groupId), { ...update, updatedAt: Timestamp.now() });
}

export async function setFirebaseGroupMembers(groupId: string, members: FirebaseContact[], admins: string[]) {
  await ensureFirebaseAuth();
  const normalizedMembers = await Promise.all(members.map(async (member) => contactForStorage({ ...member, id: normalizeId(member.id) })));
  const memberIds = normalizedMembers.map((member) => member.id);
  const normalizedAdmins = admins.map(normalizeId).filter((id) => memberIds.includes(id));
  await updateDoc(doc(db, "groups", groupId), { members: normalizedMembers, memberIds, admins: normalizedAdmins, updatedAt: Timestamp.now() });
}

export function listenToFirebaseGroupMessages(
  groupId: string,
  currentUserId: string,
  onData: (items: FirebaseMessage[]) => void,
  onError: (error: Error) => void,
  onConfirmed?: (ids: string[]) => void,
): Unsubscribe {
  const messagesQuery = query(collection(db, "groups", groupId, "messages"), orderBy("createdAt", "desc"), limit(MESSAGE_PAGE_SIZE));
  const deliverySeq = { latest: 0 };
  return resilientSnapshot<QuerySnapshot<DocumentData>>((next, error) => onSnapshot(messagesQuery, next, error), (snapshot) => {
    const seq = ++deliverySeq.latest;
    handleMessageSnapshot(snapshot, groupId, groupId, currentUserId, "groups", onData, onError, onConfirmed, () => seq === deliverySeq.latest);
  }, onError);
}

export async function sendFirebaseGroupMessage(input: FirebaseMessageInput & { memberIds: string[]; senderName: string; senderPhoto: string | null }) {
  const createdAt = input.createdAt ?? Date.now();
  const messageRef = input.id ? doc(db, "groups", input.threadId, "messages", input.id) : doc(collection(db, "groups", input.threadId, "messages"));
  const parsedMedia = input.dataUrl ? splitDataUrl(input.dataUrl) : null;
  const chunks = parsedMedia && parsedMedia.data.length > INLINE_MEDIA_MAX_CHARS ? parsedMedia.data.match(new RegExp(`.{1,${MEDIA_CHUNK_CHARS}}`, "g")) ?? [] : [];
  const others = input.memberIds.map(normalizeId).filter((id) => id !== normalizeId(input.senderId));
  // Same idempotence contract as the direct send: the message document
  // and the summary fields are fixed absolute values. Only the unread
  // increments are NOT idempotent, so the retry build leaves them out —
  // if the first attempt actually landed but its acknowledgement was
  // lost, the count must not be bumped a second time.
  const buildBatch = (isRetry: boolean): WriteBatch => {
    const batch = writeBatch(db);
    batch.set(messageRef, {
      id: messageRef.id,
      body: input.body,
      senderId: normalizeId(input.senderId),
      senderName: input.senderName,
      senderPhoto: input.senderPhoto,
      receiverId: others[0] ?? "",
      receiverIds: others,
      type: input.type,
      ...(isRetry ? {} : { status: "sent" as const }),
      createdAt: Timestamp.fromMillis(createdAt),
      ...(parsedMedia ? { mimeType: parsedMedia.mimeType, ...(chunks.length === 0 ? { dataUrl: input.dataUrl } : { hasChunks: true }) } : {}),
      ...attachmentWriteFields(input, createdAt),
      ...(input.audioDuration !== undefined ? { audioDuration: input.audioDuration } : {}),
      ...(input.waveform && input.waveform.length > 0 && !input.passwordHash ? { waveform: input.waveform.slice(0, 40) } : {}),
      ...(input.voiceEffect ? { voiceEffect: input.voiceEffect } : {}),
      ...(input.unlockAt ? { unlockAt: Timestamp.fromMillis(input.unlockAt) } : {}),
      ...(input.passwordHash ? { passwordHash: input.passwordHash } : {}),
      ...(input.passwordSalt ? { passwordSalt: input.passwordSalt } : {}),
      ...(input.ttlSeconds && input.ttlSeconds > 0 ? { expiresAt: Timestamp.fromMillis(createdAt + input.ttlSeconds * 1000) } : {}),
      ...(input.replyTo ? { replyTo: input.replyTo } : {}),
      ...(input.forwarded ? { forwarded: true } : {}),
    }, { merge: true });
    chunks.forEach((chunk, index) => batch.set(doc(db, "groups", input.threadId, "messages", messageRef.id, "mediaChunks", String(index).padStart(4, "0")), { index, data: chunk }));
    const groupUpdate: Record<string, unknown> = {
      lastMessage: input.body,
      lastMessageType: input.type,
      lastSenderId: normalizeId(input.senderId),
      updatedAt: Timestamp.fromMillis(createdAt),
    };
    if (!isRetry) others.forEach((id) => { groupUpdate[`unreadBy.${safeDocPart(id)}`] = increment(1); });
    batch.update(doc(db, "groups", input.threadId), groupUpdate as UpdateData<DocumentData>);
    return batch;
  };
  await commitWithRecovery(buildBatch);
  return { id: messageRef.id, createdAt };
}

export async function markFirebaseGroupMessagesRead(groupId: string, currentUserId: string) {
  await ensureFirebaseAuth();
  const current = normalizeId(currentUserId);
  // Targeted query: only messages addressed to this user that are not
  // read yet — never a scan of the whole group thread.
  const snapshot = await getDocs(query(
    collection(db, "groups", groupId, "messages"),
    where("receiverIds", "array-contains", current),
    where("status", "in", ["sent", "delivered"]),
  ));
  const batch = writeBatch(db);
  snapshot.docs.forEach((item) => batch.update(item.ref, { status: "read", readAt: Timestamp.now() }));
  batch.update(doc(db, "groups", groupId), { [`unreadBy.${safeDocPart(current)}`]: 0 });
  await batch.commit();
}

export async function fetchFirebaseGroupMessagesOnce(groupId: string, currentUserId: string): Promise<FirebaseMessage[]> {
  await ensureFirebaseAuth();
  const snapshot = await getDocs(query(collection(db, "groups", groupId, "messages"), orderBy("createdAt", "asc")));
  const items = await Promise.all(snapshot.docs.map((item) => mapMessage(item, groupId, currentUserId, "groups")));
  return items.filter((item) => !isExpired(item));
}

/* ===== Real 1-to-1 calls: WebRTC signaling over Firestore =====
 * Media flows peer-to-peer through RTCPeerConnection (see
 * client/src/callEngine.ts); Firestore carries only the signaling:
 * one document per call in the top-level `calls` collection holding
 * the SDP offer/answer and the call lifecycle, plus one ICE-candidate
 * subcollection per side (`callerCandidates` / `calleeCandidates`)
 * streamed with onSnapshot. Listeners attach immediately through the
 * same supervisor as every other listener in this file; writes wait
 * for the anonymous-auth bootstrap via ensureFirebaseAuth, exactly
 * like the messaging writes.
 *
 * Finalization contract: a call document must never be left in
 * "ringing" — every exit path (answer timeout, decline, hangup, ICE
 * failure, permission denial) moves it to a terminal status. The
 * CALLER is the single writer of the in-chat call-record message, so
 * both users see exactly one record per call. */

export type FirebaseCallKind = "audio" | "video";
export type FirebaseCallStatus = "ringing" | "ongoing" | "ended" | "declined" | "missed" | "failed";
export type FirebaseSdp = { type: RTCSdpType; sdp: string };

export type FirebaseCall = {
  id: string;
  caller_id: string;
  callee_id: string;
  caller_name: string;
  callee_name: string;
  caller_photo: string | null;
  callee_photo: string | null;
  conversation_id: string;
  kind: FirebaseCallKind;
  status: FirebaseCallStatus;
  offer: FirebaseSdp | null;
  answer: FirebaseSdp | null;
  created_at: string;
  answered_at: string | null;
  ended_at: string | null;
  duration_sec: number | null;
};

const CALL_STATUSES: FirebaseCallStatus[] = ["ringing", "ongoing", "ended", "declined", "missed", "failed"];

function parseSdp(value: unknown): FirebaseSdp | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  if (typeof raw.type !== "string" || typeof raw.sdp !== "string" || !raw.sdp) return null;
  if (!["offer", "answer", "pranswer", "rollback"].includes(raw.type)) return null;
  return { type: raw.type as RTCSdpType, sdp: raw.sdp };
}

function mapCallDoc(snapshotDoc: DocumentSnapshot<DocumentData> | QueryDocumentSnapshot<DocumentData>): FirebaseCall {
  const data = snapshotDoc.data() ?? {};
  const status = typeof data.status === "string" && (CALL_STATUSES as string[]).includes(data.status) ? data.status as FirebaseCallStatus : "ringing";
  return {
    id: snapshotDoc.id,
    caller_id: typeof data.callerId === "string" ? normalizeId(data.callerId) : "",
    callee_id: typeof data.calleeId === "string" ? normalizeId(data.calleeId) : "",
    caller_name: typeof data.callerName === "string" ? data.callerName : "",
    callee_name: typeof data.calleeName === "string" ? data.calleeName : "",
    caller_photo: typeof data.callerPhoto === "string" && data.callerPhoto.startsWith("data:image/") ? data.callerPhoto : null,
    callee_photo: typeof data.calleePhoto === "string" && data.calleePhoto.startsWith("data:image/") ? data.calleePhoto : null,
    conversation_id: typeof data.conversationId === "string" ? data.conversationId : "",
    kind: data.kind === "video" ? "video" : "audio",
    status,
    offer: parseSdp(data.offer),
    answer: parseSdp(data.answer),
    created_at: dateIso(data.createdAt),
    answered_at: data.answeredAt instanceof Timestamp ? data.answeredAt.toDate().toISOString() : null,
    ended_at: data.endedAt instanceof Timestamp ? data.endedAt.toDate().toISOString() : null,
    duration_sec: typeof data.durationSec === "number" ? data.durationSec : null,
  };
}

/** Create the call document (the caller's offer is already in hand, so
 *  the callee's incoming listener only ever fires for a call that can
 *  actually be answered). Returns the new call id. */
export async function createFirebaseCall(input: {
  caller: FirebaseContact;
  callee: FirebaseContact;
  conversationId: string;
  kind: FirebaseCallKind;
  offer: FirebaseSdp;
}): Promise<string> {
  await ensureFirebaseAuth();
  const caller = { ...input.caller, id: normalizeId(input.caller.id) };
  const callee = { ...input.callee, id: normalizeId(input.callee.id) };
  const callRef = doc(collection(db, "calls"));
  // Photos ride along as thumbnails so the Calls history can render
  // without a second lookup — same rule as conversation documents.
  const [callerStored, calleeStored] = await Promise.all([contactForStorage(caller), contactForStorage(callee)]);
  await setDoc(callRef, {
    id: callRef.id,
    callerId: caller.id,
    calleeId: callee.id,
    callerName: caller.name,
    calleeName: callee.name,
    callerPhoto: callerStored.photo,
    calleePhoto: calleeStored.photo,
    conversationId: input.conversationId,
    kind: input.kind,
    status: "ringing" as FirebaseCallStatus,
    offer: input.offer,
    answer: null,
    createdAt: Timestamp.now(),
    answeredAt: null,
    endedAt: null,
    durationSec: null,
  });
  return callRef.id;
}

export type FirebaseCallUpdate = {
  status?: FirebaseCallStatus;
  answer?: FirebaseSdp;
  offer?: FirebaseSdp;
  answeredAtMs?: number;
  endedAtMs?: number;
  durationSec?: number;
};

export async function updateFirebaseCall(callId: string, update: FirebaseCallUpdate): Promise<void> {
  await ensureFirebaseAuth();
  const fields: Record<string, unknown> = {};
  if (update.status !== undefined) fields.status = update.status;
  if (update.answer !== undefined) fields.answer = update.answer;
  if (update.offer !== undefined) fields.offer = update.offer;
  if (update.answeredAtMs !== undefined) fields.answeredAt = Timestamp.fromMillis(update.answeredAtMs);
  if (update.endedAtMs !== undefined) fields.endedAt = Timestamp.fromMillis(update.endedAtMs);
  if (update.durationSec !== undefined) fields.durationSec = update.durationSec;
  if (Object.keys(fields).length === 0) return;
  await updateDoc(doc(db, "calls", callId), fields as UpdateData<DocumentData>);
}

export async function fetchFirebaseCall(callId: string): Promise<FirebaseCall | null> {
  await ensureFirebaseAuth();
  const snapshot = await getDoc(doc(db, "calls", callId));
  return snapshot.exists() ? mapCallDoc(snapshot) : null;
}

/** Live view of one call document (offer/answer/status changes). */
export function listenToFirebaseCall(
  callId: string,
  onData: (call: FirebaseCall | null) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const callRef = doc(db, "calls", callId);
  return resilientSnapshot<DocumentSnapshot<DocumentData>>((next, error) => onSnapshot(callRef, next, error), (snapshot) => {
    onData(snapshot.exists() ? mapCallDoc(snapshot) : null);
  }, onError);
}

export type FirebaseIceCandidate = { candidate: string; sdpMid: string | null; sdpMLineIndex: number | null };

export async function addFirebaseCallCandidate(callId: string, side: "caller" | "callee", candidate: FirebaseIceCandidate): Promise<void> {
  await ensureFirebaseAuth();
  const sub = side === "caller" ? "callerCandidates" : "calleeCandidates";
  const ref = doc(collection(db, "calls", callId, sub));
  await setDoc(ref, { candidate: candidate.candidate, sdpMid: candidate.sdpMid, sdpMLineIndex: candidate.sdpMLineIndex, createdAt: Timestamp.now() });
}

/** Stream the OTHER side's ICE candidates. Candidates already present
 *  when the listener attaches are delivered too (the callee may start
 *  listening after the caller has already produced some). */
export function listenToFirebaseCallCandidates(
  callId: string,
  side: "caller" | "callee",
  onCandidate: (candidate: FirebaseIceCandidate) => void,
): Unsubscribe {
  const sub = side === "caller" ? "callerCandidates" : "calleeCandidates";
  const seen = new Set<string>();
  const candidatesQuery = query(collection(db, "calls", callId, sub), orderBy("createdAt", "asc"));
  return resilientSnapshot<QuerySnapshot<DocumentData>>((next, error) => onSnapshot(candidatesQuery, next, error), (snapshot) => {
    for (const item of snapshot.docs) {
      if (seen.has(item.id)) continue;
      seen.add(item.id);
      const data = item.data();
      if (typeof data.candidate !== "string" || !data.candidate) continue;
      onCandidate({
        candidate: data.candidate,
        sdpMid: typeof data.sdpMid === "string" ? data.sdpMid : null,
        sdpMLineIndex: typeof data.sdpMLineIndex === "number" ? data.sdpMLineIndex : null,
      });
    }
  }, () => undefined);
}

/** Incoming ringing calls for this user. Equality-only filters (merge
 *  join over single-field indexes — no composite index needed); the
 *  newest call is picked client-side. */
export function listenToIncomingFirebaseCalls(
  currentUserId: string,
  onData: (calls: FirebaseCall[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  const incomingQuery = query(collection(db, "calls"), where("calleeId", "==", current), where("status", "==", "ringing"));
  return resilientSnapshot<QuerySnapshot<DocumentData>>((next, error) => onSnapshot(incomingQuery, next, error), (snapshot) => {
    const items = snapshot.docs.map((item) => mapCallDoc(item)).filter((call) => call.caller_id && call.caller_id !== current);
    items.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    onData(items);
  }, onError);
}

export type FirebaseCallHistoryItem = {
  id: string;
  other_id: string;
  other_name: string;
  other_photo: string | null;
  conversation_id: string;
  kind: FirebaseCallKind;
  status: FirebaseCallStatus;
  direction: "incoming" | "outgoing";
  created_at: string;
  duration_sec: number | null;
};

function callHistoryItem(call: FirebaseCall, current: string): FirebaseCallHistoryItem {
  const outgoing = call.caller_id === current;
  return {
    id: call.id,
    other_id: outgoing ? call.callee_id : call.caller_id,
    other_name: outgoing ? call.callee_name : call.caller_name,
    other_photo: outgoing ? call.callee_photo : call.caller_photo,
    conversation_id: call.conversation_id,
    kind: call.kind,
    status: call.status,
    direction: outgoing ? "outgoing" : "incoming",
    created_at: call.created_at,
    duration_sec: call.duration_sec,
  };
}

/** Full call history for this user (both directions), newest first.
 *  Two equality queries (as caller / as callee) merged client-side. */
export function listenToFirebaseCallHistory(
  currentUserId: string,
  onData: (items: FirebaseCallHistoryItem[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const current = normalizeId(currentUserId);
  let asCaller: FirebaseCall[] = [];
  let asCallee: FirebaseCall[] = [];
  const emit = () => {
    const byId = new Map<string, FirebaseCall>();
    for (const call of [...asCaller, ...asCallee]) byId.set(call.id, call);
    const items = [...byId.values()].map((call) => callHistoryItem(call, current));
    items.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    onData(items.slice(0, 100));
  };
  /* Both queries are BOUNDED to the newest 100 (the old listeners
   * carried no limit at all: the whole call history — growing
   * forever — was downloaded and re-mapped on every snapshot, and
   * slice(0, 100) only trimmed it after the full load). The bounded
   * form needs a composite index; subscribeWithIndexFallback drops
   * back to the unbounded query if Firestore reports it missing, so
   * a not-yet-created index degrades instead of breaking history. */
  const unsubCaller = resilientSnapshot<QuerySnapshot<DocumentData>>(
    (next, error) => subscribeWithIndexFallback<QuerySnapshot<DocumentData>>(
      (n, e) => onSnapshot(query(collection(db, "calls"), where("callerId", "==", current), orderBy("createdAt", "desc"), limit(100)), n, e),
      (n, e) => onSnapshot(query(collection(db, "calls"), where("callerId", "==", current)), n, e),
      next,
      error,
    ),
    (snapshot) => { asCaller = snapshot.docs.map((item) => mapCallDoc(item)); emit(); },
    onError,
  );
  const unsubCallee = resilientSnapshot<QuerySnapshot<DocumentData>>(
    (next, error) => subscribeWithIndexFallback<QuerySnapshot<DocumentData>>(
      (n, e) => onSnapshot(query(collection(db, "calls"), where("calleeId", "==", current), orderBy("createdAt", "desc"), limit(100)), n, e),
      (n, e) => onSnapshot(query(collection(db, "calls"), where("calleeId", "==", current)), n, e),
      next,
      error,
    ),
    (snapshot) => { asCallee = snapshot.docs.map((item) => mapCallDoc(item)); emit(); },
    onError,
  );
  return () => { unsubCaller(); unsubCallee(); };
}

/** Write the ONE in-chat record of a finished call. The message id is
 *  derived from the call id, so even a retried write can never create
 *  a second record. The record is authored by the caller, so it reads
 *  as "self" for the caller and "contact" for the callee on both
 *  devices. Only the CALLER's client writes it (see the contract at
 *  the top of this section). */
export async function sendFirebaseCallRecord(input: {
  callId: string;
  threadId: string;
  callerId: string;
  calleeId: string;
  body: string;
  kind: FirebaseCallKind;
  status: FirebaseCallStatus;
  durationSec: number | null;
}): Promise<void> {
  const createdAt = Date.now();
  const messageRef = doc(db, "conversations", input.threadId, "messages", `callrecord-${input.callId}`);
  const buildBatch = (isRetry = false): WriteBatch => {
    const batch = writeBatch(db);
    batch.set(messageRef, {
      id: messageRef.id,
      body: input.body,
      senderId: normalizeId(input.callerId),
      receiverId: normalizeId(input.calleeId),
      type: "call" as const,
      callKind: input.kind,
      callStatus: input.status,
      callDurationSec: input.durationSec,
      ...(isRetry ? {} : { status: "sent" as const }),
      createdAt: Timestamp.fromMillis(createdAt),
    }, { merge: true });
    batch.set(doc(db, "conversations", input.threadId), {
      lastMessage: input.body,
      lastMessageType: "call",
      lastSenderId: normalizeId(input.callerId),
      updatedAt: Timestamp.fromMillis(createdAt),
    }, { merge: true });
    return batch;
  };
  await commitWithRecovery(buildBatch);
}

/* ------------------------------------------------------------------ */
/* Phone-number OTP login (free SMS gateway on the admin's own phone)  */
/*                                                                     */
/* Flow: the app generates a 6-digit code, stores ONLY its SHA-256     */
/* hash in an `otp_requests` doc (5-minute expiry, attempt counter,    */
/* rate-limit timestamps), and asks the "SMS Gateway for Android" app  */
/* (sms-gate.app cloud relay) to text the code from the admin's SIM.   */
/* Gateway credentials live in one Firestore config doc                */
/* (`config/otpGateway`) written from Settings by the admin; every     */
/* install reads it when a phone login is attempted. If the config is  */
/* missing the login screen shows a "not set up yet" message instead   */
/* of an error.                                                        */
/* ------------------------------------------------------------------ */

export type OtpGatewayConfig = { username: string; password: string };

export async function fetchOtpGatewayConfig(): Promise<OtpGatewayConfig | null> {
  try {
    await ensureFirebaseAuth();
    const snap = await getDoc(doc(db, "config", "otpGateway"));
    if (!snap.exists()) return null;
    const data = snap.data() as Record<string, unknown>;
    const username = typeof data.username === "string" ? data.username.trim() : "";
    const password = typeof data.password === "string" ? data.password : "";
    if (!username || !password) return null;
    return { username, password };
  } catch {
    return null;
  }
}

export async function saveOtpGatewayConfig(config: OtpGatewayConfig): Promise<void> {
  await ensureFirebaseAuth();
  await setDoc(doc(db, "config", "otpGateway"), {
    username: config.username.trim(),
    password: config.password,
    updatedAt: Timestamp.fromMillis(Date.now()),
  }, { merge: true });
}

export type OtpRequestResult =
  | { ok: true }
  | { ok: false; reason: "invalid-phone" | "not-configured" | "rate-limited" | "cooldown" | "gateway-failed" };

export type OtpVerifyResult =
  | { ok: true }
  | { ok: false; reason: "no-request" | "expired" | "wrong-code" | "too-many-attempts" };

const OTP_EXPIRY_MS = 5 * 60 * 1000;
const OTP_RESEND_COOLDOWN_MS = 30 * 1000;
const OTP_MAX_PER_HOUR = 3;
const OTP_MAX_ATTEMPTS = 5;

/** Normalize to E.164: digits with a leading +, default country +92. */
export function normalizePhoneE164(raw: string): string | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;
  let digits = trimmed.replace(/[^\d+]/g, "");
  if (digits.startsWith("00")) digits = `+${digits.slice(2)}`;
  if (!digits.startsWith("+")) {
    if (digits.startsWith("0")) digits = digits.slice(1);
    digits = `+92${digits}`;
  }
  const allDigits = digits.slice(1);
  if (!/^\d{7,15}$/.test(allDigits)) return null;
  return `+${allDigits}`;
}

function otpDocId(phoneE164: string): string {
  return phoneE164.replace(/[^\d]/g, "");
}

function base64EncodeUtf8(value: string): string {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary);
}

/**
 * Generate a code, persist ONLY its hash, and send it through the SMS
 * gateway. Rate limit: max 3 requests per phone per rolling hour,
 * judged from the otp_requests doc's own timestamps (windowStartMs /
 * sendCount / lastSentAt survive resends because the doc is per-phone).
 */
export async function requestPhoneOtp(rawPhone: string): Promise<OtpRequestResult> {
  const phone = normalizePhoneE164(rawPhone);
  if (!phone) return { ok: false, reason: "invalid-phone" };
  const config = await fetchOtpGatewayConfig();
  if (!config) return { ok: false, reason: "not-configured" };
  await ensureFirebaseAuth();
  const ref = doc(db, "otp_requests", otpDocId(phone));
  const now = Date.now();
  let windowStartMs = now;
  let sendCount = 0;
  let lastSentAt = 0;
  try {
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const data = snap.data() as Record<string, unknown>;
      if (typeof data.windowStartMs === "number") windowStartMs = data.windowStartMs;
      if (typeof data.sendCount === "number") sendCount = data.sendCount;
      if (typeof data.lastSentAt === "number") lastSentAt = data.lastSentAt;
    }
  } catch { /* a fresh window is fine on read failure */ }
  if (now - windowStartMs >= 60 * 60 * 1000) { windowStartMs = now; sendCount = 0; }
  if (lastSentAt && now - lastSentAt < OTP_RESEND_COOLDOWN_MS) return { ok: false, reason: "cooldown" };
  if (sendCount >= OTP_MAX_PER_HOUR) return { ok: false, reason: "rate-limited" };

  const code = String(Math.floor(100000 + Math.random() * 900000));
  const codeHash = await hashFirebaseVoicePassword(code, phone);
  try {
    await setDoc(ref, {
      phone,
      codeHash,
      expiresAt: Timestamp.fromMillis(now + OTP_EXPIRY_MS),
      attempts: 0,
      windowStartMs,
      sendCount: sendCount + 1,
      lastSentAt: now,
      updatedAt: Timestamp.fromMillis(now),
    }, { merge: true });
  } catch {
    return { ok: false, reason: "gateway-failed" };
  }

  try {
    const response = await fetch("https://api.sms-gate.app/3rdparty/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${base64EncodeUtf8(`${config.username}:${config.password}`)}`,
      },
      body: JSON.stringify({
        message: `Easy Chat کا تصدیقی کوڈ: ${code} — یہ کوڈ 5 منٹ کے لیے کارآمد ہے، کسی کے ساتھ شیئر نہ کریں۔`,
        phoneNumbers: [phone],
      }),
    });
    if (!response.ok) throw new Error(`gateway-${response.status}`);
  } catch {
    // The code never left the building: remove the request so the user
    // is not locked into a cooldown for an SMS that was never sent.
    try { await deleteDoc(ref); } catch { /* best-effort cleanup */ }
    return { ok: false, reason: "gateway-failed" };
  }
  return { ok: true };
}

/**
 * Verify a code against the stored hash + expiry. On success the
 * otp_requests doc is deleted; the caller then loads or creates the
 * account bound to that phone number.
 */
export async function verifyPhoneOtp(rawPhone: string, code: string): Promise<OtpVerifyResult> {
  const phone = normalizePhoneE164(rawPhone);
  if (!phone) return { ok: false, reason: "no-request" };
  await ensureFirebaseAuth();
  const ref = doc(db, "otp_requests", otpDocId(phone));
  let data: Record<string, unknown>;
  try {
    const snap = await getDoc(ref);
    if (!snap.exists()) return { ok: false, reason: "no-request" };
    data = snap.data() as Record<string, unknown>;
  } catch {
    return { ok: false, reason: "no-request" };
  }
  const expiresAt = data.expiresAt;
  const expiresMs = expiresAt instanceof Timestamp ? expiresAt.toMillis() : (typeof expiresAt === "number" ? expiresAt : 0);
  if (!expiresMs || Date.now() > expiresMs) {
    try { await deleteDoc(ref); } catch { /* best-effort cleanup */ }
    return { ok: false, reason: "expired" };
  }
  const attempts = typeof data.attempts === "number" ? data.attempts : 0;
  if (attempts >= OTP_MAX_ATTEMPTS) return { ok: false, reason: "too-many-attempts" };
  const codeHash = typeof data.codeHash === "string" ? data.codeHash : "";
  const candidate = await hashFirebaseVoicePassword(code.trim(), phone);
  if (!codeHash || candidate !== codeHash) {
    try { await updateDoc(ref, { attempts: attempts + 1 }); } catch { /* counter is best-effort */ }
    return { ok: false, reason: "wrong-code" };
  }
  try { await deleteDoc(ref); } catch { /* a stale doc expires on its own */ }
  return { ok: true };
}

/** Load the Easy Chat profile bound to a verified phone number, if any. */
export async function fetchFirebaseProfileByPhone(rawPhone: string): Promise<FirebaseContact | null> {
  const phone = normalizePhoneE164(rawPhone);
  if (!phone) return null;
  return lookupFirebaseProfile(phone);
}
