import { useEffect, useSyncExternalStore } from "react";

/* Font system for Easy Chat.
 *
 * Two catalogues share one loader:
 *  - STATUS_FONTS (~46) for the text-status editor.
 *  - APP_FONTS (12) for the app-wide Settings → Font choice.
 *
 * A core set is "built-in": those families ship with the OS / WebView
 * (Noto Nastaliq Urdu, Noto Naskh Arabic and the generic stacks), so
 * they apply instantly with no download. Every other font is fetched
 * from Google Fonts the first time it is selected: the CSS is parsed,
 * the woff2 files are downloaded and stored in IndexedDB, and on every
 * later launch the font is re-registered straight from that on-device
 * cache — instant, and it works offline. The chosen font id is all
 * that travels with a status / profile; a viewer's device runs the
 * exact same ensureFontLoaded() for it and falls back to the default
 * stack until the face is ready. */

export type FontDef = {
  id: string;
  /** Display name shown in pickers. */
  label: string;
  /** Short sample rendered in the picker, in the font itself. */
  sample: string;
  /** CSS font-family stack applied wherever this font is used. */
  stack: string;
  /** Google Fonts family name for downloadable fonts; null = built-in. */
  googleFamily: string | null;
};

const FALLBACK = `"Noto Naskh Arabic", "Noto Nastaliq Urdu", ui-sans-serif, system-ui, sans-serif`;

function builtin(id: string, label: string, sample: string, stack: string): FontDef {
  return { id, label, sample, stack, googleFamily: null };
}
function downloadable(id: string, label: string, sample: string, googleFamily: string): FontDef {
  return { id, label, sample, stack: `"${googleFamily}", ${FALLBACK}`, googleFamily };
}

export const BUILTIN_FONTS: FontDef[] = [
  builtin("default", "پہلے جیسا (Default)", "السلام علیکم", FALLBACK),
  builtin("nastaliq", "نستعلیق اردو", "السلام علیکم", `"Noto Nastaliq Urdu", "Noto Naskh Arabic", serif`),
  builtin("naskh", "نسخ عربی", "السلام عليكم", `"Noto Naskh Arabic", serif`),
  builtin("serif", "Serif", "Assalamu Alaikum", `Georgia, "Times New Roman", serif`),
  builtin("mono", "Mono", "Assalamu Alaikum", `ui-monospace, "Courier New", monospace`),
  builtin("cursive", "Cursive", "Assalamu Alaikum", `"Comic Sans MS", "Segoe Script", cursive`),
];

/** Downloadable fonts shared by both catalogues. */
const GOOGLE_FONTS: FontDef[] = [
  downloadable("gulzar", "گلزار (Nastaliq)", "السلام علیکم", "Gulzar"),
  downloadable("amiri", "امیری", "السلام عليكم", "Amiri"),
  downloadable("amiri-quran", "امیری قرآن", "بسم الله الرحمن الرحيم", "Amiri Quran"),
  downloadable("scheherazade", "شہرازاد", "السلام عليكم", "Scheherazade New"),
  downloadable("lateef", "لطیف", "السلام علیکم", "Lateef"),
  downloadable("aref-ruqaa", "عارف رقعہ", "السلام عليكم", "Aref Ruqaa"),
  downloadable("reem-kufi", "ریم کوفی", "السلام عليكم", "Reem Kufi"),
  downloadable("cairo", "قاہرہ", "السلام عليكم", "Cairo"),
  downloadable("tajawal", "تجوّل", "السلام عليكم", "Tajawal"),
  downloadable("almarai", "المرعی", "السلام عليكم", "Almarai"),
  downloadable("el-messiri", "المسیری", "السلام عليكم", "El Messiri"),
  downloadable("changa", "چنگا", "السلام عليكم", "Changa"),
  downloadable("markazi", "مرکزی", "السلام عليكم", "Markazi Text"),
  downloadable("harmattan", "ہرمتّن", "السلام عليكم", "Harmattan"),
  downloadable("mada", "مدا", "السلام عليكم", "Mada"),
  downloadable("rakkas", "رقّاص", "السلام عليكم", "Rakkas"),
  downloadable("katibeh", "کاتبہ", "السلام عليكم", "Katibeh"),
  downloadable("mirza", "میرزا", "السلام عليكم", "Mirza"),
  downloadable("lalezar", "لالہ زار", "السلام علیکم", "Lalezar"),
  downloadable("plex-arabic", "IBM عربی", "السلام عليكم", "IBM Plex Sans Arabic"),
  downloadable("lemonada", "لیمونادا", "السلام عليكم", "Lemonada"),
  downloadable("poppins", "Poppins", "Assalamu Alaikum", "Poppins"),
  downloadable("roboto", "Roboto", "Assalamu Alaikum", "Roboto"),
  downloadable("montserrat", "Montserrat", "Assalamu Alaikum", "Montserrat"),
  downloadable("oswald", "Oswald", "Assalamu Alaikum", "Oswald"),
  downloadable("bebas", "Bebas Neue", "Assalamu Alaikum", "Bebas Neue"),
  downloadable("playfair", "Playfair Display", "Assalamu Alaikum", "Playfair Display"),
  downloadable("lora", "Lora", "Assalamu Alaikum", "Lora"),
  downloadable("dancing", "Dancing Script", "Assalamu Alaikum", "Dancing Script"),
  downloadable("pacifico", "Pacifico", "Assalamu Alaikum", "Pacifico"),
  downloadable("rubik", "Rubik", "Assalamu Alaikum", "Rubik"),
  downloadable("quicksand", "Quicksand", "Assalamu Alaikum", "Quicksand"),
  downloadable("nunito", "Nunito", "Assalamu Alaikum", "Nunito"),
  downloadable("raleway", "Raleway", "Assalamu Alaikum", "Raleway"),
  downloadable("lobster", "Lobster", "Assalamu Alaikum", "Lobster"),
  downloadable("caveat", "Caveat", "Assalamu Alaikum", "Caveat"),
  downloadable("comfortaa", "Comfortaa", "Assalamu Alaikum", "Comfortaa"),
  downloadable("fredoka", "Fredoka", "Assalamu Alaikum", "Fredoka"),
  downloadable("righteous", "Righteous", "Assalamu Alaikum", "Righteous"),
  downloadable("cinzel", "Cinzel", "Assalamu Alaikum", "Cinzel"),
];

/** The text-status editor's catalogue: 6 built-in + 40 downloadable. */
export const STATUS_FONTS: FontDef[] = [...BUILTIN_FONTS, ...GOOGLE_FONTS];

const APP_DOWNLOADABLE_IDS = ["gulzar", "amiri", "cairo", "poppins", "rubik", "quicksand"];
/** Settings → Font catalogue: the 6 built-ins + 6 downloadable. */
export const APP_FONTS: FontDef[] = [...BUILTIN_FONTS, ...GOOGLE_FONTS.filter((font) => APP_DOWNLOADABLE_IDS.includes(font.id))];

const ALL_FONTS = new Map<string, FontDef>([...STATUS_FONTS].map((font) => [font.id, font]));

export function fontById(id: string | null | undefined): FontDef {
  return (id ? ALL_FONTS.get(id) : undefined) ?? BUILTIN_FONTS[0] as FontDef;
}
export function fontStack(id: string | null | undefined): string {
  return fontById(id).stack;
}

/* ------------------------------------------------------------------ */
/* IndexedDB cache: one record per Google family, holding every       */
/* subset blob (regular + bold where offered) with its descriptors.   */
/* ------------------------------------------------------------------ */

type CachedFace = { blob: Blob; style: string; weight: string; unicodeRange?: string };
const DB_NAME = "easy-chat-fonts-v1";
const STORE_NAME = "faces";

function openFontDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = window.indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => { request.result.createObjectStore(STORE_NAME); };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("font-db"));
  });
}
async function readCachedFaces(family: string): Promise<CachedFace[] | null> {
  try {
    const db = await openFontDb();
    return await new Promise<CachedFace[] | null>((resolve) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const request = tx.objectStore(STORE_NAME).get(family);
      request.onsuccess = () => resolve(Array.isArray(request.result) ? request.result as CachedFace[] : null);
      request.onerror = () => resolve(null);
      tx.oncomplete = () => db.close();
    });
  } catch { return null; }
}
async function writeCachedFaces(family: string, faces: CachedFace[]): Promise<void> {
  try {
    const db = await openFontDb();
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).put(faces, family);
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onerror = () => resolve();
    });
  } catch { /* cache is best-effort; the font still applies this session */ }
}

/* ------------------------------------------------------------------ */
/* Loader: cache-first, then Google Fonts. A version counter feeds    */
/* useSyncExternalStore so components re-render the moment a face     */
/* lands; until then they render with the fallback stack.             */
/* ------------------------------------------------------------------ */

const loadedFamilies = new Set<string>();
const inFlight = new Map<string, Promise<boolean>>();
let fontVersion = 0;
const fontListeners = new Set<() => void>();
function notifyFontChange() {
  fontVersion += 1;
  fontListeners.forEach((listener) => listener());
}
function subscribeFonts(listener: () => void) {
  fontListeners.add(listener);
  return () => { fontListeners.delete(listener); };
}
function fontSnapshot() { return fontVersion; }

async function registerFaces(family: string, faces: CachedFace[]): Promise<boolean> {
  let registered = false;
  for (const face of faces) {
    try {
      const url = URL.createObjectURL(face.blob);
      const fontFace = new FontFace(family, `url(${url})`, { style: face.style, weight: face.weight, ...(face.unicodeRange ? { unicodeRange: face.unicodeRange } : {}) });
      await fontFace.load();
      (document.fonts as unknown as { add: (fontFace: FontFace) => void }).add(fontFace);
      registered = true;
    } catch { /* one bad subset must not sink the rest */ }
  }
  return registered;
}

async function downloadFaces(family: string): Promise<CachedFace[] | null> {
  try {
    const cssUrl = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family)}:wght@400;700&display=swap`;
    const response = await fetch(cssUrl);
    if (!response.ok) return null;
    const css = await response.text();
    const blocks = css.match(/@font-face\s*{[^}]*}/g) ?? [];
    const faces: CachedFace[] = [];
    for (const block of blocks) {
      const src = /url\((https:[^)]+?\.woff2)\)/.exec(block)?.[1];
      if (!src) continue;
      const style = /font-style:\s*(\w+)/.exec(block)?.[1] ?? "normal";
      if (style !== "normal") continue;
      const weight = /font-weight:\s*(\d+)/.exec(block)?.[1] ?? "400";
      const unicodeRange = /unicode-range:\s*([^;]+);/.exec(block)?.[1]?.trim();
      const fileResponse = await fetch(src);
      if (!fileResponse.ok) continue;
      faces.push({ blob: await fileResponse.blob(), style, weight, ...(unicodeRange ? { unicodeRange } : {}) });
    }
    return faces.length > 0 ? faces : null;
  } catch { return null; }
}

/** Make a font usable on this device: instant for built-ins and for
 *  fonts already in the on-device cache; downloads and caches on
 *  first use. Resolves true when the face is ready to render. */
export function ensureFontLoaded(id: string | null | undefined): Promise<boolean> {
  const def = fontById(id);
  if (!def.googleFamily) return Promise.resolve(true);
  const family = def.googleFamily;
  if (loadedFamilies.has(family)) return Promise.resolve(true);
  const existing = inFlight.get(family);
  if (existing) return existing;
  const task = (async () => {
    const cached = await readCachedFaces(family);
    if (cached && cached.length > 0 && await registerFaces(family, cached)) {
      loadedFamilies.add(family);
      notifyFontChange();
      return true;
    }
    const downloaded = await downloadFaces(family);
    if (!downloaded) return false;
    await writeCachedFaces(family, downloaded);
    if (await registerFaces(family, downloaded)) {
      loadedFamilies.add(family);
      notifyFontChange();
      return true;
    }
    return false;
  })();
  inFlight.set(family, task);
  void task.finally(() => { if (inFlight.get(family) === task) inFlight.delete(family); });
  return task;
}

/** True when the font is ready to render on this device right now. */
export function isFontReady(id: string | null | undefined): boolean {
  const def = fontById(id);
  return !def.googleFamily || loadedFamilies.has(def.googleFamily);
}

/** React hook: triggers the (cached) load for a font id and re-renders
 *  when it becomes ready. Returns whether the face is ready. */
export function useFontReady(id: string | null | undefined): boolean {
  useSyncExternalStore(subscribeFonts, fontSnapshot, fontSnapshot);
  useEffect(() => { if (id) void ensureFontLoaded(id); }, [id]);
  return isFontReady(id);
}
