import { App as CapacitorApp } from "@capacitor/app";
import { isNativeApp } from "./nativeBiometric";

/* Native hardware back button (Capacitor App plugin).
 *
 * This is a SEPARATE channel from the web `popstate` routing in App.tsx.
 * On Android the phone's physical back button does not reliably travel
 * through the WebView history the way a browser back press does, so the
 * in-app guard-entry trick alone could still drop the user straight out
 * of the app from a full-screen page. Capacitor's App plugin instead
 * reports every hardware back press to the app through its `backButton`
 * event, and — once a listener is registered — the native shell no
 * longer applies its own default (leave the app) for that press; the
 * decision is entirely the app's:
 *
 *   - the callback returns true  → the press was consumed inside the
 *     app (a dialog closed, a full page stepped back to the Chats tab);
 *     the app stays open;
 *   - the callback returns false → nothing was open (the Chats tab at
 *     its root), so the app exits via `App.exitApp()`, exactly like
 *     WhatsApp does there.
 *
 * On the hosted web version there is no hardware button and no native
 * shell, so registration is a no-op and the popstate routing is used. */
export async function registerNativeBackButton(onHardwareBack: () => boolean): Promise<() => void> {
  if (!isNativeApp()) return () => undefined;
  try {
    const handle = await CapacitorApp.addListener("backButton", () => {
      let consumed = false;
      try {
        consumed = onHardwareBack();
      } catch {
        consumed = false;
      }
      if (!consumed) {
        void CapacitorApp.exitApp().catch(() => undefined);
      }
    });
    return () => {
      void handle.remove().catch(() => undefined);
    };
  } catch {
    /* App plugin unavailable in this build — the popstate routing in
       App.tsx remains the back-button path. */
    return () => undefined;
  }
}

/**
 * Native app lifecycle (Capacitor App plugin `appStateChange`).
 *
 * Presence depends on knowing the moment the app leaves the
 * foreground: Android can pause or kill the WebView without any web
 * event firing reliably (visibilitychange is inconsistent across
 * OEM WebViews when the app is swiped away), so the app registers
 * this native channel alongside the web ones — App.tsx treats every
 * channel idempotently, so whichever fires first wins and the rest
 * are no-ops. On the hosted web version there is no native shell and
 * registration is a no-op; the web events carry presence there.
 */
export async function registerAppLifecycle(onBackground: () => void, onForeground: () => void): Promise<() => void> {
  if (!isNativeApp()) return () => undefined;
  try {
    const handle = await CapacitorApp.addListener("appStateChange", ({ isActive }) => {
      try {
        if (isActive) onForeground();
        else onBackground();
      } catch {
        /* presence writes are best-effort — a callback failure must
           never take the lifecycle channel down with it */
      }
    });
    return () => {
      void handle.remove().catch(() => undefined);
    };
  } catch {
    /* App plugin unavailable in this build — the web lifecycle
       events in App.tsx remain the presence path. */
    return () => undefined;
  }
}
