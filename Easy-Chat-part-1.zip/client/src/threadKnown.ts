/* ===== Per-thread "this thread exists" record (on-device, durable) =====
 * The "This chat could not be found" screen may only ever be shown for a
 * thread that provably does not exist. A thread that has been listed in
 * the chat list, has delivered a snapshot, has messages queued in the
 * outbox, or has been explicitly verified against Firestore is recorded
 * here — in localStorage, so the record survives app restarts — and any
 * thread with a record here can never be treated as missing, no matter
 * what a listener error says. The record is written at RAW snapshot
 * receipt (before any async message mapping) and when a message is
 * queued or delivered, so the startup outbox flush can never strip a
 * thread's protection before its first snapshot lands. */

const KNOWN_THREADS_KEY = "easy-chat-known-threads-v1";
const MAX_KNOWN_THREADS = 300;

export type ThreadKnownRecord = {
  /** The thread has shown at least one message (snapshot or outbox). */
  messages: boolean;
  /** Epoch ms of the most recent confirmation. */
  at: number;
};

let cache: Record<string, ThreadKnownRecord> | null = null;

function load(): Record<string, ThreadKnownRecord> {
  if (cache) return cache;
  cache = {};
  try {
    const raw = window.localStorage.getItem(KNOWN_THREADS_KEY);
    if (raw) {
      const parsed: unknown = JSON.parse(raw);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        for (const [id, value] of Object.entries(parsed as Record<string, unknown>)) {
          if (value && typeof value === "object") {
            const record = value as { messages?: unknown; at?: unknown };
            cache[id] = { messages: record.messages === true, at: typeof record.at === "number" ? record.at : 0 };
          }
        }
      }
    }
  } catch { /* storage unavailable/corrupt — start empty rather than crash */ }
  return cache;
}

function persist() {
  if (!cache) return;
  try {
    const entries = Object.entries(cache).sort((a, b) => b[1].at - a[1].at).slice(0, MAX_KNOWN_THREADS);
    window.localStorage.setItem(KNOWN_THREADS_KEY, JSON.stringify(Object.fromEntries(entries)));
  } catch { /* storage full/unavailable — the in-memory record still protects this session */ }
}

/** Record that a thread exists. `hasMessages` is sticky: once a thread
 *  has shown messages, a later empty snapshot never un-marks it. */
export function markThreadKnown(threadId: string, hasMessages: boolean): void {
  if (!threadId) return;
  const records = load();
  const existing = records[threadId];
  const next: ThreadKnownRecord = { messages: hasMessages || existing?.messages === true, at: Date.now() };
  if (existing && existing.messages === next.messages && Date.now() - existing.at < 60_000) return;
  records[threadId] = next;
  persist();
}

/** True when this device has ever confirmed the thread exists. */
export function threadIsKnown(threadId: string): boolean {
  return Boolean(load()[threadId]);
}

/** True when the thread is recorded as having shown messages. */
export function threadKnownHasMessages(threadId: string): boolean {
  return load()[threadId]?.messages === true;
}

/** Forget a thread (used when the user deletes the chat for good). */
export function forgetThread(threadId: string): void {
  const records = load();
  if (!(threadId in records)) return;
  delete records[threadId];
  persist();
}
